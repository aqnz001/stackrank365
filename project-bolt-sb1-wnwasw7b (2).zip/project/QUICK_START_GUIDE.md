# Quick Start: Making Post-Interview Decisions

## Where to Find Everything

### 1. Interviews Tab Location
```
Employer Dashboard → Interviews Tab (top navigation)
```

### 2. Visual Indicators You'll See

#### Orange Alert Banner (Top of Page)
```
⚠️ 3 Interviews Awaiting Decision
You have completed interviews that need a hiring decision.
Click "Make Decision" to accept, reject, or extend an offer.
```
- Shows up when you have interviews needing decisions
- Tells you exactly how many interviews are waiting

#### Interview List Table
```
+---------------------+------------------+------------+-----------------+
| When                | Job              | Status     | Actions         |
+---------------------+------------------+------------+-----------------+
| Jan 10, 2025 2:00PM | Senior Engineer  | completed  | [Make Decision] |
| [Decision Pending]  | Jane Smith       |            | (green button)  |
+---------------------+------------------+------------+-----------------+
```
- **"Decision Pending"** orange badge appears next to the date
- Candidate name shows below the job title
- **Green "Make Decision"** button instead of blue "View"

### 3. The Interview Workflow

#### When Interview is NEW:
```
[Scheduled] → Click "Mark Complete" after interview
```

#### After Marking Complete:
```
[Completed] → Click "Add Feedback" button appears
```

#### After Adding Feedback:
```
[Completed with Feedback] → Click "Make Decision" button appears (GREEN)
```

### 4. The Decision Modal

When you click "Make Decision", you'll see:

```
┌─────────────────────────────────────────────┐
│ Post-Interview Decision                  [X]│
├─────────────────────────────────────────────┤
│                                             │
│ 📋 Interview Summary                        │
│ ├─ Position: Senior Engineer               │
│ ├─ Interview Date: Jan 10, 2025            │
│ ├─ Interview Type: Video                   │
│ ├─ Rating: 4/5                             │
│ └─ Recommendation: Recommend for hire      │
│                                             │
│ Select Your Decision:                       │
│                                             │
│ ┌─────────┐  ┌─────────────┐  ┌─────────┐ │
│ │    ✓    │  │      📨      │  │    ✗    │ │
│ │ Accept  │  │ Extend Offer │  │ Reject  │ │
│ │         │  │              │  │         │ │
│ └─────────┘  └─────────────┘  └─────────┘ │
│                                             │
│ Decision Notes: *                           │
│ ┌─────────────────────────────────────────┐│
│ │ [Write your reasoning here...]          ││
│ │                                         ││
│ └─────────────────────────────────────────┘│
│                                             │
│ ⚠️ Important Note:                          │
│ Candidate will be notified of decision     │
│                                             │
│              [Cancel] [Confirm Decision]    │
└─────────────────────────────────────────────┘
```

### 5. Button Colors & Meanings

| Button | Color | Meaning |
|--------|-------|---------|
| **Mark Complete** | Purple | Interview finished, ready for feedback |
| **Add Feedback** | Blue | Provide rating & notes |
| **Make Decision** | Green | Ready to accept/reject/offer |
| **View** | Blue | Just viewing, no actions needed |

### 6. Quick Action Flow

**The Complete Process:**
```
Step 1: Conduct Interview (offline)
   ↓
Step 2: Dashboard → Interviews Tab
   ↓
Step 3: Find interview → Click "Mark Complete"
   ↓
Step 4: Click "Add Feedback"
   ↓
Step 5: Fill rating, recommendation, notes → Submit
   ↓
Step 6: Click "Make Decision" (green button now appears)
   ↓
Step 7: Select Accept/Offer/Reject
   ↓
Step 8: Write decision notes
   ↓
Step 9: Click "Confirm Decision"
   ↓
Step 10: Done! ✓ Candidate notified automatically
```

### 7. Decision Note Templates

**Quick Copy-Paste Templates:**

**For Accept:**
```
Strong performance in technical assessment. Demonstrated proficiency
in [specific skills]. Good cultural fit. Recommend proceeding to
[next step]. Salary range discussed: $[amount].
```

**For Extend Offer:**
```
Offering [Position] at $[salary] annually. Start date: [date].
Benefits: [list]. Formal offer letter being prepared by HR.
Candidate verbally accepted during interview.
```

**For Reject:**
```
Thank you for interviewing. After careful consideration, we've
decided to proceed with candidates whose [specific requirement]
more closely matches our needs. We appreciate your time.
```

### 8. Keyboard Shortcuts

- `Esc` - Close any modal
- `Tab` - Navigate between fields
- `Enter` - Submit forms (when in text fields)

### 9. What If I Made a Mistake?

**Before Clicking "Confirm Decision":**
- Click "Cancel" and start over
- Edit your notes before confirming

**After Confirming:**
- Decision is recorded permanently
- Contact administrator to reverse
- Document why decision needs changing

### 10. Troubleshooting Checklist

**"Make Decision" button not showing?**
- ✓ Interview status = "completed"
- ✓ Feedback has been added
- ✓ Rating selected (1-5 stars)
- ✓ Recommendation chosen
- ✓ Page has been refreshed

**Can't submit decision?**
- ✓ Decision type selected (Accept/Offer/Reject)
- ✓ Decision notes filled in (required)
- ✓ Internet connection active
- ✓ Not timed out (refresh if needed)

### 11. Admin View

**To see all your past decisions:**
```
Dashboard → Applications Tab → Filter by status
```

**Decision appears in application details:**
- Decision made: [type]
- Notes: [your notes]
- Made by: [your name]
- Made on: [date/time]

---

## Need More Details?

- Full workflow guide: `POST_INTERVIEW_DECISION_WORKFLOW.md`
- Usage instructions: `USING_POST_INTERVIEW_DECISIONS.md`
- Contact support if you need help

## Summary

**You'll know interviews need decisions when you see:**
1. ⚠️ Orange banner at top
2. 🟠 "Decision Pending" badges
3. 🟢 Green "Make Decision" buttons

**Complete workflow in 10 clicks:**
Mark Complete → Add Feedback → Make Decision → Select Type → Write Notes → Confirm

That's it! The system handles notifications and status updates automatically.
