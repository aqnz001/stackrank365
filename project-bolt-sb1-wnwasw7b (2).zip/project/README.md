# JobBoard Pro - Complete Recruitment Platform

A comprehensive job board and recruiter marketplace platform built with React, TypeScript, Supabase, and Stripe.

## Features

### For Employers
- **Job Posting & Management** - Post jobs with different ad tiers (Basic, Standard, Premium)
- **Application Management** - Review and manage candidate applications
- **Recruiter Marketplace** - Accept bids from professional recruiters
- **Interview Scheduling** - Schedule and manage interviews with candidates
- **Payment & Billing** - Subscription-based pricing with usage tracking
- **Analytics & Reporting** - Comprehensive job performance analytics
- **Workflow Automation** - Automate hiring processes with custom workflows

### For Recruiters
- **Job Discovery** - Browse open jobs and submit competitive bids
- **Candidate Representation** - Request consent to represent candidates
- **Bid Management** - Track bid status and manage client relationships
- **Escrow Protection** - Secure payment processing with guarantee periods
- **Performance Tracking** - Monitor placement success and earnings

### For Candidates
- **Job Search** - Advanced search with filters and recommendations
- **Application Tracking** - Monitor application status and progress
- **Consent Management** - Control recruiter representation requests
- **Profile Management** - Maintain professional profile and preferences
- **Personalized Recommendations** - AI-powered job matching

### For Administrators
- **User Management** - Manage platform users and permissions
- **Analytics Dashboard** - Platform-wide metrics and insights
- **Audit Logging** - Track all administrative actions
- **Feature Flags** - Control feature rollouts and A/B testing
- **Dispute Resolution** - Handle payment and service disputes

## Technology Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Backend**: Supabase (PostgreSQL, Auth, Storage, Edge Functions)
- **Payments**: Stripe (Subscriptions, One-time payments, Escrow)
- **Real-time**: Supabase Realtime for live updates
- **File Storage**: Supabase Storage for resumes and documents
- **Performance**: PWA support, offline functionality, caching

## Payment System

The platform includes a complete payment infrastructure:

### Subscription Plans
- **Basic Plan** ($299/month) - Up to 5 job posts, direct applications only
- **Standard Plan** ($599/month) - Up to 20 job posts, recruiter marketplace access
- **Premium Plan** ($999/month) - Unlimited posts, full marketplace access

### Payment Features
- Secure payment processing with Stripe
- Subscription management and billing
- Escrow transactions for recruiter payments
- Usage tracking and limits enforcement
- Invoice generation and payment history

### Edge Functions
- `stripe-webhooks` - Handle Stripe webhook events
- `create-payment-intent` - Process one-time payments
- `create-subscription` - Manage subscription creation
- `manage-payment-methods` - Add/remove payment methods
- `manage-escrow` - Handle escrow transactions

## Getting Started

### Prerequisites
- Node.js 18+ 
- Supabase account
- Stripe account (for payments)

### Environment Setup

1. Copy the environment template:
```bash
cp .env.example .env
```

2. Configure your environment variables:
```env
# Supabase Configuration
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key

# Stripe Configuration  
VITE_STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
```

### Database Setup

1. Run the migrations in your Supabase dashboard:
```sql
-- Apply all migration files in supabase/migrations/ directory
-- These set up the complete database schema with RLS policies
```

2. Set up Stripe webhook endpoint in your Stripe dashboard:
```
Endpoint URL: https://your-project.supabase.co/functions/v1/stripe-webhooks
Events: payment_intent.succeeded, customer.subscription.updated, invoice.payment_succeeded
```

### Installation

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

## Architecture

### Database Schema
- **Users & Organizations** - Multi-tenant user management
- **Jobs & Applications** - Job posting and application tracking  
- **Recruiter Marketplace** - Bid system with consent management
- **Payment System** - Billing, subscriptions, and escrow
- **Workflow Engine** - Automated process management
- **Analytics & Audit** - Comprehensive tracking and reporting

### Security Features
- Row Level Security (RLS) on all tables
- JWT-based authentication with Supabase Auth
- Secure file uploads with access controls
- Payment data encryption with Stripe
- Audit logging for all administrative actions

### Performance Optimizations
- Progressive Web App (PWA) support
- Offline functionality with background sync
- Image optimization and lazy loading
- Virtual scrolling for large lists
- Code splitting and lazy loading
- Service worker caching

## Mobile Support

The platform is fully responsive and includes:
- Touch-optimized interface
- Swipe gestures for actions
- Pull-to-refresh functionality
- Mobile navigation patterns
- Offline support with sync

## Development

### Key Hooks
- `useJobs` - Job management and CRUD operations
- `useApplications` - Application tracking and status updates
- `useRecruiterBids` - Bid submission and management
- `usePayments` - Payment processing and subscription management
- `useWorkflows` - Workflow automation and templates
- `useNotifications` - Real-time notifications

### Component Structure
- `Dashboard/` - Role-specific dashboard components
- `Jobs/` - Job posting, editing, and search components
- `Applications/` - Application management and forms
- `Payments/` - Stripe integration and billing components
- `Admin/` - Administrative tools and analytics
- `Mobile/` - Mobile-specific UI components

## Deployment

The application is configured for deployment on:
- **Frontend**: Bolt Hosting (or any static hosting)
- **Backend**: Supabase (managed PostgreSQL + Edge Functions)
- **Payments**: Stripe (PCI-compliant payment processing)

## License

This project is proprietary software. All rights reserved.