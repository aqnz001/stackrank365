# Changelog

All notable changes to this project will be documented in this file.

## v0.2.0 — 2025-09-07

- Public jobs for guests: fetch and show only `visibility: open` and `status: open` jobs for unauthenticated visitors.
- Job details modal: new `JobDetails` component to display full job information (title, company, location, type, salary, description, skills, benefits).
- Auth modal wrapper: new `AuthScreen` modal using existing `LoginForm` to handle sign in / sign up.
- Gated actions: Apply button now prompts authentication for guests; authenticated users keep the Apply flow.
- UI wiring: integrated View Details + gated Apply into `SearchLayoutPage`; extended `JobCard` with `onViewDetails` action.
- Home UI parity: hero styling and exact filters (Classification, Where, What, SEEK button), plus advanced filters (Work type, Salary Min/Max, Posted within, Remote/Hybrid).
- Tailwind tokens/utilities: primary/secondary/success/warning/error palettes; component utilities (btn-primary, card, input, text-gradient).
- Job post flow: `JobPostForm` reworked to 2-step flow (Details; Location & Pricing), with industries, experience level, benefits, and Save as Draft.
- Remote/hybrid mapping: treat remote/hybrid by matching `location` (ilike `%remote%` or `%hybrid%`).

Impacted files:
- `src/hooks/useJobs.ts`
- `src/components/Jobs/JobCard.tsx`
- `src/components/Jobs/JobDetails.tsx`
- `src/components/Auth/AuthScreen.tsx`
- `src/components/Home/SearchLayoutPage.tsx`

Notes:
- App still routes guests to `SearchLayoutPage` and authenticated users to dashboards.
- Consider adding a Quick Apply modal for authenticated users on the public page in a follow-up.
