# Post-Interview Decision Workflow

This document explains how employers can make hiring decisions after completing interviews with candidates.

## Overview

The post-interview decision workflow allows employers to:
- Review completed interviews and their feedback
- Make formal decisions (Accept, Reject, or Extend Offer)
- Document decision notes for audit purposes
- Automatically notify candidates of decisions
- Update application status based on decisions
- Trigger payment milestones for recruiter-sourced candidates

## Workflow Steps

### 1. Complete the Interview

First, conduct the interview with the candidate and complete these steps in the system:

1. Navigate to the **Interviews** section in your employer dashboard
2. Find the scheduled interview
3. After the interview is completed, click **Mark Complete**
4. Click **Add Feedback** to provide your interview assessment

### 2. Add Interview Feedback

When adding feedback, you'll need to provide:

- **Overall Rating**: 1-5 stars rating of the candidate's performance
- **Recommendation**: Choose from:
  - **Proceed to next round**: Candidate should advance to another interview
  - **Recommend for hire**: Strong candidate, ready to make an offer
  - **Do not proceed**: Candidate is not suitable for this role
  - **Need more information**: Undecided, requires further evaluation
- **Notes**: Detailed feedback about the interview (strengths, concerns, observations)

This feedback is stored with the interview record and helps inform your final decision.

### 3. Make Your Final Decision

After adding feedback, a **Make Decision** button will appear on the completed interview card.

Click this button to open the **Post-Interview Decision Modal** where you can:

#### Decision Options:

1. **Accept**
   - Moves the candidate forward in the hiring process
   - Updates application status to "shortlisted"
   - Indicates you want to proceed with this candidate
   - Candidate receives acceptance notification

2. **Extend Offer**
   - Formally offers the position to the candidate
   - Updates application status to "hired"
   - Triggers payment milestones (for recruiter-sourced candidates)
   - Candidate receives job offer notification
   - Use this when you're ready to make a formal job offer

3. **Reject**
   - Removes candidate from consideration
   - Updates application status to "rejected"
   - Candidate receives professional rejection notification
   - Documents reasons for rejection

#### Required Information:

For any decision, you must provide:
- **Decision Notes**: Detailed explanation of your decision
  - For acceptance: Why this candidate is a good fit
  - For offer: Salary, start date, and offer details
  - For rejection: Specific reasons (skills gap, experience mismatch, etc.)

### 4. Decision Confirmation

Before submitting, the modal will show:
- Interview summary (date, type, rating)
- Interviewer's recommendation from feedback
- Impact statement explaining what will happen
- Warning about notifications to be sent

Review all information carefully, then click **Confirm Decision**.

## What Happens After Your Decision

### System Actions:

1. **Database Updates**:
   - Application status is updated
   - Decision and notes are recorded
   - Timestamp and decision maker are logged

2. **Notifications**:
   - Candidate receives automatic notification
   - Email may be sent (depending on configuration)
   - Notification appears in candidate's dashboard

3. **Workflow Triggers**:
   - Automated workflows are triggered
   - For accepted/hired: May trigger next steps in hiring process
   - For rejected: Application moves to archived/closed state

4. **Payment Processing** (Recruiter-Sourced Only):
   - When extending an offer to a recruiter-sourced candidate
   - Payment milestone is automatically triggered
   - Recruiter fee processing begins
   - Escrow funds are scheduled for release

## Best Practices

### Decision Notes Guidelines:

**For Acceptance**:
```
Strong technical skills demonstrated during the coding challenge.
Good culture fit with team values. Relevant experience in React
and Node.js. Communication skills excellent. Recommending for
offer discussion with salary range $90k-$100k.
```

**For Offer Extended**:
```
Offering Software Engineer position at $95,000 annual salary.
Start date: January 15, 2025. Benefits package includes health
insurance, 401k match, and 3 weeks PTO. Formal offer letter
being sent via email.
```

**For Rejection**:
```
Candidate showed good enthusiasm but lacks the required 5+ years
experience in distributed systems. Technical assessment revealed
gaps in microservices architecture knowledge. Team needs someone
who can hit the ground running. Better fit for mid-level role.
```

### Tips:

1. **Be Timely**: Make decisions within 2-3 days of the interview
2. **Be Specific**: Provide detailed notes for audit and legal purposes
3. **Be Professional**: Remember candidates will be notified
4. **Document Everything**: Your notes become part of the hiring record
5. **Review Feedback First**: Always review interview feedback before deciding

## Viewing Decision History

To view past decisions:

1. Navigate to **Applications** tab in your dashboard
2. Filter by status (accepted, rejected, hired)
3. Click on any application to view decision details
4. Decision notes and timestamp are visible in the application details

## Troubleshooting

### "Make Decision" Button Not Appearing?

- Ensure the interview status is "completed"
- Verify that interview feedback has been added
- Check that the application's decision status is "pending"
- Refresh the page to reload latest data

### Decision Failed to Submit?

- Check your internet connection
- Ensure decision notes are filled in
- Verify you have employer permissions
- Try logging out and back in

### Candidate Not Receiving Notification?

- Verify candidate's email address in their profile
- Check notification settings in platform settings
- Look in spam/junk folders
- Contact platform administrator if issue persists

## Technical Details

### Database Schema

The decision is tracked in the `applications` table with these fields:
- `interview_decision`: enum ('pending', 'accepted', 'rejected', 'offer_extended')
- `decision_notes`: text field containing your notes
- `decision_made_at`: timestamp when decision was made
- `decision_made_by`: ID of the employer who made the decision

### API Endpoint

The decision is processed through the `updateApplicationWithDecision` function which:
- Validates user permissions
- Updates application record
- Creates notifications
- Triggers workflows
- Processes payment milestones

## Support

For additional help with the post-interview decision workflow:
- Contact your platform administrator
- Review the employer onboarding guide
- Check the FAQ section
- Submit a support ticket through the help center
