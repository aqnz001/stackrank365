export interface User {
  id: string;
  email: string;
  name: string;
  role: 'employer' | 'recruiter' | 'candidate' | 'admin';
  organizationId?: string;
  profilePhotoUrl?: string;
  status: 'active' | 'inactive' | 'pending';
  kycStatus?: 'pending' | 'verified' | 'rejected';
  createdAt: Date;
}

export interface Organization {
  id: string;
  name: string;
  type: 'employer' | 'recruiter';
  status: 'active' | 'inactive';
  billingAccountId?: string;
}

export interface Job {
  id: string;
  organizationId: string;
  organizationName: string;
  organizationSize?: 'startup' | 'small' | 'medium' | 'large';
  title: string;
  description: string;
  location: string;
  salaryRange?: { min: number; max: number };
  employmentType: 'full-time' | 'part-time' | 'contract' | 'temporary';
  experienceLevel?: 'entry' | 'mid' | 'senior' | 'lead' | string;
  skills: string[];
  industry?: string[];
  benefits?: string[];
  visibility: 'closed' | 'open';
  adTier: 'basic' | 'standard' | 'premium';
  bidLimit?: number;
  blockedRecruiterIds: string[];
  status: 'open' | 'closed' | 'on_hold' | 'filled' | 'draft';
  createdAt: Date;
  applications?: Application[];
  recruiterBids?: RecruiterBid[];
}

export interface Application {
  id: string;
  jobId: string;
  candidateId: string;
  candidateName: string;
  candidateEmail: string;
  source: 'direct' | 'recruiter';
  status: 'submitted' | 'shortlisted' | 'rejected' | 'hired' | 'withdrawn';
  recruiterBidId?: string;
  resumeUrl?: string;
  resumeFileName?: string;
  coverLetter?: string;
  phone?: string;
  location?: string;
  salaryExpectation?: number;
  availabilityDate?: Date;
  workAuthorization?: string;
  willingToRelocate?: boolean;
  additionalInfo?: string;
  interviewDecision?: 'pending' | 'accepted' | 'rejected' | 'offer_extended';
  decisionNotes?: string;
  decisionMadeAt?: Date;
  decisionMadeBy?: string;
  shortlist_notes?: string;
  shortlisted_at?: Date;
  shortlisted_by?: string;
  createdAt: Date;
}

export interface FileUpload {
  id: string;
  userId: string;
  organizationId?: string;
  bucketName: string;
  filePath: string;
  fileName: string;
  fileSize: number;
  mimeType: string;
  fileType: 'resume' | 'profile_photo' | 'company_logo' | 'document';
  isActive: boolean;
  metadata: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface RecruiterBid {
  id: string;
  jobId: string;
  recruiterId: string;
  recruiterName: string;
  recruiterCompany: string;
  candidateStub: CandidateStub;
  feeType: 'flat' | 'percent';
  feeValue: number;
  guaranteeDays: number;
  status: 'submitted' | 'shortlisted' | 'accepted' | 'rejected' | 'withdrawn' | 'expired';
  revealedCandidate?: RevealedCandidate;
  createdAt: Date;
  acceptedAt?: Date;
}

export interface RevealedCandidate {
  id: string;
  name: string;
  email: string;
  phone?: string;
  resume?: string;
}

export interface CandidateStub {
  id: string;
  skills: string[];
  experienceYears: number;
  industry: string;
  highlights: string[];
  locationZone: string;
  salaryExpectation?: number;
  noticePeriod?: string;
}

export interface Consent {
  id: string;
  candidateId: string;
  candidateName?: string;
  candidateEmail?: string;
  recruiterId: string;
  jobId: string;
  jobTitle: string;
  recruiterName: string;
  recruiterCompany: string;
  message?: string; // may include embedded policies payload marker
  status: 'requested' | 'approved' | 'declined' | 'revoked' | 'blocked';
  requestedAt: Date;
  respondedAt?: Date;
}

export interface Candidate {
  id: string;
  name: string;
  email: string;
  phone?: string;
  location: string;
  skills: string[];
  experienceYears: number;
  industry: string;
  resume?: string;
  bio?: string;
  allowRecruiterRequests: boolean;
  applications: Application[];
  consents: Consent[];
}

export interface EscrowTransaction {
  id: string;
  recruiterBidId: string;
  amount: number;
  status: 'initiated' | 'authorized' | 'captured' | 'released' | 'refunded' | 'disputed';
  platformCommission: number;
  guaranteeEndsAt: Date;
  createdAt: Date;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'application_received' | 'application_status_changed' | 'bid_submitted' | 'bid_accepted' | 'bid_rejected' | 'consent_requested' | 'consent_approved' | 'job_posted' | 'payment_received' | 'system_announcement';
  title: string;
  message: string;
  data: any;
  read: boolean;
  createdAt: Date;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  recipientId: string;
  content: string;
  messageType: 'text' | 'file' | 'system';
  read: boolean;
  createdAt: Date;
  senderName?: string;
  recipientName?: string;
}

export interface Conversation {
  id: string;
  participants: string[];
  jobId?: string;
  lastMessageAt: Date;
  createdAt: Date;
  jobTitle?: string;
  participantNames?: string[];
  lastMessage?: Message;
  unreadCount?: number;
}

export interface PlatformSetting {
  id: string;
  key: string;
  value: any;
  description?: string;
  category: string;
  isPublic: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface FeatureFlag {
  id: string;
  name: string;
  description?: string;
  isEnabled: boolean;
  rolloutPercentage: number;
  targetRoles: string[];
  targetOrganizations: string[];
  metadata: any;
  createdAt: Date;
  updatedAt: Date;
}

export interface AuditLogEntry {
  id: string;
  userId: string;
  userName?: string;
  action: string;
  entityType: string;
  entityId?: string;
  oldValues?: any;
  newValues?: any;
  ipAddress?: string;
  userAgent?: string;
  createdAt: Date;
}

export interface Activity {
  id: string;
  userId: string;
  actorId: string;
  actionType: 'created' | 'updated' | 'applied' | 'submitted_bid' | 'accepted_bid' | 'approved_consent';
  entityType: 'job' | 'application' | 'bid' | 'consent';
  entityId: string;
  data: any;
  createdAt: Date;
  actorName?: string;
}

export interface SavedSearch {
  id: string;
  userId: string;
  name: string;
  searchCriteria: {
    query?: string;
    location?: string;
    employmentType?: string[];
    salaryMin?: number;
    salaryMax?: number;
    skills?: string[];
    adTier?: string[];
    visibility?: string[];
    status?: string[];
  };
  emailAlerts: boolean;
  alertFrequency: 'immediate' | 'daily' | 'weekly';
  lastAlertSent?: Date;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface JobRecommendation {
  id: string;
  candidateId: string;
  jobId: string;
  job?: Job;
  matchScore: number;
  matchReasons: {
    skillMatch?: string[];
    locationMatch?: string;
    salaryMatch?: string;
    experienceMatch?: string;
    industryMatch?: string;
  };
  skillMatchScore: number;
  locationMatchScore: number;
  salaryMatchScore: number;
  experienceMatchScore: number;
  isViewed: boolean;
  isDismissed: boolean;
  createdAt: Date;
}

export interface MatchingPreferences {
  id: string;
  userId: string;
  skillWeight: number;
  locationWeight: number;
  salaryWeight: number;
  experienceWeight: number;
  industryWeight: number;
  maxCommuteDistance: number;
  remoteWorkPreference: 'required' | 'preferred' | 'flexible' | 'no';
  salaryFlexibility: number;
  notificationFrequency: 'immediate' | 'daily' | 'weekly' | 'never';
  createdAt: Date;
  updatedAt: Date;
}

export interface Interview {
  id: string;
  applicationId?: string;
  recruiterBidId?: string;
  interviewerId: string;
  candidateId: string;
  interviewType: 'phone' | 'video' | 'in_person' | 'technical' | 'panel';
  status: 'scheduled' | 'confirmed' | 'rescheduled' | 'completed' | 'cancelled' | 'no_show';
  scheduledAt: Date;
  durationMinutes: number;
  location?: string;
  meetingLink?: string;
  meetingId?: string;
  notes?: string;
  feedback: any;
  reminderSent: boolean;
  calendarEventId?: string;
  createdAt: Date;
  updatedAt: Date;
  candidateName?: string;
  interviewerName?: string;
  jobTitle?: string;
}

export interface DocumentShare {
  id: string;
  ownerId: string;
  sharedWithId: string;
  fileUploadId: string;
  applicationId?: string;
  recruiterBidId?: string;
  accessLevel: 'view' | 'download' | 'edit';
  expiresAt?: Date;
  passwordProtected: boolean;
  accessPassword?: string;
  downloadCount: number;
  lastAccessedAt?: Date;
  isActive: boolean;
  createdAt: Date;
  fileName?: string;
  fileSize?: number;
  sharedWithName?: string;
  ownerName?: string;
}

export interface WorkflowTemplate {
  id: string;
  name: string;
  description?: string;
  category: 'hiring' | 'onboarding' | 'recruitment' | 'compliance';
  triggerEvent: 'application_received' | 'bid_accepted' | 'interview_scheduled' | 'offer_made';
  steps: WorkflowStepTemplate[];
  isActive: boolean;
  organizationId: string;
  createdBy?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface WorkflowStepTemplate {
  stepNumber: number;
  name: string;
  type: 'email' | 'notification' | 'task' | 'delay' | 'condition' | 'approval';
  config: any;
  assignedRole?: string;
  delayDays?: number;
  conditions?: any;
}

export interface WorkflowInstance {
  id: string;
  templateId: string;
  entityType: 'application' | 'recruiter_bid' | 'interview';
  entityId: string;
  status: 'active' | 'completed' | 'paused' | 'cancelled';
  currentStep: number;
  contextData: any;
  startedAt: Date;
  completedAt?: Date;
  createdAt: Date;
  template?: WorkflowTemplate;
  steps?: WorkflowStep[];
}

export interface WorkflowStep {
  id: string;
  workflowInstanceId: string;
  stepNumber: number;
  stepName: string;
  stepType: 'email' | 'notification' | 'task' | 'delay' | 'condition' | 'approval';
  status: 'pending' | 'in_progress' | 'completed' | 'skipped' | 'failed';
  assignedTo?: string;
  dueDate?: Date;
  completedAt?: Date;
  stepData: any;
  resultData: any;
  createdAt: Date;
  assignedToName?: string;
}

export interface StatusUpdate {
  id: string;
  entityType: 'application' | 'recruiter_bid' | 'interview' | 'job';
  entityId: string;
  oldStatus?: string;
  newStatus: string;
  changedBy?: string;
  changedByName?: string;
  reason?: string;
  notes?: string;
  metadata: any;
  createdAt: Date;
}

export interface PricingTier {
  name: 'basic' | 'standard' | 'premium';
  price: number;
  description: string;
  features: string[];
  bidLimit?: number;
}

export interface PaymentMilestone {
  name: string;
  trigger: string;
  percentage: number;
  description: string;
}

export interface PaymentSchedule {
  id: string;
  name: string;
  description?: string;
  milestones: PaymentMilestone[];
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface ScheduledPayment {
  id: string;
  recruiterBidId: string;
  escrowTransactionId?: string;
  milestoneName: string;
  milestoneTrigger: string;
  amount: number;
  percentage: number;
  status: 'pending' | 'triggered' | 'released' | 'failed';
  triggerDate?: Date;
  releaseDate?: Date;
  sequenceOrder: number;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface CandidateSelection {
  id: string;
  jobId: string;
  applicationId: string;
  recruiterBidId?: string;
  selectedBy: string;
  offerExtendedDate?: Date;
  startDate?: Date;
  onboardingStatus: 'offer_extended' | 'offer_accepted' | 'onboarding' | 'active' | 'completed';
  onboardingNotes?: string;
  createdAt: Date;
  updatedAt: Date;
  candidateName?: string;
  jobTitle?: string;
}
