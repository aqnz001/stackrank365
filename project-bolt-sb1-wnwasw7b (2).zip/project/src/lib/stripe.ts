import { loadStripe, Stripe } from '@stripe/stripe-js';

const stripePublishableKey = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY;

if (!stripePublishableKey) {
  console.warn('Stripe publishable key not found. Payment features will be disabled.');
}

let stripePromise: Promise<Stripe | null> | null = null;

export const getStripe = () => {
  if (!stripePromise && stripePublishableKey) {
    stripePromise = loadStripe(stripePublishableKey);
  }
  return stripePromise || Promise.resolve(null);
};

// Stripe configuration
export const stripeConfig = {
  appearance: {
    theme: 'stripe' as const,
    variables: {
      colorPrimary: '#2563eb',
      colorBackground: '#ffffff',
      colorText: '#1f2937',
      colorDanger: '#ef4444',
      fontFamily: 'system-ui, sans-serif',
      spacingUnit: '4px',
      borderRadius: '8px',
    },
  },
  loader: 'auto' as const,
};

// Payment method types
export const paymentMethodTypes = {
  CARD: 'card',
  BANK_ACCOUNT: 'us_bank_account',
  DIGITAL_WALLET: 'digital_wallet',
} as const;

// Currency formatting
export const formatCurrency = (amount: number, currency = 'USD'): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
  }).format(amount / 100); // Convert from cents
};

// Stripe error handling
export const handleStripeError = (error: any): string => {
  switch (error.type) {
    case 'card_error':
      return error.message || 'Your card was declined.';
    case 'validation_error':
      return 'Please check your payment information and try again.';
    case 'api_connection_error':
      return 'Network error. Please check your connection and try again.';
    case 'api_error':
      return 'Payment processing error. Please try again.';
    case 'authentication_error':
      return 'Authentication error. Please refresh and try again.';
    case 'rate_limit_error':
      return 'Too many requests. Please wait a moment and try again.';
    default:
      return error.message || 'An unexpected error occurred.';
  }
};

// Subscription plan helpers
export const getSubscriptionFeatures = (planName: string): string[] => {
  const plans: Record<string, string[]> = {
    basic: [
      'Up to 5 job posts per month',
      'Direct applications only',
      'Basic analytics',
      'Email support',
      '1GB file storage',
    ],
    standard: [
      'Up to 20 job posts per month',
      'Recruiter marketplace access',
      'Up to 10 bids per job',
      'Advanced analytics',
      'Priority support',
      'Custom workflows',
      '5GB file storage',
    ],
    premium: [
      'Unlimited job posts',
      'Full recruiter marketplace',
      'Unlimited bids per job',
      'Premium analytics',
      'Dedicated support',
      'White-label options',
      'API access',
      '50GB file storage',
    ],
  };
  
  return plans[planName.toLowerCase()] || [];
};

// Calculate platform commission
export const calculatePlatformFee = (amount: number, feePercentage = 0.15): number => {
  return Math.round(amount * feePercentage);
};

// Validate payment amount
export const validatePaymentAmount = (amount: number): boolean => {
  return amount >= 50 && amount <= 99999999; // $0.50 to $999,999.99
};