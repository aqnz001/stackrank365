import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables. Please check your .env file.');
}

// Reuse the same client across HMR refreshes (Vite/Next dev)
const g = globalThis as unknown as { __sb?: SupabaseClient };

export const supabase: SupabaseClient =
  g.__sb ??
  (g.__sb = createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
  }));

// Updated database types based on current schema
export type Database = {
  public: {
    Enums: {
      user_status: 'active' | 'inactive' | 'pending';
      kyc_status: 'pending' | 'verified' | 'rejected';
      organization_type: 'employer' | 'recruiter';
      organization_status: 'active' | 'inactive';
      user_role: 'employer' | 'recruiter' | 'candidate' | 'admin';
      employment_type: 'full-time' | 'part-time' | 'contract' | 'temporary';
      job_visibility: 'closed' | 'open';
      ad_tier: 'basic' | 'standard' | 'premium';
      job_status: 'open' | 'closed' | 'on_hold' | 'filled';
      bid_fee_type: 'flat' | 'percent';
      bid_status: 'submitted' | 'accepted' | 'rejected' | 'withdrawn' | 'expired';
      consent_status: 'requested' | 'approved' | 'declined' | 'revoked';
      payment_status: 'pending' | 'processing' | 'succeeded' | 'failed' | 'canceled' | 'refunded';
      invoice_status: 'draft' | 'open' | 'paid' | 'void' | 'uncollectible';
      subscription_status: 'active' | 'canceled' | 'incomplete' | 'incomplete_expired' | 'past_due' | 'trialing' | 'unpaid';
      escrow_status: 'pending' | 'held' | 'released' | 'refunded' | 'disputed';
      notification_type: 'application_received' | 'application_status_changed' | 'bid_submitted' | 'bid_accepted' | 'bid_rejected' | 'consent_requested' | 'consent_approved' | 'job_posted' | 'payment_received' | 'system_announcement';
      message_type: 'text' | 'file' | 'system';
      activity_action: 'created' | 'updated' | 'deleted' | 'applied' | 'submitted_bid' | 'accepted_bid' | 'rejected_bid' | 'approved_consent' | 'declined_consent';
      activity_entity: 'job' | 'application' | 'bid' | 'consent' | 'payment';
      interview_type: 'phone' | 'video' | 'in_person' | 'technical' | 'panel';
      interview_status: 'scheduled' | 'confirmed' | 'rescheduled' | 'completed' | 'cancelled' | 'no_show';
      document_access_level: 'view' | 'download' | 'edit';
      workflow_category: 'hiring' | 'onboarding' | 'recruitment' | 'compliance';
      workflow_trigger_event: 'application_received' | 'bid_accepted' | 'interview_scheduled' | 'offer_made';
      workflow_instance_status: 'active' | 'completed' | 'paused' | 'cancelled';
      workflow_entity_type: 'application' | 'recruiter_bid' | 'interview';
      workflow_step_type: 'email' | 'notification' | 'task' | 'delay' | 'condition' | 'approval';
      workflow_step_status: 'pending' | 'in_progress' | 'completed' | 'skipped' | 'failed';
      status_entity_type: 'application' | 'recruiter_bid' | 'interview' | 'job';
      billing_interval: 'month' | 'year';
      payment_dispute_status: 'needs_response' | 'under_review' | 'won' | 'lost' | 'warning_needs_response' | 'warning_under_review' | 'closed';
      alert_frequency: 'immediate' | 'daily' | 'weekly';
      remote_work_preference: 'required' | 'preferred' | 'flexible' | 'no';
      notification_frequency: 'immediate' | 'daily' | 'weekly' | 'never';
    };
    Tables: {
      workflow_templates: {
        Row: {
          id: string;
          name: string;
          description: string | null;
          category: Database['public']['Enums']['workflow_category'];
          trigger_event: Database['public']['Enums']['workflow_trigger_event'];
          steps: any;
          is_active: boolean | null;
          organization_id: string;
          created_by: string | null;
          created_at: string | null;
          updated_at: string | null;
        };
        Insert: {
          id?: string;
          name: string;
          description?: string | null;
          category?: Database['public']['Enums']['workflow_category'];
          trigger_event: Database['public']['Enums']['workflow_trigger_event'];
          steps?: any;
          is_active?: boolean | null;
          organization_id: string;
          created_by?: string | null;
          created_at?: string | null;
          updated_at?: string | null;
        };
        Update: {
          id?: string;
          name?: string;
          description?: string | null;
          category?: Database['public']['Enums']['workflow_category'];
          trigger_event?: Database['public']['Enums']['workflow_trigger_event'];
          steps?: any;
          is_active?: boolean | null;
          organization_id?: string;
          created_by?: string | null;
          created_at?: string | null;
          updated_at?: string | null;
        };
      };
      workflow_instances: {
        Row: {
          id: string;
          template_id: string;
          entity_type: Database['public']['Enums']['workflow_entity_type'];
          entity_id: string;
          status: Database['public']['Enums']['workflow_instance_status'];
          current_step: number | null;
          context_data: any | null;
          started_at: string | null;
          completed_at: string | null;
          created_at: string | null;
        };
        Insert: {
          id?: string;
          template_id: string;
          entity_type: Database['public']['Enums']['workflow_entity_type'];
          entity_id: string;
          status?: Database['public']['Enums']['workflow_instance_status'];
          current_step?: number | null;
          context_data?: any | null;
          started_at?: string | null;
          completed_at?: string | null;
          created_at?: string | null;
        };
        Update: {
          id?: string;
          template_id?: string;
          entity_type?: Database['public']['Enums']['workflow_entity_type'];
          entity_id?: string;
          status?: Database['public']['Enums']['workflow_instance_status'];
          current_step?: number | null;
          context_data?: any | null;
          started_at?: string | null;
          completed_at?: string | null;
          created_at?: string | null;
        };
      };
      workflow_steps: {
        Row: {
          id: string;
          workflow_instance_id: string;
          step_number: number;
          step_name: string;
          step_type: Database['public']['Enums']['workflow_step_type'];
          status: Database['public']['Enums']['workflow_step_status'];
          assigned_to: string | null;
          due_date: string | null;
          completed_at: string | null;
          step_data: any;
          result_data: any;
          created_at: string | null;
        };
        Insert: {
          id?: string;
          workflow_instance_id: string;
          step_number: number;
          step_name: string;
          step_type: Database['public']['Enums']['workflow_step_type'];
          status?: Database['public']['Enums']['workflow_step_status'];
          assigned_to?: string | null;
          due_date?: string | null;
          completed_at?: string | null;
          step_data?: any;
          result_data?: any;
          created_at?: string | null;
        };
        Update: {
          id?: string;
          workflow_instance_id?: string;
          step_number?: number;
          step_name?: string;
          step_type?: Database['public']['Enums']['workflow_step_type'];
          status?: Database['public']['Enums']['workflow_step_status'];
          assigned_to?: string | null;
          due_date?: string | null;
          completed_at?: string | null;
          step_data?: any;
          result_data?: any;
          created_at?: string | null;
        };
      };
      profiles: {
        Row: {
          id: string;
          email: string;
          name: string;
          role: Database['public']['Enums']['user_role'];
          organization_id: string | null;
          status: Database['public']['Enums']['user_status'];
          kyc_status: Database['public']['Enums']['kyc_status'];
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          name: string;
          role?: Database['public']['Enums']['user_role'];
          organization_id?: string | null;
          status?: Database['public']['Enums']['user_status'];
          kyc_status?: Database['public']['Enums']['kyc_status'];
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          name?: string;
          role?: Database['public']['Enums']['user_role'];
          organization_id?: string | null;
          status?: Database['public']['Enums']['user_status'];
          kyc_status?: Database['public']['Enums']['kyc_status'];
          created_at?: string;
          updated_at?: string;
        };
      };
      organizations: {
        Row: {
          id: string;
          name: string;
          type: Database['public']['Enums']['organization_type'];
          status: Database['public']['Enums']['organization_status'];
          billing_account_id: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          type: Database['public']['Enums']['organization_type'];
          status?: Database['public']['Enums']['organization_status'];
          billing_account_id?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          type?: Database['public']['Enums']['organization_type'];
          status?: Database['public']['Enums']['organization_status'];
          billing_account_id?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      jobs: {
        Row: {
          id: string;
          organization_id: string;
          title: string;
          description: string;
          location: string;
          salary_min: number | null;
          salary_max: number | null;
          employment_type: Database['public']['Enums']['employment_type'];
          skills: string[];
          visibility: Database['public']['Enums']['job_visibility'];
          ad_tier: Database['public']['Enums']['ad_tier'];
          bid_limit: number | null;
          blocked_recruiter_ids: string[];
          status: Database['public']['Enums']['job_status'];
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          organization_id: string;
          title: string;
          description: string;
          location: string;
          salary_min?: number | null;
          salary_max?: number | null;
          employment_type: Database['public']['Enums']['employment_type'];
          skills: string[];
          visibility?: Database['public']['Enums']['job_visibility'];
          ad_tier?: Database['public']['Enums']['ad_tier'];
          bid_limit?: number | null;
          blocked_recruiter_ids?: string[];
          status?: Database['public']['Enums']['job_status'];
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          organization_id?: string;
          title?: string;
          description?: string;
          location?: string;
          salary_min?: number | null;
          salary_max?: number | null;
          employment_type?: Database['public']['Enums']['employment_type'];
          skills?: string[];
          visibility?: Database['public']['Enums']['job_visibility'];
          ad_tier?: Database['public']['Enums']['ad_tier'];
          bid_limit?: number | null;
          blocked_recruiter_ids?: string[];
          status?: Database['public']['Enums']['job_status'];
          created_at?: string;
          updated_at?: string;
        };
      };
      search_analytics: {
        Row: {
          id: string;
          user_id: string;
          search_query: string;
          search_filters: any;
          results_count: number | null;
          search_duration_ms: number | null;
          session_id: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          search_query: string;
          search_filters?: any;
          results_count?: number | null;
          search_duration_ms?: number | null;
          session_id?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          search_query?: string;
          search_filters?: any;
          results_count?: number | null;
          search_duration_ms?: number | null;
          session_id?: string | null;
          created_at?: string;
        };
      };
      saved_searches: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          search_criteria: any;
          email_alerts: boolean;
          alert_frequency: Database['public']['Enums']['alert_frequency'];
          last_alert_sent: string | null;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          search_criteria: any;
          email_alerts?: boolean;
          alert_frequency: Database['public']['Enums']['alert_frequency'];
          last_alert_sent?: string | null;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          name?: string;
          search_criteria?: any;
          email_alerts?: boolean;
          alert_frequency?: Database['public']['Enums']['alert_frequency'];
          last_alert_sent?: string | null;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      job_recommendations: {
        Row: {
          id: string;
          candidate_id: string;
          job_id: string;
          match_score: number;
          match_reasons: any;
          skill_match_score: number | null;
          location_match_score: number | null;
          salary_match_score: number | null;
          experience_match_score: number | null;
          is_viewed: boolean;
          is_dismissed: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          candidate_id: string;
          job_id: string;
          match_score: number;
          match_reasons?: any;
          skill_match_score?: number | null;
          location_match_score?: number | null;
          salary_match_score?: number | null;
          experience_match_score?: number | null;
          is_viewed?: boolean;
          is_dismissed?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          candidate_id?: string;
          job_id?: string;
          match_score?: number;
          match_reasons?: any;
          skill_match_score?: number | null;
          location_match_score?: number | null;
          salary_match_score?: number | null;
          experience_match_score?: number | null;
          is_viewed?: boolean;
          is_dismissed?: boolean;
          created_at?: string;
        };
      };
      candidate_recommendations: {
        Row: {
          id: string;
          job_id: string;
          candidate_id: string;
          match_score: number;
          match_reasons: any;
          skill_match_score: number | null;
          location_match_score: number | null;
          salary_match_score: number | null;
          experience_match_score: number | null;
          is_viewed: boolean;
          is_contacted: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          job_id: string;
          candidate_id: string;
          match_score: number;
          match_reasons?: any;
          skill_match_score?: number | null;
          location_match_score?: number | null;
          salary_match_score?: number | null;
          experience_match_score?: number | null;
          is_viewed?: boolean;
          is_contacted?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          job_id?: string;
          candidate_id?: string;
          match_score?: number;
          match_reasons?: any;
          skill_match_score?: number | null;
          location_match_score?: number | null;
          salary_match_score?: number | null;
          experience_match_score?: number | null;
          is_viewed?: boolean;
          is_contacted?: boolean;
          created_at?: string;
        };
      };
      matching_preferences: {
        Row: {
          id: string;
          user_id: string;
          skill_weight: number;
          location_weight: number;
          salary_weight: number;
          experience_weight: number;
          industry_weight: number;
          max_commute_distance: number;
          remote_work_preference: Database['public']['Enums']['remote_work_preference'];
          salary_flexibility: number;
          notification_frequency: Database['public']['Enums']['notification_frequency'];
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          skill_weight?: number;
          location_weight?: number;
          salary_weight?: number;
          experience_weight?: number;
          industry_weight?: number;
          max_commute_distance?: number;
          remote_work_preference: Database['public']['Enums']['remote_work_preference'];
          salary_flexibility?: number;
          notification_frequency: Database['public']['Enums']['notification_frequency'];
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          skill_weight?: number;
          location_weight?: number;
          salary_weight?: number;
          experience_weight?: number;
          industry_weight?: number;
          max_commute_distance?: number;
          remote_work_preference?: Database['public']['Enums']['remote_work_preference'];
          salary_flexibility?: number;
          notification_frequency?: Database['public']['Enums']['notification_frequency'];
          created_at?: string;
          updated_at?: string;
        };
      };
      subscription_plans: {
        Row: {
          id: string;
          stripe_price_id: string | null;
          name: string;
          description: string | null;
          amount: number;
          currency: string;
          billing_interval: Database['public']['Enums']['billing_interval'];
          trial_period_days: number;
          features: any | null;
          limits: any | null;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          stripe_price_id?: string | null;
          name: string;
          description?: string | null;
          amount: number;
          currency?: string;
          billing_interval: Database['public']['Enums']['billing_interval'];
          trial_period_days?: number;
          features?: any | null;
          limits?: any | null;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          stripe_price_id?: string | null;
          name?: string;
          description?: string | null;
          amount?: number;
          currency?: string;
          billing_interval?: Database['public']['Enums']['billing_interval'];
          trial_period_days?: number;
          features?: any | null;
          limits?: any | null;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      subscription_usage: {
        Row: {
          id: string;
          subscription_id: string | null;
          billing_account_id: string | null;
          usage_type: string;
          quantity: number;
          unit_price: number;
          period_start: string;
          period_end: string;
          metadata: any | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          subscription_id?: string | null;
          billing_account_id?: string | null;
          usage_type: string;
          quantity: number;
          unit_price: number;
          period_start: string;
          period_end: string;
          metadata?: any | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          subscription_id?: string | null;
          billing_account_id?: string | null;
          usage_type?: string;
          quantity?: number;
          unit_price?: number;
          period_start?: string;
          period_end?: string;
          metadata?: any | null;
          created_at?: string;
        };
      };
      payment_disputes: {
        Row: {
          id: string;
          payment_id: string | null;
          escrow_transaction_id: string | null;
          stripe_dispute_id: string | null;
          amount: number;
          currency: string;
          reason: string | null;
          status: Database['public']['Enums']['payment_dispute_status'];
          evidence: any | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          payment_id?: string | null;
          escrow_transaction_id?: string | null;
          stripe_dispute_id?: string | null;
          amount: number;
          currency?: string;
          reason?: string | null;
          status: Database['public']['Enums']['payment_dispute_status'];
          evidence?: any | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          payment_id?: string | null;
          escrow_transaction_id?: string | null;
          stripe_dispute_id?: string | null;
          amount?: number;
          currency?: string;
          reason?: string | null;
          status?: Database['public']['Enums']['payment_dispute_status'];
          evidence?: any | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      webhook_events: {
        Row: {
          id: string;
          stripe_event_id: string | null;
          event_type: string;
          processed: boolean;
          data: any;
          created_at: string;
        };
        Insert: {
          id?: string;
          stripe_event_id?: string | null;
          event_type: string;
          processed?: boolean;
          data: any;
          created_at?: string;
        };
        Update: {
          id?: string;
          stripe_event_id?: string | null;
          event_type?: string;
          processed?: boolean;
          data?: any;
          created_at?: string;
        };
      };
      document_shares: {
        Row: {
          id: string;
          owner_id: string;
          shared_with_id: string;
          file_upload_id: string;
          application_id: string | null;
          recruiter_bid_id: string | null;
          access_level: Database['public']['Enums']['document_access_level'];
          expires_at: string | null;
          password_protected: boolean | null;
          access_password: string | null;
          download_count: number | null;
          last_accessed_at: string | null;
          is_active: boolean | null;
          created_at: string | null;
        };
        Insert: {
          id?: string;
          owner_id: string;
          shared_with_id: string;
          file_upload_id: string;
          application_id?: string | null;
          recruiter_bid_id?: string | null;
          access_level?: Database['public']['Enums']['document_access_level'];
          expires_at?: string | null;
          password_protected?: boolean | null;
          access_password?: string | null;
          download_count?: number | null;
          last_accessed_at?: string | null;
          is_active?: boolean | null;
          created_at?: string | null;
        };
        Update: {
          id?: string;
          owner_id?: string;
          shared_with_id?: string;
          file_upload_id?: string;
          application_id?: string | null;
          recruiter_bid_id?: string | null;
          access_level?: Database['public']['Enums']['document_access_level'];
          expires_at?: string | null;
          password_protected?: boolean | null;
          access_password?: string | null;
          download_count?: number | null;
          last_accessed_at?: string | null;
          is_active?: boolean | null;
          created_at?: string | null;
        };
      };
    };
    Functions: {
      current_user_role: {
        Args: Record<PropertyKey, never>;
        Returns: string;
      };
      current_org_id: {
        Args: Record<PropertyKey, never>;
        Returns: string;
      };
    };
  };
};