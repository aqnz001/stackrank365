import React, { useMemo, useState } from 'react';
import BidForm from '../Bids/BidForm';
import { useAuth } from '../../context/AuthContext';
import { useJobs } from '../../hooks/useJobs';
import { useAdvancedSearch, type SearchFilters } from '../../hooks/useAdvancedSearch';
import JobCard from '../Jobs/JobCard';
import JobListItem from '../Jobs/JobListItem';
import JobPreviewPanel from '../Jobs/JobPreviewPanel';
import JobApplicationForm from '../Applications/JobApplicationForm';
import JobDetails from '../Jobs/JobDetails';
import AuthScreen from '../Auth/AuthScreen';
import { useApplications } from '../../hooks/useApplications';
import { useRecruiterBids } from '../../hooks/useRecruiterBids';
import { getJobLifecycle } from '../../utils/jobs';
import type { Job } from '../../types';
import { Search, MapPin, Filter, X, ChevronDown, Briefcase, Users, Building } from 'lucide-react';
import { useAppliedJobs } from '../../hooks/useAppliedJobs';

const defaultFilters: SearchFilters = {
  query: '',
  location: '',
  radius: 25,
  employmentType: [],
  salaryMin: '',
  salaryMax: '',
  skills: [],
  experienceLevel: '',
  adTier: [],
  visibility: [],
  status: ['open'],
  postedWithin: '',
  companySize: [],
  industry: [],
  remoteWork: false,
  benefits: [],
};

type SortOption = 'relevance' | 'newest' | 'oldest' | 'salary-high' | 'salary-low' | 'company';

const SearchLayoutPage: React.FC = () => {
  const { user } = useAuth();
  const { jobs, loading: jobsLoading } = useJobs();
  const { performSearch, searchResults, loading: searchLoading, clearSearchResults } = useAdvancedSearch();
  const { createApplication } = useApplications();
  const { bids } = useRecruiterBids();

  const [query, setQuery] = useState('');
  const [location, setLocation] = useState('');
  const [hasSearched, setHasSearched] = useState(false);
  const [employerFilter, setEmployerFilter] = useState<{ id: string; name: string } | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [skillInput, setSkillInput] = useState('');
  const [filters, setFilters] = useState<SearchFilters>(defaultFilters);
  const [sortBy, setSortBy] = useState<SortOption>('relevance');
  const [pageSize, setPageSize] = useState(20);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [bidJob, setBidJob] = useState<Job | null>(null);
  const [isDesktop, setIsDesktop] = useState(false);
  const [showApplicationForm, setShowApplicationForm] = useState(false);
  const { isApplied } = useAppliedJobs();

  // Check URL for employer filter on mount
  React.useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const employerId = params.get('employerId');
    const employerName = params.get('employer');
    if (employerId && employerName) {
      setEmployerFilter({ id: employerId, name: decodeURIComponent(employerName) });
    }
  }, []);

  // Public fallback list (no branding, open jobs only)
  const publicJobs = useMemo(() => {
    let filtered = jobs.filter(j => j.visibility === 'open' && j.status === 'open');
    if (employerFilter) {
      filtered = filtered.filter(j => j.organizationId === employerFilter.id);
    }
    return filtered;
  }, [jobs, employerFilter]);

  const isLoading = hasSearched ? searchLoading : jobsLoading;
  const baseJobs = hasSearched && searchResults ? searchResults.jobs : publicJobs;

  const sortedJobs = useMemo(() => {
    const list = [...baseJobs];
    switch (sortBy) {
      case 'newest':
        return list.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
      case 'oldest':
        return list.sort((a, b) => +new Date(a.createdAt) - +new Date(b.createdAt));
      case 'salary-high':
        return list.sort((a, b) => (b.salaryRange?.max || 0) - (a.salaryRange?.max || 0));
      case 'salary-low':
        return list.sort((a, b) => (a.salaryRange?.min || 0) - (b.salaryRange?.min || 0));
      case 'company':
        return list.sort((a, b) => a.organizationName.localeCompare(b.organizationName));
      default:
        return list;
    }
  }, [baseJobs, sortBy]);

  // Filter out closed jobs unless viewer qualifies for exceptions
  const filteredJobs = useMemo(() => {
    const bidJobIds = new Set((bids || []).map(b => b.jobId));
    return sortedJobs.filter((j) => {
      const life = getJobLifecycle(j);
      if (life.isOpen) return true;
      if (user?.role === 'recruiter') return bidJobIds.has(j.id);
      if (user?.role === 'candidate') return isApplied(j.id);
      if (user?.role === 'employer' && user.organizationId && j.organizationId === user.organizationId) return true;
      return false;
    });
  }, [sortedJobs, bids, user?.role, user?.organizationId, isApplied]);

  const visibleJobs = useMemo(() => filteredJobs.slice(0, pageSize), [filteredJobs, pageSize]);

  // Select first job for preview on desktop
  React.useEffect(() => {
    if (!selectedJob && visibleJobs.length > 0) {
      setSelectedJob(visibleJobs[0]);
    }
  }, [visibleJobs, selectedJob]);

  React.useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    const update = () => setIsDesktop(mq.matches);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, []);

  // Open Auth modal when navbar sets a hash (#signin | #signup)
  React.useEffect(() => {
    const handle = () => {
      const h = window.location.hash.toLowerCase();
      if (!user) {
        if (h === '#signin' || h === '#login') {
          setAuthMode('signin');
          setShowAuthModal(true);
        } else if (h === '#signup' || h === '#register') {
          setAuthMode('signup');
          setShowAuthModal(true);
        }
      }
    };
    handle();
    window.addEventListener('hashchange', handle);
    return () => window.removeEventListener('hashchange', handle);
  }, [user]);

  const applySearch = async () => {
    const next: SearchFilters = {
      ...filters,
      query,
      location,
    };
    setFilters(next);
    setHasSearched(true);
    await performSearch(next);
  };

  // Central apply handler - only candidates can apply
  const handleApply = (job: Job) => {
    if (!user) {
      try {
        localStorage.setItem('postLoginApplyJobId', job.id);
      } catch {}
      setAuthMode('signin');
      setShowAuthModal(true);
      // Also set a hash so Navbar shortcuts can open the modal consistently
      try { window.location.hash = '#signin'; } catch {}
      return;
    }
    if (user.role !== 'candidate') {
      return; // hide for non-candidates, do nothing if somehow triggered
    }
    setSelectedJob(job);
    setShowApplicationForm(true);
  };

  // After login, if we stored an intent to apply, open the application form on that job
  React.useEffect(() => {
    if (!user) return;
    let jobId: string | null = null;
    try { jobId = localStorage.getItem('postLoginApplyJobId'); } catch {}
    if (jobId) {
      // Find job from loaded jobs list
      const allJobs = jobs || [];
      const target = allJobs.find(j => j.id === jobId);
      if (target && user.role === 'candidate') {
        setSelectedJob(target);
        setShowApplicationForm(true);
      }
      try { localStorage.removeItem('postLoginApplyJobId'); } catch {}
    }
  }, [user, jobs]);

  // If another view requests to show a specific job, open it in preview
  React.useEffect(() => {
    let viewId: string | null = null;
    try { viewId = localStorage.getItem('viewJobId'); } catch {}
    if (!viewId) return;
    const allJobs = jobs || [];
    const target = allJobs.find(j => j.id === viewId);
    if (target) {
      setSelectedJob(target);
    }
    try { localStorage.removeItem('viewJobId'); } catch {}
  }, [jobs]);

  const applySearchWith = async (partial?: Partial<SearchFilters>, qOverride?: string, locOverride?: string) => {
    const next: SearchFilters = {
      ...filters,
      ...(partial || {}),
      query: qOverride !== undefined ? qOverride : query,
      location: locOverride !== undefined ? locOverride : location,
    } as SearchFilters;
    setFilters(next);
    setHasSearched(true);
    await performSearch(next);
  };

  const clearAll = () => {
    setQuery('');
    setLocation('');
    setFilters(defaultFilters);
    setHasSearched(false);
    clearSearchResults();
  };

  const toggleArray = (key: keyof SearchFilters, value: string) => {
    const current = (filters[key] as string[]) || [];
    const updated = current.includes(value) ? current.filter(v => v !== value) : [...current, value];
    const next = { ...filters, [key]: updated } as SearchFilters;
    setFilters(next);
    if (hasSearched) performSearch(next);
  };

  const setField = (key: keyof SearchFilters, value: any) => {
    const next = { ...filters, [key]: value } as SearchFilters;
    setFilters(next);
    if (hasSearched) performSearch(next);
  };

  const sortLabel = (s: SortOption) => ({
    relevance: 'Most Relevant',
    newest: 'Newest First',
    oldest: 'Oldest First',
    'salary-high': 'Highest Salary',
    'salary-low': 'Lowest Salary',
    company: 'Company A–Z',
  }[s]);

  const postedWithinLabel = (v: string) => {
    switch (v) {
      case '1': return 'Last 24 hours';
      case '7': return 'Last 7 days';
      case '14': return 'Last 14 days';
      case '30': return 'Last 30 days';
      default: return '';
    }
  };

  const formatMoney = (n: string | number) => {
    const num = typeof n === 'string' ? parseInt(n) : n;
    if (!num) return '';
    return `$${num.toLocaleString()}`;
  };

  const addSkillFromInput = () => {
    const s = skillInput.trim();
    if (!s) return;
    if (!filters.skills.includes(s)) {
      toggleArray('skills', s);
    }
    setSkillInput('');
  };

  const jobClassifications = [
    'Accounting', 'Administration & Office Support', 'Advertising, Arts & Media', 'Banking & Financial Services', 'Call Centre & Customer Service', 'Community Services & Development', 'Construction', 'Consulting & Strategy', 'Design & Architecture', 'Education & Training', 'Engineering', 'Farming, Animals & Conservation', 'Government & Defence', 'Healthcare & Medical', 'Hospitality & Tourism', 'Human Resources & Recruitment', 'Information & Communication Technology', 'Insurance & Superannuation', 'Legal', 'Manufacturing, Transport & Logistics', 'Marketing & Communications', 'Mining, Resources & Energy', 'Real Estate & Property', 'Retail & Consumer Products', 'Sales', 'Science & Technology', 'Self Employment', 'Sport & Recreation', 'Trades & Services'
  ];
  const workTypes = ['Full time', 'Part time', 'Contract/Temp', 'Casual/Vacation'];
  const remoteOptions = ['Work from home', 'Flexible / hybrid', 'No remote work'];
  const salaryStops = [
    { label: '$0', value: '0' }, { label: '$30,000', value: '30000' }, { label: '$40,000', value: '40000' },
    { label: '$50,000', value: '50000' }, { label: '$60,000', value: '60000' }, { label: '$70,000', value: '70000' },
    { label: '$80,000', value: '80000' }, { label: '$90,000', value: '90000' }, { label: '$100,000', value: '100000' },
    { label: '$120,000', value: '120000' }, { label: '$150,000', value: '150000' }, { label: '$200,000', value: '200000' },
    { label: '$250,000', value: '250000' }, { label: '$300,000', value: '300000' }, { label: '$350,000+', value: '350000' },
  ];
  const listedTimeOptions = [
    { label: 'Any time', value: '' },
    { label: 'Last 24 hours', value: '1' },
    { label: 'Last 3 days', value: '3' },
    { label: 'Last 7 days', value: '7' },
    { label: 'Last 14 days', value: '14' },
    { label: 'Last 30 days', value: '30' },
  ];

  // Old-to-new mappings
  const mapWorkType = (label: string): string | '' => {
    switch (label) {
      case 'Full time': return 'full-time';
      case 'Part time': return 'part-time';
      case 'Contract/Temp': return 'contract';
      case 'Casual/Vacation': return 'temporary';
      default: return '';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Hero Header + Search */}
      <div className="relative overflow-hidden">
        {/* Decorative shapes */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-20 left-10 w-32 h-32 bg-pink-400 rounded-full opacity-20"></div>
          <div className="absolute top-40 right-20 w-24 h-24 bg-blue-400 rounded-full opacity-15"></div>
          <div className="absolute bottom-20 left-1/4 w-16 h-16 bg-purple-400 rounded-full opacity-25"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-16">
          <div className="bg-white shadow-xl rounded-2xl p-4 md:p-6">
            {/* Auth CTA moved to Navbar (top menu) */}
            {/* Search Row (What / Classification / Where / Search) */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              <div className="md:col-span-4">
                <label className="block text-sm font-medium text-secondary-700 mb-2">What</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-secondary-400 w-5 h-5" />
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); applySearch(); } }}
                    placeholder="Enter keywords/job title/company"
                    className="w-full pl-10 pr-4 py-3 border border-secondary-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  />
                </div>
              </div>
              <div className="md:col-span-3">
                <label className="block text-sm font-medium text-secondary-700 mb-2">Classification</label>
                <div className="relative">
                  <select
                    value={filters.industry[0] || ''}
                    onChange={async (e) => {
                      const val = e.target.value;
                      const next = { ...filters, industry: val ? [val] : [] } as SearchFilters;
                      setFilters(next);
                      if (hasSearched) await performSearch({ ...next, query, location });
                    }}
                    className="w-full px-4 py-3 border border-secondary-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500 appearance-none bg-white"
                  >
                    <option value="">Any classification</option>
                    {jobClassifications.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-secondary-500 pointer-events-none" />
                </div>
              </div>
              <div className="md:col-span-3">
                <label className="block text-sm font-medium text-secondary-700 mb-2">Where</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-secondary-400 w-5 h-5" />
                  <input
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); applySearch(); } }}
                    placeholder="Enter suburb, town or city"
                    className="w-full pl-10 pr-4 py-3 border border-secondary-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  />
                </div>
              </div>
              <div className="md:col-span-2 flex items-end">
                <button onClick={applySearch} className="w-full bg-primary-600 text-white py-3 px-6 rounded-xl hover:bg-primary-700 font-semibold shadow">
                  Search
                </button>
              </div>
            </div>

            {/* Employer Filter Indicator */}
            {employerFilter && (
              <div className="mt-4 flex items-center justify-center gap-2">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 border border-blue-200 rounded-full text-sm">
                  <Building className="w-4 h-4 text-blue-600" />
                  <span className="text-blue-800">
                    Showing jobs from <strong>{employerFilter.name}</strong>
                  </span>
                  <button
                    onClick={() => {
                      setEmployerFilter(null);
                      window.history.pushState({}, '', window.location.pathname);
                    }}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* More Options toggle */}
            <div className="mt-4 flex justify-center">
              <button onClick={() => setShowFilters(!showFilters)} className="flex items-center text-secondary-600 hover:text-secondary-900 font-medium">
                More options
                <ChevronDown className={`w-4 h-4 ml-1 transition-transform ${showFilters ? 'rotate-180' : ''}`} />
              </button>
            </div>

            {/* Advanced Filters (old set) */}
            {showFilters && (
              <div className="bg-slate-50 border-t border-secondary-200 mt-4 p-4 md:p-6">
                <div className="flex flex-wrap gap-3 items-center">
                  {/* Work type */}
                  <div className="relative">
                    <select
                      className="appearance-none bg-white border-2 border-secondary-300 rounded-full px-6 py-2 pr-10 text-sm font-medium text-secondary-700 hover:border-secondary-400 focus:border-primary-500 focus:ring-2 focus:ring-primary-200"
                      value={(filters.employmentType[0] || '').toString().replace('-', ' ')}
                      onChange={async (e) => {
                        const mapped = mapWorkType(e.target.value);
                        const next = { ...filters, employmentType: mapped ? [mapped] : [] } as SearchFilters;
                        setFilters(next);
                        if (hasSearched) await performSearch({ ...next, query, location });
                      }}
                    >
                      <option value="">All work types</option>
                      {workTypes.map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-secondary-500 pointer-events-none" />
                  </div>
                  {/* Salary min */}
                  <div className="relative">
                    <select
                      className="appearance-none bg-white border-2 border-secondary-300 rounded-full px-6 py-2 pr-10 text-sm font-medium text-secondary-700 hover:border-secondary-400 focus:border-primary-500 focus:ring-2 focus:ring-primary-200"
                      value={filters.salaryMin}
                      onChange={async (e) => { setField('salaryMin', e.target.value); if (hasSearched) await performSearch({ ...filters, query, location, salaryMin: e.target.value }); }}
                    >
                      <option value="">Min salary</option>
                      {salaryStops.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-secondary-500 pointer-events-none" />
                  </div>
                  {/* Salary max */}
                  <div className="relative">
                    <select
                      className="appearance-none bg-white border-2 border-secondary-300 rounded-full px-6 py-2 pr-10 text-sm font-medium text-secondary-700 hover:border-secondary-400 focus:border-primary-500 focus:ring-2 focus:ring-primary-200"
                      value={filters.salaryMax}
                      onChange={async (e) => { setField('salaryMax', e.target.value); if (hasSearched) await performSearch({ ...filters, query, location, salaryMax: e.target.value }); }}
                    >
                      <option value="">Max salary</option>
                      {salaryStops.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-secondary-500 pointer-events-none" />
                  </div>
                  {/* Posted within */}
                  <div className="relative">
                    <select
                      className="appearance-none bg-white border-2 border-secondary-300 rounded-full px-6 py-2 pr-10 text-sm font-medium text-secondary-700 hover:border-secondary-400 focus:border-primary-500 focus:ring-2 focus:ring-primary-200"
                      value={filters.postedWithin}
                      onChange={async (e) => { setField('postedWithin', e.target.value); if (hasSearched) await performSearch({ ...filters, query, location, postedWithin: e.target.value }); }}
                    >
                      {listedTimeOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-secondary-500 pointer-events-none" />
                  </div>
                  {/* Remote */}
                  <div className="relative">
                    <select
                      className="appearance-none bg-white border-2 border-secondary-300 rounded-full px-6 py-2 pr-10 text-sm font-medium text-secondary-700 hover:border-secondary-400 focus:border-primary-500 focus:ring-2 focus:ring-primary-200"
                      value={filters.remoteWork ? 'Work from home' : ''}
                      onChange={async (e) => {
                        const val = e.target.value;
                        const next = { ...filters, remoteWork: val === 'Work from home' || val === 'Flexible / hybrid' } as SearchFilters;
                        setFilters(next);
                        if (hasSearched) await performSearch({ ...next, query, location });
                      }}
                    >
                      <option value="">All workplace options</option>
                      {remoteOptions.map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                    <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-secondary-500 pointer-events-none" />
                  </div>
                  {/* Clear */}
                  <button onClick={clearAll} className="ml-auto px-4 py-2 border border-secondary-300 rounded-full text-sm text-secondary-700 hover:bg-secondary-50">Clear</button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Advanced filters (desktop) */}
      {false && (
        <div className="border-b bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs text-gray-600 mb-1">Radius</label>
                <select className="w-full border rounded-md px-2 py-2 text-sm" value={filters.radius} onChange={(e) => setField('radius', Number(e.target.value))}>
                  {[10,25,50,100].map(r => <option key={r} value={r}>{r} km</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">Experience level</label>
                <select className="w-full border rounded-md px-2 py-2 text-sm" value={filters.experienceLevel} onChange={(e) => setField('experienceLevel', e.target.value)}>
                  <option value="">Any</option>
                  <option value="entry">Entry</option>
                  <option value="mid">Mid</option>
                  <option value="senior">Senior</option>
                  <option value="lead">Lead</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">Add skills</label>
                <input
                  value={skillInput}
                  onChange={(e) => setSkillInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); addSkillFromInput(); } }}
                  placeholder="e.g. React, TypeScript"
                  className="w-full border rounded-md px-3 py-2 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs text-gray-600 mb-1">Industry</label>
                <div className="flex flex-wrap gap-2">
                  {industries.map(i => (
                    <button key={i} onClick={() => toggleArray('industry', i)} className={`px-2 py-1 rounded-full text-xs border ${filters.industry.includes(i) ? 'bg-blue-600 text-white border-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>{i}</button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">Company size</label>
                <div className="flex flex-wrap gap-2">
                  {companySizes.map(s => (
                    <button key={s} onClick={() => toggleArray('companySize', s)} className={`px-2 py-1 rounded-full text-xs border capitalize ${filters.companySize.includes(s) ? 'bg-blue-600 text-white border-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>{s}</button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">Benefits</label>
                <div className="flex flex-wrap gap-2">
                  {benefitsList.map(b => (
                    <button key={b} onClick={() => toggleArray('benefits', b)} className={`px-2 py-1 rounded-full text-xs border ${filters.benefits.includes(b) ? 'bg-blue-600 text-white border-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>{b}</button>
                  ))}
                </div>
              </div>

              <div>
                <label className="inline-flex items-center gap-2 text-sm text-gray-700">
                  <input type="checkbox" checked={!!filters.remoteWork} onChange={(e) => setField('remoteWork', e.target.checked)} />
                  Remote work
                </label>
              </div>
              <div>
                <label className="block text-xs text-gray-600 mb-1">Ad tier</label>
                <div className="flex flex-wrap gap-2">
                  {['basic','standard','premium'].map(t => (
                    <button key={t} onClick={() => toggleArray('adTier', t)} className={`px-2 py-1 rounded-full text-xs border capitalize ${filters.adTier.includes(t) ? 'bg-blue-600 text-white border-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>{t}</button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Left filters removed to match homepage look */}

          {/* Results */}
          <section className="lg:col-span-2">
            {/* Results header */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-3">
              <div>
                <h2 className="text-lg font-semibold text-gray-900">
                  {filteredJobs.length.toLocaleString()} jobs found
                </h2>
                {hasSearched && searchResults && (
                  <p className="text-xs text-gray-600">Search completed in {searchResults.searchTime.toFixed(0)}ms</p>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button className="px-2.5 py-1.5 rounded-full text-xs bg-blue-50 text-blue-700 border border-blue-200">New to you</button>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as SortOption)}
                  className="border rounded-md px-2 py-2 text-sm"
                >
                  {(['relevance','newest','oldest','salary-high','salary-low','company'] as SortOption[]).map((s) => (
                    <option key={s} value={s}>{sortLabel(s)}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Active chips */}
            <div className="mb-4 flex flex-wrap gap-2">
              {query && (
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-800">
                  {query}
                  <button className="ml-2" onClick={async () => { setQuery(''); await applySearchWith(undefined, ''); }}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {location && (
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-800">
                  {location}
                  <button className="ml-2" onClick={async () => { setLocation(''); await applySearchWith(undefined, undefined, ''); }}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {filters.employmentType.map((t) => (
                <span key={t} className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-800 capitalize">
                  {t.replace('-', ' ')}
                  <button className="ml-2" onClick={() => toggleArray('employmentType', t)}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
              {filters.salaryMin && (
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-800">
                  Min {formatMoney(filters.salaryMin)}
                  <button className="ml-2" onClick={() => setField('salaryMin', '')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {filters.postedWithin && (
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-800">
                  {postedWithinLabel(filters.postedWithin)}
                  <button className="ml-2" onClick={() => setField('postedWithin', '')}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              )}
              {filters.skills.map((s) => (
                <span key={s} className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-800">
                  {s}
                  <button className="ml-2" onClick={() => toggleArray('skills', s)}>
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
              {(query || location || filters.employmentType.length || filters.salaryMin || filters.postedWithin || filters.skills.length) ? (
                <button onClick={clearAll} className="ml-2 text-sm text-blue-600">Clear all</button>
              ) : null}
            </div>

            {/* Loading */}
            {isLoading && (
              <div className="space-y-3">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="bg-white border rounded-lg p-5 animate-pulse">
                    <div className="h-5 bg-gray-200 rounded w-2/3 mb-2" />
                    <div className="h-4 bg-gray-200 rounded w-1/3 mb-4" />
                    <div className="h-4 bg-gray-200 rounded w-5/6" />
                  </div>
                ))}
              </div>
            )}

            {/* Results list */}
            {!isLoading && (
              <>
                {filteredJobs.length === 0 ? (
                  <div className="text-center py-12 bg-white border rounded-lg">
                    <p className="text-gray-700 font-medium mb-1">No results</p>
                    <p className="text-gray-500 text-sm">Try adjusting your search or filters</p>
                    {hasSearched && (
                      <button onClick={clearAll} className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md">Clear filters</button>
                    )}
                  </div>
                ) : (
                  <div className="space-y-2.5 lg:pr-2 lg:sticky lg:top-4 lg:max-h-[calc(100vh-140px)] lg:overflow-auto">
                    {visibleJobs.map((job) => (
                      <JobListItem
                        key={job.id}
                        job={job}
                        selected={selectedJob?.id === job.id}
                        onSelect={() => setSelectedJob(job)}
                        onApply={() => handleApply(job)}
                        onBid={() => { console.log('[BidModal] open from SearchLayout list', { jobId: job.id, title: job.title }); setBidJob(job); }}
                        compact
                      />
                    ))}
                  </div>
                )}

                {visibleJobs.length > 0 && filteredJobs.length > visibleJobs.length && (
                  <div className="text-center mt-6">
                    <button
                      onClick={() => setPageSize(ps => ps + 20)}
                      className="px-5 py-2.5 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                    >
                      Load more ({filteredJobs.length - visibleJobs.length} more)
                    </button>
                  </div>
                )}
              </>
            )}
          </section>

          {/* Right preview panel */}
          <aside className="hidden lg:block lg:col-span-3 lg:sticky lg:top-4 self-start">
            <div className="max-h-[calc(100vh-140px)] overflow-auto pr-1">
              <JobPreviewPanel job={selectedJob} onApply={(j) => handleApply(j)} onBid={(j)=> { console.log('[BidModal] open from SearchLayout preview', { jobId: j.id, title: j.title }); setBidJob(j); }} />
            </div>
          </aside>
        </div>
      </div>

      {/* Filters drawer (mobile) */}
      {filtersOpen && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/40" onClick={() => setFiltersOpen(false)} />
          <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-xl p-6 overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold text-gray-900">Filters</h3>
              <button onClick={() => setFiltersOpen(false)} className="p-2 text-gray-500 hover:text-gray-700">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-6">
              <div>
                <p className="text-xs text-gray-600 mb-2">Employment type</p>
                {['full-time','part-time','contract','temporary'].map((t) => (
                  <label key={t} className="flex items-center gap-2 text-sm text-gray-700 mb-1">
                    <input
                      type="checkbox"
                      checked={filters.employmentType.includes(t)}
                      onChange={() => toggleArray('employmentType', t)}
                    />
                    <span className="capitalize">{t.replace('-', ' ')}</span>
                  </label>
                ))}
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-2">Experience level</p>
                <select className="w-full border rounded-md px-2 py-2 text-sm" value={filters.experienceLevel} onChange={(e) => setField('experienceLevel', e.target.value)}>
                  <option value="">Any</option>
                  <option value="entry">Entry</option>
                  <option value="mid">Mid</option>
                  <option value="senior">Senior</option>
                  <option value="lead">Lead</option>
                </select>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-2">Posted within</p>
                <select
                  className="w-full border rounded-md px-2 py-2 text-sm"
                  value={filters.postedWithin}
                  onChange={(e) => setField('postedWithin', e.target.value)}
                >
                  <option value="">Any time</option>
                  <option value="1">Last 24 hours</option>
                  <option value="7">Last 7 days</option>
                  <option value="14">Last 14 days</option>
                  <option value="30">Last 30 days</option>
                </select>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-2">Minimum salary</p>
                <select
                  className="w-full border rounded-md px-2 py-2 text-sm"
                  value={filters.salaryMin}
                  onChange={(e) => setField('salaryMin', e.target.value)}
                >
                  <option value="">Any</option>
                  <option value="50000">$50,000</option>
                  <option value="75000">$75,000</option>
                  <option value="100000">$100,000</option>
                  <option value="150000">$150,000</option>
                </select>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-2">Radius</p>
                <select className="w-full border rounded-md px-2 py-2 text-sm" value={filters.radius} onChange={(e) => setField('radius', Number(e.target.value))}>
                  {[10,25,50,100].map(r => <option key={r} value={r}>{r} km</option>)}
                </select>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-2">Industry</p>
                <div className="flex flex-wrap gap-2">
                  {industries.map(i => (
                    <button key={i} onClick={() => toggleArray('industry', i)} className={`px-2 py-1 rounded-full text-xs border ${filters.industry.includes(i) ? 'bg-blue-600 text-white border-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>{i}</button>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-2">Company size</p>
                <div className="flex flex-wrap gap-2">
                  {companySizes.map(s => (
                    <button key={s} onClick={() => toggleArray('companySize', s)} className={`px-2 py-1 rounded-full text-xs border capitalize ${filters.companySize.includes(s) ? 'bg-blue-600 text-white border-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>{s}</button>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-2">Benefits</p>
                <div className="flex flex-wrap gap-2">
                  {benefitsList.map(b => (
                    <button key={b} onClick={() => toggleArray('benefits', b)} className={`px-2 py-1 rounded-full text-xs border ${filters.benefits.includes(b) ? 'bg-blue-600 text-white border-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>{b}</button>
                  ))}
                </div>
              </div>
              <label className="inline-flex items-center gap-2 text-sm text-gray-700">
                <input type="checkbox" checked={!!filters.remoteWork} onChange={(e) => setField('remoteWork', e.target.checked)} />
                Remote work
              </label>
              <div>
                <p className="text-xs text-gray-600 mb-2">Ad tier</p>
                <div className="flex flex-wrap gap-2">
                  {['basic','standard','premium'].map(t => (
                    <button key={t} onClick={() => toggleArray('adTier', t)} className={`px-2 py-1 rounded-full text-xs border capitalize ${filters.adTier.includes(t) ? 'bg-blue-600 text-white border-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}>{t}</button>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-2">Add skills</p>
                <input
                  value={skillInput}
                  onChange={(e) => setSkillInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); addSkillFromInput(); } }}
                  placeholder="e.g. React, TypeScript"
                  className="w-full border rounded-md px-3 py-2 text-sm"
                />
              </div>
              <div className="flex gap-2">
                <button onClick={clearAll} className="flex-1 px-3 py-2 border rounded-md">Clear</button>
                <button onClick={() => { setFiltersOpen(false); applySearch(); }} className="flex-1 px-3 py-2 bg-blue-600 text-white rounded-md">Apply</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Auth Modal */}
      <AuthScreen 
        isOpen={!!showAuthModal && !user} 
        initialMode={authMode} 
        onClose={() => {
          setShowAuthModal(false);
          // Clear auth hash if present
          const h = window.location.hash.toLowerCase();
          if (h === '#signin' || h === '#signup' || h === '#login' || h === '#register') {
            window.history.replaceState(null, '', window.location.pathname + window.location.search);
          }
        }} 
      />

      {!isDesktop && selectedJob && (
        <JobDetails
          job={selectedJob}
          onClose={() => setSelectedJob(null)}
          onApply={() => handleApply(selectedJob)}
        />
      )}

      {/* Application Form Modal (desktop & mobile) */}
      {showApplicationForm && selectedJob && user?.role === 'candidate' && (
        <JobApplicationForm
          job={selectedJob}
          onClose={() => setShowApplicationForm(false)}
          onSubmit={async (data) => {
            try {
              await createApplication(data);
            } finally {
              setShowApplicationForm(false);
            }
          }}
        />
      )}
      {bidJob && (
        <BidForm job={bidJob} onClose={() => { console.log('[BidModal] close'); setBidJob(null); }} />
      )}
    </div>
  );
};

export default SearchLayoutPage;
