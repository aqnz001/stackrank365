import React, { useState } from 'react';
import { useJobs } from '../../hooks/useJobs';
import { useAdvancedSearch } from '../../hooks/useAdvancedSearch';
import { useJobRecommendations } from '../../hooks/useJobRecommendations';
import { useSavedSearches } from '../../hooks/useSavedSearches';
import { useAuth } from '../../context/AuthContext';
import JobCard from '../Jobs/JobCard';
import BidForm from '../Bids/BidForm';
import JobApplicationForm from '../Applications/JobApplicationForm';
import { useApplications } from '../../hooks/useApplications';
import {
  Search,
  MapPin,
  Filter,
  Briefcase,
  Star,
  Grid,
  List,
  Users,
  Building,
  Bookmark
} from 'lucide-react';
import { getJobLifecycle } from '../../utils/jobs';

const HomePage: React.FC = () => {
  const { user } = useAuth();
  const { jobs, loading: jobsLoading } = useJobs();
  const [bidJob, setBidJob] = React.useState<any>(null);
  const { performSearch, searchResults, loading: searchLoading, clearSearchResults } = useAdvancedSearch();
  const { jobRecommendations } = useJobRecommendations();
  const { savedSearches } = useSavedSearches();
  const { createApplication } = useApplications();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [locationQuery, setLocationQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState('newest');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedJob, setSelectedJob] = useState<any>(null);
  const [showApplicationForm, setShowApplicationForm] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [pageSize, setPageSize] = useState(20);

  // Get all open jobs for public viewing (respect 30-day lifespan)
  const publicJobs = jobs.filter(job => job.visibility === 'open' && getJobLifecycle(job).isOpen);
  const displayJobs = hasSearched && searchResults ? searchResults.jobs : publicJobs;

  const categories = [
    'Technology',
    'Healthcare', 
    'Finance',
    'Marketing',
    'Sales',
    'Engineering',
    'Design',
    'Operations',
    'Education',
    'Legal'
  ];

  const sortOptions = [
    { value: 'newest', label: 'Newest first' },
    { value: 'oldest', label: 'Oldest first' },
    { value: 'salary-high', label: 'Highest salary' },
    { value: 'salary-low', label: 'Lowest salary' },
  ];

  const handleSearch = async () => {
    const filters = {
      query: searchQuery,
      location: locationQuery,
      radius: 25,
      employmentType: [],
      salaryMin: '',
      salaryMax: '',
      skills: [],
      experienceLevel: '',
      adTier: [],
      visibility: ['open'],
      status: ['open'],
      postedWithin: '',
      companySize: [],
      industry: selectedCategory ? [selectedCategory] : [],
      remoteWork: undefined,
      benefits: [],
    };
    setHasSearched(true);
    await performSearch(filters);
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setLocationQuery('');
    setSelectedCategory('');
    setHasSearched(false);
    clearSearchResults();
  };

  const handleJobApply = (job: any) => {
    if (!user) {
      try { localStorage.setItem('postLoginApplyJobId', job.id); } catch {}
      window.location.hash = '#signin';
      return;
    }
    if (user.role !== 'candidate') return;
    setSelectedJob(job);
    setShowApplicationForm(true);
  };

  React.useEffect(() => {
    if (!user) return;
    let jobId: string | null = null;
    try { jobId = localStorage.getItem('postLoginApplyJobId'); } catch {}
    if (jobId) {
      const target = publicJobs.find(j => j.id === jobId) || displayJobs.find(j => j.id === jobId);
      if (target && user.role === 'candidate') {
        setSelectedJob(target);
        setShowApplicationForm(true);
      }
      try { localStorage.removeItem('postLoginApplyJobId'); } catch {}
    }
  }, [user, publicJobs, displayJobs]);

  const handleApplicationSubmit = async (applicationData: any) => {
    try {
      await createApplication(applicationData);
      setShowApplicationForm(false);
      setSelectedJob(null);
      alert('Application submitted successfully!');
    } catch (error) {
      console.error('Failed to submit application:', error);
      throw error;
    }
  };

  const handleLoadSavedSearch = (criteria: any) => {
    if (criteria.query) setSearchQuery(criteria.query);
    if (criteria.location) setLocationQuery(criteria.location);
    handleSearch();
  };

  const sortedJobs = React.useMemo(() => {
    const jobsToSort = [...displayJobs];
    const toNum = (v: unknown) => typeof v === 'number' ? v : Number((v as any) ?? 0);
    switch (sortBy) {
      case 'newest':
        return jobsToSort.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      case 'oldest':
        return jobsToSort.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
      case 'salary-high':
        return jobsToSort.sort((a, b) => toNum(b.salaryRange?.max) - toNum(a.salaryRange?.max));
      case 'salary-low':
        return jobsToSort.sort((a, b) => toNum(a.salaryRange?.min) - toNum(b.salaryRange?.min));
      default:
        return jobsToSort;
    }
  }, [displayJobs, sortBy]);

  const visibleJobs = React.useMemo(() => sortedJobs.slice(0, pageSize), [sortedJobs, pageSize]);

  const isLoading = hasSearched ? searchLoading : jobsLoading;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section with Search */}
      <div className="bg-gradient-hero text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxkZWZzPjxwYXR0ZXJuIGlkPSJhIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiPjxwYXRoIGQ9Ik0wIDQwTDQwIDBNNDAgNDBMMCA0ME00MCAwTDAgMCIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLXdpZHRoPSIwLjUiIG9wYWNpdHk9IjAuMSIgZmlsbD0ibm9uZSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNhKSIvPjwvc3ZnPg==')] opacity-30"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative">
          <div className="text-center mb-16 animate-fade-in">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Discover Your Next<br />
              <span className="text-blue-200">Career Opportunity</span>
            </h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto leading-relaxed">
              Connect with thousands of opportunities from leading companies and work with professional recruiters to find your perfect role
            </p>
          </div>

          {/* Search Form */}
          <div className="max-w-5xl mx-auto animate-slide-up">
            <div className="glass rounded-2xl shadow-2xl p-8 backdrop-blur-lg">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
                <div className="md:col-span-2">
                  <label className="block text-sm font-semibold text-gray-700 mb-2.5">What</label>
                  <div className="relative">
                    <Search className="w-5 h-5 absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Job title, keywords, or company"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-12 pr-4 py-3.5 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900 placeholder-gray-400 bg-white transition-all hover:border-gray-300"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2.5">Where</label>
                  <div className="relative">
                    <MapPin className="w-5 h-5 absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      placeholder="City or remote"
                      value={locationQuery}
                      onChange={(e) => setLocationQuery(e.target.value)}
                      className="w-full pl-12 pr-4 py-3.5 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900 placeholder-gray-400 bg-white transition-all hover:border-gray-300"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2.5">Category</label>
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900 bg-white transition-all hover:border-gray-300 font-medium"
                  >
                    <option value="">All categories</option>
                    {categories.map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row justify-between items-center mt-8 gap-4">
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center px-5 py-2.5 border-2 border-gray-300 rounded-xl hover:bg-gray-50 hover:border-gray-400 transition-all font-medium text-gray-700"
                >
                  <Filter className="w-4 h-4 mr-2" />
                  {showFilters ? 'Hide filters' : 'Advanced filters'}
                </button>

                <button
                  onClick={handleSearch}
                  className="w-full sm:w-auto px-10 py-3.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 active:bg-blue-800 transition-all font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                >
                  Search Jobs
                </button>
              </div>

              {/* Advanced Filters */}
              {showFilters && (
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Employment Type</label>
                      <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-gray-900 bg-white">
                        <option value="">Any type</option>
                        <option value="full-time">Full-time</option>
                        <option value="part-time">Part-time</option>
                        <option value="contract">Contract</option>
                        <option value="temporary">Temporary</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Salary Range</label>
                      <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-gray-900 bg-white">
                        <option value="">Any salary</option>
                        <option value="0-50000">$0 - $50k</option>
                        <option value="50000-75000">$50k - $75k</option>
                        <option value="75000-100000">$75k - $100k</option>
                        <option value="100000-150000">$100k - $150k</option>
                        <option value="150000+">$150k+</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Posted</label>
                      <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-gray-900 bg-white">
                        <option value="">Any time</option>
                        <option value="1">Last 24 hours</option>
                        <option value="7">Last week</option>
                        <option value="30">Last month</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex gap-8">
          {/* Sidebar */}
          <div className="hidden lg:block w-72 space-y-6">
            {/* Saved Searches */}
            {user && user.role === 'candidate' && savedSearches.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
                <div className="flex items-center space-x-2 mb-5">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Bookmark className="w-5 h-5 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900">Saved Searches</h3>
                </div>
                <div className="space-y-2">
                  {savedSearches.slice(0, 3).map((search) => (
                    <button
                      key={search.id}
                      onClick={() => handleLoadSavedSearch(search.searchCriteria)}
                      className="w-full p-3 bg-gray-50 rounded-lg hover:bg-blue-50 hover:border-blue-200 border border-transparent transition-all text-left group"
                    >
                      <h4 className="font-semibold text-gray-900 text-sm mb-1 group-hover:text-blue-600">{search.name}</h4>
                      <p className="text-xs text-gray-600 line-clamp-2">
                        {search.searchCriteria.query && `"${search.searchCriteria.query}"`}
                        {search.searchCriteria.location && ` in ${search.searchCriteria.location}`}
                      </p>
                    </button>
                  ))}
                </div>
                {savedSearches.length > 3 && (
                  <button
                    onClick={() => window.location.hash = '#dashboard'}
                    className="w-full mt-3 text-sm text-blue-600 hover:text-blue-700"
                  >
                    View all searches
                  </button>
                )}
              </div>
            )}

            {/* Recommended for You */}
            {user && jobRecommendations.length > 0 && (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div className="flex items-center space-x-2 mb-4">
                  <Star className="w-5 h-5 text-yellow-500" />
                  <h3 className="font-semibold text-gray-900">Recommended for you</h3>
                </div>
                <div className="space-y-3">
                  {jobRecommendations.slice(0, 3).map((rec) => (
                    <div key={rec.id} className="p-3 bg-gray-50 rounded-lg">
                      <h4 className="font-medium text-gray-900 text-sm">{rec.job?.title}</h4>
                      <p className="text-xs text-gray-600">{rec.job?.organizationName}</p>
                      <div className="flex justify-between items-center mt-2">
                        <span className="text-xs text-yellow-600 font-medium">
                          {Math.round(rec.matchScore)}% match
                        </span>
                        <button
                          onClick={() => handleJobApply(rec.job)}
                          className="text-xs text-blue-600 hover:text-blue-700"
                        >
                          Apply
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Popular Categories */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Popular Categories</h3>
              <div className="space-y-2">
                {categories.slice(0, 6).map(category => (
                  <button
                    key={category}
                    onClick={() => {
                      setSelectedCategory(category);
                      setHasSearched(true);
                      const filters = {
                        query: '',
                        location: '',
                        radius: 25,
                        employmentType: [],
                        salaryMin: '',
                        salaryMax: '',
                        skills: [],
                        experienceLevel: '',
                        adTier: [],
                        visibility: ['open'],
                        status: ['open'],
                        postedWithin: '',
                        companySize: [],
                        industry: [category],
                        remoteWork: undefined,
                        benefits: [],
                      };
                      performSearch(filters);
                    }}
                    className="block w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Stats */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Platform Stats</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Briefcase className="w-4 h-4 text-blue-600" />
                    <span className="text-sm text-gray-600">Active Jobs</span>
                  </div>
                  <span className="font-semibold text-gray-900">{publicJobs.length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Building className="w-4 h-4 text-green-600" />
                    <span className="text-sm text-gray-600">Companies</span>
                  </div>
                  <span className="font-semibold text-gray-900">
                    {new Set(publicJobs.map(job => job.organizationName)).size}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-purple-600" />
                    <span className="text-sm text-gray-600">New This Week</span>
                  </div>
                  <span className="font-semibold text-gray-900">
                    {publicJobs.filter(job => {
                      const weekAgo = new Date();
                      weekAgo.setDate(weekAgo.getDate() - 7);
                      const createdAt = new Date(job.createdAt);
                      return createdAt.getTime() >= weekAgo.getTime();
                    }).length}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Results Header */}
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-6 space-y-4 sm:space-y-0">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">
                  {hasSearched ? 'Search Results' : 'Latest Jobs'}
                </h2>
                <p className="text-gray-600">
                  {hasSearched 
                    ? `${searchResults?.totalCount ?? displayJobs.length} jobs found`
                    : `${publicJobs.length} jobs available`
                  }
                  {searchQuery && ` for "${searchQuery}"`}
                  {locationQuery && ` in ${locationQuery}`}
                  {selectedCategory && ` in ${selectedCategory}`}
                </p>
              </div>

              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`p-2 rounded ${viewMode === 'grid' ? 'bg-blue-100 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
                  >
                    <Grid className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`p-2 rounded ${viewMode === 'list' ? 'bg-blue-100 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
                  >
                    <List className="w-4 h-4" />
                  </button>
                </div>

                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-gray-900 bg-white"
                >
                  {sortOptions.map(option => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Loading State */}
            {isLoading && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 animate-pulse">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
                        <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
                        <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                      </div>
                      <div className="w-20 h-6 bg-gray-200 rounded"></div>
                    </div>
                    <div className="space-y-2">
                      <div className="h-4 bg-gray-200 rounded"></div>
                      <div className="h-4 bg-gray-200 rounded w-5/6"></div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Job Results */}
            {!isLoading && (
              <>
                {sortedJobs.length === 0 ? (
                  <div className="text-center py-12">
                    <Briefcase className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-xl font-medium text-gray-900 mb-2">No jobs found</h3>
                    <p className="text-gray-600 mb-6">
                      {hasSearched
                        ? 'Try adjusting your search criteria'
                        : 'No jobs are currently available'
                      }
                    </p>
                    {hasSearched && (
                      <button
                        onClick={handleClearSearch}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                      >
                        View All Jobs
                      </button>
                    )}
                  </div>
                ) : (
                  <>
                    {/* Debug info */}
                    {import.meta.env.DEV && (
                      <div className="mb-4 text-sm text-gray-500">
                        Debug: Showing {visibleJobs.length} jobs (hasSearched: {hasSearched.toString()}, searchResults: {searchResults ? 'exists' : 'null'})
                      </div>
                    )}
                  <div className={
                    viewMode === 'grid' 
                      ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' 
                      : 'space-y-4'
                  }>
                    {visibleJobs.map((job) => (
                      <JobCard 
                        key={job.id} 
                        job={job}
                        showApplyButton={!user || (user?.role === 'candidate' && !isApplied(job.id))}
                        showBidForRecruiter
                        onBid={() => { console.log('[BidModal] open from HomePage', { jobId: job.id, title: job.title }); setBidJob(job); }}
                        onApply={() => handleJobApply(job)}
                      />
                    ))}
                  </div>
                  </>
                )}
              </>
            )}

            {/* Load More Button */}
            {visibleJobs.length > 0 && sortedJobs.length > visibleJobs.length && (
              <div className="text-center mt-8">
                <button
                  onClick={() => setPageSize(ps => ps + 20)}
                  className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Load More Jobs
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Application Form Modal */}
      {bidJob && (
        <BidForm job={bidJob} onClose={() => { console.log('[BidModal] close'); setBidJob(null); }} />
      )}
      {showApplicationForm && selectedJob && user && (
        <JobApplicationForm
          job={selectedJob}
          onClose={() => {
            setShowApplicationForm(false);
            setSelectedJob(null);
          }}
          onSubmit={handleApplicationSubmit}
        />
      )}
    </div>
  );
};

export default HomePage;
