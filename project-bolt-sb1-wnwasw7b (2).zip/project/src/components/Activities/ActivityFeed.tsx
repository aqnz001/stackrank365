import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { Clock, User, Briefcase, FileText, Users, CheckCircle } from 'lucide-react';

interface Activity {
  id: string;
  userId: string;
  actorId: string;
  actionType: 'created' | 'updated' | 'applied' | 'submitted_bid' | 'accepted_bid' | 'approved_consent';
  entityType: 'job' | 'application' | 'bid' | 'consent';
  entityId: string;
  data: any;
  createdAt: Date;
  actorName?: string;
}

interface ActivityFeedProps {
  activities: Activity[];
  loading?: boolean;
}

const ActivityFeed: React.FC<ActivityFeedProps> = ({ activities, loading = false }) => {
  const { user } = useAuth();

  const getActivityIcon = (actionType: string, entityType: string) => {
    switch (entityType) {
      case 'job':
        return <Briefcase className="w-4 h-4" />;
      case 'application':
        return <FileText className="w-4 h-4" />;
      case 'bid':
        return <Users className="w-4 h-4" />;
      case 'consent':
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <User className="w-4 h-4" />;
    }
  };

  const getActivityColor = (actionType: string) => {
    switch (actionType) {
      case 'created':
        return 'text-blue-600 bg-blue-100';
      case 'applied':
        return 'text-green-600 bg-green-100';
      case 'submitted_bid':
        return 'text-purple-600 bg-purple-100';
      case 'accepted_bid':
        return 'text-green-600 bg-green-100';
      case 'approved_consent':
        return 'text-blue-600 bg-blue-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getActivityMessage = (activity: Activity) => {
    const actorName = activity.actorName || 'Someone';
    const isCurrentUser = activity.actorId === user?.id;
    const actor = isCurrentUser ? 'You' : actorName;

    switch (activity.actionType) {
      case 'created':
        if (activity.entityType === 'job') {
          return `${actor} posted a new job: ${activity.data.job_title || 'Untitled'}`;
        }
        break;
      case 'applied':
        return `${actor} applied to ${activity.data.job_title || 'a job'}`;
      case 'submitted_bid':
        return `${actor} submitted a bid for ${activity.data.job_title || 'a job'}`;
      case 'accepted_bid':
        return `${actor} accepted a recruiter bid for ${activity.data.job_title || 'a job'}`;
      case 'approved_consent':
        return `${actor} approved consent for ${activity.data.job_title || 'a job'}`;
      default:
        return `${actor} performed an action`;
    }
  };

  const getTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays}d ago`;
    
    const diffInWeeks = Math.floor(diffInDays / 7);
    return `${diffInWeeks}w ago`;
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="flex items-start space-x-3 animate-pulse">
            <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
            <div className="flex-1">
              <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-1/2"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (activities.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <Clock className="w-12 h-12 text-gray-300 mx-auto mb-4" />
        <p>No recent activity</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {activities.map((activity) => (
        <div key={activity.id} className="flex items-start space-x-3">
          <div className={`p-2 rounded-full ${getActivityColor(activity.actionType)}`}>
            {getActivityIcon(activity.actionType, activity.entityType)}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm text-gray-900">
              {getActivityMessage(activity)}
            </p>
            <div className="flex items-center mt-1 text-xs text-gray-500">
              <Clock className="w-3 h-3 mr-1" />
              {getTimeAgo(activity.createdAt)}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ActivityFeed;