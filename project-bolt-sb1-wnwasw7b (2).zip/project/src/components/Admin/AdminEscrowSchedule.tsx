import React from 'react';
import { supabase } from '../../lib/supabase';

const AdminEscrowSchedule: React.FC = () => {
  const [rows, setRows] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [status, setStatus] = React.useState<string>('all');

  const fetchRows = async () => {
    setLoading(true);
    const sel = `id, recruiter_bid_id, employer_org_name, recruiter_company, amount, currency, status, scheduled_payout_at`;
    const { data, error } = await supabase.from('escrow_transactions').select(sel).order('scheduled_payout_at', { ascending: true });
    if (!error) setRows(data || []);
    setLoading(false);
  };
  React.useEffect(()=>{ fetchRows(); }, []);

  const markReleased = async (id: string) => {
    const { error } = await supabase.from('escrow_transactions').update({ status: 'released', updated_at: new Date().toISOString() } as any).eq('id', id);
    if (!error) fetchRows();
  };

  const filtered = rows.filter(r => status==='all' ? true : r.status===status);

  if (loading) return <div className="text-sm text-gray-600">Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Escrow Payout Schedule</h3>
        <select value={status} onChange={e=>setStatus(e.target.value)} className="border rounded px-3 py-2 text-sm">
          {['all','initiated','authorized','captured','released','refunded','disputed'].map(s=> <option key={s} value={s}>{s}</option>)}
        </select>
      </div>
      <div className="overflow-auto border rounded">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-left px-3 py-2">When</th>
              <th className="text-left px-3 py-2">Employer</th>
              <th className="text-left px-3 py-2">Recruiter</th>
              <th className="text-left px-3 py-2">Amount</th>
              <th className="text-left px-3 py-2">Status</th>
              <th className="text-right px-3 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((r:any) => (
              <tr key={r.id} className="border-t">
                <td className="px-3 py-2">{r.scheduled_payout_at ? new Date(r.scheduled_payout_at).toLocaleString() : '—'}</td>
                <td className="px-3 py-2">{r.employer_org_name || '—'}</td>
                <td className="px-3 py-2">{r.recruiter_company || '—'}</td>
                <td className="px-3 py-2">{r.amount ? `${r.currency || 'USD'} ${Number(r.amount).toLocaleString()}` : '—'}</td>
                <td className="px-3 py-2">{r.status}</td>
                <td className="px-3 py-2 text-right">
                  {r.status !== 'released' && (
                    <button onClick={()=>markReleased(r.id)} className="px-3 py-1 border rounded">Mark Released</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminEscrowSchedule;

