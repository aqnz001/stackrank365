import React, { useState } from 'react';
import { usePlatformSettings } from '../../hooks/usePlatformSettings';
import { 
  Settings, 
  Save, 
  ToggleLeft, 
  ToggleRight,
  Plus,
  Edit,
  Trash2,
  Flag
} from 'lucide-react';

const PlatformSettings: React.FC = () => {
  const { 
    settings, 
    featureFlags, 
    loading, 
    updateSetting, 
    toggleFeatureFlag, 
    createFeatureFlag 
  } = usePlatformSettings();
  const [editingSettings, setEditingSettings] = useState<Record<string, any>>({});
  const [showNewFlagForm, setShowNewFlagForm] = useState(false);
  const [newFlag, setNewFlag] = useState({
    name: '',
    description: '',
    isEnabled: false,
    targetRoles: [] as string[],
  });

  const handleSettingChange = (key: string, value: any) => {
    setEditingSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleSaveSetting = async (key: string) => {
    try {
      await updateSetting(key, editingSettings[key]);
      setEditingSettings(prev => {
        const { [key]: removed, ...rest } = prev;
        return rest;
      });
    } catch (error) {
      console.error('Error saving setting:', error);
      alert('Failed to save setting');
    }
  };

  const handleToggleFlag = async (flagName: string, enabled: boolean) => {
    try {
      await toggleFeatureFlag(flagName, enabled);
    } catch (error) {
      console.error('Error toggling feature flag:', error);
      alert('Failed to toggle feature flag');
    }
  };

  const handleCreateFlag = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createFeatureFlag(newFlag);
      setNewFlag({ name: '', description: '', isEnabled: false, targetRoles: [] });
      setShowNewFlagForm(false);
    } catch (error) {
      console.error('Error creating feature flag:', error);
      alert('Failed to create feature flag');
    }
  };

  const settingsByCategory = settings.reduce((acc, setting) => {
    if (!acc[setting.category]) {
      acc[setting.category] = [];
    }
    acc[setting.category].push(setting);
    return acc;
  }, {} as Record<string, typeof settings>);

  const roles = ['admin', 'employer', 'recruiter', 'candidate'];

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Platform Settings</h2>
        <p className="text-gray-600">Configure platform behavior and features</p>
      </div>

      {/* Platform Settings */}
      <div className="space-y-6">
        {Object.entries(settingsByCategory).map(([category, categorySettings]) => (
          <div key={category} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 capitalize">
              {category} Settings
            </h3>
            <div className="space-y-4">
              {categorySettings.map((setting) => (
                <div key={setting.key} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3">
                      <Settings className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="font-medium text-gray-900">{setting.key.replace(/_/g, ' ')}</p>
                        {setting.description && (
                          <p className="text-sm text-gray-600">{setting.description}</p>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    {typeof setting.value === 'boolean' ? (
                      <button
                        onClick={() => handleSaveSetting(setting.key)}
                        className="flex items-center"
                      >
                        {setting.value ? (
                          <ToggleRight className="w-8 h-8 text-green-600" />
                        ) : (
                          <ToggleLeft className="w-8 h-8 text-gray-400" />
                        )}
                      </button>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <input
                          type={typeof setting.value === 'number' ? 'number' : 'text'}
                          value={editingSettings[setting.key] ?? setting.value}
                          onChange={(e) => handleSettingChange(setting.key, e.target.value)}
                          className="w-32 px-3 py-1 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                        />
                        {editingSettings[setting.key] !== undefined && (
                          <button
                            onClick={() => handleSaveSetting(setting.key)}
                            className="p-1 text-blue-600 hover:text-blue-700"
                          >
                            <Save className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Feature Flags */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Feature Flags</h3>
          <button
            onClick={() => setShowNewFlagForm(true)}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Feature Flag
          </button>
        </div>

        <div className="space-y-4">
          {featureFlags.map((flag) => (
            <div key={flag.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
              <div className="flex items-center space-x-3">
                <Flag className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="font-medium text-gray-900">{flag.name}</p>
                  {flag.description && (
                    <p className="text-sm text-gray-600">{flag.description}</p>
                  )}
                  {flag.targetRoles.length > 0 && (
                    <div className="flex space-x-1 mt-1">
                      {flag.targetRoles.map(role => (
                        <span key={role} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">
                          {role}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <span className="text-sm text-gray-600">{flag.rolloutPercentage}%</span>
                <button
                  onClick={() => handleToggleFlag(flag.name, !flag.isEnabled)}
                  className="flex items-center"
                >
                  {flag.isEnabled ? (
                    <ToggleRight className="w-8 h-8 text-green-600" />
                  ) : (
                    <ToggleLeft className="w-8 h-8 text-gray-400" />
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* New Feature Flag Form */}
      {showNewFlagForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-gray-900">Create Feature Flag</h3>
              <button
                onClick={() => setShowNewFlagForm(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <Plus className="w-6 h-6 rotate-45" />
              </button>
            </div>

            <form onSubmit={handleCreateFlag} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Flag Name
                </label>
                <input
                  type="text"
                  required
                  value={newFlag.name}
                  onChange={(e) => setNewFlag(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  placeholder="e.g., advanced_search"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  value={newFlag.description}
                  onChange={(e) => setNewFlag(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Describe what this feature flag controls..."
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Target Roles
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {roles.map(role => (
                    <label key={role} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={newFlag.targetRoles.includes(role)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setNewFlag(prev => ({ ...prev, targetRoles: [...prev.targetRoles, role] }));
                          } else {
                            setNewFlag(prev => ({ ...prev, targetRoles: prev.targetRoles.filter(r => r !== role) }));
                          }
                        }}
                        className="rounded border-gray-300 text-blue-600"
                      />
                      <span className="ml-2 text-sm text-gray-700 capitalize">{role}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  checked={newFlag.isEnabled}
                  onChange={(e) => setNewFlag(prev => ({ ...prev, isEnabled: e.target.checked }))}
                  className="rounded border-gray-300 text-blue-600"
                />
                <span className="ml-2 text-sm text-gray-700">Enable immediately</span>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowNewFlagForm(false)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Create Flag
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PlatformSettings;