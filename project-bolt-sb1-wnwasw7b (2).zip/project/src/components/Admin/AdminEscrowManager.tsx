import React, { useState } from 'react';
import { useEscrowPolicy } from '../../hooks/useEscrowPolicy';
import { useEscrowTransactions } from '../../hooks/useEscrowTransactions';
import { X, FileText, DollarSign, CheckCircle, AlertTriangle } from 'lucide-react';

interface Props { onClose: () => void }

const AdminEscrowManager: React.FC<Props> = ({ onClose }) => {
  const { policy, save } = useEscrowPolicy();
  const { items, updateStatus } = useEscrowTransactions();
  const [title, setTitle] = useState(policy?.title || 'Escrow Terms & Conditions');
  const [content, setContent] = useState(policy?.content || `Payments from employers are held in escrow by the platform and released to recruiters on successful placement per the guarantee terms. Refunds or releases follow the dispute resolution policy.`);

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-start justify-center overflow-auto">
      <div className="bg-white w-full max-w-5xl mt-16 mb-10 rounded-xl shadow-lg border">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="font-semibold text-gray-900">Escrow Manager</div>
          <button onClick={onClose} className="p-2 text-gray-500 hover:text-gray-700"><X className="w-5 h-5"/></button>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 p-4">
          <div className="border rounded">
            <div className="p-3 border-b flex items-center gap-2"><FileText className="w-4 h-4"/>Escrow Terms & Conditions</div>
            <div className="p-3 space-y-3">
              <input value={title} onChange={e=>setTitle(e.target.value)} className="w-full px-3 py-2 border rounded" />
              <textarea value={content} onChange={e=>setContent(e.target.value)} rows={14} className="w-full px-3 py-2 border rounded"></textarea>
              <div className="flex justify-end"><button onClick={()=>save({ title, content })} className="px-4 py-2 bg-blue-600 text-white rounded">Save Policy</button></div>
            </div>
          </div>
          <div className="border rounded">
            <div className="p-3 border-b flex items-center justify-between">
              <div className="flex items-center gap-2"><DollarSign className="w-4 h-4"/>Escrow Transactions</div>
              <div className="text-xs text-gray-600">{items.length} total</div>
            </div>
            <div className="max-h-[60vh] overflow-auto divide-y">
              {items.length === 0 ? (
                <div className="p-3 text-sm text-gray-500">No transactions yet.</div>
              ) : items.map(tx => (
                <div key={tx.id} className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="font-medium text-gray-900">{tx.employerOrganizationName || 'Employer'} → {tx.recruiterCompany || 'Recruiter'}</div>
                    <div className="text-xs text-gray-500">{new Date(tx.createdAt).toLocaleString()}</div>
                  </div>
                  <div className="text-sm text-gray-700">
                    Bid: {tx.recruiterBidId} • Fee: {tx.feeType==='percent' ? `${tx.feeValue}%` : `$${tx.feeValue.toLocaleString()}`} {tx.amount ? `(amount $${tx.amount.toLocaleString()})` : ''}
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    {(['initiated','authorized','captured','released','refunded','disputed'] as const).map(s => (
                      <button key={s} onClick={()=>updateStatus(tx.id, s)} className={`px-2 py-1 rounded text-xs border ${tx.status===s?'bg-blue-600 text-white border-blue-600':'bg-white text-gray-700 border-gray-300'}`}>{s}</button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div className="p-3 text-xs text-gray-500 border-t flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-yellow-600"/>
              Local, demo-only escrow list. Hook to backend when ready.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminEscrowManager;
