import React from 'react';
import { supabase } from '../../lib/supabase';

const AdminUsersOrgs: React.FC = () => {
  const [rows, setRows] = React.useState<any[]>([]);
  const [orgs, setOrgs] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(()=>{
    (async ()=>{
      setLoading(true);
      // profiles joined with organizations
      const { data, error } = await supabase
        .from('profiles')
        .select('id, email, name, role, organization_id, organizations:organizations!profiles_organization_id_fkey(name)');
      if (!error) setRows(data || []);
      const { data: orgData } = await supabase
        .from('organizations')
        .select('id, name')
        .order('name', { ascending: true });
      setOrgs(orgData || []);
      setLoading(false);
    })();
  },[]);

  const grouped = React.useMemo(()=>{
    const map: Record<string, any> = {};
    // Seed all organizations
    for (const o of orgs) {
      map[o.name || '—'] = [];
    }
    // Add users; place users without org under '—'
    for (const r of rows) {
      const org = r.organizations?.name || '—';
      if (!map[org]) map[org] = [];
      map[org].push(r);
    }
    return map;
  }, [rows, orgs]);

  if (loading) return <div className="text-sm text-gray-600">Loading…</div>;

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-gray-900">Users & Organizations</h3>
      {Object.keys(grouped).length === 0 ? (
        <div className="text-sm text-gray-600">No users found.</div>
      ) : (
        Object.entries(grouped).map(([org, list]) => (
          <div key={org} className="border rounded">
            <div className="px-4 py-2 bg-gray-50 font-medium text-gray-900">{org}</div>
            <div className="overflow-auto">
              <table className="min-w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left px-3 py-2">Name</th>
                    <th className="text-left px-3 py-2">Email</th>
                    <th className="text-left px-3 py-2">Role</th>
                    <th className="text-left px-3 py-2">User ID</th>
                  </tr>
                </thead>
                <tbody>
                  {(list as any[]).map(u => (
                    <tr key={u.id} className="border-t">
                      <td className="px-3 py-2 font-medium text-gray-900">{u.name || '—'}</td>
                      <td className="px-3 py-2">{u.email}</td>
                      <td className="px-3 py-2">{u.role}</td>
                      <td className="px-3 py-2">{u.id}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default AdminUsersOrgs;
