import React from 'react';
import { useSubscriptions } from '../../hooks/useSubscriptions';
import { supabase } from '../../lib/supabase';
import { AlertCircle, RefreshCw } from 'lucide-react';

interface ActiveSubscription {
  id: string;
  plan_name: string;
  status: string;
  billing_account_id: string;
  organization_name: string;
  created_at: string;
}

const AdminSubscriptionsManager: React.FC = () => {
  const { plans, refetch } = useSubscriptions();
  const [formOpen, setFormOpen] = React.useState(false);
  const [editingId, setEditingId] = React.useState<string | null>(null);
  const [name, setName] = React.useState('');
  const [description, setDescription] = React.useState('');
  const [amount, setAmount] = React.useState<number>(0);
  const [currency, setCurrency] = React.useState('usd');
  const [interval, setInterval] = React.useState<'month'|'year'>('month');
  const [audience, setAudience] = React.useState<'employer'|'recruiter'>('employer');
  const [features, setFeatures] = React.useState<string>('');
  const [limits, setLimits] = React.useState<string>('{"job_posts_per_month": 5}');
  const [active, setActive] = React.useState(true);
  const [from, setFrom] = React.useState<string>('');
  const [to, setTo] = React.useState<string>('');
  const [saving, setSaving] = React.useState(false);
  const [activeSubscriptions, setActiveSubscriptions] = React.useState<ActiveSubscription[]>([]);
  const [loadingSubscriptions, setLoadingSubscriptions] = React.useState(false);

  const openNew = () => {
    setEditingId(null);
    setName(''); setDescription(''); setAmount(0); setCurrency('usd'); setInterval('month'); setAudience('employer');
    setFeatures(''); setLimits('{"job_posts_per_month": 5}'); setActive(true); setFrom(''); setTo(''); setFormOpen(true);
  };
  const openEdit = (id: string) => {
    const p = plans.find(pl => pl.id === id)!;
    setEditingId(id);
    setName(p.name); setDescription(p.description || ''); setAmount(p.amount); setCurrency(p.currency);
    setInterval(p.billingInterval); setAudience(p.audience);
    setFeatures((p.features||[]).join('\n'));
    setLimits(JSON.stringify(p.limits||{}, null, 2));
    setActive(p.isActive);
    setFrom(p.availableFrom ? p.availableFrom.toISOString().slice(0,16) : '');
    setTo(p.availableTo ? p.availableTo.toISOString().slice(0,16) : '');
    setFormOpen(true);
  };

  const save = async () => {
    setSaving(true);
    try {
      const payload: any = {
        name, description, amount, currency,
        billing_interval: interval,
        audience,
        features: features.split('\n').map(s => s.trim()).filter(Boolean),
        limits: JSON.parse(limits || '{}'),
        is_active: active,
        available_from: from ? new Date(from).toISOString() : null,
        available_to: to ? new Date(to).toISOString() : null,
      };
      if (!editingId) {
        const { error } = await supabase.from('subscription_plans').insert(payload);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('subscription_plans').update(payload).eq('id', editingId);
        if (error) throw error;
      }
      setFormOpen(false);
      await refetch();
    } catch (e) {
      alert((e as any)?.message || 'Failed to save plan');
    } finally {
      setSaving(false);
    }
  };

  const loadActiveSubscriptions = async () => {
    setLoadingSubscriptions(true);
    try {
      const { data, error } = await supabase
        .from('subscriptions')
        .select(`
          id,
          plan_name,
          status,
          billing_account_id,
          created_at,
          billing_accounts!inner(
            organization_id,
            organizations!inner(name)
          )
        `)
        .in('status', ['active', 'trialing', 'past_due'])
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formatted = (data || []).map((sub: any) => ({
        id: sub.id,
        plan_name: sub.plan_name,
        status: sub.status,
        billing_account_id: sub.billing_account_id,
        organization_name: sub.billing_accounts?.organizations?.name || 'Unknown',
        created_at: sub.created_at,
      }));

      setActiveSubscriptions(formatted);
    } catch (e) {
      console.error('Error loading subscriptions:', e);
      alert('Failed to load subscriptions');
    } finally {
      setLoadingSubscriptions(false);
    }
  };

  const cancelSubscription = async (subId: string) => {
    if (!confirm('Cancel this subscription?')) return;
    try {
      const { error } = await supabase
        .from('subscriptions')
        .update({
          status: 'canceled',
          canceled_at: new Date().toISOString(),
        })
        .eq('id', subId);

      if (error) throw error;
      alert('Subscription canceled');
      await loadActiveSubscriptions();
    } catch (e) {
      alert('Failed to cancel subscription');
    }
  };

  React.useEffect(() => {
    loadActiveSubscriptions();
  }, []);

  return (
    <div className="space-y-6">
      {/* Active Subscriptions Debugger */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-orange-500" />
            Active Subscriptions (Debug)
          </h3>
          <button
            onClick={loadActiveSubscriptions}
            disabled={loadingSubscriptions}
            className="flex items-center gap-2 px-3 py-2 text-sm border rounded hover:bg-gray-50"
          >
            <RefreshCw className={`w-4 h-4 ${loadingSubscriptions ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>

        <div className="overflow-auto border rounded">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left px-3 py-2">Organization</th>
                <th className="text-left px-3 py-2">Plan Name</th>
                <th className="text-left px-3 py-2">Status</th>
                <th className="text-left px-3 py-2">Created</th>
                <th className="text-right px-3 py-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {activeSubscriptions.length === 0 && !loadingSubscriptions && (
                <tr>
                  <td colSpan={5} className="px-3 py-4 text-center text-gray-500">
                    No active subscriptions found
                  </td>
                </tr>
              )}
              {activeSubscriptions.map(sub => (
                <tr key={sub.id} className="border-t">
                  <td className="px-3 py-2 font-medium">{sub.organization_name}</td>
                  <td className="px-3 py-2">{sub.plan_name}</td>
                  <td className="px-3 py-2">
                    <span className={`px-2 py-0.5 rounded text-xs ${
                      sub.status === 'active' ? 'bg-green-100 text-green-800' :
                      sub.status === 'trialing' ? 'bg-blue-100 text-blue-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {sub.status}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-xs text-gray-600">
                    {new Date(sub.created_at).toLocaleString()}
                  </td>
                  <td className="px-3 py-2 text-right">
                    <button
                      onClick={() => cancelSubscription(sub.id)}
                      className="px-2 py-1 text-xs border border-red-300 text-red-700 rounded hover:bg-red-50"
                    >
                      Cancel
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Subscription Plans */}
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-900">Subscription Plans</h3>
        <button onClick={openNew} className="px-3 py-2 bg-blue-600 text-white rounded">New Plan</button>
      </div>
      <div className="overflow-auto border rounded">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-left px-3 py-2">Name</th>
              <th className="text-left px-3 py-2">Audience</th>
              <th className="text-left px-3 py-2">Amount</th>
              <th className="text-left px-3 py-2">Interval</th>
              <th className="text-left px-3 py-2">Active</th>
              <th className="text-right px-3 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {plans.map(p => (
              <tr key={p.id} className="border-t">
                <td className="px-3 py-2 font-medium text-gray-900">{p.name}</td>
                <td className="px-3 py-2">{p.audience}</td>
                <td className="px-3 py-2">{(p.amount/100).toLocaleString(undefined,{style:'currency',currency:p.currency}).replace('US$','$')}</td>
                <td className="px-3 py-2">{p.billingInterval}</td>
                <td className="px-3 py-2">{p.isActive ? 'Yes' : 'No'}</td>
                <td className="px-3 py-2 text-right">
                  <button onClick={()=>openEdit(p.id)} className="px-2 py-1 border rounded">Edit</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {formOpen && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/40" onClick={()=>setFormOpen(false)} />
          <div className="absolute inset-0 flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden">
              <div className="px-6 py-4 border-b font-semibold">{editingId ? 'Edit Plan' : 'New Plan'}</div>
              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm mb-1">Name</label>
                  <input value={name} onChange={e=>setName(e.target.value)} className="w-full border rounded px-3 py-2" />
                </div>
                <div>
                  <label className="block text-sm mb-1">Audience</label>
                  <select value={audience} onChange={e=>setAudience(e.target.value as any)} className="w-full border rounded px-3 py-2">
                    <option value="employer">Employer</option>
                    <option value="recruiter">Recruiter</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm mb-1">Amount (cents)</label>
                  <input type="number" value={amount} onChange={e=>setAmount(parseInt(e.target.value||'0'))} className="w-full border rounded px-3 py-2" />
                </div>
                <div>
                  <label className="block text-sm mb-1">Currency</label>
                  <input value={currency} onChange={e=>setCurrency(e.target.value)} className="w-full border rounded px-3 py-2" />
                </div>
                <div>
                  <label className="block text-sm mb-1">Interval</label>
                  <select value={interval} onChange={e=>setInterval(e.target.value as any)} className="w-full border rounded px-3 py-2">
                    <option value="month">Monthly</option>
                    <option value="year">Annual</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm mb-1">Active</label>
                  <select value={active? 'yes':'no'} onChange={e=>setActive(e.target.value==='yes')} className="w-full border rounded px-3 py-2">
                    <option value="yes">Yes</option>
                    <option value="no">No</option>
                  </select>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm mb-1">Available From / To</label>
                  <div className="grid grid-cols-2 gap-3">
                    <input type="datetime-local" value={from} onChange={e=>setFrom(e.target.value)} className="w-full border rounded px-3 py-2" />
                    <input type="datetime-local" value={to} onChange={e=>setTo(e.target.value)} className="w-full border rounded px-3 py-2" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm mb-1">Features (one per line)</label>
                  <textarea rows={5} value={features} onChange={e=>setFeatures(e.target.value)} className="w-full border rounded px-3 py-2" />
                </div>
                <div>
                  <label className="block text-sm mb-1">Limits (JSON)</label>
                  <textarea rows={5} value={limits} onChange={e=>setLimits(e.target.value)} className="w-full border rounded px-3 py-2 font-mono text-xs" />
                </div>
              </div>
              <div className="px-6 py-4 border-t flex justify-end gap-2">
                <button onClick={()=>setFormOpen(false)} className="px-4 py-2 border rounded">Cancel</button>
                <button onClick={save} disabled={saving} className="px-4 py-2 bg-blue-600 text-white rounded">{saving ? 'Saving…' : 'Save Plan'}</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminSubscriptionsManager;

