import React, { useState } from 'react';
import { FileText, Play, RefreshCw, CheckCircle, XCircle, AlertCircle, Loader } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import toast from 'react-hot-toast';

interface BatchResult {
  total: number;
  alreadyParsed: number;
  parsed: number;
  failed: number;
  skipped: number;
  details: Array<{
    fileId: string;
    status: string;
    skills?: number;
    experiences?: number;
    error?: string;
  }>;
}

const BatchResumeParser: React.FC = () => {
  const [processing, setProcessing] = useState(false);
  const [dryRun, setDryRun] = useState(true);
  const [limit, setLimit] = useState(10);
  const [result, setResult] = useState<BatchResult | null>(null);

  const handleBatchParse = async () => {
    try {
      setProcessing(true);
      setResult(null);

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('You must be logged in to perform this action');
        return;
      }

      const edgeUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/parse-existing-resumes`;

      const response = await fetch(edgeUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          limit,
          dryRun,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        let errorData;
        try {
          errorData = JSON.parse(errorText);
        } catch {
          throw new Error(`Server error: ${response.status} ${errorText}`);
        }
        throw new Error(errorData.error || 'Failed to parse resumes');
      }

      const data = await response.json();
      console.log('Batch parse response:', data);

      if (!data.results) {
        throw new Error('Invalid response from server: missing results');
      }

      setResult(data.results);

      if (dryRun) {
        toast.success(`Dry run complete: ${data.results.total} resumes analyzed`);
      } else {
        toast.success(`Batch parsing complete: ${data.results.parsed} resumes parsed`);
      }
    } catch (error: any) {
      console.error('Error batch parsing resumes:', error);
      toast.error(error.message || 'Failed to parse resumes');
    } finally {
      setProcessing(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'parsed':
      case 'would_parse':
      case 'already_parsed':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'error':
      case 'fetch_failed':
      case 'fetch_error':
        return <XCircle className="w-4 h-4 text-red-600" />;
      case 'url_error':
        return <AlertCircle className="w-4 h-4 text-orange-600" />;
      default:
        return <AlertCircle className="w-4 h-4 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'parsed':
      case 'would_parse':
        return 'bg-green-50 border-green-200 text-green-800';
      case 'already_parsed':
        return 'bg-blue-50 border-blue-200 text-blue-800';
      case 'error':
      case 'fetch_failed':
      case 'fetch_error':
        return 'bg-red-50 border-red-200 text-red-800';
      case 'url_error':
        return 'bg-orange-50 border-orange-200 text-orange-800';
      default:
        return 'bg-gray-50 border-gray-200 text-gray-800';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border p-6">
      <div className="flex items-center gap-3 mb-6">
        <FileText className="w-6 h-6 text-blue-600" />
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Batch Resume Parser</h3>
          <p className="text-sm text-gray-600">Parse all existing resumes to populate the resume_parsed_data table</p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Batch Size
            </label>
            <input
              type="number"
              min="1"
              max="100"
              value={limit}
              onChange={(e) => setLimit(parseInt(e.target.value) || 10)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              disabled={processing}
            />
            <p className="text-xs text-gray-500 mt-1">Number of resumes to process per batch (max 100)</p>
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
              <input
                type="checkbox"
                checked={dryRun}
                onChange={(e) => setDryRun(e.target.checked)}
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                disabled={processing}
              />
              Dry Run Mode
            </label>
            <p className="text-xs text-gray-500 mt-1">
              {dryRun
                ? 'Analyze resumes without saving parsed data'
                : 'Parse and save data to database'}
            </p>
          </div>
        </div>

        <div className="pt-4 border-t">
          <button
            onClick={handleBatchParse}
            disabled={processing}
            className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {processing ? (
              <>
                <Loader className="w-5 h-5 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Play className="w-5 h-5" />
                {dryRun ? 'Run Analysis' : 'Start Batch Parsing'}
              </>
            )}
          </button>
        </div>

        {result && (
          <div className="mt-6 space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                <div className="text-2xl font-bold text-gray-900">{result.total}</div>
                <div className="text-xs text-gray-600 mt-1">Total Resumes</div>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="text-2xl font-bold text-green-900">{result.parsed}</div>
                <div className="text-xs text-green-700 mt-1">{dryRun ? 'Would Parse' : 'Parsed'}</div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="text-2xl font-bold text-blue-900">{result.alreadyParsed}</div>
                <div className="text-xs text-blue-700 mt-1">Already Parsed</div>
              </div>

              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <div className="text-2xl font-bold text-orange-900">{result.skipped}</div>
                <div className="text-xs text-orange-700 mt-1">Skipped</div>
              </div>

              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="text-2xl font-bold text-red-900">{result.failed}</div>
                <div className="text-xs text-red-700 mt-1">Failed</div>
              </div>
            </div>

            <div className="border border-gray-200 rounded-lg overflow-hidden">
              <div className="bg-gray-50 px-4 py-2 border-b border-gray-200">
                <h4 className="text-sm font-medium text-gray-900">Processing Details</h4>
              </div>
              <div className="max-h-96 overflow-y-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">File ID</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Skills</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Experiences</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Error</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {result.details.map((detail, index) => (
                      <tr key={index} className={getStatusColor(detail.status)}>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            {getStatusIcon(detail.status)}
                            <span className="text-xs font-medium">{detail.status.replace(/_/g, ' ')}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className="text-xs font-mono">{detail.fileId.slice(0, 8)}...</span>
                        </td>
                        <td className="px-4 py-3">
                          <span className="text-xs">{detail.skills || '-'}</span>
                        </td>
                        <td className="px-4 py-3">
                          <span className="text-xs">{detail.experiences || '-'}</span>
                        </td>
                        <td className="px-4 py-3">
                          <span className="text-xs text-gray-600">{detail.error || '-'}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {dryRun && result.parsed > 0 && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-medium text-blue-900 mb-1">Ready to Parse</h4>
                    <p className="text-sm text-blue-800">
                      {result.parsed} resumes are ready to be parsed. Uncheck "Dry Run Mode" and run again to save the parsed data to the database.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default BatchResumeParser;
