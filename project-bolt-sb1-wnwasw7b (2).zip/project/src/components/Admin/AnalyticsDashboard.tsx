import React, { useState } from 'react';
import { useAnalytics } from '../../hooks/useAnalytics';
import { 
  TrendingUp, 
  Users, 
  DollarSign, 
  Briefcase,
  Calendar,
  Download,
  RefreshCw,
  BarChart3,
  PieChart,
  Activity,
  Target
} from 'lucide-react';

const AnalyticsDashboard: React.FC = () => {
  const { 
    platformMetrics, 
    userEngagement, 
    revenueMetrics, 
    jobMetrics,
    loading,
    error,
    generateReport,
    refetch
  } = useAnalytics();
  const [selectedTimeframe, setSelectedTimeframe] = useState('30d');
  const [generatingReport, setGeneratingReport] = useState(false);

  const timeframes = [
    { value: '7d', label: 'Last 7 days' },
    { value: '30d', label: 'Last 30 days' },
    { value: '90d', label: 'Last 90 days' },
    { value: '1y', label: 'Last year' },
  ];

  const handleGenerateReport = async (reportType: string) => {
    setGeneratingReport(true);
    try {
      await generateReport(reportType, { timeframe: selectedTimeframe });
      alert('Report generation started. You will be notified when it\'s ready.');
    } catch (error) {
      console.error('Error generating report:', error);
      alert('Failed to generate report. Please try again.');
    } finally {
      setGeneratingReport(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <p className="text-red-800">Error loading analytics: {error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Platform Analytics</h2>
          <p className="text-gray-600">Comprehensive insights into platform performance</p>
        </div>
        <div className="flex space-x-3">
          <select
            value={selectedTimeframe}
            onChange={(e) => setSelectedTimeframe(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
          >
            {timeframes.map(timeframe => (
              <option key={timeframe.value} value={timeframe.value}>
                {timeframe.label}
              </option>
            ))}
          </select>
          <button
            onClick={refetch}
            className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </button>
          <button
            onClick={() => handleGenerateReport('comprehensive')}
            disabled={generatingReport}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            <Download className="w-4 h-4 mr-2" />
            {generatingReport ? 'Generating...' : 'Export Report'}
          </button>
        </div>
      </div>

      {/* Platform Overview */}
      {platformMetrics && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Platform Overview</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-blue-100">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
                <div className="ml-4">
                  <h4 className="text-2xl font-bold text-gray-900">{platformMetrics.totalUsers.toLocaleString()}</h4>
                  <p className="text-gray-600 text-sm">Total Users</p>
                  <p className="text-green-600 text-xs">+12% this month</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-green-100">
                  <Briefcase className="w-6 h-6 text-green-600" />
                </div>
                <div className="ml-4">
                  <h4 className="text-2xl font-bold text-gray-900">{platformMetrics.totalJobs.toLocaleString()}</h4>
                  <p className="text-gray-600 text-sm">Total Jobs</p>
                  <p className="text-green-600 text-xs">+8% this month</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-purple-100">
                  <DollarSign className="w-6 h-6 text-purple-600" />
                </div>
                <div className="ml-4">
                  <h4 className="text-2xl font-bold text-gray-900">${platformMetrics.totalRevenue.toLocaleString()}</h4>
                  <p className="text-gray-600 text-sm">Total Revenue</p>
                  <p className="text-green-600 text-xs">+23% this month</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-orange-100">
                  <Target className="w-6 h-6 text-orange-600" />
                </div>
                <div className="ml-4">
                  <h4 className="text-2xl font-bold text-gray-900">{platformMetrics.conversionRate}%</h4>
                  <p className="text-gray-600 text-sm">Conversion Rate</p>
                  <p className="text-green-600 text-xs">+2.1% this month</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* User Engagement */}
      {userEngagement && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">User Engagement</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-medium text-gray-900">Active Users</h4>
                <Activity className="w-5 h-5 text-gray-400" />
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Daily</span>
                  <span className="font-semibold">{userEngagement.dailyActiveUsers.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Weekly</span>
                  <span className="font-semibold">{userEngagement.weeklyActiveUsers.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Monthly</span>
                  <span className="font-semibold">{userEngagement.monthlyActiveUsers.toLocaleString()}</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-medium text-gray-900">Session Metrics</h4>
                <BarChart3 className="w-5 h-5 text-gray-400" />
              </div>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Avg Duration</span>
                  <span className="font-semibold">{userEngagement.averageSessionDuration}m</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Bounce Rate</span>
                  <span className="font-semibold">{userEngagement.bounceRate}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Retention</span>
                  <span className="font-semibold text-green-600">{userEngagement.retentionRate}%</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-medium text-gray-900">Growth Trends</h4>
                <TrendingUp className="w-5 h-5 text-green-500" />
              </div>
              <div className="h-32 flex items-center justify-center bg-gray-50 rounded-lg">
                <p className="text-gray-500 text-sm">Growth chart visualization</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Revenue Analytics */}
      {revenueMetrics && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue Analytics</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-gray-900">Monthly Revenue</h4>
                <DollarSign className="w-5 h-5 text-green-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">
                ${revenueMetrics.monthlyRecurringRevenue.toLocaleString()}
              </div>
              <p className="text-green-600 text-sm">+{revenueMetrics.revenueGrowthRate}% growth</p>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-gray-900">ARPU</h4>
                <Users className="w-5 h-5 text-blue-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">
                ${revenueMetrics.averageRevenuePerUser.toLocaleString()}
              </div>
              <p className="text-gray-600 text-sm">Average Revenue Per User</p>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-gray-900">LTV</h4>
                <TrendingUp className="w-5 h-5 text-purple-600" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">
                ${revenueMetrics.lifetimeValue.toLocaleString()}
              </div>
              <p className="text-gray-600 text-sm">Customer Lifetime Value</p>
            </div>
          </div>
        </div>
      )}

      {/* Job Performance */}
      {jobMetrics && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Job Performance</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 text-center">
              <Briefcase className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">{jobMetrics.totalJobsPosted}</div>
              <div className="text-sm text-gray-600">Jobs Posted</div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 text-center">
              <Users className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">{jobMetrics.averageApplicationsPerJob}</div>
              <div className="text-sm text-gray-600">Avg Applications/Job</div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 text-center">
              <Target className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">{jobMetrics.averageBidsPerJob}</div>
              <div className="text-sm text-gray-600">Avg Bids/Job</div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 text-center">
              <TrendingUp className="w-8 h-8 text-orange-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">{jobMetrics.jobFillRate}%</div>
              <div className="text-sm text-gray-600">Fill Rate</div>
            </div>
          </div>
        </div>
      )}

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Revenue Trends</h3>
            <BarChart3 className="w-5 h-5 text-gray-400" />
          </div>
          <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
            <div className="text-center">
              <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">Revenue chart visualization</p>
              <p className="text-sm text-gray-400">Integration with charting library needed</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">User Distribution</h3>
            <PieChart className="w-5 h-5 text-gray-400" />
          </div>
          <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
            <div className="text-center">
              <PieChart className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">User distribution chart</p>
              <p className="text-sm text-gray-400">By role, location, activity</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Reports</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <button
            onClick={() => handleGenerateReport('user_activity')}
            className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 text-left"
          >
            <Users className="w-6 h-6 text-blue-600 mb-2" />
            <div className="font-medium text-gray-900">User Activity</div>
            <div className="text-sm text-gray-600">Login patterns, engagement</div>
          </button>

          <button
            onClick={() => handleGenerateReport('revenue_breakdown')}
            className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 text-left"
          >
            <DollarSign className="w-6 h-6 text-green-600 mb-2" />
            <div className="font-medium text-gray-900">Revenue Breakdown</div>
            <div className="text-sm text-gray-600">By tier, organization, time</div>
          </button>

          <button
            onClick={() => handleGenerateReport('job_performance')}
            className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 text-left"
          >
            <Briefcase className="w-6 h-6 text-purple-600 mb-2" />
            <div className="font-medium text-gray-900">Job Performance</div>
            <div className="text-sm text-gray-600">Applications, success rates</div>
          </button>

          <button
            onClick={() => handleGenerateReport('platform_health')}
            className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 text-left"
          >
            <Activity className="w-6 h-6 text-orange-600 mb-2" />
            <div className="font-medium text-gray-900">Platform Health</div>
            <div className="text-sm text-gray-600">System metrics, performance</div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsDashboard;