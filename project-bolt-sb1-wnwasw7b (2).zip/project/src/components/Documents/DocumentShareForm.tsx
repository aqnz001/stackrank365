import React, { useState } from 'react';
import { useDocumentSharing } from '../../hooks/useDocumentSharing';
import { useFileUpload } from '../../hooks/useFileUpload';
import FileUploadZone from '../FileUpload/FileUploadZone';
import { X, Share, Lock, Calendar, Eye, Download, Edit } from 'lucide-react';

interface DocumentShareFormProps {
  applicationId?: string;
  recruiterBidId?: string;
  recipientId: string;
  recipientName: string;
  onClose: () => void;
}

const DocumentShareForm: React.FC<DocumentShareFormProps> = ({
  applicationId,
  recruiterBidId,
  recipientId,
  recipientName,
  onClose,
}) => {
  const { shareDocument } = useDocumentSharing();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadedFile, setUploadedFile] = useState<any>(null);
  const [formData, setFormData] = useState({
    accessLevel: 'view' as const,
    expiresIn: '30',
    passwordProtected: false,
    password: '',
    message: '',
  });

  const accessLevels = [
    { value: 'view', label: 'View Only', icon: <Eye className="w-4 h-4" />, description: 'Can view but not download' },
    { value: 'download', label: 'View & Download', icon: <Download className="w-4 h-4" />, description: 'Can view and download' },
    { value: 'edit', label: 'Full Access', icon: <Edit className="w-4 h-4" />, description: 'Can view, download, and edit' },
  ];

  const expirationOptions = [
    { value: '1', label: '1 day' },
    { value: '7', label: '1 week' },
    { value: '30', label: '1 month' },
    { value: '90', label: '3 months' },
    { value: '', label: 'Never expires' },
  ];

  const handleFileUpload = (file: any) => {
    setUploadedFile(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!uploadedFile) {
      setError('Please upload a document to share');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      console.log('Submitting document share form with data:', {
        fileUploadId: uploadedFile.id,
        sharedWithId: recipientId,
        accessLevel: formData.accessLevel,
        expiresIn: formData.expiresIn,
        passwordProtected: formData.passwordProtected
      });
      
      const expiresAt = formData.expiresIn 
        ? new Date(Date.now() + parseInt(formData.expiresIn) * 24 * 60 * 60 * 1000)
        : undefined;

      await shareDocument({
        fileUploadId: uploadedFile.id,
        sharedWithId: recipientId,
        applicationId,
        recruiterBidId,
        accessLevel: formData.accessLevel,
        expiresAt,
        password: formData.passwordProtected ? formData.password : undefined,
      });

      console.log('Document shared successfully');
      onClose();
    } catch (err) {
      console.error('Error sharing document:', err);
      setError(err instanceof Error ? err.message : 'Failed to share document');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold text-gray-900">Share Document</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 p-2"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-center">
            <Share className="w-5 h-5 text-blue-600 mr-2" />
            <p className="text-blue-800">
              Sharing with: <span className="font-medium">{recipientName}</span>
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* File Upload */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Document to Share
            </label>
            <FileUploadZone
              options={{
                bucket: 'documents',
                fileType: 'document',
                maxSize: 20 * 1024 * 1024, // 20MB
              }}
              onUploadComplete={handleFileUpload}
              onUploadError={(error) => setError(error)}
            />
          </div>

          {/* Access Level */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Access Level
            </label>
            <div className="space-y-3">
              {accessLevels.map(level => (
                <label key={level.value} className="cursor-pointer">
                  <input
                    type="radio"
                    name="accessLevel"
                    value={level.value}
                    checked={formData.accessLevel === level.value}
                    onChange={(e) => setFormData(prev => ({ ...prev, accessLevel: e.target.value as any }))}
                    className="sr-only"
                  />
                  <div className={`p-3 border-2 rounded-lg transition-all ${
                    formData.accessLevel === level.value
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}>
                    <div className="flex items-center">
                      {level.icon}
                      <div className="ml-3">
                        <div className="font-medium text-gray-900">{level.label}</div>
                        <div className="text-sm text-gray-600">{level.description}</div>
                      </div>
                    </div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Expiration */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Calendar className="w-4 h-4 inline mr-1" />
              Access Expires
            </label>
            <select
              value={formData.expiresIn}
              onChange={(e) => setFormData(prev => ({ ...prev, expiresIn: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            >
              {expirationOptions.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          {/* Password Protection */}
          <div>
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={formData.passwordProtected}
                onChange={(e) => setFormData(prev => ({ ...prev, passwordProtected: e.target.checked }))}
                className="rounded border-gray-300 text-blue-600"
              />
              <Lock className="w-4 h-4 ml-2 mr-1" />
              <span className="text-sm text-gray-700">Password protect this document</span>
            </label>
            
            {formData.passwordProtected && (
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter password"
                required
              />
            )}
          </div>

          {/* Message */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Message (Optional)
            </label>
            <textarea
              rows={3}
              value={formData.message}
              onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              placeholder="Add a message about this document..."
            />
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-800">{error}</p>
            </div>
          )}

          <div className="flex justify-end space-x-4 pt-6 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !uploadedFile}
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              {isSubmitting ? 'Sharing...' : 'Share Document'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DocumentShareForm;