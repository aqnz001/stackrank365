import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { 
  CheckCircle, 
  Clock, 
  XCircle, 
  ArrowRight,
  User,
  Calendar,
  MessageSquare,
  FileText
} from 'lucide-react';

interface StatusUpdate {
  id: string;
  entityType: 'application' | 'recruiter_bid' | 'interview' | 'job';
  entityId: string;
  oldStatus?: string;
  newStatus: string;
  changedBy?: string;
  changedByName?: string;
  reason?: string;
  notes?: string;
  metadata: any;
  createdAt: Date;
}

interface StatusTrackerProps {
  entityType: 'application' | 'recruiter_bid' | 'interview' | 'job';
  entityId: string;
  currentStatus: string;
  onStatusChange?: (newStatus: string, reason?: string) => void;
}

const StatusTracker: React.FC<StatusTrackerProps> = ({
  entityType,
  entityId,
  currentStatus,
  onStatusChange,
}) => {
  const [statusHistory, setStatusHistory] = useState<StatusUpdate[]>([]);
  const [loading, setLoading] = useState(true);
  const [showChangeForm, setShowChangeForm] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [reason, setReason] = useState('');
  const { user } = useAuth();

  const fetchStatusHistory = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('status_updates')
        .select(`
          *,
          profiles!status_updates_changed_by_fkey (
            name
          )
        `)
        .eq('entity_type', entityType)
        .eq('entity_id', entityId)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const transformedUpdates: StatusUpdate[] = (data || []).map(update => ({
        id: update.id,
        entityType: update.entity_type,
        entityId: update.entity_id,
        oldStatus: update.old_status,
        newStatus: update.new_status,
        changedBy: update.changed_by,
        changedByName: update.profiles?.name,
        reason: update.reason,
        notes: update.notes,
        metadata: update.metadata,
        createdAt: new Date(update.created_at),
      }));

      setStatusHistory(transformedUpdates);
    } catch (err) {
      console.error('Error fetching status history:', err);
    } finally {
      setLoading(false);
    }
  };

  const getStatusOptions = () => {
    switch (entityType) {
      case 'application':
        return [
          { value: 'submitted', label: 'Submitted' },
          { value: 'shortlisted', label: 'Shortlisted' },
          { value: 'rejected', label: 'Rejected' },
          { value: 'hired', label: 'Hired' },
          { value: 'withdrawn', label: 'Withdrawn' },
        ];
      case 'recruiter_bid':
        return [
          { value: 'submitted', label: 'Submitted' },
          { value: 'accepted', label: 'Accepted' },
          { value: 'rejected', label: 'Rejected' },
          { value: 'withdrawn', label: 'Withdrawn' },
          { value: 'expired', label: 'Expired' },
        ];
      case 'interview':
        return [
          { value: 'scheduled', label: 'Scheduled' },
          { value: 'confirmed', label: 'Confirmed' },
          { value: 'rescheduled', label: 'Rescheduled' },
          { value: 'completed', label: 'Completed' },
          { value: 'cancelled', label: 'Cancelled' },
          { value: 'no_show', label: 'No Show' },
        ];
      case 'job':
        return [
          { value: 'open', label: 'Open' },
          { value: 'closed', label: 'Closed' },
          { value: 'draft', label: 'Draft' },
          { value: 'on_hold', label: 'On Hold' },
          { value: 'filled', label: 'Filled' },
        ];
      default:
        return [];
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'submitted':
      case 'scheduled':
      case 'open':
        return <Clock className="w-4 h-4 text-blue-600" />;
      case 'shortlisted':
      case 'confirmed':
      case 'accepted':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'completed':
      case 'hired':
      case 'filled':
        return <CheckCircle className="w-4 h-4 text-purple-600" />;
      case 'rejected':
      case 'cancelled':
      case 'closed':
        return <XCircle className="w-4 h-4 text-red-600" />;
      default:
        return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const handleStatusChange = async () => {
    if (!newStatus || !onStatusChange) return;

    try {
      await onStatusChange(newStatus, reason);
      
      // Log the status change
      await supabase.from('status_updates').insert({
        entity_type: entityType,
        entity_id: entityId,
        old_status: currentStatus,
        new_status: newStatus,
        changed_by: user?.id,
        reason: reason || null,
      });

      setShowChangeForm(false);
      setNewStatus('');
      setReason('');
      await fetchStatusHistory();
    } catch (error) {
      console.error('Error changing status:', error);
      alert('Failed to update status');
    }
  };

  useEffect(() => {
    fetchStatusHistory();
  }, [entityType, entityId]);

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-gray-200 rounded w-1/3"></div>
          <div className="space-y-3">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                <div className="flex-1 h-4 bg-gray-200 rounded"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Status History</h3>
        {onStatusChange && (
          <button
            onClick={() => setShowChangeForm(true)}
            className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm"
          >
            Update Status
          </button>
        )}
      </div>

      <div className="space-y-4">
        {statusHistory.map((update, index) => (
          <div key={update.id} className="flex items-start space-x-3">
            <div className="flex-shrink-0 mt-1">
              {getStatusIcon(update.newStatus)}
            </div>
            
            <div className="flex-1">
              <div className="flex items-center space-x-2">
                {update.oldStatus && (
                  <>
                    <span className="text-sm text-gray-600">{update.oldStatus}</span>
                    <ArrowRight className="w-3 h-3 text-gray-400" />
                  </>
                )}
                <span className="text-sm font-medium text-gray-900">{update.newStatus}</span>
              </div>
              
              <div className="flex items-center space-x-4 mt-1 text-xs text-gray-500">
                <div className="flex items-center">
                  <User className="w-3 h-3 mr-1" />
                  {update.changedByName || 'System'}
                </div>
                <div className="flex items-center">
                  <Calendar className="w-3 h-3 mr-1" />
                  {update.createdAt.toLocaleDateString()} {update.createdAt.toLocaleTimeString()}
                </div>
              </div>
              
              {update.reason && (
                <p className="text-sm text-gray-600 mt-2">{update.reason}</p>
              )}
              
              {update.notes && (
                <div className="mt-2 p-2 bg-gray-50 rounded text-sm text-gray-700">
                  {update.notes}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Status Change Form */}
      {showChangeForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 z-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Update Status</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  New Status
                </label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Select new status...</option>
                  {getStatusOptions()
                    .filter(option => option.value !== currentStatus)
                    .map(option => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Reason (Optional)
                </label>
                <textarea
                  rows={3}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Explain the reason for this status change..."
                />
              </div>
            </div>

            <div className="flex justify-end space-x-3 mt-6">
              <button
                onClick={() => setShowChangeForm(false)}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleStatusChange}
                disabled={!newStatus}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                Update Status
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StatusTracker;
