import React, { useState } from 'react';
import { useBilling } from '../../hooks/useBilling';
import { useSubscriptions } from '../../hooks/useSubscriptions';
import { usePayments } from '../../hooks/usePayments';
import PaymentMethodManager from '../Payments/PaymentMethodManager';
import { useAuth } from '../../context/AuthContext';
import BillingAccountForm from './BillingAccountForm';
import PaymentMethodCard from './PaymentMethodCard';
import InvoiceCard from './InvoiceCard';
import SubscriptionManager from '../Payments/SubscriptionManager';
import EscrowManager from '../Payments/EscrowManager';
import PaymentForm from '../Payments/PaymentForm';
import { formatCurrency } from '../../lib/stripe';
import { 
  CreditCard, 
  FileText, 
  DollarSign, 
  Calendar,
  Plus,
  Settings,
  Download,
  AlertCircle,
  Shield,
  Crown,
  Share,
  HardDrive
} from 'lucide-react';

const BillingDashboard: React.FC = () => {
  const { user } = useAuth();
  const { 
    billingAccount, 
    paymentMethods, 
    invoices, 
    payments, 
    loading, 
    error 
  } = useBilling();
  const { currentSubscription, usage, getUsageSummary } = useSubscriptions();
  const { paymentMethods: stripePaymentMethods } = usePayments();
  const [activeTab, setActiveTab] = useState('overview');
  const [showBillingForm, setShowBillingForm] = useState(false);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [paymentData, setPaymentData] = useState<any>(null);

  const usageSummary = getUsageSummary();
  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'subscription', label: 'Subscription' },
    { id: 'payment-methods', label: 'Payment Methods' },
    { id: 'invoices', label: 'Invoices' },
    { id: 'payments', label: 'Payment History' },
    { id: 'documents', label: 'Documents' },
    { id: 'escrow', label: 'Escrow' },
    { id: 'settings', label: 'Billing Settings' },
  ];

  const stats = [
    {
      icon: <DollarSign className="w-6 h-6" />,
      label: 'Outstanding Balance',
      value: formatCurrency(invoices.filter(i => i.status === 'open').reduce((sum, i) => sum + i.amountDue, 0)),
      color: 'red'
    },
    { 
      icon: <FileText className="w-6 h-6" />, 
      label: 'Total Invoices', 
      value: invoices.length.toString(), 
      color: 'blue' 
    },
    { 
      icon: <CreditCard className="w-6 h-6" />, 
      label: 'Payment Methods', 
      value: paymentMethods.length.toString(), 
      color: 'green' 
    },
    {
      icon: <Calendar className="w-6 h-6" />,
      label: 'This Month',
      value: formatCurrency(payments.filter(p => {
        const thisMonth = new Date();
        thisMonth.setDate(1);
        return p.createdAt >= thisMonth && p.status === 'succeeded';
      }).reduce((sum, p) => sum + p.amount, 0)),
      color: 'purple'
    },
    { 
      icon: <Crown className="w-6 h-6" />, 
      label: 'Subscription', 
      value: currentSubscription ? currentSubscription.planName : 'None', 
      change: currentSubscription?.status || 'inactive', 
      color: 'blue' 
    },
    { 
      icon: <Shield className="w-6 h-6" />, 
      label: 'Job Posts Used', 
      value: (usageSummary.job_posts_per_month || 0).toString(), 
      change: 'this month', 
      color: 'orange' 
    },
  ];

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <div className="flex items-center">
          <AlertCircle className="w-5 h-5 text-red-600 mr-2" />
          <p className="text-red-800">Error loading billing data: {error}</p>
        </div>
      </div>
    );
  }


  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Billing & Payments</h1>
            <p className="text-gray-600 mt-1">Manage your billing account and payment history</p>
          </div>
          <div className="flex space-x-3">
            <button className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Download className="w-5 h-5 mr-2" />
              Export
            </button>
            <button
              onClick={() => setShowBillingForm(true)}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Settings className="w-5 h-5 mr-2" />
              Settings
            </button>
          </div>
        </div>

        {/* No Billing Account Notice */}
        {!billingAccount && (
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="font-medium text-blue-900">Billing Account Not Set Up</div>
              <div className="text-sm text-blue-800 mt-1">
                Set up your billing account to manage subscriptions, payment methods, and invoices.
              </div>
              <button
                onClick={() => setShowBillingForm(true)}
                className="mt-3 inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700 transition-colors"
              >
                <Plus className="w-4 h-4 mr-2" />
                Set Up Billing Account
              </button>
            </div>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center">
                <div className={`p-3 rounded-lg bg-${stat.color}-100`}>
                  <div className={`text-${stat.color}-600`}>
                    {stat.icon}
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-2xl font-bold text-gray-900">{stat.value}</h3>
                  <p className="text-gray-600 text-sm">{stat.label}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-8">
        <nav className="-mb-px flex space-x-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Invoices</h3>
              <div className="space-y-4">
                {invoices.slice(0, 3).map((invoice) => (
                  <div key={invoice.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">{invoice.invoiceNumber}</p>
                      <p className="text-sm text-gray-600">{invoice.description}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-gray-900">{formatCurrency(invoice.amountDue)}</p>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        invoice.status === 'paid' ? 'bg-green-100 text-green-800' :
                        invoice.status === 'open' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {invoice.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Payment Methods</h3>
              <div className="space-y-4">
                {paymentMethods.slice(0, 2).map((method) => (
                  <PaymentMethodCard key={method.id} paymentMethod={method} />
                ))}
                {paymentMethods.length === 0 && (
                  <div className="text-center py-4">
                    <CreditCard className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-500">No payment methods added</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'subscription' && (
        <SubscriptionManager />
      )}

      {activeTab === 'payment-methods' && (
        <PaymentMethodManager />
      )}

      {activeTab === 'invoices' && (
        <div className="space-y-6">
          {invoices.map((invoice) => (
            <InvoiceCard key={invoice.id} invoice={invoice} />
          ))}
        </div>
      )}

      {activeTab === 'payments' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Payment History</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Description
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {payments.map((payment) => (
                  <tr key={payment.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {payment.createdAt.toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {payment.description || 'Payment'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {formatCurrency(payment.amount)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        payment.status === 'succeeded' ? 'bg-green-100 text-green-800' :
                        payment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        payment.status === 'failed' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {payment.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'escrow' && (
        <EscrowManager />
      )}

      {activeTab === 'documents' && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Document Management</h3>
            <p className="text-gray-600 mb-6">
              Manage your organization's documents and file sharing
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center p-6 bg-blue-50 rounded-lg">
                <FileText className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">24</div>
                <div className="text-sm text-gray-600">Total Files</div>
              </div>
              <div className="text-center p-6 bg-green-50 rounded-lg">
                <Share className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">8</div>
                <div className="text-sm text-gray-600">Shared Documents</div>
              </div>
              <div className="text-center p-6 bg-purple-50 rounded-lg">
                <HardDrive className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">2.4GB</div>
                <div className="text-sm text-gray-600">Storage Used</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'settings' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Billing Settings</h3>
          <BillingAccountForm 
            billingAccount={billingAccount}
            onClose={() => {}} 
            isModal={false}
          />
        </div>
      )}

      {/* Modals */}
      {showBillingForm && (
        <BillingAccountForm 
          billingAccount={billingAccount}
          onClose={() => setShowBillingForm(false)} 
        />
      )}

      {/* Payment Form Modal */}
      {showPaymentForm && paymentData && (
        <PaymentForm
          amount={paymentData.amount}
          description={paymentData.description}
          onSuccess={(paymentIntent) => {
            console.log('Payment successful:', paymentIntent);
            setShowPaymentForm(false);
            setPaymentData(null);
          }}
          onError={(error) => {
            console.error('Payment failed:', error);
            alert(`Payment failed: ${error}`);
          }}
          onClose={() => {
            setShowPaymentForm(false);
            setPaymentData(null);
          }}
        />
      )}
    </div>
  );
};

export default BillingDashboard;