import React from 'react';
import { Invoice } from '../../hooks/useBilling';
import { FileText, Download, Eye, Calendar, DollarSign } from 'lucide-react';
import { formatCurrency } from '../../lib/stripe';

interface InvoiceCardProps {
  invoice: Invoice;
}

const InvoiceCard: React.FC<InvoiceCardProps> = ({ invoice }) => {
  const getStatusConfig = () => {
    switch (invoice.status) {
      case 'paid':
        return { color: 'green', label: 'Paid' };
      case 'open':
        return { color: 'yellow', label: 'Outstanding' };
      case 'draft':
        return { color: 'gray', label: 'Draft' };
      case 'void':
        return { color: 'red', label: 'Void' };
      case 'uncollectible':
        return { color: 'red', label: 'Uncollectible' };
      default:
        return { color: 'gray', label: 'Unknown' };
    }
  };

  const statusConfig = getStatusConfig();

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
            <FileText className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{invoice.invoiceNumber}</h3>
            <p className="text-gray-600 text-sm">{invoice.description}</p>
          </div>
        </div>

        <span className={`px-3 py-1 rounded-full text-sm font-medium bg-${statusConfig.color}-100 text-${statusConfig.color}-800`}>
          {statusConfig.label}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        <div className="flex items-center">
          <DollarSign className="w-4 h-4 text-gray-400 mr-2" />
          <div>
            <p className="text-sm text-gray-600">Amount Due</p>
            <p className="font-semibold text-gray-900">{formatCurrency(invoice.amountDue)}</p>
          </div>
        </div>

        <div className="flex items-center">
          <Calendar className="w-4 h-4 text-gray-400 mr-2" />
          <div>
            <p className="text-sm text-gray-600">Created</p>
            <p className="font-medium text-gray-900">{invoice.createdAt.toLocaleDateString()}</p>
          </div>
        </div>

        {invoice.dueDate && (
          <div className="flex items-center">
            <Calendar className="w-4 h-4 text-gray-400 mr-2" />
            <div>
              <p className="text-sm text-gray-600">Due Date</p>
              <p className="font-medium text-gray-900">{invoice.dueDate.toLocaleDateString()}</p>
            </div>
          </div>
        )}
      </div>

      {invoice.items.length > 0 && (
        <div className="mb-4">
          <h4 className="font-medium text-gray-900 mb-2">Invoice Items</h4>
          <div className="bg-gray-50 rounded-lg p-3">
            {invoice.items.map((item) => (
              <div key={item.id} className="flex justify-between items-center py-1">
                <span className="text-sm text-gray-700">
                  {item.description} {item.quantity > 1 && `(${item.quantity}x)`}
                </span>
                <span className="text-sm font-medium text-gray-900">
                  {formatCurrency(item.totalAmount)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="flex justify-between items-center pt-4 border-t border-gray-100">
        <div className="flex space-x-3">
          <button className="flex items-center text-sm text-blue-600 hover:text-blue-700">
            <Eye className="w-4 h-4 mr-1" />
            View Details
          </button>
          <button className="flex items-center text-sm text-gray-600 hover:text-gray-700">
            <Download className="w-4 h-4 mr-1" />
            Download PDF
          </button>
        </div>

        {invoice.status === 'open' && (
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            Pay Now
          </button>
        )}
      </div>
    </div>
  );
};

export default InvoiceCard;