import React, { useState } from 'react';
import { useBilling, BillingAccount } from '../../hooks/useBilling';
import { X, Building, Mail, Hash, MapPin } from 'lucide-react';

interface BillingAccountFormProps {
  billingAccount?: BillingAccount | null;
  onClose: () => void;
  isModal?: boolean;
}

const BillingAccountForm: React.FC<BillingAccountFormProps> = ({ 
  billingAccount, 
  onClose, 
  isModal = true 
}) => {
  const { createBillingAccount, updateBillingAccount } = useBilling();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    billingEmail: billingAccount?.billingEmail || '',
    companyName: billingAccount?.companyName || '',
    taxId: billingAccount?.taxId || '',
    address: {
      line1: billingAccount?.billingAddress?.line1 || '',
      line2: billingAccount?.billingAddress?.line2 || '',
      city: billingAccount?.billingAddress?.city || '',
      state: billingAccount?.billingAddress?.state || '',
      postalCode: billingAccount?.billingAddress?.postal_code || '',
      country: billingAccount?.billingAddress?.country || 'US',
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      const billingData = {
        billingEmail: formData.billingEmail,
        companyName: formData.companyName,
        taxId: formData.taxId,
        billingAddress: {
          line1: formData.address.line1,
          line2: formData.address.line2,
          city: formData.address.city,
          state: formData.address.state,
          postal_code: formData.address.postalCode,
          country: formData.address.country,
        },
      };

      if (billingAccount) {
        await updateBillingAccount(billingData);
      } else {
        await createBillingAccount(billingData);
      }

      if (isModal) {
        onClose();
      }
    } catch (err) {
      console.error('Error saving billing account:', err);
      setError(err instanceof Error ? err.message : 'Failed to save billing account');
    } finally {
      setIsSubmitting(false);
    }
  };

  const countries = [
    { code: 'US', name: 'United States' },
    { code: 'CA', name: 'Canada' },
    { code: 'GB', name: 'United Kingdom' },
    { code: 'AU', name: 'Australia' },
    { code: 'NZ', name: 'New Zealand' },
    { code: 'SG', name: 'Singapore' },
    { code: 'IN', name: 'India' },
    { code: 'DE', name: 'Germany' },
    { code: 'FR', name: 'France' },
  ];

  const content = (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Mail className="w-4 h-4 inline mr-1" />
            Billing Email
          </label>
          <input
            type="email"
            required
            value={formData.billingEmail}
            onChange={(e) => setFormData(prev => ({ ...prev, billingEmail: e.target.value }))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            placeholder="billing@company.com"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Building className="w-4 h-4 inline mr-1" />
            Company Name
          </label>
          <input
            type="text"
            required
            value={formData.companyName}
            onChange={(e) => setFormData(prev => ({ ...prev, companyName: e.target.value }))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            placeholder="Your Company Inc."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Hash className="w-4 h-4 inline mr-1" />
            Tax ID
          </label>
          <input
            type="text"
            required
            value={formData.taxId}
            onChange={(e) => setFormData(prev => ({ ...prev, taxId: e.target.value }))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            placeholder="12-3456789"
          />
          <p className="mt-1 text-xs text-gray-500">Required for subscription payments and invoicing</p>
        </div>
      </div>

      <div>
        <h4 className="text-lg font-medium text-gray-900 mb-4">
          <MapPin className="w-5 h-5 inline mr-1" />
          Billing Address
        </h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Address Line 1
            </label>
            <input
              type="text"
              required
              value={formData.address.line1}
              onChange={(e) => setFormData(prev => ({ 
                ...prev, 
                address: { ...prev.address, line1: e.target.value }
              }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              placeholder="123 Main Street"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Address Line 2 (Optional)
            </label>
            <input
              type="text"
              value={formData.address.line2}
              onChange={(e) => setFormData(prev => ({ 
                ...prev, 
                address: { ...prev.address, line2: e.target.value }
              }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              placeholder="Suite 100"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              City
            </label>
            <input
              type="text"
              required
              value={formData.address.city}
              onChange={(e) => setFormData(prev => ({ 
                ...prev, 
                address: { ...prev.address, city: e.target.value }
              }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              placeholder="San Francisco"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              State/Province
            </label>
            <input
              type="text"
              required
              value={formData.address.state}
              onChange={(e) => setFormData(prev => ({ 
                ...prev, 
                address: { ...prev.address, state: e.target.value }
              }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              placeholder="CA"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Postal Code
            </label>
            <input
              type="text"
              required
              value={formData.address.postalCode}
              onChange={(e) => setFormData(prev => ({ 
                ...prev, 
                address: { ...prev.address, postalCode: e.target.value }
              }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              placeholder="94105"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Country
            </label>
            <select
              value={formData.address.country}
              onChange={(e) => setFormData(prev => ({ 
                ...prev, 
                address: { ...prev.address, country: e.target.value }
              }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            >
              {countries.map(country => (
                <option key={country.code} value={country.code}>
                  {country.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-800">{error}</p>
        </div>
      )}

      <div className="flex justify-end space-x-4">
        {isModal && (
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
        )}
        <button
          type="submit"
          disabled={isSubmitting}
          className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50"
        >
          {isSubmitting ? 'Saving...' : billingAccount ? 'Update Account' : 'Create Account'}
        </button>
      </div>
    </form>
  );

  if (!isModal) {
    return content;
  }

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-20 mx-auto p-5 border w-full max-w-4xl shadow-lg rounded-md bg-white">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold text-gray-900">
            {billingAccount ? 'Update Billing Account' : 'Set Up Billing Account'}
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 p-2"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        {content}
      </div>
    </div>
  );
};

export default BillingAccountForm;