import React from 'react';
import { PaymentMethod } from '../../hooks/useBilling';
import { CreditCard, MoreVertical, Star } from 'lucide-react';

interface PaymentMethodCardProps {
  paymentMethod: PaymentMethod;
  showActions?: boolean;
}

const PaymentMethodCard: React.FC<PaymentMethodCardProps> = ({ 
  paymentMethod, 
  showActions = false 
}) => {
  const getCardBrandIcon = (brand?: string) => {
    // In a real app, you'd use actual card brand icons
    return <CreditCard className="w-6 h-6" />;
  };

  const getCardBrandColor = (brand?: string) => {
    switch (brand?.toLowerCase()) {
      case 'visa': return 'text-blue-600';
      case 'mastercard': return 'text-red-600';
      case 'amex': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className={`${getCardBrandColor(paymentMethod.cardBrand)}`}>
            {getCardBrandIcon(paymentMethod.cardBrand)}
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <p className="font-medium text-gray-900">
                {paymentMethod.cardBrand?.toUpperCase()} •••• {paymentMethod.cardLast4}
              </p>
              {paymentMethod.isDefault && (
                <Star className="w-4 h-4 text-yellow-500 fill-current" />
              )}
            </div>
            <p className="text-sm text-gray-500">
              Expires {paymentMethod.cardExpMonth?.toString().padStart(2, '0')}/{paymentMethod.cardExpYear}
            </p>
          </div>
        </div>

        {showActions && (
          <div className="flex items-center space-x-2">
            {!paymentMethod.isDefault && (
              <button className="text-sm text-blue-600 hover:text-blue-700">
                Set as Default
              </button>
            )}
            <button className="p-1 text-gray-400 hover:text-gray-600">
              <MoreVertical className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default PaymentMethodCard;