import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useFileUpload, UploadedFile } from '../../hooks/useFileUpload';
import { Camera, User, Loader, X } from 'lucide-react';

interface ProfilePhotoUploadProps {
  currentPhotoUrl?: string;
  onPhotoUpdate: (photoUrl: string) => void;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const ProfilePhotoUpload: React.FC<ProfilePhotoUploadProps> = ({
  currentPhotoUrl,
  onPhotoUpdate,
  size = 'md',
  className = '',
}) => {
  const { user } = useAuth();
  const { uploadFile, uploading, error } = useFileUpload();
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const sizeClasses = {
    sm: 'w-16 h-16',
    md: 'w-24 h-24',
    lg: 'w-32 h-32',
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    console.log('Profile photo selected:', file.name, formatFileSize(file.size));

    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreviewUrl(e.target?.result as string);
    };
    reader.readAsDataURL(file);

    try {
      const uploadedFile: UploadedFile = await uploadFile(file, {
        bucket: 'profile-photos',
        fileType: 'profile_photo',
        maxSize: 5 * 1024 * 1024, // 5MB
        allowedTypes: ['image/jpeg', 'image/png', 'image/webp'],
      });

      console.log('Profile photo uploaded successfully:', uploadedFile.url);
      onPhotoUpdate(uploadedFile.url);
      setPreviewUrl(null);
    } catch (err) {
      console.error('Photo upload failed:', err);
      setPreviewUrl(null);
    }
  };

  const removePreview = () => {
    setPreviewUrl(null);
  };

  const displayUrl = previewUrl || currentPhotoUrl;

  return (
    <div className={`relative ${className}`}>
      <div className={`${sizeClasses[size]} rounded-full overflow-hidden bg-gray-100 border-2 border-gray-200 relative group`}>
        {displayUrl ? (
          <img
            src={displayUrl}
            alt="Profile"
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <User className="w-1/2 h-1/2 text-gray-400" />
          </div>
        )}

        {/* Upload overlay */}
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          {uploading ? (
            <Loader className="w-6 h-6 text-white animate-spin" />
          ) : (
            <Camera className="w-6 h-6 text-white" />
          )}
        </div>

        {/* File input */}
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp"
          onChange={handleFileSelect}
          disabled={uploading}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
        />
      </div>

      {/* Preview controls */}
      {previewUrl && (
        <button
          onClick={removePreview}
          className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      )}

      {/* Upload status */}
      {uploading && (
        <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2">
          <p className="text-xs text-gray-600">Uploading...</p>
        </div>
      )}

      {/* Error message */}
      {error && (
        <div className="absolute -bottom-12 left-1/2 transform -translate-x-1/2 w-48">
          <p className="text-xs text-red-600 text-center">{error}</p>
        </div>
      )}
    </div>
  );
};

export default ProfilePhotoUpload;