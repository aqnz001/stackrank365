import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { useFileUpload, FileUploadOptions, UploadedFile } from '../../hooks/useFileUpload';
import { Upload, File, X, CheckCircle, AlertCircle, Loader } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';

interface FileUploadZoneProps {
  options: FileUploadOptions;
  onUploadComplete: (file: UploadedFile) => void;
  onUploadError?: (error: string) => void;
  className?: string;
  multiple?: boolean;
  disabled?: boolean;
  children?: React.ReactNode;
}

const FileUploadZone: React.FC<FileUploadZoneProps> = ({
  options,
  onUploadComplete,
  onUploadError,
  className = '',
  multiple = false,
  disabled = false,
  children,
}) => {
  const { uploadFile, uploading, progress, error } = useFileUpload();
  const { user } = useAuth();
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [parsingResume, setParsingResume] = useState(false);

  const parseResumeAfterUpload = async (uploadedFile: UploadedFile) => {
    if (options.bucket !== 'resumes' || !user?.id) {
      return;
    }

    try {
      setParsingResume(true);
      console.log('Triggering resume parsing for:', uploadedFile.id);

      const { data: { session } } = await supabase.auth.getSession();
      const edgeUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/parse-resume`;

      const parseResponse = await fetch(edgeUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.access_token || ''}`,
        },
        body: JSON.stringify({
          fileUploadId: uploadedFile.id,
          userId: user.id,
          storeToDB: true,
        }),
      });

      if (parseResponse.ok) {
        const parseData = await parseResponse.json();
        console.log('Resume parsed successfully:', parseData);
      } else {
        const errorText = await parseResponse.text();
        console.error('Resume parsing failed:', errorText);
      }
    } catch (err) {
      console.error('Error triggering resume parsing:', err);
    } finally {
      setParsingResume(false);
    }
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    console.log('Files dropped:', acceptedFiles.length);

    for (const file of acceptedFiles) {
      try {
        console.log('Uploading file:', file.name, 'Size:', formatFileSize(file.size));
        const uploadedFile = await uploadFile(file, options);
        console.log('File uploaded successfully:', uploadedFile.id);
        setUploadedFiles(prev => [...prev, uploadedFile]);

        if (options.bucket === 'resumes') {
          await parseResumeAfterUpload(uploadedFile);
        }

        onUploadComplete(uploadedFile);
      } catch (err) {
        console.error('File upload failed:', err);
        const errorMessage = err instanceof Error ? err.message : 'Upload failed';
        onUploadError?.(errorMessage);
      }
    }
  }, [uploadFile, options, onUploadComplete, onUploadError, user?.id]);

  const { getRootProps, getInputProps, isDragActive, isDragReject } = useDropzone({
    onDrop,
    multiple,
    disabled: disabled || uploading,
    accept: getAcceptTypes(options.bucket),
    maxSize: options.maxSize || getDefaultMaxSize(options.bucket),
  });

  const removeFile = (fileId: string) => {
    setUploadedFiles(prev => prev.filter(f => f.id !== fileId));
  };

  return (
    <div className={`space-y-4 ${className}`}>
      <div
        {...getRootProps()}
        className={`
          border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors
          ${isDragActive && !isDragReject ? 'border-blue-400 bg-blue-50' : ''}
          ${isDragReject ? 'border-red-400 bg-red-50' : ''}
          ${!isDragActive && !isDragReject ? 'border-gray-300 hover:border-gray-400' : ''}
          ${disabled || uploading ? 'opacity-50 cursor-not-allowed' : ''}
        `}
      >
        <input {...getInputProps()} />
        
        {uploading || parsingResume ? (
          <div className="space-y-4">
            <Loader className="w-8 h-8 text-blue-600 mx-auto animate-spin" />
            <div>
              <p className="text-sm text-gray-600 mb-2">
                {uploading ? 'Uploading...' : 'Processing resume...'}
              </p>
              {uploading && (
                <>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">{progress}%</p>
                </>
              )}
              {parsingResume && !uploading && (
                <p className="text-xs text-gray-500 mt-1">Extracting resume details...</p>
              )}
            </div>
          </div>
        ) : children ? (
          children
        ) : (
          <div className="space-y-4">
            <Upload className="w-8 h-8 text-gray-400 mx-auto" />
            <div>
              <p className="text-sm text-gray-600">
                {isDragActive
                  ? 'Drop files here...'
                  : 'Drag & drop files here, or click to select'
                }
              </p>
              <p className="text-xs text-gray-500 mt-1">
                {getFileTypeDescription(options.bucket)} • Max {formatFileSize(options.maxSize || getDefaultMaxSize(options.bucket))}
              </p>
            </div>
          </div>
        )}
      </div>

      {error && (
        <div className="flex items-center p-3 bg-red-50 border border-red-200 rounded-lg">
          <AlertCircle className="w-5 h-5 text-red-600 mr-2" />
          <p className="text-sm text-red-800">{error}</p>
        </div>
      )}

      {uploadedFiles.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-gray-700">Uploaded Files</h4>
          {uploadedFiles.map((file) => (
            <div key={file.id} className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                <div>
                  <p className="text-sm font-medium text-gray-900">{file.name}</p>
                  <p className="text-xs text-gray-500">{formatFileSize(file.size)}</p>
                </div>
              </div>
              <button
                onClick={() => removeFile(file.id)}
                className="p-1 text-gray-400 hover:text-gray-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// Helper functions
const getAcceptTypes = (bucket: string): Record<string, string[]> => {
  switch (bucket) {
    case 'resumes':
      return {
        'application/pdf': ['.pdf'],
      };
    case 'profile-photos':
      return {
        'image/jpeg': ['.jpg', '.jpeg'],
        'image/png': ['.png'],
        'image/webp': ['.webp'],
      };
    case 'company-logos':
      return {
        'image/jpeg': ['.jpg', '.jpeg'],
        'image/png': ['.png'],
        'image/svg+xml': ['.svg'],
        'image/webp': ['.webp'],
      };
    case 'documents':
      return {
        'application/pdf': ['.pdf'],
        'application/msword': ['.doc'],
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
        'image/jpeg': ['.jpg', '.jpeg'],
        'image/png': ['.png'],
      };
    default:
      return {};
  }
};

const getFileTypeDescription = (bucket: string): string => {
  switch (bucket) {
    case 'resumes':
      return 'PDF only';
    case 'profile-photos':
      return 'JPG, PNG, WebP';
    case 'company-logos':
      return 'JPG, PNG, SVG, WebP';
    case 'documents':
      return 'PDF, DOC, DOCX, JPG, PNG';
    default:
      return 'All files';
  }
};

const getDefaultMaxSize = (bucket: string): number => {
  switch (bucket) {
    case 'resumes':
      return 10 * 1024 * 1024; // 10MB
    case 'profile-photos':
      return 5 * 1024 * 1024; // 5MB
    case 'company-logos':
      return 2 * 1024 * 1024; // 2MB
    case 'documents':
      return 20 * 1024 * 1024; // 20MB
    default:
      return 5 * 1024 * 1024; // 5MB default
  }
};

const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export default FileUploadZone;