import React from 'react';
import { X, Plus, Trash2, Upload, Briefcase, MapPin, GraduationCap, Settings, CheckCircle, FileText, User } from 'lucide-react';
import { useCandidateProfile, CandidateProfile, WorkExperience, RoleClassification, WorkLocation, ResumeMeta } from '../../hooks/useCandidateProfile';
import { useParsedResume } from '../../hooks/useParsedResume';
import toast from 'react-hot-toast';
import { supabase } from '../../lib/supabase';
import FileUploadZone from '../FileUpload/FileUploadZone';
import { UploadedFile } from '../../hooks/useFileUpload';

interface Props { isOpen: boolean; onClose: () => void; onSaved?: (p: CandidateProfile) => void }

const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const years = Array.from({length: 50}, (_,i) => String(new Date().getFullYear()-i));
const workTypes = ['Full time','Part time','Contract','Casual'];
const cities = ['Auckland','Wellington','Christchurch','Hamilton','Tauranga','Dunedin'];

// Role classifications from old project (JB-Old)
const roleCategories = [
  'Information & Communication',
  'Healthcare & Social Assistance',
  'Professional Services',
  'Education & Training',
  'Manufacturing',
  'Construction',
  'Retail Trade',
  'Transport & Logistics',
  'Finance & Insurance',
  'Government & Public Administration'
];
const subcategoryOptions: Record<string, string[]> = {
  'Information & Communication': ['Consultants','Developers','Analysts','Support','Management'],
  'Healthcare & Social Assistance': ['Nurses','Doctors','Therapists','Support Workers','Administration'],
  'Professional Services': ['Consultants','Advisors','Specialists','Managers','Support'],
  'Education & Training': ['Teachers','Trainers','Administration','Support','Management'],
  'Manufacturing': ['Production','Quality Control','Engineering','Management','Support'],
  'Construction': ['Trades','Engineering','Project Management','Safety','Administration'],
  'Retail Trade': ['Sales','Management','Customer Service','Merchandising','Support'],
  'Transport & Logistics': ['Drivers','Coordinators','Management','Warehouse','Administration'],
  'Finance & Insurance': ['Analysts','Advisors','Management','Administration','Support'],
  'Government & Public Administration': ['Policy','Administration','Management','Support','Specialists']
};

const CandidateProfileSetup: React.FC<Props> = ({ isOpen, onClose, onSaved }) => {
  const { profile, save } = useCandidateProfile();
  if (!isOpen) return null;

  const initial: CandidateProfile = profile ?? {
    workExperience: [{
      id: Date.now().toString(), jobTitle: '', company: '', industry: '',
      startMonth: '', startYear: '', endMonth: '', endYear: '', isCurrentRole: false, description: ''
    }],
    currentStatus: { location: '', roleClassifications: [{ id: '1', category: '', subcategory: '' }] },
    qualifications: { highestQualification: '', skills: [] },
    rolePreferences: { workTypes: [], workLocations: [{ id: '1', city: '', area: '' }], rightToWorkNZ: '', salaryType: 'Annual', minimumSalary: '' },
  };

  const [data, setData] = React.useState<CandidateProfile>(initial);
  const [step, setStep] = React.useState(0);
  const [parsedPreview, setParsedPreview] = React.useState<{ skills: string[]; experiences: WorkExperience[] } | null>(null);

  const presentParsed = (parsed: { skills: string[]; experiences: WorkExperience[] }) => {
    setParsedPreview(parsed);
  };

  const applyParsedPreview = () => {
    if (!parsedPreview) return;
    setData(d => {
      const mergedSkills = Array.from(new Set([...(d.qualifications.skills || []), ...(parsedPreview.skills || [])])).slice(0, 12);
      const existingSig = new Set((d.workExperience || []).map(w => (w.jobTitle + '|' + w.company).toLowerCase()));
      const newExperiences = (parsedPreview.experiences || []).filter(w => !existingSig.has((w.jobTitle + '|' + w.company).toLowerCase()));
      const workExperience = (d.workExperience && d.workExperience.length>0) ? [...d.workExperience, ...newExperiences] : (newExperiences.length>0 ? newExperiences : d.workExperience);
      return { ...d, qualifications: { ...d.qualifications, skills: mergedSkills }, workExperience };
    });
    toast.success(`Applied ${parsedPreview.skills.length} skills, ${parsedPreview.experiences.length} roles`);
    setParsedPreview(null);
  };

  const cancelParsedPreview = () => setParsedPreview(null);

  // Helper: fetch parsed data from database and apply to profile
  const extractFromResume = async (r: ResumeMeta) => {
    try {
      if (!r.id) {
        toast.error('Resume ID not available');
        return;
      }

      const { data: parsedData, error } = await supabase
        .from('resume_parsed_data')
        .select('*')
        .eq('file_upload_id', r.id)
        .maybeSingle();

      if (error) {
        console.error('Error fetching parsed data:', error);
        toast.error('Could not load parsed resume data');
        return;
      }

      if (!parsedData) {
        toast('Resume is being parsed. Please wait a moment and try again.');
        return;
      }

      if (parsedData.parsing_status === 'pending') {
        toast('Resume is still being processed. Please wait a moment.');
        return;
      }

      if (parsedData.parsing_status === 'failed') {
        toast.error('Resume parsing failed. Please try uploading again.');
        return;
      }

      const parsed = {
        skills: parsedData.parsed_skills || [],
        experiences: (parsedData.parsed_experiences || []).map((exp: any) => ({
          id: exp.id || String(Math.random()),
          jobTitle: exp.jobTitle || '',
          company: exp.company || '',
          industry: exp.industry || '',
          startMonth: exp.startMonth || '',
          startYear: exp.startYear || '',
          endMonth: exp.endMonth || '',
          endYear: exp.endYear || '',
          isCurrentRole: exp.isCurrentRole || false,
          description: exp.description || '',
        })),
      };

      presentParsed(parsed);
    } catch (e: any) {
      console.error('Error extracting resume data:', e);
      toast.error(e?.message || 'Could not extract resume data');
    }
  };

  // Make a simple bridge to let helper apply parsed data without threading props too far
  React.useEffect(() => {
    (window as any).__presentResumeParsed = (parsed: { skills: string[]; experiences: WorkExperience[] }) => {
      presentParsed(parsed);
    };
    return () => { delete (window as any).__presentResumeParsed; };
  }, []);

  // Keep form data in sync when a saved profile is loaded/updated
  React.useEffect(() => {
    if (isOpen && profile) {
      setData(profile);
    }
  }, [isOpen, profile]);

  const addExperience = () => setData(d => ({ ...d, workExperience: [...d.workExperience, { ...d.workExperience[0], id: Date.now().toString(), jobTitle: '', company: '', industry: '', startMonth: '', startYear: '', endMonth: '', endYear: '', isCurrentRole: false, description: '' }] }));
  const rmExperience = (id: string) => setData(d => ({ ...d, workExperience: d.workExperience.length>1 ? d.workExperience.filter(x => x.id !== id) : d.workExperience }));
  const updExperience = (id: string, field: keyof WorkExperience, value: any) => setData(d => ({ ...d, workExperience: d.workExperience.map(x => x.id===id ? { ...x, [field]: value } : x) }));

  const addRoleClass = () => setData(d => ({ ...d, currentStatus: { ...d.currentStatus, roleClassifications: [...d.currentStatus.roleClassifications, { id: Date.now().toString(), category: '', subcategory: '' }] } }));
  const rmRoleClass = (id: string) => setData(d => ({ ...d, currentStatus: { ...d.currentStatus, roleClassifications: d.currentStatus.roleClassifications.length>1 ? d.currentStatus.roleClassifications.filter(r => r.id!==id) : d.currentStatus.roleClassifications } }));
  const updRoleClass = (id: string, field: keyof RoleClassification, value: string) => setData(d => ({ ...d, currentStatus: { ...d.currentStatus, roleClassifications: d.currentStatus.roleClassifications.map(r => r.id===id ? { ...r, [field]: value } : r) } }));
  const onChangeRoleCategory = (id: string, category: string) => {
    // When category changes, reset subcategory
    setData(d => ({
      ...d,
      currentStatus: {
        ...d.currentStatus,
        roleClassifications: d.currentStatus.roleClassifications.map(rc => rc.id===id ? { ...rc, category, subcategory: '' } : rc)
      }
    }));
  };

  const addLoc = () => setData(d => ({ ...d, rolePreferences: { ...d.rolePreferences, workLocations: [...d.rolePreferences.workLocations, { id: Date.now().toString(), city: '', area: '' }] } }));
  const rmLoc = (id: string) => setData(d => ({ ...d, rolePreferences: { ...d.rolePreferences, workLocations: d.rolePreferences.workLocations.length>1 ? d.rolePreferences.workLocations.filter(l=>l.id!==id) : d.rolePreferences.workLocations } }));
  const updLoc = (id: string, field: keyof WorkLocation, value: string) => setData(d => ({ ...d, rolePreferences: { ...d.rolePreferences, workLocations: d.rolePreferences.workLocations.map(l => l.id===id ? { ...l, [field]: value } : l) } }));

  const addSkill = (s: string) => { if (!s.trim()) return; if (data.qualifications.skills.length>=10) return; setData(d => ({ ...d, qualifications: { ...d.qualifications, skills: [...d.qualifications.skills, s.trim()] } })); };
  const rmSkill = (s: string) => setData(d => ({ ...d, qualifications: { ...d.qualifications, skills: d.qualifications.skills.filter(x => x!==s) } }));

  const canNext = () => {
    // Step 0 (Resumes): optional, always allow Next
    if (step===0) return true;
    // Step 1 (Career history)
    if (step===1) return data.workExperience[0].jobTitle.trim().length>0;
    // Step 2 (Current status)
    if (step===2) return data.currentStatus.location.trim().length>0;
    // Step 3 (Skills)
    if (step===3) return data.qualifications.skills.length>0;
    return true;
  };

  const onSave = () => { save(data); onSaved?.(data); onClose(); };

  const stepTitles = ['Resume Upload', 'Work Experience', 'Current Status', 'Skills & Qualifications', 'Work Preferences'];

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4 overflow-y-auto">
        <div className="bg-white w-full max-w-4xl my-8 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[calc(100vh-4rem)]">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b bg-gradient-to-r from-blue-600 to-purple-600 text-white flex-shrink-0">
            <div className="flex items-center gap-2">
              <User className="w-6 h-6" />
              <div>
                <h3 className="text-xl font-semibold">Candidate Profile Setup</h3>
                <p className="text-blue-100 text-sm">Step {step + 1} of {stepTitles.length}: {stepTitles[step]}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 text-white/80 hover:text-white" aria-label="Close">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="px-6 py-6 flex-1 overflow-y-auto">
            {/* Progress Indicator */}
            <div className="flex items-center justify-center gap-3 mb-8">
              {stepTitles.map((_, i) => (
                <div key={i} className="flex items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    i <= step ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
                  }`}>
                    {i < step ? <CheckCircle className="w-4 h-4" /> : i + 1}
                  </div>
                  {i < stepTitles.length - 1 && (
                    <div className={`w-12 h-1 mx-2 ${i < step ? 'bg-blue-600' : 'bg-gray-200'}`} />
                  )}
                </div>
              ))}
            </div>

            {/* Step Content */}
            <div className="px-2">

              {step===1 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <Briefcase className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">Work Experience</h4>
                    <p className="text-gray-600">Tell us about your professional experience</p>
                  </div>
                  <div className="space-y-4">
                  {data.workExperience.map((exp, idx) => (
                    <div key={exp.id} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="font-medium">Role {idx+1}</div>
                        {data.workExperience.length>1 && (
                          <button onClick={()=>rmExperience(exp.id)} className="p-1 text-gray-500 hover:text-red-600"><Trash2 className="w-4 h-4"/></button>
                        )}
                      </div>
                      <input className="w-full border rounded px-3 py-2" placeholder="Job title" value={exp.jobTitle} onChange={e=>updExperience(exp.id,'jobTitle',e.target.value)} />
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <input className="border rounded px-3 py-2" placeholder="Company" value={exp.company} onChange={e=>updExperience(exp.id,'company',e.target.value)} />
                        <input className="border rounded px-3 py-2" placeholder="Industry" value={exp.industry} onChange={e=>updExperience(exp.id,'industry',e.target.value)} />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="grid grid-cols-2 gap-2">
                          <select className="border rounded px-2 py-2" value={exp.startMonth} onChange={e=>updExperience(exp.id,'startMonth',e.target.value)}>
                            <option value="">Start month</option>
                            {months.map(m=> <option key={m}>{m}</option>)}
                          </select>
                          <select className="border rounded px-2 py-2" value={exp.startYear} onChange={e=>updExperience(exp.id,'startYear',e.target.value)}>
                            <option value="">Year</option>
                            {years.map(y=> <option key={y}>{y}</option>)}
                          </select>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <select className="border rounded px-2 py-2" value={exp.isCurrentRole? '': exp.endMonth} onChange={e=>updExperience(exp.id,'endMonth',e.target.value)} disabled={exp.isCurrentRole}>
                            <option value="">End month</option>
                            {months.map(m=> <option key={m}>{m}</option>)}
                          </select>
                          <input className="border rounded px-2 py-2" placeholder={exp.isCurrentRole? 'Still in this role':'End year'} disabled={exp.isCurrentRole} value={exp.isCurrentRole? '': exp.endYear} onChange={e=>updExperience(exp.id,'endYear',e.target.value)} />
                        </div>
                        <label className="col-span-2 inline-flex items-center gap-2 text-sm"><input type="checkbox" checked={exp.isCurrentRole} onChange={e=>updExperience(exp.id,'isCurrentRole',e.target.checked)} />Still in this role</label>
                      </div>
                      <textarea className="w-full border rounded px-3 py-2" rows={3} placeholder="Describe your responsibilities and achievements" value={exp.description} onChange={e=>updExperience(exp.id,'description',e.target.value)} />
                    </div>
                  ))}
                  <button onClick={addExperience} className="inline-flex items-center text-blue-600 hover:text-blue-700"><Plus className="w-4 h-4 mr-1"/>Add another role</button>
                  </div>
                </div>
              )}

              {step===2 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <MapPin className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">Current Status</h4>
                    <p className="text-gray-600">Where are you located and what roles are you interested in?</p>
                  </div>
                  <div className="space-y-4">
                  <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Your current location" value={data.currentStatus.location} onChange={e=>setData(d=>({...d, currentStatus:{...d.currentStatus, location:e.target.value}}))} />
                  <div className="space-y-2">
                    <div className="font-medium text-gray-900">Role Classifications</div>
                    {data.currentStatus.roleClassifications.map(rc => (
                      <div key={rc.id} className="grid grid-cols-2 gap-2 items-center">
                        <select className="border rounded px-3 py-2" value={rc.category} onChange={e=>onChangeRoleCategory(rc.id, e.target.value)}>
                          <option value="">Select category…</option>
                          {roleCategories.map(c => (<option key={c} value={c}>{c}</option>))}
                        </select>
                        <div className="flex gap-2 items-center">
                          <select className="border rounded px-3 py-2 flex-1" value={rc.subcategory} onChange={e=>updRoleClass(rc.id,'subcategory',e.target.value)} disabled={!rc.category}>
                            <option value="">Select subcategory…</option>
                            {(subcategoryOptions[rc.category] || []).map(s => (<option key={s} value={s}>{s}</option>))}
                          </select>
                          {data.currentStatus.roleClassifications.length>1 && (<button onClick={()=>rmRoleClass(rc.id)} className="p-2 text-gray-500 hover:text-red-600"><Trash2 className="w-4 h-4"/></button>)}
                        </div>
                      </div>
                    ))}
                    <button onClick={addRoleClass} className="inline-flex items-center text-blue-600 hover:text-blue-700"><Plus className="w-4 h-4 mr-1"/>Add classification</button>
                  </div>
                  </div>
                </div>
              )}

              {step===3 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <GraduationCap className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">Skills & Qualifications</h4>
                    <p className="text-gray-600">Share your education and professional skills</p>
                  </div>
                  <div className="space-y-4">
                  <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Highest qualification (e.g., Bachelor's Degree in Computer Science)" value={data.qualifications.highestQualification} onChange={e=>setData(d=>({...d, qualifications:{...d.qualifications, highestQualification:e.target.value}}))} />
                  <div>
                    <div className="font-medium text-gray-900 mb-2">Skills (max 10)</div>
                    <SkillInput skills={data.qualifications.skills} onAdd={addSkill} onRemove={rmSkill} />
                  </div>
                  </div>
                </div>
              )}

              {step===4 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <Settings className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">Work Preferences</h4>
                    <p className="text-gray-600">Tell us about your ideal work arrangement</p>
                  </div>
                  <div className="space-y-4">
                  <div>
                    <div className="font-medium text-gray-900 mb-2">Work Types</div>
                    <div className="flex flex-wrap gap-2">
                      {workTypes.map(w => (
                        <button key={w} onClick={()=>setData(d=>({ ...d, rolePreferences:{...d.rolePreferences, workTypes: d.rolePreferences.workTypes.includes(w)? d.rolePreferences.workTypes.filter(x=>x!==w): [...d.rolePreferences.workTypes,w] }}))} className={`px-3 py-1 rounded border ${data.rolePreferences.workTypes.includes(w)?'bg-pink-50 border-pink-500 text-pink-700':'bg-white'}`}>{w}</button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <div className="font-medium mb-1">Preferred locations</div>
                    <div className="space-y-2">
                      {data.rolePreferences.workLocations.map(loc => (
                        <div key={loc.id} className="flex gap-2 items-center">
                          <select className="border rounded px-2 py-2" value={loc.city} onChange={e=>updLoc(loc.id,'city',e.target.value)}>
                            <option value="">City</option>
                            {cities.map(c=> <option key={c}>{c}</option>)}
                          </select>
                          <input className="border rounded px-2 py-2 flex-1" placeholder="Area" value={loc.area} onChange={e=>updLoc(loc.id,'area',e.target.value)} />
                          {data.rolePreferences.workLocations.length>1 && (<button onClick={()=>rmLoc(loc.id)} className="p-2 text-gray-500 hover:text-red-600"><Trash2 className="w-4 h-4"/></button>)}
                        </div>
                      ))}
                      <button onClick={addLoc} className="inline-flex items-center text-blue-600 hover:text-blue-700"><Plus className="w-4 h-4 mr-1"/>Add location</button>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <div className="font-medium mb-1">Right to work in NZ</div>
                      <div className="flex gap-2">
                        {['Yes','No'].map(v => (
                          <button key={v} onClick={()=>setData(d=>({...d, rolePreferences:{...d.rolePreferences, rightToWorkNZ: v}}))} className={`px-3 py-1 rounded border ${data.rolePreferences.rightToWorkNZ===v? 'bg-pink-50 border-pink-500 text-pink-700':'bg-white'}`}>{v}</button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <div className="font-medium text-gray-900 mb-2">Minimum Salary (display)</div>
                      <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="e.g. NZD $100,000" value={data.rolePreferences.minimumSalary} onChange={e=>setData(d=>({...d, rolePreferences:{...d.rolePreferences, minimumSalary:e.target.value}}))} />
                    </div>
                  </div>
                  </div>
                </div>
              )}

              {step===0 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <Upload className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">Resume Upload</h4>
                    <p className="text-gray-600">Upload your resume to help us auto-fill your profile (optional)</p>
                  </div>
                  <div>
                    <FileUploadZone
                      options={{ bucket: 'resumes', fileType: 'resume', maxSize: 10 * 1024 * 1024 }}
                      onUploadComplete={async (file: UploadedFile) => {
                        const meta: ResumeMeta = { id: file.id, name: file.name, url: file.url, path: file.path, size: file.size, uploadedAt: new Date().toISOString() };
                        setData(d => ({ ...d, resumes: [...(d.resumes || []), meta], primaryResumeId: d.primaryResumeId || meta.id }));
                        // Ask if we should auto-fill using this resume
                        try {
                          const yes = window.confirm('Use this resume to auto-fill your profile?');
                          if (yes) { await extractFromResume(meta); }
                        } catch {}
                      }}
                    />
                  </div>
                  {(data.resumes && data.resumes.length > 0) ? (
                    <div>
                      {parsedPreview && (
                        <div className="mb-4 border rounded-lg p-4 bg-blue-50 border-blue-200">
                          <div className="flex items-center justify-between mb-2">
                            <div className="font-medium text-blue-900">Review extracted details</div>
                            <div className="text-xs text-blue-800">Preview before applying</div>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                            <div>
                              <div className="font-semibold mb-1">Skills</div>
                              {parsedPreview.skills.length === 0 ? (
                                <div className="text-blue-800">None detected</div>
                              ) : (
                                <div className="flex flex-wrap gap-1">
                                  {parsedPreview.skills.map(s => (
                                    <span key={s} className="px-2 py-0.5 rounded bg-white text-blue-900 border border-blue-200">{s}</span>
                                  ))}
                                </div>
                              )}
                            </div>
                            <div>
                              <div className="font-semibold mb-1">Experience</div>
                              {parsedPreview.experiences.length === 0 ? (
                                <div className="text-blue-800">None detected</div>
                              ) : (
                                <ul className="list-disc list-inside text-blue-900">
                                  {parsedPreview.experiences.map((e, i) => (
                                    <li key={i}><span className="font-medium">{e.jobTitle}</span> — {e.company}</li>
                                  ))}
                                </ul>
                              )}
                            </div>
                          </div>
                          <div className="mt-3 flex gap-2 justify-end">
                            <button onClick={cancelParsedPreview} className="px-3 py-1.5 text-sm border rounded">Cancel</button>
                            <button onClick={applyParsedPreview} className="px-3 py-1.5 text-sm bg-blue-600 text-white rounded">Apply</button>
                          </div>
                        </div>
                      )}
                      <div className="font-medium mb-2">Your resumes</div>
                      <div className="space-y-2">
                        {data.resumes.map(r => (
                          <div key={r.id} className="border rounded p-3">
                            <div className="flex items-center justify-between">
                              <label className="flex items-center gap-3">
                                <input type="radio" name="primaryResume" checked={data.primaryResumeId === r.id} onChange={()=>setData(d=>({...d, primaryResumeId: r.id}))} />
                                <div>
                                  <div className="font-medium text-sm">{r.name}</div>
                                  <div className="text-xs text-gray-500">{r.size ? (r.size/1024/1024).toFixed(2)+' MB' : ''} {r.uploadedAt ? '• ' + new Date(r.uploadedAt).toLocaleDateString() : ''}</div>
                                </div>
                              </label>
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={()=>setData(d=>({ ...d, resumes: (d.resumes||[]).filter(x=>x.id!==r.id), primaryResumeId: d.primaryResumeId===r.id ? (d.resumes||[]).find(x=>x.id!==r.id)?.id : d.primaryResumeId }))}
                                  className="p-2 text-gray-500 hover:text-red-600"
                                  title="Remove resume"
                                >
                                  <Trash2 className="w-4 h-4"/>
                                </button>
                                <button
                                  onClick={async ()=>{ await extractFromResume(r); }}
                                  className="px-2 py-1 text-xs border rounded hover:bg-gray-50"
                                  title="Extract details from this resume"
                                >
                                  Extract Details
                                </button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-600">No resumes yet. Upload a PDF or DOC (max 10MB).</p>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="px-6 py-4 border-t bg-gray-50 flex items-center justify-between flex-shrink-0">
            <div className="text-sm text-gray-600">Step {step + 1} of {stepTitles.length}</div>
            <div className="flex items-center gap-3">
              {step > 0 && (
                <button
                  onClick={() => setStep(s => Math.max(0, s - 1))}
                  className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100 font-medium transition-colors"
                >
                  Back
                </button>
              )}
              {step < stepTitles.length - 1 ? (
                <button
                  onClick={() => canNext() && setStep(s => s + 1)}
                  disabled={!canNext()}
                  className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Next
                </button>
              ) : (
                <button
                  onClick={onSave}
                  className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium transition-colors flex items-center gap-2"
                >
                  <CheckCircle className="w-4 h-4" />
                  Save Profile
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const SkillInput: React.FC<{ skills: string[]; onAdd: (s: string)=>void; onRemove:(s:string)=>void }> = ({ skills, onAdd, onRemove }) => {
  const [input, setInput] = React.useState('');
  return (
    <div>
      <div className="flex gap-2 mb-2">
        <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{ if (e.key==='Enter'){ e.preventDefault(); onAdd(input); setInput(''); } }} className="flex-1 border rounded px-3 py-2" placeholder="Add a skill and press Enter" />
        <button onClick={()=>{ onAdd(input); setInput(''); }} className="px-3 py-2 bg-blue-600 text-white rounded">Add</button>
      </div>
      <div className="flex flex-wrap gap-2">
        {skills.map(s => (
          <span key={s} className="inline-flex items-center px-2 py-1 rounded-full bg-gray-100 text-gray-700 text-xs">{s}<button onClick={()=>onRemove(s)} className="ml-1 text-gray-500 hover:text-gray-700"><X className="w-3 h-3"/></button></span>
        ))}
      </div>
    </div>
  );
};

export default CandidateProfileSetup;
