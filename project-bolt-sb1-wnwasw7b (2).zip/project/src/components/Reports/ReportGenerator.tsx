import React, { useState } from 'react';
import { useAnalytics } from '../../hooks/useAnalytics';
import { 
  FileText, 
  Download, 
  Calendar, 
  Filter,
  BarChart3,
  Users,
  DollarSign,
  Briefcase,
  Clock,
  CheckCircle
} from 'lucide-react';

interface ReportConfig {
  type: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  parameters: string[];
}

const ReportGenerator: React.FC = () => {
  const { generateReport } = useAnalytics();
  const [selectedReport, setSelectedReport] = useState<string>('');
  const [parameters, setParameters] = useState<Record<string, any>>({
    dateFrom: '',
    dateTo: '',
    includeDetails: true,
    format: 'pdf',
  });
  const [generating, setGenerating] = useState(false);

  const reportConfigs: ReportConfig[] = [
    {
      type: 'user_activity',
      name: 'User Activity Report',
      description: 'Detailed user engagement and activity patterns',
      icon: <Users className="w-5 h-5" />,
      parameters: ['dateFrom', 'dateTo', 'userRole', 'includeDetails'],
    },
    {
      type: 'revenue_breakdown',
      name: 'Revenue Analysis',
      description: 'Revenue breakdown by tier, organization, and time period',
      icon: <DollarSign className="w-5 h-5" />,
      parameters: ['dateFrom', 'dateTo', 'groupBy', 'includeProjections'],
    },
    {
      type: 'job_performance',
      name: 'Job Performance Report',
      description: 'Job posting success rates and application metrics',
      icon: <Briefcase className="w-5 h-5" />,
      parameters: ['dateFrom', 'dateTo', 'adTier', 'includeComparisons'],
    },
    {
      type: 'platform_health',
      name: 'Platform Health Report',
      description: 'System performance, uptime, and technical metrics',
      icon: <BarChart3 className="w-5 h-5" />,
      parameters: ['dateFrom', 'dateTo', 'includeAlerts', 'detailLevel'],
    },
    {
      type: 'compliance_audit',
      name: 'Compliance Audit Report',
      description: 'Data privacy, security, and regulatory compliance',
      icon: <CheckCircle className="w-5 h-5" />,
      parameters: ['dateFrom', 'dateTo', 'complianceType', 'includeRecommendations'],
    },
    {
      type: 'financial_summary',
      name: 'Financial Summary',
      description: 'Comprehensive financial overview and projections',
      icon: <FileText className="w-5 h-5" />,
      parameters: ['dateFrom', 'dateTo', 'includeForecasts', 'breakdownLevel'],
    },
  ];

  const handleGenerateReport = async () => {
    if (!selectedReport) {
      alert('Please select a report type');
      return;
    }

    setGenerating(true);
    try {
      await generateReport(selectedReport, parameters);
      alert('Report generation started. You will receive a notification when it\'s ready.');
    } catch (error) {
      console.error('Error generating report:', error);
      alert('Failed to generate report. Please try again.');
    } finally {
      setGenerating(false);
    }
  };

  const selectedConfig = reportConfigs.find(config => config.type === selectedReport);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Report Generator</h2>
        <p className="text-gray-600">Generate comprehensive reports and analytics</p>
      </div>

      {/* Report Selection */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Select Report Type</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {reportConfigs.map((config) => (
            <label key={config.type} className="cursor-pointer">
              <input
                type="radio"
                name="reportType"
                value={config.type}
                checked={selectedReport === config.type}
                onChange={(e) => setSelectedReport(e.target.value)}
                className="sr-only"
              />
              <div className={`p-4 border-2 rounded-lg transition-all ${
                selectedReport === config.type
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}>
                <div className="flex items-center mb-2">
                  <div className={`p-2 rounded-lg ${
                    selectedReport === config.type ? 'bg-blue-100' : 'bg-gray-100'
                  }`}>
                    <div className={selectedReport === config.type ? 'text-blue-600' : 'text-gray-600'}>
                      {config.icon}
                    </div>
                  </div>
                  <h4 className="ml-3 font-medium text-gray-900">{config.name}</h4>
                </div>
                <p className="text-sm text-gray-600">{config.description}</p>
              </div>
            </label>
          ))}
        </div>
      </div>

      {/* Report Parameters */}
      {selectedConfig && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Report Parameters</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Date Range */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="w-4 h-4 inline mr-1" />
                Date From
              </label>
              <input
                type="date"
                value={parameters.dateFrom}
                onChange={(e) => setParameters(prev => ({ ...prev, dateFrom: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="w-4 h-4 inline mr-1" />
                Date To
              </label>
              <input
                type="date"
                value={parameters.dateTo}
                onChange={(e) => setParameters(prev => ({ ...prev, dateTo: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            {/* Format Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <FileText className="w-4 h-4 inline mr-1" />
                Format
              </label>
              <select
                value={parameters.format}
                onChange={(e) => setParameters(prev => ({ ...prev, format: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="pdf">PDF</option>
                <option value="csv">CSV</option>
                <option value="excel">Excel</option>
                <option value="json">JSON</option>
              </select>
            </div>

            {/* Additional Parameters based on report type */}
            {selectedReport === 'user_activity' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  User Role Filter
                </label>
                <select
                  value={parameters.userRole || ''}
                  onChange={(e) => setParameters(prev => ({ ...prev, userRole: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">All Roles</option>
                  <option value="employer">Employers</option>
                  <option value="recruiter">Recruiters</option>
                  <option value="candidate">Candidates</option>
                </select>
              </div>
            )}

            {selectedReport === 'revenue_breakdown' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Group By
                </label>
                <select
                  value={parameters.groupBy || 'month'}
                  onChange={(e) => setParameters(prev => ({ ...prev, groupBy: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="day">Daily</option>
                  <option value="week">Weekly</option>
                  <option value="month">Monthly</option>
                  <option value="quarter">Quarterly</option>
                </select>
              </div>
            )}
          </div>

          {/* Options */}
          <div className="mt-6">
            <h4 className="font-medium text-gray-900 mb-3">Options</h4>
            <div className="space-y-2">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={parameters.includeDetails}
                  onChange={(e) => setParameters(prev => ({ ...prev, includeDetails: e.target.checked }))}
                  className="rounded border-gray-300 text-blue-600"
                />
                <span className="ml-2 text-sm text-gray-700">Include detailed breakdowns</span>
              </label>
              
              {selectedReport === 'revenue_breakdown' && (
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={parameters.includeProjections}
                    onChange={(e) => setParameters(prev => ({ ...prev, includeProjections: e.target.checked }))}
                    className="rounded border-gray-300 text-blue-600"
                  />
                  <span className="ml-2 text-sm text-gray-700">Include revenue projections</span>
                </label>
              )}

              {selectedReport === 'platform_health' && (
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={parameters.includeAlerts}
                    onChange={(e) => setParameters(prev => ({ ...prev, includeAlerts: e.target.checked }))}
                    className="rounded border-gray-300 text-blue-600"
                  />
                  <span className="ml-2 text-sm text-gray-700">Include system alerts</span>
                </label>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Generate Button */}
      {selectedConfig && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-gray-900">Ready to Generate</h4>
              <p className="text-sm text-gray-600">
                {selectedConfig.name} • {parameters.format.toUpperCase()} format
              </p>
            </div>
            <button
              onClick={handleGenerateReport}
              disabled={generating}
              className="flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {generating ? (
                <>
                  <Clock className="w-5 h-5 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Download className="w-5 h-5 mr-2" />
                  Generate Report
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Recent Reports */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Reports</h3>
        <div className="space-y-3">
          {[
            { name: 'User Activity Report', type: 'user_activity', generatedAt: new Date(), status: 'completed' },
            { name: 'Revenue Analysis', type: 'revenue_breakdown', generatedAt: new Date(), status: 'completed' },
            { name: 'Platform Health Report', type: 'platform_health', generatedAt: new Date(), status: 'generating' },
          ].map((report, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <FileText className="w-5 h-5 text-gray-400 mr-3" />
                <div>
                  <p className="font-medium text-gray-900">{report.name}</p>
                  <p className="text-sm text-gray-600">
                    Generated {report.generatedAt.toLocaleDateString()}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                  report.status === 'completed' ? 'bg-green-100 text-green-800' :
                  report.status === 'generating' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {report.status}
                </span>
                {report.status === 'completed' && (
                  <button className="flex items-center text-sm text-blue-600 hover:text-blue-700">
                    <Download className="w-4 h-4 mr-1" />
                    Download
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ReportGenerator;