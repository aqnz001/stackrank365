import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  Home,
  Briefcase,
  Users,
  FileText,
  Settings,
  Shield,
  User,
  MessageSquare,
  CreditCard,
  BarChart3,
  UserPlus,
  Eye
} from 'lucide-react';

interface SidebarItem {
  icon: React.ReactNode;
  label: string;
  href: string;
  roles: string[];
}

const sidebarItems: SidebarItem[] = [
  { icon: <Home className="w-5 h-5" />, label: 'Dashboard', href: '#dashboard', roles: ['employer', 'recruiter', 'candidate', 'admin'] },
  { icon: <Briefcase className="w-5 h-5" />, label: 'Jobs', href: '#jobs', roles: ['employer', 'recruiter', 'candidate'] },
  { icon: <Users className="w-5 h-5" />, label: 'Applications', href: '#applications', roles: ['employer'] },
  { icon: <UserPlus className="w-5 h-5" />, label: 'Recruiter Bids', href: '#bids', roles: ['employer'] },
  { icon: <Eye className="w-5 h-5" />, label: 'Job Search', href: '#job-search', roles: ['recruiter'] },
  { icon: <MessageSquare className="w-5 h-5" />, label: 'Bidding', href: '#bidding', roles: ['recruiter'] },
  { icon: <FileText className="w-5 h-5" />, label: 'Consents', href: '#consents', roles: ['candidate'] },
  { icon: <User className="w-5 h-5" />, label: 'Profile', href: '#profile', roles: ['recruiter'] },
  { icon: <CreditCard className="w-5 h-5" />, label: 'Billing', href: '#billing', roles: ['employer', 'recruiter'] },
  { icon: <BarChart3 className="w-5 h-5" />, label: 'Analytics', href: '#analytics', roles: ['employer', 'admin'] },
  { icon: <Shield className="w-5 h-5" />, label: 'Admin', href: '#admin', roles: ['admin'] },
  { icon: <Settings className="w-5 h-5" />, label: 'Settings', href: '#settings', roles: ['employer', 'recruiter', 'candidate', 'admin'] },
];

const Sidebar: React.FC = () => {
  const { user } = useAuth();
  const [activeItem, setActiveItem] = React.useState('#dashboard');

  const filteredItems = sidebarItems.filter(item => 
    user?.role && item.roles.includes(user.role)
  );

  return (
    <div className="w-64 bg-white border-r border-gray-200 min-h-screen">
      <div className="p-4">
        <nav className="space-y-2">
          {filteredItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={(e) => {
                e.preventDefault();
                setActiveItem(item.href);
              }}
              className={`flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeItem === item.href
                  ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-600'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
            </a>
          ))}
        </nav>
      </div>
    </div>
  );
};

export default Sidebar;
