import React from 'react';
import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../hooks/useNotifications';
import { useMessages } from '../../hooks/useMessages';
import NotificationCenter from '../Notifications/NotificationCenter';
import MessageCenter from '../Messages/MessageCenter';
import JobPostForm from '../Jobs/JobPostForm';
import MyApplicationsModal from '../Applications/MyApplicationsModal';
import CompanyProfileModal from '../Organizations/CompanyProfileModal';
import OnboardingWizard from '../Recruiter/OnboardingWizard';
import ThemeToggle from './ThemeToggle';
import { 
  User, 
  LogOut, 
  Settings, 
  Bell,
  MessageSquare,
  Briefcase,
  Users,
  UserCheck,
  Shield
} from 'lucide-react';

const Navbar: React.FC = () => {
  const { user, logout } = useAuth();
  const { unreadCount } = useNotifications();
  const { conversations } = useMessages();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showMessages, setShowMessages] = useState(false);
  const [showJobPost, setShowJobPost] = useState(false);
  const [showMyApps, setShowMyApps] = useState(false);
  const [showCompanyProfile, setShowCompanyProfile] = useState(false);
  const [showTeamManager, setShowTeamManager] = useState(false);

  const unreadMessageCount = conversations.reduce((total, conv) => total + (conv.unreadCount || 0), 0);

  const getRoleIcon = () => {
    switch (user?.role) {
      case 'employer': return <Briefcase className="w-5 h-5" />;
      case 'recruiter': return <Users className="w-5 h-5" />;
      case 'candidate': return <UserCheck className="w-5 h-5" />;
      case 'admin': return <Shield className="w-5 h-5" />;
      default: return <User className="w-5 h-5" />;
    }
  };

  const getRoleName = () => {
    switch (user?.role) {
      case 'employer': return 'Employer';
      case 'recruiter': return 'Recruiter';
      case 'candidate': return 'Candidate';
      case 'admin': return 'Admin';
      default: return 'User';
    }
  };

  // Navigation helpers (function declarations are hoisted to avoid init-order issues)
  function onGotoDashboard() {
    if (window.location.hash !== '#dashboard') {
      window.location.hash = '#dashboard';
    }
  }

  function onGotoHome() {
    if (window.location.hash) {
      window.location.hash = '';
    }
  }

  function onGotoDashboardTab(tab: string) {
    const target = `#dashboard:${tab}`;
    if (window.location.hash !== target) {
      window.location.hash = target;
    }
  }

  // Build primary menu based on role
  const primaryMenu = React.useMemo(() => {
    const btn = (label: string, onClick?: () => void, extra?: React.ReactNode) => (
      <button key={label} onClick={onClick} className="px-4 py-2 rounded-lg text-gray-700 hover:text-blue-600 hover:bg-blue-50 whitespace-nowrap inline-flex items-center gap-2 font-medium transition-all">
        <span>{label}</span>
        {extra}
      </button>
    );

    if (!user) {
      return [
        btn('Profile'),
        btn('Career advice'),
        btn('Explore companies'),
        btn('Explore recruiters'),
        btn('Community', undefined, <span className="text-[10px] px-1.5 py-0.5 rounded bg-green-500 text-white">New</span>),
      ];
    }

    switch (user.role) {
      case 'candidate':
        return [
          btn('Home', onGotoHome),
          btn('Dashboard', onGotoDashboard),
        ];
      case 'employer':
        return [
          btn('Dashboard', onGotoDashboard),
          btn('Post a job', () => setShowJobPost(true)),
          btn('Company profile', () => setShowCompanyProfile(true)),
        ];
      case 'recruiter':
        return [
          btn('Dashboard', onGotoDashboard),
          btn('Team', () => setShowTeamManager(true)),
          btn('Agency profile', () => setShowCompanyProfile(true)),
        ];
      case 'admin':
        return [
          btn('Dashboard', onGotoDashboard),
          btn('Admin tools', onGotoDashboard),
        ];
      default:
        return [btn('Dashboard', onGotoDashboard)];
    }
  }, [user]);

  const isGuest = !user;

  return (
    <nav className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Left: Brand + Primary nav */}
          <div className="flex items-center min-w-0">
            <button onClick={onGotoHome} className="flex items-center flex-shrink-0 group">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-blue-700 text-white flex items-center justify-center font-bold text-lg shadow-md group-hover:shadow-lg transition-all">JH</div>
              <span className="ml-3 text-xl font-bold tracking-tight text-gray-900">JobHub</span>
            </button>
            <div className="hidden md:flex items-center ml-8 gap-2 text-sm">
              {primaryMenu}
            </div>
          </div>

          {/* Right: Auth/Actions */}
          <div className="flex items-center gap-2">
            {isGuest ? (
              <>
                <button
                  onClick={() => { window.location.hash = '#signin'; }}
                  className="hidden sm:inline-flex items-center px-4 py-2 rounded-lg border-2 border-gray-300 text-gray-700 hover:bg-gray-50 hover:border-gray-400 font-medium transition-all"
                >
                  Sign in
                </button>
                <button
                  onClick={() => { window.location.hash = '#signup'; }}
                  className="hidden sm:inline-flex items-center px-5 py-2 rounded-lg bg-blue-600 text-white font-semibold hover:bg-blue-700 active:bg-blue-800 shadow-sm hover:shadow-md transition-all"
                >
                  Sign up
                </button>
                <button
                  onClick={onGotoDashboard}
                  className="inline-flex items-center px-4 py-2 rounded-lg border-2 border-gray-300 text-gray-700 hover:bg-gray-50 hover:border-gray-400 font-medium transition-all"
                >
                  Employer site
                </button>
              </>
            ) : (
              <>
                {/* Role-based quick actions */}
                {/* Employer quick-post removed to avoid duplication */}
                {/* Candidate quick-link removed per navigation cleanup */}

                <button
                  onClick={() => setShowMessages(true)}
                  className="relative p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
                  aria-label="Messages"
                >
                  <MessageSquare className="w-5 h-5" />
                  {unreadMessageCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                      {unreadMessageCount > 9 ? '9+' : unreadMessageCount}
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setShowNotifications(true)}
                  className="relative p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
                  aria-label="Notifications"
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </span>
                  )}
                </button>

                <div className="flex items-center space-x-2">
                  <ThemeToggle />
                  <div className="hidden md:flex items-center space-x-2 px-3 py-1.5 bg-gray-100 rounded-lg text-gray-700">
                    {getRoleIcon()}
                    <span className="text-sm font-medium">{getRoleName()}</span>
                  </div>
                  <div className="w-8 h-8 bg-gray-200 rounded flex items-center justify-center text-gray-700">
                    <span className="text-sm font-medium">
                      {user?.name?.charAt(0)?.toUpperCase()}
                    </span>
                  </div>
                  <div className="hidden lg:block">
                    <div className="text-sm font-medium text-gray-800">{user?.name}</div>
                    <div className="text-xs text-gray-500">{user?.email}</div>
                  </div>
                  <button className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors" aria-label="Settings">
                    <Settings className="w-5 h-5" />
                  </button>
                  <button
                    onClick={logout}
                    className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
                    aria-label="Sign out"
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Notification Center */}
      <NotificationCenter
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
      />

      {/* Message Center */}
      <MessageCenter
        isOpen={showMessages}
        onClose={() => setShowMessages(false)}
      />

      {/* Role-based modals */}
      {showJobPost && user?.role === 'employer' && (
        <JobPostForm onClose={() => setShowJobPost(false)} />
      )}
      {showCompanyProfile && user?.role === 'employer' && (
        <CompanyProfileModal onClose={() => setShowCompanyProfile(false)} />
      )}
      {showCompanyProfile && user?.role === 'recruiter' && (
        <OnboardingWizard isOpen={showCompanyProfile} onClose={() => setShowCompanyProfile(false)} />
      )}
      {showTeamManager && user?.role === 'recruiter' && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/40" onClick={()=>setShowTeamManager(false)} />
          <div className="absolute inset-0 flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden">
              <div className="px-6 py-4 border-b font-semibold">Team</div>
              <div className="p-6 max-h-[80vh] overflow-auto">
                {(() => { const C = require('../Recruiter/RecruiterTeamManager').default; return <C onClose={()=>setShowTeamManager(false)} />; })()}
              </div>
            </div>
          </div>
        </div>
      )}
      {/* MyApplications modal removed from navbar for candidates */}
    </nav>
  );
};

export default Navbar;
