import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { usePayments } from '../../hooks/usePayments';
import { formatCurrency } from '../../lib/stripe';
import { 
  Shield, 
  DollarSign, 
  Clock, 
  CheckCircle,
  AlertTriangle,
  Eye,
  Download,
  RefreshCw
} from 'lucide-react';

interface EscrowTransaction {
  id: string;
  recruiterBidId: string;
  billingAccountId: string;
  amount: number;
  platformFee: number;
  recruiterFee: number;
  currency: string;
  status: 'pending' | 'held' | 'released' | 'refunded' | 'disputed';
  heldUntil?: Date;
  releasedAt?: Date;
  refundedAt?: Date;
  disputeId?: string;
  metadata: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
  // Populated fields
  recruiterName?: string;
  jobTitle?: string;
  candidateName?: string;
}

const EscrowManager: React.FC = () => {
  const [escrowTransactions, setEscrowTransactions] = useState<EscrowTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedTransaction, setSelectedTransaction] = useState<EscrowTransaction | null>(null);
  const { user } = useAuth();
  const { releaseEscrow } = usePayments();

  const fetchEscrowTransactions = async () => {
    if (!user?.organizationId) return;

    try {
      setLoading(true);
      setError(null);

      // First, get all recruiter bids related to this organization's jobs
      const { data: jobsData } = await supabase
        .from('jobs')
        .select('id')
        .eq('organization_id', user.organizationId);

      const jobIds = (jobsData || []).map(job => job.id);

      if (jobIds.length === 0) {
        setEscrowTransactions([]);
        setLoading(false);
        return;
      }

      // Get recruiter bids for these jobs
      const { data: bidsData } = await supabase
        .from('recruiter_bids')
        .select('id')
        .in('job_id', jobIds);

      const bidIds = (bidsData || []).map(bid => bid.id);

      if (bidIds.length === 0) {
        setEscrowTransactions([]);
        setLoading(false);
        return;
      }

      // Now fetch escrow transactions for these bids
      const { data, error: fetchError } = await supabase
        .from('escrow_transactions')
        .select(`
          *,
          recruiter_bids!escrow_transactions_recruiter_bid_id_fkey (
            id,
            recruiter_id,
            job_id,
            profiles!recruiter_bids_recruiter_id_fkey (
              name
            ),
            jobs!recruiter_bids_job_id_fkey (
              title,
              organization_id
            )
          )
        `)
        .in('recruiter_bid_id', bidIds)
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;

      const transformedTransactions: EscrowTransaction[] = (data || []).map(tx => ({
        id: tx.id,
        recruiterBidId: tx.recruiter_bid_id,
        billingAccountId: tx.billing_account_id,
        amount: tx.amount,
        platformFee: tx.platform_fee,
        recruiterFee: tx.recruiter_fee,
        currency: tx.currency,
        status: tx.status,
        heldUntil: tx.held_until ? new Date(tx.held_until) : undefined,
        releasedAt: tx.released_at ? new Date(tx.released_at) : undefined,
        refundedAt: tx.refunded_at ? new Date(tx.refunded_at) : undefined,
        disputeId: tx.dispute_id,
        metadata: tx.metadata,
        createdAt: new Date(tx.created_at),
        updatedAt: new Date(tx.updated_at),
        recruiterName: tx.recruiter_bids?.profiles?.name,
        jobTitle: tx.recruiter_bids?.jobs?.title,
      }));

      setEscrowTransactions(transformedTransactions);
    } catch (err) {
      console.error('Error fetching escrow transactions:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch escrow transactions');
    } finally {
      setLoading(false);
    }
  };


  const handleReleaseEscrow = async (transactionId: string) => {
    if (window.confirm('Are you sure you want to release this escrow payment? This action cannot be undone.')) {
      try {
        await releaseEscrow(transactionId);
        await fetchEscrowTransactions();
      } catch (error) {
        console.error('Error releasing escrow:', error);
        alert('Failed to release escrow payment. Please try again.');
      }
    }
  };

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'pending':
        return { color: 'yellow', icon: <Clock className="w-4 h-4" />, label: 'Pending' };
      case 'held':
        return { color: 'blue', icon: <Shield className="w-4 h-4" />, label: 'Held in Escrow' };
      case 'released':
        return { color: 'green', icon: <CheckCircle className="w-4 h-4" />, label: 'Released' };
      case 'refunded':
        return { color: 'gray', icon: <RefreshCw className="w-4 h-4" />, label: 'Refunded' };
      case 'disputed':
        return { color: 'red', icon: <AlertTriangle className="w-4 h-4" />, label: 'Disputed' };
      default:
        return { color: 'gray', icon: <Clock className="w-4 h-4" />, label: 'Unknown' };
    }
  };

  useEffect(() => {
    fetchEscrowTransactions();
  }, [user?.organizationId]);

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <div className="flex items-center">
          <AlertTriangle className="w-5 h-5 text-red-600 mr-2" />
          <p className="text-red-800">Error loading escrow data: {error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Escrow Management</h2>
          <p className="text-gray-600">Manage recruiter payment escrow transactions</p>
        </div>
        <button
          onClick={fetchEscrowTransactions}
          className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
        >
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </button>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
          <Shield className="w-8 h-8 text-blue-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-gray-900">
            {escrowTransactions.filter(tx => tx.status === 'held').length}
          </div>
          <div className="text-sm text-gray-600">Active Escrows</div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
          <DollarSign className="w-8 h-8 text-green-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-gray-900">
            {formatCurrency(
              escrowTransactions
                .filter(tx => tx.status === 'held')
                .reduce((sum, tx) => sum + tx.amount, 0)
            )}
          </div>
          <div className="text-sm text-gray-600">Total Held</div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
          <CheckCircle className="w-8 h-8 text-purple-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-gray-900">
            {escrowTransactions.filter(tx => tx.status === 'released').length}
          </div>
          <div className="text-sm text-gray-600">Released</div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
          <AlertTriangle className="w-8 h-8 text-red-600 mx-auto mb-2" />
          <div className="text-2xl font-bold text-gray-900">
            {escrowTransactions.filter(tx => tx.status === 'disputed').length}
          </div>
          <div className="text-sm text-gray-600">Disputes</div>
        </div>
      </div>

      {/* Escrow Transactions */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Escrow Transactions</h3>
        </div>

        {escrowTransactions.length === 0 ? (
          <div className="text-center py-12">
            <Shield className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h4 className="text-lg font-medium text-gray-900 mb-2">No Escrow Transactions</h4>
            <p className="text-gray-600">
              Escrow transactions will appear here when recruiter bids are accepted
            </p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {escrowTransactions.map((transaction) => {
              const statusConfig = getStatusConfig(transaction.status);
              
              return (
                <div key={transaction.id} className="p-6 hover:bg-gray-50">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h4 className="font-semibold text-gray-900">{transaction.jobTitle}</h4>
                        <span className={`flex items-center px-3 py-1 rounded-full text-sm font-medium bg-${statusConfig.color}-100 text-${statusConfig.color}-800`}>
                          {statusConfig.icon}
                          <span className="ml-1">{statusConfig.label}</span>
                        </span>
                      </div>
                      
                      <p className="text-gray-600 mb-2">
                        Recruiter: {transaction.recruiterName}
                      </p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="text-gray-500">Total Amount:</span>
                          <div className="font-semibold text-gray-900">{formatCurrency(transaction.amount)}</div>
                        </div>
                        <div>
                          <span className="text-gray-500">Platform Fee:</span>
                          <div className="font-semibold text-gray-900">{formatCurrency(transaction.platformFee)}</div>
                        </div>
                        <div>
                          <span className="text-gray-500">Recruiter Fee:</span>
                          <div className="font-semibold text-gray-900">{formatCurrency(transaction.recruiterFee)}</div>
                        </div>
                      </div>

                      {transaction.heldUntil && (
                        <p className="text-sm text-gray-500 mt-2">
                          <Clock className="w-4 h-4 inline mr-1" />
                          Held until: {transaction.heldUntil.toLocaleDateString()}
                        </p>
                      )}
                    </div>

                    <div className="flex flex-col space-y-2 ml-6">
                      <button
                        onClick={() => setSelectedTransaction(transaction)}
                        className="flex items-center px-3 py-1 text-sm bg-gray-100 text-gray-700 rounded hover:bg-gray-200"
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        Details
                      </button>
                      
                      {transaction.status === 'held' && user?.role === 'employer' && (
                        <button
                          onClick={() => handleReleaseEscrow(transaction.id)}
                          className="px-3 py-1 text-sm bg-green-600 text-white rounded hover:bg-green-700"
                        >
                          Release Payment
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Transaction Details Modal */}
      {selectedTransaction && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-gray-900">Escrow Transaction Details</h3>
              <button
                onClick={() => setSelectedTransaction(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-3">Transaction Info</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Transaction ID:</span>
                      <span className="font-mono text-gray-900">{selectedTransaction.id.slice(0, 8)}...</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Created:</span>
                      <span className="font-medium">{selectedTransaction.createdAt.toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Status:</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        getStatusConfig(selectedTransaction.status).color === 'green' ? 'bg-green-100 text-green-800' :
                        getStatusConfig(selectedTransaction.status).color === 'blue' ? 'bg-blue-100 text-blue-800' :
                        getStatusConfig(selectedTransaction.status).color === 'red' ? 'bg-red-100 text-red-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {getStatusConfig(selectedTransaction.status).label}
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-gray-900 mb-3">Payment Breakdown</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Amount:</span>
                      <span className="font-semibold">{formatCurrency(selectedTransaction.amount)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Platform Fee (15%):</span>
                      <span className="font-medium">{formatCurrency(selectedTransaction.platformFee)}</span>
                    </div>
                    <div className="flex justify-between border-t pt-2">
                      <span className="text-gray-600">Recruiter Receives:</span>
                      <span className="font-bold text-green-600">{formatCurrency(selectedTransaction.recruiterFee)}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium text-gray-900 mb-3">Job & Recruiter Info</h4>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="font-medium text-gray-900">{selectedTransaction.jobTitle}</p>
                  <p className="text-gray-600">Recruiter: {selectedTransaction.recruiterName}</p>
                </div>
              </div>

              {selectedTransaction.status === 'held' && selectedTransaction.heldUntil && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-center">
                    <Clock className="w-5 h-5 text-yellow-600 mr-2" />
                    <div>
                      <p className="font-medium text-yellow-900">Guarantee Period</p>
                      <p className="text-yellow-800 text-sm">
                        Payment will be automatically released on {selectedTransaction.heldUntil.toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setSelectedTransaction(null)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Close
                </button>
                
                {selectedTransaction.status === 'held' && user?.role === 'employer' && (
                  <button
                    onClick={() => {
                      handleReleaseEscrow(selectedTransaction.id);
                      setSelectedTransaction(null);
                    }}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                  >
                    Release Payment
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EscrowManager;