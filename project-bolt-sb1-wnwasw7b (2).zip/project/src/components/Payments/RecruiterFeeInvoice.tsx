import React, { useState, useEffect } from 'react';
import {
  FileText,
  DollarSign,
  Calendar,
  Building,
  User,
  Download,
  Send,
  CheckCircle,
  Clock,
  AlertTriangle,
} from 'lucide-react';
import { useBilling } from '../../hooks/useBilling';
import { useScheduledPayments } from '../../hooks/usePaymentSchedules';
import type { RecruiterBid } from '../../types';

interface RecruiterFeeInvoiceProps {
  bid: RecruiterBid;
  jobTitle: string;
  salaryAmount?: number;
  onPaymentComplete?: () => void;
}

const RecruiterFeeInvoice: React.FC<RecruiterFeeInvoiceProps> = ({
  bid,
  jobTitle,
  salaryAmount,
  onPaymentComplete,
}) => {
  const [totalAmount, setTotalAmount] = useState<number>(0);
  const [showPaymentConfirmation, setShowPaymentConfirmation] = useState(false);
  const [processing, setProcessing] = useState(false);

  const { createInvoice, billingAccount } = useBilling();
  const { payments } = useScheduledPayments(bid.id);

  useEffect(() => {
    if (bid.feeType === 'flat') {
      setTotalAmount(bid.feeValue);
    } else if (bid.feeType === 'percent' && salaryAmount) {
      setTotalAmount((salaryAmount * bid.feeValue) / 100);
    }
  }, [bid, salaryAmount]);

  const milestonePayments = payments.map((payment) => ({
    name: payment.milestoneName,
    amount: payment.amount / 100,
    percentage: payment.percentage,
    status: payment.status,
  }));

  const handleGenerateInvoice = async () => {
    if (!billingAccount) {
      alert('Please set up billing account first');
      return;
    }

    setProcessing(true);

    try {
      await createInvoice({
        description: `Recruiter Fee - ${jobTitle}`,
        items: [
          {
            description: `Recruiter services for ${jobTitle}`,
            quantity: 1,
            unitAmount: Math.round(totalAmount * 100),
          },
          ...milestonePayments.map((milestone) => ({
            description: `  - ${milestone.name} (${milestone.percentage}%)`,
            quantity: 1,
            unitAmount: Math.round(milestone.amount * 100),
          })),
        ],
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      });

      setShowPaymentConfirmation(true);
      if (onPaymentComplete) {
        onPaymentComplete();
      }
    } catch (error) {
      console.error('Error generating invoice:', error);
      alert('Failed to generate invoice. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg border border-gray-200">
      <div className="px-6 py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <FileText className="w-6 h-6 mr-3" />
            <div>
              <h3 className="text-lg font-bold">Recruiter Fee Invoice</h3>
              <p className="text-blue-100 text-sm">Payment required for accepted bid</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-blue-100">Invoice Date</p>
            <p className="font-semibold">{new Date().toLocaleDateString()}</p>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="grid grid-cols-2 gap-6">
          <div>
            <div className="flex items-center text-sm text-gray-600 mb-1">
              <Building className="w-4 h-4 mr-2" />
              Recruiter
            </div>
            <p className="font-semibold text-gray-900">{bid.recruiterName}</p>
            <p className="text-sm text-gray-600">{bid.recruiterCompany}</p>
          </div>

          <div>
            <div className="flex items-center text-sm text-gray-600 mb-1">
              <User className="w-4 h-4 mr-2" />
              Position
            </div>
            <p className="font-semibold text-gray-900">{jobTitle}</p>
            <p className="text-sm text-gray-600">
              {bid.feeType === 'flat' ? 'Flat Fee' : `${bid.feeValue}% of salary`}
            </p>
          </div>
        </div>

        <div className="border-t border-gray-200 pt-6">
          <h4 className="font-semibold text-gray-900 mb-4">Fee Breakdown</h4>

          <div className="bg-gray-50 rounded-lg p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-700">Base Fee</span>
              <span className="font-semibold text-gray-900">
                ${totalAmount.toFixed(2)}
              </span>
            </div>

            {salaryAmount && bid.feeType === 'percent' && (
              <div className="text-sm text-gray-600 pl-4">
                {bid.feeValue}% of ${salaryAmount.toLocaleString()} annual salary
              </div>
            )}
          </div>
        </div>

        <div className="border-t border-gray-200 pt-6">
          <h4 className="font-semibold text-gray-900 mb-4 flex items-center">
            <Clock className="w-5 h-5 mr-2 text-blue-600" />
            Payment Schedule ({bid.guaranteeDays} day guarantee)
          </h4>

          <div className="space-y-3">
            {milestonePayments.map((milestone, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 bg-blue-50 rounded-lg"
              >
                <div className="flex items-center">
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                    <span className="text-sm font-semibold text-blue-700">
                      {index + 1}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{milestone.name}</p>
                    <p className="text-sm text-gray-600">{milestone.percentage}%</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">
                    ${milestone.amount.toFixed(2)}
                  </p>
                  <span
                    className={`text-xs px-2 py-1 rounded-full ${
                      milestone.status === 'pending'
                        ? 'bg-yellow-100 text-yellow-700'
                        : milestone.status === 'triggered'
                        ? 'bg-blue-100 text-blue-700'
                        : milestone.status === 'released'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-gray-100 text-gray-700'
                    }`}
                  >
                    {milestone.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="border-t border-gray-200 pt-6">
          <div className="flex justify-between items-center mb-6">
            <span className="text-lg font-semibold text-gray-900">Total Amount</span>
            <span className="text-2xl font-bold text-blue-600">
              ${totalAmount.toFixed(2)}
            </span>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
            <div className="flex items-start">
              <AlertTriangle className="w-5 h-5 text-yellow-600 mr-3 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-yellow-700">
                <p className="font-medium mb-1">Escrow Protection</p>
                <p>
                  This payment will be held in escrow and released to the recruiter based on
                  the milestone schedule above. If the candidate leaves within {bid.guaranteeDays}{' '}
                  days, you may be eligible for a refund or replacement.
                </p>
              </div>
            </div>
          </div>

          {showPaymentConfirmation ? (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <div>
                  <p className="font-medium text-green-900">Invoice Generated</p>
                  <p className="text-sm text-green-700">
                    The invoice has been created and sent to your billing account.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex space-x-3">
              <button
                onClick={handleGenerateInvoice}
                disabled={processing || !billingAccount}
                className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center font-medium"
              >
                {processing ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5 mr-2" />
                    Generate & Send Invoice
                  </>
                )}
              </button>
              <button
                disabled={processing}
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center font-medium"
              >
                <Download className="w-5 h-5 mr-2" />
                Download PDF
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RecruiterFeeInvoice;
