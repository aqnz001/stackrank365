import React, { useState, useEffect } from 'react';
import { useSubscriptions } from '../../hooks/useSubscriptions';
import { usePayments } from '../../hooks/usePayments';
import { useBilling } from '../../hooks/useBilling';
import PaymentForm from './PaymentForm';
import BillingAccountForm from '../Billing/BillingAccountForm';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { formatCurrency } from '../../lib/stripe';
import {
  Crown,
  Check,
  X,
  CreditCard,
  Calendar,
  TrendingUp,
  AlertCircle,
  Star,
  Zap,
  CheckCircle,
  Plus,
  Loader,
  Users,
  FileText
} from 'lucide-react';

interface SubscriptionManagerProps {
  onPlanSelect?: (planId: string) => void;
}

const SubscriptionManager: React.FC<SubscriptionManagerProps> = ({ onPlanSelect }) => {
  const {
    plans,
    currentSubscription,
    usage,
    getUsageSummary,
    getTeamMemberCount,
    getJobPostsThisMonth,
    checkUsageLimit,
    createDefaultPlans,
    loading: subscriptionLoading,
    refetch
  } = useSubscriptions();
  const { createSubscription, cancelSubscription } = usePayments();
  const { billingAccount, isBillingComplete } = useBilling();
  const { user } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState<string>('');
  const [billingInterval, setBillingInterval] = useState<'month' | 'year'>('month');
  const [loading, setLoading] = useState(false);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [showBillingForm, setShowBillingForm] = useState(false);
  const [payPlanId, setPayPlanId] = useState<string>('');
  const [teamMemberCount, setTeamMemberCount] = useState<number>(0);
  const [jobPostsCount, setJobPostsCount] = useState<number>(0);

  const usageSummary = getUsageSummary();

  useEffect(() => {
    const loadCounts = async () => {
      const teamCount = await getTeamMemberCount();
      const jobCount = await getJobPostsThisMonth();
      setTeamMemberCount(teamCount);
      setJobPostsCount(jobCount);
    };
    loadCounts();
  }, [user?.organizationId, getTeamMemberCount, getJobPostsThisMonth]);

  const handlePlanSelect = async (planId: string) => {
    // Check if billing information is complete
    if (!isBillingComplete()) {
      alert('Please complete your billing information (including address and tax ID) before subscribing to a plan.');
      setShowBillingForm(true);
      return;
    }

    setLoading(true);
    try {
      const plan = plans.find(p => p.id === planId);
      if (!plan) throw new Error('Plan not found');

      console.log('Selecting plan:', plan.name);

      if (plan.stripePriceId) {
        await createSubscription({
          priceId: plan.stripePriceId || plan.id,
          quantity: 1,
          trialPeriodDays: plan.trialPeriodDays,
          metadata: {
            plan_name: plan.name,
            organization_id: 'current',
          },
        });
        onPlanSelect?.(planId);
      } else {
        // Fallback: charge the first period like job posting and then create a local subscription
        setPayPlanId(planId);
        setShowPaymentForm(true);
      }
    } catch (error) {
      console.error('Error selecting plan:', error);
      alert('Failed to subscribe to plan. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const finalizeManualSubscription = async () => {
    if (!user?.organizationId || !payPlanId) return;
    const plan = plans.find(p => p.id === payPlanId);
    if (!plan) return;

    try {
      // Ensure billing account exists
      let billingAccountId: string | null = null;
      const { data: ba } = await supabase
        .from('billing_accounts')
        .select('id')
        .eq('organization_id', user.organizationId)
        .maybeSingle();
      if (ba?.id) billingAccountId = ba.id;
      else {
        const { data: newBa, error } = await supabase
          .from('billing_accounts')
          .insert({ organization_id: user.organizationId })
          .select('id')
          .single();
        if (error) throw error;
        billingAccountId = newBa.id;
      }

      // Cancel ALL existing active/trialing subscriptions for this billing account
      const { data: existingSubs } = await supabase
        .from('subscriptions')
        .select('id, plan_name, status')
        .eq('billing_account_id', billingAccountId)
        .in('status', ['active', 'trialing', 'past_due']);

      if (existingSubs && existingSubs.length > 0) {
        console.log('Found existing subscriptions to cancel:', existingSubs);
        for (const oldSub of existingSubs) {
          const { error: cancelError } = await supabase
            .from('subscriptions')
            .update({
              status: 'canceled',
              canceled_at: new Date().toISOString(),
            })
            .eq('id', oldSub.id);

          if (cancelError) {
            console.error('Error canceling subscription:', oldSub.id, cancelError);
          } else {
            console.log('Canceled subscription:', oldSub.id, oldSub.plan_name);
          }
        }
      }

      const periodEnd = new Date(Date.now() + (plan.billingInterval === 'year' ? 365 : 30) * 24 * 60 * 60 * 1000);

      const { error: subError } = await supabase
        .from('subscriptions')
        .insert({
          billing_account_id: billingAccountId,
          status: 'active',
          plan_name: plan.name,
          plan_amount: plan.amount,
          currency: plan.currency,
          billing_interval: plan.billingInterval,
          quantity: 1,
          current_period_start: new Date().toISOString(),
          current_period_end: periodEnd.toISOString(),
          trial_end: plan.trialPeriodDays ? new Date(Date.now() + plan.trialPeriodDays * 24 * 60 * 60 * 1000).toISOString() : null,
          metadata: { source: 'manual_payment', upgraded_from: currentSubscription?.planName || null },
        });
      if (subError) throw subError;

      console.log('Subscription created successfully, creating invoice and payment records...');

      // Generate invoice number
      const invoiceNumber = `INV-${Date.now()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

      // Create invoice
      const { data: invoice, error: invoiceError } = await supabase
        .from('invoices')
        .insert({
          billing_account_id: billingAccountId,
          invoice_number: invoiceNumber,
          status: 'paid',
          amount_due: plan.amount,
          amount_paid: plan.amount,
          currency: plan.currency,
          description: `${plan.name} - ${plan.billingInterval === 'year' ? 'Annual' : 'Monthly'} Subscription`,
          due_date: new Date().toISOString(),
          paid_at: new Date().toISOString(),
        })
        .select('id')
        .single();

      if (invoiceError) {
        console.error('Error creating invoice:', invoiceError);
      } else if (invoice) {
        // Create invoice item
        const { error: itemError } = await supabase
          .from('invoice_items')
          .insert({
            invoice_id: invoice.id,
            description: `${plan.name} Subscription (${new Date().toLocaleDateString()} - ${periodEnd.toLocaleDateString()})`,
            quantity: 1,
            unit_amount: plan.amount,
            total_amount: plan.amount,
            metadata: { plan_id: plan.id, billing_interval: plan.billingInterval },
          });

        if (itemError) console.error('Error creating invoice item:', itemError);

        // Create payment record
        const { error: paymentError } = await supabase
          .from('payments')
          .insert({
            billing_account_id: billingAccountId,
            invoice_id: invoice.id,
            amount: plan.amount,
            currency: plan.currency,
            status: 'succeeded',
            payment_method_id: 'manual',
            description: `Payment for ${plan.name} subscription`,
            metadata: {
              source: 'manual_payment',
              plan_id: plan.id,
              invoice_number: invoiceNumber,
            },
          });

        if (paymentError) console.error('Error creating payment:', paymentError);
      }

      console.log('Invoice and payment records created successfully');

      // Small delay to ensure DB write is complete
      await new Promise(resolve => setTimeout(resolve, 500));

      // Refetch subscription data to update UI
      await refetch();

      console.log('Subscription data refetched, calling onPlanSelect callback');

      // Call the callback to advance to next step
      onPlanSelect?.(payPlanId);
    } catch (error) {
      console.error('Error creating subscription:', error);
      alert('Subscription created but failed to update. Please refresh the page.');
      throw error;
    }
  };

  const handleCancelSubscription = async () => {
    if (!currentSubscription) return;

    if (window.confirm('Are you sure you want to cancel your subscription? You will lose access to premium features at the end of your billing period.')) {
      try {
        await cancelSubscription(currentSubscription.stripeSubscriptionId || currentSubscription.id);
      } catch (error) {
        console.error('Error canceling subscription:', error);
        alert('Failed to cancel subscription. Please contact support.');
      }
    }
  };

  const handleCreateDefaultPlans = async () => {
    try {
      await createDefaultPlans();
    } catch (error) {
      console.error('Error creating default plans:', error);
      alert('Failed to create default plans. Please try again.');
    }
  };
  const getUsagePercentage = (usageType: string): number => {
    if (!currentSubscription) return 0;

    const currentPlan = plans.find(p => p.name.toLowerCase().includes(currentSubscription.planName.toLowerCase()));
    if (!currentPlan) return 0;

    const limit = currentPlan.limits[usageType];
    if (limit === -1) return 0; // Unlimited

    const used = usageSummary[usageType] || 0;
    return Math.min((used / limit) * 100, 100);
  };

  const filteredPlans = plans.filter(plan => {
    const now = new Date();
    const inWindow = (!plan.availableFrom || plan.availableFrom <= now) && (!plan.availableTo || plan.availableTo >= now);
    // Audience-based filtering: recruiters see recruiter plans; others see employer plans
    const audienceOk = (user?.role === 'recruiter') ? plan.audience === 'recruiter' : plan.audience === 'employer';
    return plan.billingInterval === billingInterval && inWindow && audienceOk;
  });

  const getPlanTier = (planName: string): 'basic' | 'standard' | 'premium' => {
    const name = planName.toLowerCase();
    if (name.includes('premium')) return 'premium';
    if (name.includes('standard')) return 'standard';
    return 'basic';
  };

  const getPlanIcon = (tier: string) => {
    switch (tier) {
      case 'premium': return <Crown className="w-6 h-6 text-yellow-500" />;
      case 'standard': return <Star className="w-6 h-6 text-purple-500" />;
      default: return <Zap className="w-6 h-6 text-blue-500" />;
    }
  };

  if (subscriptionLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="text-center">
          <Loader className="w-8 h-8 text-blue-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading subscription plans...</p>
        </div>
      </div>
    );
  }
  return (
    <div className="space-y-8">
      {/* Billing Information Required Warning */}
      {!isBillingComplete() && (
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
          <div className="flex items-start">
            <AlertCircle className="w-5 h-5 text-yellow-400 mr-3 mt-0.5" />
            <div className="flex-1">
              <h3 className="text-sm font-medium text-yellow-800">
                Billing Information Required
              </h3>
              <p className="mt-1 text-sm text-yellow-700">
                Please complete your billing information including address and tax ID before subscribing to a plan.
              </p>
              <button
                onClick={() => setShowBillingForm(true)}
                className="mt-3 inline-flex items-center px-4 py-2 bg-yellow-600 text-white text-sm font-medium rounded-md hover:bg-yellow-700"
              >
                <FileText className="w-4 h-4 mr-2" />
                Complete Billing Information
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Billing Form Modal */}
      {showBillingForm && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4">
            <div className="fixed inset-0 bg-black opacity-50" onClick={() => setShowBillingForm(false)} />
            <div className="relative bg-white rounded-lg shadow-xl max-w-3xl w-full p-6 z-10">
              <BillingAccountForm
                billingAccount={billingAccount}
                onClose={() => setShowBillingForm(false)}
                isModal={true}
              />
            </div>
          </div>
        </div>
      )}

      {showPaymentForm && payPlanId && (() => {
        const plan = plans.find(p => p.id === payPlanId)!;
        return (
          <PaymentForm
            amount={plan.amount}
            description={`Subscription: ${plan.name}`}
            onSuccess={async () => {
              setShowPaymentForm(false);
              try {
                await finalizeManualSubscription();
              } catch (error) {
                console.error('Error finalizing subscription:', error);
              }
            }}
            onError={(msg) => {
              console.error('Payment error', msg);
              alert(`Payment failed: ${msg}`);
              setShowPaymentForm(false);
            }}
            onClose={() => setShowPaymentForm(false)}
          />
        );
      })()}
      {/* Current Subscription */}
      {currentSubscription && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Current Subscription</h3>
              <p className="text-gray-600">{currentSubscription.planName}</p>
              <p className="text-2xl font-bold text-blue-600 mt-2">
                {formatCurrency(currentSubscription.planAmount)}
                <span className="text-sm text-gray-500">/month</span>
              </p>
            </div>
            
            <div className="text-right">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                currentSubscription.status === 'active' ? 'bg-green-100 text-green-800' :
                currentSubscription.status === 'trialing' ? 'bg-blue-100 text-blue-800' :
                'bg-yellow-100 text-yellow-800'
              }`}>
                {currentSubscription.status}
              </span>
              
              {currentSubscription.currentPeriodEnd && (
                <p className="text-sm text-gray-500 mt-2">
                  {currentSubscription.canceledAt ? 'Ends' : 'Renews'}: {currentSubscription.currentPeriodEnd.toLocaleDateString()}
                </p>
              )}
            </div>
          </div>

          {/* Usage Summary */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <h4 className="font-medium text-gray-900 mb-4">Current Usage</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-600">Job Posts This Month</span>
                  <span className="font-medium">
                    {jobPostsCount}
                    {(() => {
                      const currentPlan = plans.find(p => p.name.toLowerCase().includes(currentSubscription?.planName.toLowerCase() || ''));
                      const limit = currentPlan?.limits.job_posts_per_month;
                      return limit && limit !== -1 ? ` / ${limit}` : '';
                    })()}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full"
                    style={{
                      width: `${(() => {
                        const currentPlan = plans.find(p => p.name.toLowerCase().includes(currentSubscription?.planName.toLowerCase() || ''));
                        const limit = currentPlan?.limits.job_posts_per_month;
                        if (limit === -1 || !limit) return 0;
                        return Math.min((jobPostsCount / limit) * 100, 100);
                      })()}%`
                    }}
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <div className="flex items-center">
                    <Users className="w-4 h-4 mr-1 text-gray-500" />
                    <span className="text-gray-600">Team Members</span>
                  </div>
                  <span className="font-medium">
                    {teamMemberCount}
                    {(() => {
                      const currentPlan = plans.find(p => p.name.toLowerCase().includes(currentSubscription?.planName.toLowerCase() || ''));
                      const limit = currentPlan?.limits.team_members;
                      return limit && limit !== -1 ? ` / ${limit}` : '';
                    })()}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-green-600 h-2 rounded-full"
                    style={{
                      width: `${(() => {
                        const currentPlan = plans.find(p => p.name.toLowerCase().includes(currentSubscription?.planName.toLowerCase() || ''));
                        const limit = currentPlan?.limits.team_members;
                        if (limit === -1 || !limit) return 0;
                        return Math.min((teamMemberCount / limit) * 100, 100);
                      })()}%`
                    }}
                  />
                </div>
              </div>
            </div>
          </div>

          {!currentSubscription.canceledAt && (
            <div className="mt-6 pt-6 border-t border-gray-200">
              <button
                onClick={handleCancelSubscription}
                className="text-red-600 hover:text-red-700 text-sm"
              >
                Cancel Subscription
              </button>
            </div>
          )}
        </div>
      )}

      {/* Plan Selection */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="text-center mb-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-2">Choose Your Plan</h3>
          <p className="text-gray-600">Select the plan that best fits your hiring needs</p>
          
          {/* Billing Toggle */}
          <div className="flex items-center justify-center mt-6">
            <span className={`text-sm ${billingInterval === 'month' ? 'text-gray-900' : 'text-gray-500'}`}>
              Monthly
            </span>
            <button
              onClick={() => setBillingInterval(billingInterval === 'month' ? 'year' : 'month')}
              className="mx-3 relative inline-flex h-6 w-11 items-center rounded-full bg-gray-200 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  billingInterval === 'year' ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
            <span className={`text-sm ${billingInterval === 'year' ? 'text-gray-900' : 'text-gray-500'}`}>
              Annual
              <span className="ml-1 px-2 py-1 bg-green-100 text-green-800 text-xs rounded">Save 20%</span>
            </span>
          </div>
        </div>

        {/* No Plans Available */}
        {filteredPlans.length === 0 && (
          <div className="text-center py-8">
            <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h4 className="text-lg font-medium text-gray-900 mb-2">No Plans Available</h4>
            <p className="text-gray-600 mb-4">
              No subscription plans are currently available for the selected billing interval.
            </p>
            {user?.role === 'admin' && (
              <button
                onClick={handleCreateDefaultPlans}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 mx-auto"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Default Plans
              </button>
            )}
            {user?.role !== 'admin' && (
              <p className="text-sm text-gray-500">
                Please contact support or switch to monthly billing.
              </p>
            )}
          </div>
        )}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {filteredPlans.map((plan) => {
            const tier = getPlanTier(plan.name);
            const isCurrentPlan = currentSubscription?.planName.toLowerCase().includes(tier);
            const isPopular = tier === 'standard';

            return (
              <div
                key={plan.id}
                className={`relative rounded-xl border-2 p-6 ${
                  isCurrentPlan
                    ? 'border-blue-500 bg-blue-50'
                    : isPopular
                    ? 'border-purple-500 bg-purple-50'
                    : 'border-gray-200 bg-white hover:border-gray-300'
                } transition-all`}
              >
                {isPopular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <span className="px-3 py-1 bg-purple-600 text-white text-sm font-medium rounded-full">
                      Most Popular
                    </span>
                  </div>
                )}

                <div className="text-center">
                  <div className="flex justify-center mb-4">
                    {getPlanIcon(tier)}
                  </div>
                  
                  <h4 className="text-xl font-semibold text-gray-900 mb-2">{plan.name}</h4>
                  <p className="text-gray-600 text-sm mb-4">{plan.description}</p>
                  
                  <div className="mb-6">
                    <span className="text-4xl font-bold text-gray-900">
                      {formatCurrency(plan.amount)}
                    </span>
                    <span className="text-gray-500">/{plan.billingInterval}</span>
                    
                    {billingInterval === 'year' && (
                      <p className="text-sm text-green-600 mt-1">
                        Save {formatCurrency(plan.amount * 12 * 0.2)} per year
                      </p>
                    )}
                  </div>

                  <ul className="space-y-3 mb-6 text-left">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <Check className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Usage Limits */}
                  <div className="mb-6 p-3 bg-gray-50 rounded-lg text-left">
                    <h5 className="text-sm font-medium text-gray-900 mb-2">Plan Limits</h5>
                    <div className="space-y-1 text-xs text-gray-600">
                      {Object.entries(plan.limits).map(([key, value]) => (
                        <div key={key} className="flex justify-between">
                          <span className="capitalize">{key.replace(/_/g, ' ')}:</span>
                          <span className="font-medium">
                            {value === -1 ? 'Unlimited' : value.toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                  {isCurrentPlan ? (
                    <div className="flex items-center justify-center px-4 py-2 bg-blue-100 text-blue-800 rounded-lg">
                      <CheckCircle className="w-5 h-5 mr-2" />
                      Current Plan
                    </div>
                  ) : (
                    <button
                      onClick={() => handlePlanSelect(plan.id)}
                      disabled={loading}
                      className={`w-full px-4 py-2 rounded-lg font-medium transition-colors ${
                        isPopular
                          ? 'bg-purple-600 text-white hover:bg-purple-700'
                          : 'bg-blue-600 text-white hover:bg-blue-700'
                      } disabled:opacity-50`}
                    >
                      {loading ? 'Processing...' : 'Select Plan'}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Enterprise Option */}
        <div className="mt-8 text-center p-6 bg-gray-50 rounded-xl">
          <h4 className="text-lg font-semibold text-gray-900 mb-2">Need something custom?</h4>
          <p className="text-gray-600 mb-4">
            Contact our sales team for enterprise pricing and custom features
          </p>
          <button className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-white transition-colors">
            Contact Sales
          </button>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionManager;
