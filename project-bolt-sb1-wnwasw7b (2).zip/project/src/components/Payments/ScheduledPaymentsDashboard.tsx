import React, { useState } from 'react';
import {
  DollarSign,
  TrendingUp,
  Clock,
  CheckCircle,
  AlertCircle,
  Calendar,
  ChevronDown,
  ChevronUp,
  Filter,
} from 'lucide-react';
import { useScheduledPayments } from '../../hooks/usePaymentSchedules';

const ScheduledPaymentsDashboard: React.FC = () => {
  const { payments, loading, error } = useScheduledPayments();
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [expandedPayment, setExpandedPayment] = useState<string | null>(null);

  const filteredPayments = payments.filter((payment) => {
    if (statusFilter === 'all') return true;
    return payment.status === statusFilter;
  });

  const statistics = {
    total: payments.reduce((sum, p) => sum + p.amount, 0),
    pending: payments
      .filter((p) => p.status === 'pending')
      .reduce((sum, p) => sum + p.amount, 0),
    triggered: payments
      .filter((p) => p.status === 'triggered')
      .reduce((sum, p) => sum + p.amount, 0),
    released: payments
      .filter((p) => p.status === 'released')
      .reduce((sum, p) => sum + p.amount, 0),
  };

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'pending':
        return {
          color: 'yellow',
          icon: Clock,
          label: 'Pending',
          bgColor: 'bg-yellow-100',
          textColor: 'text-yellow-800',
        };
      case 'triggered':
        return {
          color: 'blue',
          icon: TrendingUp,
          label: 'Triggered',
          bgColor: 'bg-blue-100',
          textColor: 'text-blue-800',
        };
      case 'released':
        return {
          color: 'green',
          icon: CheckCircle,
          label: 'Released',
          bgColor: 'bg-green-100',
          textColor: 'text-green-800',
        };
      case 'failed':
        return {
          color: 'red',
          icon: AlertCircle,
          label: 'Failed',
          bgColor: 'bg-red-100',
          textColor: 'text-red-800',
        };
      default:
        return {
          color: 'gray',
          icon: Clock,
          label: 'Unknown',
          bgColor: 'bg-gray-100',
          textColor: 'text-gray-800',
        };
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <p className="text-red-700">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Scheduled Payments</h2>
        <p className="text-gray-600">
          Track your milestone-based payments and expected earnings
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Total Value</span>
            <DollarSign className="w-5 h-5 text-gray-400" />
          </div>
          <p className="text-2xl font-bold text-gray-900">
            ${(statistics.total / 100).toFixed(2)}
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Pending</span>
            <Clock className="w-5 h-5 text-yellow-500" />
          </div>
          <p className="text-2xl font-bold text-yellow-600">
            ${(statistics.pending / 100).toFixed(2)}
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">In Progress</span>
            <TrendingUp className="w-5 h-5 text-blue-500" />
          </div>
          <p className="text-2xl font-bold text-blue-600">
            ${(statistics.triggered / 100).toFixed(2)}
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Released</span>
            <CheckCircle className="w-5 h-5 text-green-500" />
          </div>
          <p className="text-2xl font-bold text-green-600">
            ${(statistics.released / 100).toFixed(2)}
          </p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <h3 className="font-semibold text-gray-900">Monthly Payment Schedule</h3>
          <div className="flex items-center space-x-2">
            <Filter className="w-5 h-5 text-gray-400" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="triggered">Triggered</option>
              <option value="released">Released</option>
              <option value="failed">Failed</option>
            </select>
          </div>
        </div>

        <div className="divide-y divide-gray-200">
          {filteredPayments.length === 0 ? (
            <div className="px-6 py-12 text-center">
              <DollarSign className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No scheduled payments found</p>
            </div>
          ) : (
            filteredPayments.map((payment) => {
              const statusConfig = getStatusConfig(payment.status);
              const StatusIcon = statusConfig.icon;
              const isExpanded = expandedPayment === payment.id;

              return (
                <div key={payment.id} className="px-6 py-4 hover:bg-gray-50 transition-colors">
                  <div
                    className="flex items-center justify-between cursor-pointer"
                    onClick={() =>
                      setExpandedPayment(isExpanded ? null : payment.id)
                    }
                  >
                    <div className="flex items-center space-x-4 flex-1">
                      <div className="flex items-center justify-center w-10 h-10 rounded-full bg-blue-100">
                        <span className="text-sm font-semibold text-blue-700">
                          M{payment.monthNumber}
                        </span>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">
                          {payment.installmentName}
                        </h4>
                        <p className="text-sm text-gray-600">
                          {payment.paymentDate ? `Due: ${payment.paymentDate.toLocaleDateString()}` : 'Date pending'}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className="font-semibold text-gray-900">
                          ${(payment.amount / 100).toFixed(2)}
                        </p>
                        <p className="text-sm text-gray-600">{payment.percentage}%</p>
                      </div>

                      <span
                        className={`px-3 py-1 rounded-full text-sm font-medium flex items-center ${statusConfig.bgColor} ${statusConfig.textColor}`}
                      >
                        <StatusIcon className="w-4 h-4 mr-1" />
                        {statusConfig.label}
                      </span>

                      {isExpanded ? (
                        <ChevronUp className="w-5 h-5 text-gray-400" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-gray-400" />
                      )}
                    </div>
                  </div>

                  {isExpanded && (
                    <div className="mt-4 pl-14 space-y-3">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        {payment.paymentDate && (
                          <div>
                            <p className="text-gray-600 mb-1">Scheduled Payment Date</p>
                            <div className="flex items-center text-gray-900">
                              <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                              {payment.paymentDate.toLocaleDateString()}
                            </div>
                          </div>
                        )}
                        {payment.releaseDate && (
                          <div>
                            <p className="text-gray-600 mb-1">Released Date</p>
                            <div className="flex items-center text-gray-900">
                              <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                              {payment.releaseDate.toLocaleDateString()}
                            </div>
                          </div>
                        )}
                      </div>

                      {payment.notes && (
                        <div>
                          <p className="text-gray-600 text-sm mb-1">Notes</p>
                          <p className="text-gray-900 text-sm bg-gray-50 rounded-lg p-3">
                            {payment.notes}
                          </p>
                        </div>
                      )}

                      {payment.status === 'pending' && (
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                          <p className="text-sm text-blue-700">
                            This payment will be automatically released when the milestone
                            criteria is met.
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

export default ScheduledPaymentsDashboard;
