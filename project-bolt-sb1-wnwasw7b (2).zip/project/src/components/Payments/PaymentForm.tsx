import React, { useState } from 'react';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { getStripe, stripeConfig, formatCurrency, handleStripeError } from '../../lib/stripe';
import { usePayments } from '../../hooks/usePayments';
import { X, CreditCard, Lock, CheckCircle, AlertCircle } from 'lucide-react';

interface PaymentFormProps {
  amount: number;
  description: string;
  onSuccess: (paymentIntent: any) => void;
  onError: (error: string) => void;
  onClose: () => void;
}

const PaymentFormContent: React.FC<PaymentFormProps> = ({
  amount,
  description,
  onSuccess,
  onError,
  onClose,
}) => {
  const stripe = useStripe();
  const elements = useElements();
  const { createPaymentIntent, paymentMethods } = usePayments();
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [useExistingMethod, setUseExistingMethod] = useState(false);
  const [selectedMethodId, setSelectedMethodId] = useState('');
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [cardComplete, setCardComplete] = useState(false);

  // Fetch client secret when component mounts or amount changes
  React.useEffect(() => {
    let isMounted = true;

    const fetchClientSecret = async () => {
      try {
        setLoading(true);
        const paymentIntent = await createPaymentIntent({
          amount,
          description,
          metadata: {
            source: 'job_posting',
          },
        });

        if (isMounted) {
          setClientSecret(paymentIntent.clientSecret);
        }
      } catch (err) {
        if (isMounted) {
          const errorMessage = err instanceof Error ? err.message : 'Failed to initialize payment';
          setError(errorMessage);
          onError(errorMessage);
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    fetchClientSecret();

    return () => {
      isMounted = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [amount, description]);

  const handleCardChange = (event: any) => {
    setCardComplete(event.complete);
    if (event.error) {
      setError(event.error.message);
    } else {
      setError(null);
    }
  };
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!stripe || !elements || !clientSecret) {
      setError('Payment system not ready. Please try again.');
      return;
    }

    setProcessing(true);
    setError(null);

    try {
      console.log('Confirming payment with client secret:', clientSecret);
      
      // For demo purposes, simulate successful payment
      if (clientSecret.includes('mock')) {
        console.log('Mock payment confirmation - simulating success');
        const mockPaymentIntent = {
          id: clientSecret.split('_secret_')[0],
          status: 'succeeded',
          amount: amount,
          currency: 'usd',
        };
        
        // Call onSuccess to close the modal and handle success
        onSuccess(mockPaymentIntent);
        return mockPaymentIntent;
      }
      
      // Real Stripe payment confirmation (when using real Stripe)
      let result;

      if (useExistingMethod && selectedMethodId) {
        // Use existing payment method
        result = await stripe.confirmPayment({
          clientSecret,
          confirmParams: {
            payment_method: selectedMethodId,
          },
        });
      } else {
        // Use new card
        const cardElement = elements.getElement(CardElement);
        if (!cardElement) {
          throw new Error('Card element not found');
        }

        result = await stripe.confirmPayment({
          clientSecret,
          elements,
          confirmParams: {
            return_url: window.location.origin,
          },
        });
      }
      
      if (useExistingMethod && selectedMethodId) {
        result = await stripe.confirmPayment({
          clientSecret,
          confirmParams: {
            payment_method: selectedMethodId,
          },
        });
      } else {
        const cardElement = elements.getElement(CardElement);
        if (!cardElement) {
          throw new Error('Card element not found');
        }

        result = await stripe.confirmPayment({
          clientSecret,
          elements,
          confirmParams: {
            return_url: window.location.origin,
          },
        });
      }

      if (result.error) {
        throw new Error(handleStripeError(result.error));
      }

      return result.paymentIntent;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Payment failed';
      setError(errorMessage);
      onError(errorMessage);
    } finally {
      setProcessing(false);
    }
  };

  const cardElementOptions = {
    style: {
      base: {
        fontSize: '16px',
        color: '#424770',
        '::placeholder': {
          color: '#aab7c4',
        },
      },
      invalid: {
        color: '#9e2146',
      },
    },
    hidePostalCode: false,
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div className="relative top-20 mx-auto p-5 border w-full max-w-md shadow-lg rounded-md bg-white">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Initializing Payment</h3>
            <p className="text-gray-600">Please wait while we prepare your payment...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-20 mx-auto p-5 border w-full max-w-md shadow-lg rounded-md bg-white">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-gray-900">Complete Payment</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 p-2"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900">{description}</p>
              <p className="text-sm text-gray-600">One-time payment</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-blue-600">{formatCurrency(amount)}</p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Payment Method Selection */}
          {paymentMethods.length > 0 && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Payment Method
              </label>
              <div className="space-y-3">
                <label className="cursor-pointer">
                  <input
                    type="radio"
                    name="paymentMethod"
                    checked={!useExistingMethod}
                    onChange={() => setUseExistingMethod(false)}
                    className="sr-only"
                  />
                  <div className={`p-3 border-2 rounded-lg ${
                    !useExistingMethod ? 'border-blue-500 bg-blue-50' : 'border-gray-200'
                  }`}>
                    <div className="flex items-center">
                      <CreditCard className="w-5 h-5 mr-2" />
                      <span className="font-medium">Use new card</span>
                    </div>
                  </div>
                </label>

                {paymentMethods.map(method => (
                  <label key={method.id} className="cursor-pointer">
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={useExistingMethod && selectedMethodId === method.stripePaymentMethodId}
                      onChange={() => {
                        setUseExistingMethod(true);
                        setSelectedMethodId(method.stripePaymentMethodId);
                      }}
                      className="sr-only"
                    />
                    <div className={`p-3 border-2 rounded-lg ${
                      useExistingMethod && selectedMethodId === method.stripePaymentMethodId
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200'
                    }`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <CreditCard className="w-5 h-5 mr-2" />
                          <span className="font-medium">
                            {method.cardBrand?.toUpperCase()} •••• {method.cardLast4}
                          </span>
                        </div>
                        {method.isDefault && (
                          <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">
                            Default
                          </span>
                        )}
                      </div>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          )}

          {/* Card Element for new cards */}
          {!useExistingMethod && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <CreditCard className="w-4 h-4 inline mr-1" />
                Card Information
              </label>
              <div className="p-3 border border-gray-300 rounded-lg">
                <CardElement 
                  options={cardElementOptions}
                  onChange={handleCardChange}
                />
              </div>
            </div>
          )}

          {/* Security Notice */}
          <div className="flex items-center p-3 bg-gray-50 rounded-lg">
            <Lock className="w-5 h-5 text-gray-500 mr-2" />
            <p className="text-sm text-gray-600">
              Your payment information is encrypted and secure. We use Stripe for payment processing.
            </p>
          </div>

          {error && (
            <div className="flex items-center p-3 bg-red-50 border border-red-200 rounded-lg">
              <AlertCircle className="w-5 h-5 text-red-600 mr-2" />
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}

          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={
                processing || 
                !stripe || 
                !clientSecret || 
                (!useExistingMethod && !cardComplete) ||
                (useExistingMethod && !selectedMethodId)
              }
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              {processing ? 'Processing...' : `Pay ${formatCurrency(amount)}`}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

const PaymentForm: React.FC<PaymentFormProps> = (props) => {
  // Check if Stripe is configured
  if (!import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY) {
    return (
      <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div className="relative top-20 mx-auto p-5 border w-full max-w-md shadow-lg rounded-md bg-white">
          <div className="text-center">
            <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Payment Unavailable</h3>
            <p className="text-gray-600 mb-4">
              Stripe publishable key is missing. Please add VITE_STRIPE_PUBLISHABLE_KEY to your .env file.
            </p>
            <button
              onClick={props.onClose}
              className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    );
  }

  const stripePromise = getStripe();

  return (
    <Elements stripe={stripePromise} options={stripeConfig}>
      <PaymentFormContent {...props} />
    </Elements>
  );
};

export default PaymentForm;