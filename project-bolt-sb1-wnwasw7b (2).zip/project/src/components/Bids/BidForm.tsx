import React, { useMemo, useState } from 'react';
import { useRecruiterBids } from '../../hooks/useRecruiterBids';
import { Job } from '../../types';
import { X, DollarSign, Shield, User, MapPin, Briefcase, Award, Eye, Sparkles, Loader2, CheckCircle2 } from 'lucide-react';
import { useConsentRequests } from '../../hooks/useConsentRequests';
import { supabase } from '../../lib/supabase';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

interface BidFormProps {
  job: Job;
  onClose: () => void;
}

const BidForm: React.FC<BidFormProps> = ({ job, onClose }) => {
  const { createBid } = useRecruiterBids();
  const { consents } = useConsentRequests() as any;
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [step, setStep] = useState(1);
  const [selectedCandidate, setSelectedCandidate] = useState<{ id: string; name?: string; email?: string; profile?: any } | null>(null);
  const [candidateStub, setCandidateStub] = useState({
    skills: '',
    experienceYears: '',
    industry: '',
    highlights: '',
    locationZone: '',
    salaryExpectation: '',
    noticePeriod: '',
  });
  const [generatingProfile, setGeneratingProfile] = useState(false);
  const [skillsMatch, setSkillsMatch] = useState<{ matched: string[]; missing: string[]; score: number } | null>(null);
  const [keywordsMatch, setKeywordsMatch] = useState<{ matched: string[]; score: number } | null>(null);
  
  const [bidDetails, setBidDetails] = useState({
    feeType: 'percent',
    feeValue: '',
    guaranteeDays: '90',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      if (!selectedCandidate) {
        alert('Select a consented candidate to proceed.');
        setIsSubmitting(false);
        return;
      }
      const candidateStubData = {
        id: `stub-${Date.now()}`,
        skills: candidateStub.skills.split(',').map(s => s.trim()).filter(Boolean),
        experienceYears: parseInt(candidateStub.experienceYears),
        industry: candidateStub.industry,
        highlights: candidateStub.highlights.split('\n').map(h => h.trim()).filter(Boolean),
        locationZone: candidateStub.locationZone,
        salaryExpectation: candidateStub.salaryExpectation ? parseInt(candidateStub.salaryExpectation) : undefined,
        noticePeriod: candidateStub.noticePeriod,
      };

      await createBid({
        jobId: job.id,
        candidateStub: candidateStubData,
        feeType: bidDetails.feeType as 'flat' | 'percent',
        feeValue: parseFloat(bidDetails.feeValue),
        guaranteeDays: parseInt(bidDetails.guaranteeDays),
      });

      console.log('Bid submitted successfully');
      onClose();
    } catch (error) {
      console.error('Error submitting bid:', error);
      alert('Failed to submit bid. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleNext = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    if (step === 1 && !selectedCandidate) {
      alert('Please select a consented candidate first.');
      return;
    }
    if (step < 3) {
      setStep(step + 1);
      console.log('Next Step', step + 1);
    }
  };

  const consentedCandidates = useMemo(() => {
    return (consents || [])
      .filter((c: any) => c.status === 'approved' && c.jobId === job.id)
      .map((c: any) => ({
        id: c.candidateId,
        name: c.candidateName,
        email: c.candidateEmail,
        profile: c.candidateProfile
      }))
      .filter((c: any) => !!c.id);
  }, [consents, job?.id]);

  const generateHighlights = (job: Job) => {
    const skills = (job.skills || []).slice(0, 4);
    const bullets: string[] = [];
    if (skills.length) bullets.push(`Delivered outcomes using ${skills.join(', ')}`);
    bullets.push('Partnered with stakeholders to clarify requirements and priorities');
    bullets.push('Improved quality and reliability through testing and iteration');
    return bullets.join('\n');
  };

  const calculateSkillsMatch = (candidateSkills: string[], jobSkills: string[]) => {
    const normalizedCandidateSkills = candidateSkills.map(s => s.toLowerCase().trim());
    const normalizedJobSkills = jobSkills.map(s => s.toLowerCase().trim());

    const matched = normalizedJobSkills.filter(jobSkill =>
      normalizedCandidateSkills.some(candSkill =>
        candSkill.includes(jobSkill) || jobSkill.includes(candSkill)
      )
    );

    const missing = normalizedJobSkills.filter(jobSkill =>
      !normalizedCandidateSkills.some(candSkill =>
        candSkill.includes(jobSkill) || jobSkill.includes(candSkill)
      )
    );

    const score = jobSkills.length > 0 ? Math.round((matched.length / jobSkills.length) * 100) : 0;

    return { matched, missing, score };
  };

  const extractKeywords = (text: string) => {
    const commonWords = new Set(['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'been', 'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'should', 'could', 'may', 'might', 'must', 'can', 'this', 'that', 'these', 'those']);
    const words = text.toLowerCase().match(/\\b[a-z]{3,}\\b/g) || [];
    return words.filter(w => !commonWords.has(w));
  };

  const calculateKeywordsMatch = (candidateProfile: any, jobDescription: string) => {
    const jobKeywords = extractKeywords(jobDescription);
    const candidateText = `${candidateProfile.bio || ''} ${candidateProfile.experience || ''} ${(candidateProfile.skills || []).join(' ')}`.toLowerCase();

    const matched = jobKeywords.filter(keyword => candidateText.includes(keyword));
    const score = jobKeywords.length > 0 ? Math.round((matched.length / jobKeywords.length) * 100) : 0;

    return { matched: Array.from(new Set(matched)), score };
  };

  const handleGenerateProfile = async () => {
    if (!selectedCandidate?.profile) {
      alert('No candidate profile available. The candidate needs to complete their profile setup first.');
      return;
    }

    if (!selectedCandidate.profile.skills || selectedCandidate.profile.skills.length === 0) {
      alert('Candidate profile is incomplete. They need to add skills and work experience.');
      return;
    }

    setGeneratingProfile(true);

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const response = await fetch(`${supabaseUrl}/functions/v1/generate-candidate-profile`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseAnonKey}`,
        },
        body: JSON.stringify({
          candidateProfile: selectedCandidate.profile,
          jobDescription: job.description,
          jobTitle: job.title,
          jobSkills: job.skills,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate profile');
      }

      const data = await response.json();

      setCandidateStub(prev => ({
        ...prev,
        skills: data.skills.join(', '),
        experienceYears: data.experienceYears.toString(),
        industry: data.industry,
        highlights: data.summary,
        locationZone: data.location || prev.locationZone,
      }));

      const skillsMatchData = calculateSkillsMatch(data.skills, job.skills || []);
      setSkillsMatch(skillsMatchData);

      const keywordsMatchData = calculateKeywordsMatch(selectedCandidate.profile, job.description);
      setKeywordsMatch(keywordsMatchData);

      console.log('Profile generated successfully');
    } catch (error) {
      console.error('Error generating profile:', error);
      alert('Failed to generate profile. Please try again.');
    } finally {
      setGeneratingProfile(false);
    }
  };

  const fetchCandidateProfile = async (candidateId: string) => {
    try {
      const profileKey = `candidate_profile:${candidateId}`;
      const raw = localStorage.getItem(profileKey);

      if (!raw) {
        console.log('No profile found in localStorage for:', candidateId);
        return null;
      }

      const profile = JSON.parse(raw);
      console.log('Profile loaded from localStorage:', profile);

      const bio = profile.workExperience?.[0]?.description || '';
      const skills = profile.qualifications?.skills || [];
      const experienceYears = profile.workExperience?.length || 0;
      const location = profile.currentStatus?.location || '';
      const industry = profile.workExperience?.[0]?.industry || '';

      const experience = profile.workExperience?.map((exp: any) =>
        `${exp.jobTitle} at ${exp.company}: ${exp.description}`
      ).join('\\n') || '';

      const education = profile.qualifications?.highestQualification || '';

      return {
        bio,
        skills,
        experienceYears,
        location,
        industry,
        experience,
        education
      };
    } catch (error) {
      console.error('Error fetching candidate profile:', error);
      return null;
    }
  };

  const prefillFromSelection = async (cand: { id: string; name?: string; email?: string }) => {
    const ok = window.confirm(`Use consent from ${cand.name || cand.email || cand.id} for this bid?`);
    if (!ok) return;

    const profile = await fetchCandidateProfile(cand.id);

    setSelectedCandidate({
      ...cand,
      profile: profile
    });

    setCandidateStub(prev => ({
      ...prev,
      industry: (job.industry && job.industry[0]) || prev.industry,
      locationZone: job.location || prev.locationZone,
      skills: (job.skills || []).slice(0, 6).join(', '),
      highlights: generateHighlights(job),
    }));
  };

  const renderStepIndicator = () => (
    <div className="flex items-center justify-center mb-6">
      {[1, 2, 3].map((stepNum) => (
        <div key={stepNum} className="flex items-center">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
            step >= stepNum ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
          }`}>
            {stepNum}
          </div>
          {stepNum < 3 && (
            <div className={`w-12 h-1 ${step > stepNum ? 'bg-blue-600' : 'bg-gray-200'}`} />
          )}
        </div>
      ))}
    </div>
  );

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-20 mx-auto p-5 border w-full max-w-4xl shadow-lg rounded-md bg-white">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold text-gray-900">Submit Recruiter Bid</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 p-2"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Job Info */}
        <div className="bg-blue-50 p-4 rounded-lg mb-6">
          <h4 className="font-semibold text-gray-900">{job.title}</h4>
          <p className="text-gray-600">{job.organizationName} • {job.location}</p>
          <div className="flex items-center mt-2 text-sm text-gray-500">
            <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs mr-2">
              {job.adTier.charAt(0).toUpperCase() + job.adTier.slice(1)} Tier
            </span>
            <span>Up to {job.bidLimit || '∞'} bids accepted</span>
          </div>
        </div>

        {renderStepIndicator()}

        <form onSubmit={handleSubmit}>
          {step === 1 && (
            <div className="space-y-6">
              <h4 className="text-lg font-semibold text-gray-900 mb-4">
                Step 1: Candidate Consent & Summary
              </h4>
              
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                <div className="flex items-center">
                  <Eye className="w-5 h-5 text-yellow-600 mr-2" />
                  <p className="text-yellow-800 font-medium">Privacy Protection</p>
                </div>
                <p className="text-yellow-700 text-sm mt-1">
                  Only anonymized candidate information will be shared with the employer until your bid is accepted.
                  Ensure you have obtained candidate consent before proceeding.
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Select Consented Candidate</label>
                {consentedCandidates.length === 0 ? (
                  <div className="text-sm text-gray-600 p-3 border rounded bg-gray-50">
                    No approved consents found for this job. Request consent from the candidate before submitting a bid.
                  </div>
                ) : (
                  <select
                    value={selectedCandidate?.id || ''}
                    onChange={(e) => {
                      const cand = consentedCandidates.find(c => c.id === e.target.value);
                      if (cand) prefillFromSelection(cand);
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Choose a candidate…</option>
                    {consentedCandidates.map(c => (
                      <option key={c.id} value={c.id}>{c.name || c.email || c.id}</option>
                    ))}
                  </select>
                )}
                <p className="text-xs text-gray-500 mt-1">Only candidates with approved consent for this job are listed.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Briefcase className="w-4 h-4 inline mr-1" />
                    Years of Experience
                  </label>
                  <input
                    type="number"
                    required
                    value={candidateStub.experienceYears}
                    onChange={(e) => setCandidateStub(prev => ({ ...prev, experienceYears: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g., 5"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Industry
                  </label>
                  <input
                    type="text"
                    required
                    value={candidateStub.industry}
                    onChange={(e) => setCandidateStub(prev => ({ ...prev, industry: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g., Technology, Finance, Healthcare"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <MapPin className="w-4 h-4 inline mr-1" />
                    Location Zone
                  </label>
                  <input
                    type="text"
                    required
                    value={candidateStub.locationZone}
                    onChange={(e) => setCandidateStub(prev => ({ ...prev, locationZone: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g., Bay Area, New York Metro, Remote"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <DollarSign className="w-4 h-4 inline mr-1" />
                    Salary Expectation (Optional)
                  </label>
                  <input
                    type="number"
                    value={candidateStub.salaryExpectation}
                    onChange={(e) => setCandidateStub(prev => ({ ...prev, salaryExpectation: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g., 120000"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Technical Skills
                  </label>
                  <input
                    type="text"
                    required
                    value={candidateStub.skills}
                    onChange={(e) => setCandidateStub(prev => ({ ...prev, skills: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="e.g., React, TypeScript, Node.js, AWS (comma-separated)"
                  />
                </div>

                <div className="md:col-span-2">
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-medium text-gray-700">
                      <Award className="w-4 h-4 inline mr-1" />
                      Candidate Profile Summary
                    </label>
                    {selectedCandidate && (
                      <button
                        type="button"
                        onClick={handleGenerateProfile}
                        disabled={generatingProfile}
                        className="flex items-center px-3 py-1 text-sm bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 disabled:opacity-50"
                      >
                        {generatingProfile ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                            Generating...
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4 mr-1" />
                            Generate with AI
                          </>
                        )}
                      </button>
                    )}
                  </div>
                  <ReactQuill
                    theme="snow"
                    value={candidateStub.highlights}
                    onChange={(value) => setCandidateStub(prev => ({ ...prev, highlights: value }))}
                    className="bg-white rounded-md"
                    modules={{
                      toolbar: [
                        ['bold', 'italic', 'underline'],
                        [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                        ['clean']
                      ]
                    }}
                    placeholder="Describe the candidate's experience, achievements, and how they match the job requirements..."
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Use the AI assistant to generate an anonymized, compelling profile based on the candidate's actual experience.
                  </p>
                </div>

                {/* Skills Match Indicator */}
                {skillsMatch && (
                  <div className="md:col-span-2 bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h5 className="font-medium text-gray-900">Skills Match</h5>
                      <div className="flex items-center">
                        <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                          <div
                            className={`h-2 rounded-full ${
                              skillsMatch.score >= 80 ? 'bg-green-600' :
                              skillsMatch.score >= 60 ? 'bg-yellow-600' :
                              'bg-orange-600'
                            }`}
                            style={{ width: `${skillsMatch.score}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-semibold">{skillsMatch.score}%</span>
                      </div>
                    </div>
                    {skillsMatch.matched.length > 0 && (
                      <div className="mb-2">
                        <p className="text-xs text-gray-600 mb-1">Matched Skills:</p>
                        <div className="flex flex-wrap gap-1">
                          {skillsMatch.matched.map((skill, idx) => (
                            <span key={idx} className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full flex items-center">
                              <CheckCircle2 className="w-3 h-3 mr-1" />
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                    {skillsMatch.missing.length > 0 && (
                      <div>
                        <p className="text-xs text-gray-600 mb-1">Skills to Highlight:</p>
                        <div className="flex flex-wrap gap-1">
                          {skillsMatch.missing.map((skill, idx) => (
                            <span key={idx} className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Keywords Match Indicator */}
                {keywordsMatch && keywordsMatch.matched.length > 0 && (
                  <div className="md:col-span-2 bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h5 className="font-medium text-gray-900">Keywords Match</h5>
                      <span className="text-sm font-semibold text-green-700">{keywordsMatch.score}%</span>
                    </div>
                    <p className="text-xs text-gray-600 mb-2">Key terms from job description found in candidate profile:</p>
                    <div className="flex flex-wrap gap-1">
                      {keywordsMatch.matched.slice(0, 15).map((keyword, idx) => (
                        <span key={idx} className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">
                          {keyword}
                        </span>
                      ))}
                      {keywordsMatch.matched.length > 15 && (
                        <span className="px-2 py-1 text-xs text-gray-600">
                          +{keywordsMatch.matched.length - 15} more
                        </span>
                      )}
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Notice Period
                  </label>
                  <select
                    value={candidateStub.noticePeriod}
                    onChange={(e) => setCandidateStub(prev => ({ ...prev, noticePeriod: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Select notice period</option>
                    <option value="Immediate">Immediate</option>
                    <option value="2 weeks">2 weeks</option>
                    <option value="1 month">1 month</option>
                    <option value="2 months">2 months</option>
                    <option value="3+ months">3+ months</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <h4 className="text-lg font-semibold text-gray-900 mb-4">
                Step 2: Set Your Success Fee
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Fee Type
                  </label>
                  <div className="space-y-3">
                    <label className="cursor-pointer">
                      <input
                        type="radio"
                        name="feeType"
                        value="percent"
                        checked={bidDetails.feeType === 'percent'}
                        onChange={(e) => setBidDetails(prev => ({ ...prev, feeType: e.target.value }))}
                        className="sr-only"
                      />
                      <div className={`p-4 border-2 rounded-lg ${
                        bidDetails.feeType === 'percent'
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}>
                        <div className="flex items-center mb-1">
                          <span className="font-medium">Percentage Fee</span>
                        </div>
                        <p className="text-sm text-gray-600">% of first year salary</p>
                      </div>
                    </label>

                    <label className="cursor-pointer">
                      <input
                        type="radio"
                        name="feeType"
                        value="flat"
                        checked={bidDetails.feeType === 'flat'}
                        onChange={(e) => setBidDetails(prev => ({ ...prev, feeType: e.target.value }))}
                        className="sr-only"
                      />
                      <div className={`p-4 border-2 rounded-lg ${
                        bidDetails.feeType === 'flat'
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}>
                        <div className="flex items-center mb-1">
                          <span className="font-medium">Flat Fee</span>
                        </div>
                        <p className="text-sm text-gray-600">Fixed amount</p>
                      </div>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <DollarSign className="w-4 h-4 inline mr-1" />
                    {bidDetails.feeType === 'percent' ? 'Percentage (%)' : 'Amount ($)'}
                  </label>
                  <input
                    type="number"
                    required
                    value={bidDetails.feeValue}
                    onChange={(e) => setBidDetails(prev => ({ ...prev, feeValue: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder={bidDetails.feeType === 'percent' ? 'e.g., 18' : 'e.g., 25000'}
                    min="0"
                    max={bidDetails.feeType === 'percent' ? '100' : undefined}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Shield className="w-4 h-4 inline mr-1" />
                    Guarantee Period (Days)
                  </label>
                  <select
                    value={bidDetails.guaranteeDays}
                    onChange={(e) => setBidDetails(prev => ({ ...prev, guaranteeDays: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="30">30 days</option>
                    <option value="60">60 days</option>
                    <option value="90">90 days</option>
                    <option value="120">120 days</option>
                  </select>
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h5 className="font-medium text-gray-900 mb-2">Fee Calculation Preview</h5>
                <div className="text-sm text-gray-600">
                  {bidDetails.feeType === 'percent' && candidateStub.salaryExpectation ? (
                    <p>
                      Based on expected salary of ${parseInt(candidateStub.salaryExpectation).toLocaleString()}:
                      <span className="font-semibold text-gray-900 ml-1">
                        ${Math.round(parseInt(candidateStub.salaryExpectation) * parseInt(bidDetails.feeValue || '0') / 100).toLocaleString()}
                      </span>
                    </p>
                  ) : bidDetails.feeType === 'flat' && bidDetails.feeValue ? (
                    <p>
                      Flat fee: <span className="font-semibold text-gray-900">${parseInt(bidDetails.feeValue).toLocaleString()}</span>
                    </p>
                  ) : (
                    <p>Enter fee details to see calculation</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <h4 className="text-lg font-semibold text-gray-900 mb-4">
                Step 3: Review & Submit
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h5 className="font-medium text-gray-900 mb-3">Candidate Summary</h5>
                  <div className="space-y-2 text-sm">
                    <p><span className="font-medium">Experience:</span> {candidateStub.experienceYears} years</p>
                    <p><span className="font-medium">Industry:</span> {candidateStub.industry}</p>
                    <p><span className="font-medium">Location:</span> {candidateStub.locationZone}</p>
                    <p><span className="font-medium">Skills:</span> {candidateStub.skills}</p>
                    {candidateStub.salaryExpectation && (
                      <p><span className="font-medium">Salary:</span> ${parseInt(candidateStub.salaryExpectation).toLocaleString()}</p>
                    )}
                    {candidateStub.noticePeriod && (
                      <p><span className="font-medium">Notice:</span> {candidateStub.noticePeriod}</p>
                    )}
                  </div>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <h5 className="font-medium text-gray-900 mb-3">Bid Details</h5>
                  <div className="space-y-2 text-sm">
                    <p><span className="font-medium">Fee Type:</span> {bidDetails.feeType === 'percent' ? 'Percentage' : 'Flat Fee'}</p>
                    <p><span className="font-medium">Fee Amount:</span> {
                      bidDetails.feeType === 'percent' 
                        ? `${bidDetails.feeValue}%` 
                        : `$${parseInt(bidDetails.feeValue || '0').toLocaleString()}`
                    }</p>
                    <p><span className="font-medium">Guarantee:</span> {bidDetails.guaranteeDays} days</p>
                  </div>
                </div>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <h5 className="font-medium text-yellow-900 mb-2">Important Terms</h5>
                <ul className="text-sm text-yellow-800 space-y-1">
                  <li>• Candidate identity remains anonymous until bid acceptance</li>
                  <li>• Success fee is held in escrow upon hiring</li>
                  <li>• Platform commission (15%) applies to successful placements</li>
                  <li>• Guarantee period starts from candidate's first day</li>
                </ul>
              </div>
            </div>
          )}

          <div className="flex justify-between items-center pt-6 border-t mt-8">
            <div className="flex space-x-3">
              {step > 1 && (
                <button
                  type="button"
                  onClick={() => setStep(step - 1)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
                >
                  Previous
                </button>
              )}
            </div>
            
            <div className="flex space-x-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              
              {step < 3 ? (
                <button
                  type="button"
                  onClick={(e) => handleNext(e)}
                  className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                >
                  Next
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                >
                  {isSubmitting ? 'Submitting...' : 'Submit Bid'}
                </button>
              )}
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BidForm;
