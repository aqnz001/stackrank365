import React, { useMemo, useState } from 'react';
import { RecruiterBid } from '../../types';
import { useJobs } from '../../hooks/useJobs';
import { useRecruiterBids } from '../../hooks/useRecruiterBids';
import { useApplications } from '../../hooks/useApplications';
import { useEscrowPolicy } from '../../hooks/useEscrowPolicy';
import { useEscrowTransactions } from '../../hooks/useEscrowTransactions';
import { X, Briefcase, Building, Shield, FileText, CheckCircle, Calendar, DollarSign } from 'lucide-react';
import { useEscrowPayments } from '../../hooks/useEscrowPayments';
import RecruiterFeeInvoice from '../Payments/RecruiterFeeInvoice';

interface Props {
  bid: RecruiterBid;
  isOpen: boolean;
  onClose: () => void;
}

const BidReviewWizard: React.FC<Props> = ({ bid, isOpen, onClose }) => {
  const { jobs } = useJobs();
  const job = jobs.find(j => j.id === bid.jobId);
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [agreeEscrow, setAgreeEscrow] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const { updateBidStatus } = useRecruiterBids();
  const { createApplication } = useApplications();
  const { policy } = useEscrowPolicy();
  const { createForBid } = useEscrowTransactions();
  const { createPaymentIntent } = useEscrowPayments();

  if (!isOpen) return null;

  const formatFee = () => bid.feeType === 'percent' ? `${bid.feeValue}% of first year salary` : `$${bid.feeValue.toLocaleString()} flat fee`;

  const onConfirm = async () => {
    if (!agreeEscrow) return;
    setSubmitting(true);
    try {
      const revealedCandidate = {
        id: 'candidate-123',
        name: 'John Doe',
        email: 'john.doe@example.com',
        phone: '+1-555-0123',
        resume: 'Full resume content would be here...',
      };

      // For flat fee bids, optionally initiate a payment intent (test mode via Edge Function)
      if (bid.feeType === 'flat') {
        const cents = Math.round(bid.feeValue * 100);
        await createPaymentIntent({ amountCents: cents, currency: 'USD', metadata: { recruiter_bid_id: bid.id, job_id: job?.id } });
      }

      await updateBidStatus(bid.id, 'accepted', revealedCandidate);
      try {
        await createApplication({
          jobId: job?.id,
          candidateId: revealedCandidate.id,
          candidateName: revealedCandidate.name,
          candidateEmail: revealedCandidate.email,
          source: 'recruiter',
          status: 'submitted',
          recruiterBidId: bid.id,
          coverLetter: undefined,
          phone: revealedCandidate.phone,
          location: '',
          salaryExpectation: null,
          availabilityDate: null,
          workAuthorization: null,
          willingToRelocate: false,
          additionalInfo: 'Application created from accepted recruiter bid',
          resumeUrl: null,
          resumeFileName: null,
        });
      } catch (error) {
        console.error('Failed to create application from bid:', error);
      }

      // Create a placeholder escrow transaction
      createForBid({
        recruiterBidId: bid.id,
        jobId: job?.id || null,
        employerOrgId: job?.organizationId || null,
        employerOrganizationName: job?.organizationName || null,
        recruiterCompany: bid.recruiterCompany || null,
        feeType: bid.feeType,
        feeValue: bid.feeValue,
        amount: bid.feeType === 'flat' ? bid.feeValue : null,
        currency: 'USD',
      });

      setShowSuccess(true);
      setTimeout(() => onClose(), 3000);
    } catch (e) {
      alert('Failed to accept bid');
    } finally {
      setSubmitting(false);
    }
  };

  const stepTitles = ['Bid Overview', 'Escrow Terms', 'Payment Invoice', 'Confirm & Accept'];

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <div className="flex items-center gap-2">
              <Shield className="w-6 h-6" />
              <div>
                <h3 className="text-xl font-semibold">Review Recruiter Bid</h3>
                <p className="text-blue-100 text-sm">Step {step} of {stepTitles.length}: {stepTitles[step - 1]}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 text-white/80 hover:text-white" aria-label="Close">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="px-6 py-6">
            {showSuccess ? (
              <div className="flex flex-col items-center justify-center py-12 space-y-4">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-12 h-12 text-green-600" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900">Bid Accepted!</h3>
                <p className="text-center text-gray-600 max-w-md">
                  The recruiter bid for <span className="font-semibold">{job?.title}</span> has been successfully accepted.
                  The candidate will be added to your applications and the escrow process has been initiated.
                </p>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
                  <p className="text-sm text-blue-900">
                    <strong>Next Steps:</strong>
                  </p>
                  <ul className="text-sm text-blue-800 mt-2 space-y-1 list-disc list-inside">
                    <li>Review the candidate in your Applications tab</li>
                    <li>Escrow funds are being held securely</li>
                    <li>Schedule an interview if interested</li>
                  </ul>
                </div>
                <p className="text-sm text-gray-500 mt-4">This window will close automatically...</p>
              </div>
            ) : (
              <>
            {/* Progress Indicator */}
            <div className="flex items-center justify-center gap-3 mb-8">
              {stepTitles.map((_, i) => (
                <div key={i} className="flex items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    i + 1 <= step ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
                  }`}>
                    {i + 1 < step ? <CheckCircle className="w-4 h-4" /> : i + 1}
                  </div>
                  {i < stepTitles.length - 1 && (
                    <div className={`w-12 h-1 mx-2 ${i + 1 < step ? 'bg-blue-600' : 'bg-gray-200'}`} />
                  )}
                </div>
              ))}
            </div>
            {/* Step Content */}
            <div className="min-h-[400px]">
              {step === 1 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <Building className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">Bid Overview</h4>
                    <p className="text-gray-600">Review the recruiter's bid details</p>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                      <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center text-white">
                        <Building className="w-6 h-6"/>
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900">{bid.recruiterCompany}</div>
                        <div className="text-sm text-gray-600">{bid.recruiterName}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-gray-800 p-4 bg-gray-50 rounded-lg">
                      <Briefcase className="w-5 h-5 text-blue-600" />
                      <span className="font-medium">{job?.title}</span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <div className="text-xs font-medium text-blue-600 mb-1">Success Fee</div>
                        <div className="font-semibold text-gray-900">{formatFee()}</div>
                      </div>
                      <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                        <div className="text-xs font-medium text-green-600 mb-1">Guarantee Period</div>
                        <div className="font-semibold text-gray-900">
                          <Shield className="w-4 h-4 inline mr-1" />{bid.guaranteeDays} days
                        </div>
                      </div>
                      <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
                        <div className="text-xs font-medium text-gray-600 mb-1">Submitted</div>
                        <div className="font-semibold text-gray-900">
                          <Calendar className="w-4 h-4 inline mr-1" />{bid.createdAt.toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              {step === 2 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <FileText className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">{policy?.title || 'Escrow Terms & Conditions'}</h4>
                    <p className="text-gray-600">Review and accept the escrow payment terms</p>
                  </div>

                  <div className="prose prose-sm max-w-none whitespace-pre-wrap text-gray-800 border border-gray-300 rounded-lg p-4 bg-gray-50 max-h-[300px] overflow-y-auto" style={{fontFamily:'inherit'}}>
                    {policy?.content || 'Define escrow terms in Admin • Escrow Manager.'}
                  </div>

                  <label className="flex items-start gap-3 p-4 border-2 border-gray-300 rounded-lg cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-all">
                    <input
                      type="checkbox"
                      checked={agreeEscrow}
                      onChange={e=>setAgreeEscrow(e.target.checked)}
                      className="mt-1 w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                    />
                    <span className="text-sm text-gray-800 font-medium">
                      I agree to the platform escrow terms and payment flow
                    </span>
                  </label>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-6">
                  <RecruiterFeeInvoice
                    bid={bid}
                    jobTitle={job?.title || 'Position'}
                    salaryAmount={job?.salaryRange?.max}
                  />
                </div>
              )}

              {step === 4 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">Confirm & Accept</h4>
                    <p className="text-gray-600">Review payment summary and accept the bid</p>
                  </div>

                  <div className="space-y-4">
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                        <DollarSign className="w-5 h-5 text-blue-600"/>
                        Payment Summary
                      </div>
                      <div className="space-y-2 text-sm text-gray-800">
                        <div className="flex justify-between">
                          <span>Success Fee:</span>
                          <span className="font-semibold">{formatFee()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Guarantee Period:</span>
                          <span className="font-semibold">{bid.guaranteeDays} days</span>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-gray-50 border border-gray-300 rounded-lg text-sm text-gray-700">
                      <p>Payment is made to the platform and held in escrow. Funds are released to the recruiter based on guarantee and placement conditions.</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          <div className="px-6 py-4 border-t bg-gray-50 flex justify-between items-center">
            <div className="text-sm text-gray-600">Step {step} of {stepTitles.length}</div>
            <div className="flex items-center gap-3">
              {step > 1 && (
                <button
                  onClick={() => setStep((s)=> (s-1) as any)}
                  className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100 font-medium transition-colors"
                >
                  Back
                </button>
              )}
              {step < 4 && (
                <button
                  onClick={() => setStep((s)=> (s+1) as any)}
                  disabled={step===2 && !agreeEscrow}
                  className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Next
                </button>
              )}
              {step === 4 && (
                <button
                  disabled={!agreeEscrow || submitting}
                  onClick={onConfirm}
                  className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  <CheckCircle className="w-4 h-4" />
                  {submitting ? 'Confirming…' : 'Confirm & Accept Bid'}
                </button>
              )}
            </div>
          </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BidReviewWizard;
