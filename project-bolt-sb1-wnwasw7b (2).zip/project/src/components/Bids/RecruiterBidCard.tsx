import React, { useState, useEffect } from 'react';
import { useRecruiterBids } from '../../hooks/useRecruiterBids';
import { useApplications } from '../../hooks/useApplications';
import { RecruiterBid, Application } from '../../types';
import { useJobs } from '../../hooks/useJobs';
import {
  Building,
  DollarSign,
  Calendar,
  Shield,
  Eye,
  CheckCircle,
  XCircle,
  Clock,
  Star,
  MapPin,
  Briefcase,
  Award,
  CheckCircle2
} from 'lucide-react';
import 'react-quill/dist/quill.snow.css';
import BidReviewWizard from './BidReviewWizard';
import ApplicationDetailsModal from '../Applications/ApplicationDetailsModal';

interface RecruiterBidCardProps {
  bid: RecruiterBid;
  showActions?: boolean;
  onAccept?: () => void;
  onReject?: () => void;
  onViewDetails?: () => void;
}

const RecruiterBidCard: React.FC<RecruiterBidCardProps> = ({
  bid,
  showActions = true,
  onAccept,
  onReject,
  onViewDetails,
}) => {
  const { jobs } = useJobs();
  const { updateBidStatus } = useRecruiterBids();
  const { createApplication, applications } = useApplications();
  const [showWizard, setShowWizard] = useState(false);
  const [showResumeModal, setShowResumeModal] = useState(false);
  const [bidApplication, setBidApplication] = useState<Application | null>(null);
  const job = jobs.find(j => j.id === bid.jobId);

  useEffect(() => {
    if (bid.status === 'accepted' && applications.length > 0) {
      const app = applications.find(a => a.recruiterBidId === bid.id);
      if (app) {
        setBidApplication(app);
      }
    }
  }, [bid.id, bid.status, applications]);

  const calculateSkillsMatch = () => {
    if (!job?.skills || !bid.candidateStub.skills) return null;

    const jobSkills = job.skills.map(s => s.toLowerCase().trim());
    const candidateSkills = bid.candidateStub.skills.map((s: string) => s.toLowerCase().trim());

    const matched = jobSkills.filter(jobSkill =>
      candidateSkills.some(candSkill =>
        candSkill.includes(jobSkill) || jobSkill.includes(candSkill)
      )
    );

    const score = jobSkills.length > 0 ? Math.round((matched.length / jobSkills.length) * 100) : 0;

    return { matched, total: jobSkills.length, score };
  };

  const skillsMatch = calculateSkillsMatch();

  const getStatusConfig = () => {
    switch (bid.status) {
      case 'submitted':
        return { color: 'blue', icon: <Clock className="w-4 h-4" />, label: 'Pending Review' };
      case 'accepted':
        return { color: 'green', icon: <CheckCircle className="w-4 h-4" />, label: 'Accepted' };
      case 'rejected':
        return { color: 'red', icon: <XCircle className="w-4 h-4" />, label: 'Rejected' };
      case 'withdrawn':
        return { color: 'gray', icon: <XCircle className="w-4 h-4" />, label: 'Withdrawn' };
      case 'expired':
        return { color: 'orange', icon: <Clock className="w-4 h-4" />, label: 'Expired' };
      default:
        return { color: 'gray', icon: <Clock className="w-4 h-4" />, label: 'Processing' };
    }
  };

  const statusConfig = getStatusConfig();

  const formatFee = () => {
    return bid.feeType === 'percent' 
      ? `${bid.feeValue}% of first year salary` 
      : `$${bid.feeValue.toLocaleString()} flat fee`;
  };

  const handleAccept = async () => {
    setShowWizard(true);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center">
          <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center mr-4">
            <Building className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{bid.recruiterCompany}</h3>
            <p className="text-gray-600">{bid.recruiterName}</p>
            <div className="flex items-center mt-1">
              <Star className="w-4 h-4 text-yellow-500" />
              <span className="text-sm text-gray-600 ml-1">4.8 rating • 127 placements</span>
            </div>
          </div>
        </div>

        <span className={`flex items-center px-3 py-1 rounded-full text-sm font-medium bg-${statusConfig.color}-100 text-${statusConfig.color}-800`}>
          {statusConfig.icon}
          <span className="ml-1">{statusConfig.label}</span>
        </span>
      </div>

      <div className="mb-4">
        <h4 className="font-medium text-gray-900 mb-1">{job?.title}</h4>
        <p className="text-gray-600 text-sm">{job?.organizationName} • {job?.location}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div className="bg-gray-50 p-4 rounded-lg">
          <h5 className="font-medium text-gray-900 mb-3">Candidate Summary</h5>
          <div className="space-y-2 text-sm">
            <div className="flex items-center text-gray-600">
              <Briefcase className="w-4 h-4 mr-2" />
              {bid.candidateStub.experienceYears} years in {bid.candidateStub.industry}
            </div>
            <div className="flex items-center text-gray-600">
              <MapPin className="w-4 h-4 mr-2" />
              {bid.candidateStub.locationZone}
            </div>
            {bid.candidateStub.salaryExpectation && (
              <div className="flex items-center text-gray-600">
                <DollarSign className="w-4 h-4 mr-2" />
                ${bid.candidateStub.salaryExpectation.toLocaleString()} expected
              </div>
            )}
          </div>

          <div className="mt-3">
            <p className="text-sm text-gray-600 mb-2">Skills:</p>
            <div className="flex flex-wrap gap-1">
              {bid.candidateStub.skills.slice(0, 4).map((skill, index) => (
                <span key={index} className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded">
                  {skill}
                </span>
              ))}
            </div>
          </div>

          <div className="mt-3">
            <p className="text-sm font-medium text-gray-900 mb-2">Profile Summary:</p>
            <div
              className="text-xs text-gray-700 prose prose-sm max-w-none ql-editor-readonly"
              dangerouslySetInnerHTML={{ __html: typeof bid.candidateStub.highlights === 'string' ? bid.candidateStub.highlights : bid.candidateStub.highlights?.join('<br>') || '' }}
            />
          </div>
        </div>

        <div className="bg-blue-50 p-4 rounded-lg">
          <h5 className="font-medium text-gray-900 mb-3">Bid Details</h5>
          <div className="space-y-3">
            <div>
              <div className="text-sm text-gray-600">Success Fee</div>
              <div className="text-lg font-semibold text-blue-600">{formatFee()}</div>
            </div>
            
            <div>
              <div className="text-sm text-gray-600">Guarantee Period</div>
              <div className="font-medium flex items-center">
                <Shield className="w-4 h-4 mr-1 text-green-600" />
                {bid.guaranteeDays} days
              </div>
            </div>

            <div>
              <div className="text-sm text-gray-600">Submitted</div>
              <div className="font-medium flex items-center">
                <Calendar className="w-4 h-4 mr-1" />
                {bid.createdAt.toLocaleDateString()}
              </div>
            </div>

            {bid.candidateStub.noticePeriod && (
              <div>
                <div className="text-sm text-gray-600">Notice Period</div>
                <div className="font-medium">{bid.candidateStub.noticePeriod}</div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Skills Match Indicator */}
      {skillsMatch && skillsMatch.score > 0 && (
        <div className="mb-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <h5 className="font-medium text-gray-900">Skills Match</h5>
            <div className="flex items-center">
              <div className="w-32 bg-gray-200 rounded-full h-2 mr-3">
                <div
                  className={`h-2 rounded-full ${
                    skillsMatch.score >= 80 ? 'bg-green-600' :
                    skillsMatch.score >= 60 ? 'bg-yellow-600' :
                    'bg-orange-600'
                  }`}
                  style={{ width: `${skillsMatch.score}%` }}
                ></div>
              </div>
              <span className="text-sm font-semibold">{skillsMatch.score}%</span>
            </div>
          </div>
          <p className="text-xs text-gray-600 mb-2">
            Candidate matches {skillsMatch.matched.length} of {skillsMatch.total} required skills
          </p>
          <div className="flex flex-wrap gap-1">
            {skillsMatch.matched.map((skill, idx) => (
              <span key={idx} className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full flex items-center">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                {skill}
              </span>
            ))}
          </div>
        </div>
      )}

      {bid.status === 'accepted' && bid.revealedCandidate && (
        <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg">
          <h5 className="font-medium text-green-900 mb-2">Candidate Revealed</h5>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <p><span className="font-medium">Name:</span> {bid.revealedCandidate.name}</p>
              <p><span className="font-medium">Email:</span> {bid.revealedCandidate.email}</p>
              {bid.revealedCandidate.phone && (
                <p><span className="font-medium">Phone:</span> {bid.revealedCandidate.phone}</p>
              )}
            </div>
            <div>
              <p className="font-medium mb-1">Resume:</p>
              {bidApplication?.resumeUrl ? (
                <button
                  onClick={() => setShowResumeModal(true)}
                  className="text-blue-600 hover:text-blue-700 text-sm flex items-center"
                >
                  <Eye className="w-4 h-4 mr-1" />
                  View Resume
                </button>
              ) : (
                <span className="text-gray-500 text-sm">No resume available</span>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="flex justify-end items-center">
        {showActions && bid.status === 'submitted' && (
          <div className="flex space-x-3">
            <button
              onClick={() => updateBidStatus(bid.id, 'rejected').then(() => onReject?.()).catch(console.error)}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Reject
            </button>
            <button onClick={handleAccept} className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">Accept Bid</button>
          </div>
        )}
      </div>
      {showWizard && (
        <BidReviewWizard bid={bid} isOpen={showWizard} onClose={() => { setShowWizard(false); onAccept?.(); }} />
      )}
      {showResumeModal && bidApplication && (
        <ApplicationDetailsModal
          application={bidApplication}
          isOpen={showResumeModal}
          onClose={() => setShowResumeModal(false)}
        />
      )}
    </div>
  );
};

export default RecruiterBidCard;
