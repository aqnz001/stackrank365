import React, { useState } from 'react';
import { useWorkflows, WorkflowTemplate, WorkflowStepTemplate } from '../../hooks/useWorkflows';
import { 
  X, 
  Plus, 
  Mail, 
  Bell, 
  CheckSquare, 
  Clock,
  GitBranch,
  UserCheck,
  ArrowDown,
  Trash2,
  Edit
} from 'lucide-react';

interface WorkflowBuilderProps {
  template?: WorkflowTemplate;
  onClose: () => void;
}

const WorkflowBuilder: React.FC<WorkflowBuilderProps> = ({ template, onClose }) => {
  const { createWorkflowTemplate } = useWorkflows();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: template?.name || '',
    description: template?.description || '',
    category: template?.category || 'hiring' as const,
    triggerEvent: template?.triggerEvent || 'application_received' as const,
  });
  const [steps, setSteps] = useState<WorkflowStepTemplate[]>(template?.steps || []);

  const stepTypes = [
    { value: 'email', label: 'Send Email', icon: <Mail className="w-4 h-4" />, description: 'Send automated email' },
    { value: 'notification', label: 'Send Notification', icon: <Bell className="w-4 h-4" />, description: 'In-app notification' },
    { value: 'task', label: 'Create Task', icon: <CheckSquare className="w-4 h-4" />, description: 'Assign task to user' },
    { value: 'delay', label: 'Wait/Delay', icon: <Clock className="w-4 h-4" />, description: 'Wait for specified time' },
    { value: 'condition', label: 'Condition', icon: <GitBranch className="w-4 h-4" />, description: 'Conditional logic' },
    { value: 'approval', label: 'Approval', icon: <UserCheck className="w-4 h-4" />, description: 'Require approval' },
  ];

  const categories = [
    { value: 'hiring', label: 'Hiring Process' },
    { value: 'onboarding', label: 'Employee Onboarding' },
    { value: 'recruitment', label: 'Recruitment' },
    { value: 'compliance', label: 'Compliance' },
  ];

  const triggerEvents = [
    { value: 'application_received', label: 'Application Received' },
    { value: 'bid_accepted', label: 'Recruiter Bid Accepted' },
    { value: 'interview_scheduled', label: 'Interview Scheduled' },
    { value: 'offer_made', label: 'Job Offer Made' },
  ];

  const addStep = () => {
    const newStep: WorkflowStepTemplate = {
      stepNumber: steps.length + 1,
      name: '',
      type: 'email',
      config: {},
    };
    setSteps([...steps, newStep]);
  };

  const updateStep = (index: number, updates: Partial<WorkflowStepTemplate>) => {
    setSteps(prev => prev.map((step, i) => 
      i === index ? { ...step, ...updates } : step
    ));
  };

  const removeStep = (index: number) => {
    setSteps(prev => prev.filter((_, i) => i !== index).map((step, i) => ({
      ...step,
      stepNumber: i + 1,
    })));
  };

  const moveStep = (index: number, direction: 'up' | 'down') => {
    if (
      (direction === 'up' && index === 0) ||
      (direction === 'down' && index === steps.length - 1)
    ) {
      return;
    }

    const newSteps = [...steps];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    
    [newSteps[index], newSteps[targetIndex]] = [newSteps[targetIndex], newSteps[index]];
    
    // Update step numbers
    newSteps.forEach((step, i) => {
      step.stepNumber = i + 1;
    });
    
    setSteps(newSteps);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (steps.length === 0) {
      setError('Please add at least one workflow step');
      return;
    }
    
    setIsSubmitting(true);
    setError(null);

    try {
      console.log('Creating workflow template with', steps.length, 'steps');
      
      await createWorkflowTemplate({
        name: formData.name,
        description: formData.description,
        category: formData.category,
        triggerEvent: formData.triggerEvent,
        steps,
      });

      console.log('Workflow template created successfully');
      onClose();
    } catch (err) {
      console.error('Error creating workflow template:', err);
      setError(err instanceof Error ? err.message : 'Failed to create workflow template');
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStepConfig = (step: WorkflowStepTemplate, index: number) => {
    switch (step.type) {
      case 'email':
        return (
          <div className="space-y-3">
            <input
              type="text"
              placeholder="Recipient (e.g., candidate, employer, recruiter)"
              value={step.config.recipient || ''}
              onChange={(e) => updateStep(index, {
                config: { ...step.config, recipient: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
            <input
              type="text"
              placeholder="Email subject"
              value={step.config.subject || ''}
              onChange={(e) => updateStep(index, {
                config: { ...step.config, subject: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
            <textarea
              rows={3}
              placeholder="Email body"
              value={step.config.body || ''}
              onChange={(e) => updateStep(index, {
                config: { ...step.config, body: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        );
      
      case 'delay':
        return (
          <div className="flex items-center space-x-2">
            <input
              type="number"
              placeholder="Days"
              value={step.delayDays || ''}
              onChange={(e) => updateStep(index, { delayDays: parseInt(e.target.value) })}
              className="w-20 px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
            <span className="text-sm text-gray-600">days</span>
          </div>
        );
      
      case 'task':
        return (
          <div className="space-y-3">
            <input
              type="text"
              placeholder="Task description"
              value={step.config.description || ''}
              onChange={(e) => updateStep(index, {
                config: { ...step.config, description: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
            <select
              value={step.assignedRole || ''}
              onChange={(e) => updateStep(index, { assignedRole: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select role</option>
              <option value="employer">Employer</option>
              <option value="recruiter">Recruiter</option>
              <option value="admin">Admin</option>
            </select>
          </div>
        );
      
      case 'notification':
        return (
          <div className="space-y-3">
            <input
              type="text"
              placeholder="Notification title"
              value={step.config.title || ''}
              onChange={(e) => updateStep(index, {
                config: { ...step.config, title: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
            <textarea
              rows={2}
              placeholder="Notification message"
              value={step.config.message || ''}
              onChange={(e) => updateStep(index, {
                config: { ...step.config, message: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        );
      
      case 'condition':
        return (
          <div className="space-y-3">
            <select
              value={step.config.field || ''}
              onChange={(e) => updateStep(index, {
                config: { ...step.config, field: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select field to check</option>
              <option value="application_status">Application Status</option>
              <option value="bid_status">Bid Status</option>
              <option value="interview_status">Interview Status</option>
            </select>
            <select
              value={step.config.operator || ''}
              onChange={(e) => updateStep(index, {
                config: { ...step.config, operator: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Select condition</option>
              <option value="equals">Equals</option>
              <option value="not_equals">Not Equals</option>
              <option value="contains">Contains</option>
            </select>
            <input
              type="text"
              placeholder="Value to compare"
              value={step.config.value || ''}
              onChange={(e) => updateStep(index, {
                config: { ...step.config, value: e.target.value }
              })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        );
      
      default:
        return (
          <input
            type="text"
            placeholder="Configuration"
            value={step.config.value || ''}
            onChange={(e) => updateStep(index, {
              config: { ...step.config, value: e.target.value }
            })}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          />
        );
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-20 mx-auto p-5 border w-full max-w-4xl shadow-lg rounded-md bg-white">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold text-gray-900">
            {template ? 'Edit' : 'Create'} Workflow Template
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 p-2"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Workflow Name
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="e.g., Standard Hiring Process"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Category
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value as any }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              >
                {categories.map(category => (
                  <option key={category.value} value={category.value}>
                    {category.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                rows={2}
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="Describe what this workflow does..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Trigger Event
              </label>
              <select
                value={formData.triggerEvent}
                onChange={(e) => setFormData(prev => ({ ...prev, triggerEvent: e.target.value as any }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              >
                {triggerEvents.map(event => (
                  <option key={event.value} value={event.value}>
                    {event.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Workflow Steps */}
          <div>
            <div className="flex justify-between items-center mb-4">
              <h4 className="text-lg font-semibold text-gray-900">Workflow Steps</h4>
              <button
                type="button"
                onClick={addStep}
                className="flex items-center px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Step
              </button>
            </div>

            <div className="space-y-4">
              {steps.map((step, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-blue-600 font-medium">{step.stepNumber}</span>
                      </div>
                      <input
                        type="text"
                        placeholder="Step name"
                        value={step.name}
                        onChange={(e) => updateStep(index, { name: e.target.value })}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        onClick={() => moveStep(index, 'up')}
                        disabled={index === 0}
                        className="p-1 text-gray-400 hover:text-gray-600 disabled:opacity-50"
                      >
                        ↑
                      </button>
                      <button
                        type="button"
                        onClick={() => moveStep(index, 'down')}
                        disabled={index === steps.length - 1}
                        className="p-1 text-gray-400 hover:text-gray-600 disabled:opacity-50"
                      >
                        ↓
                      </button>
                      <button
                        type="button"
                        onClick={() => removeStep(index)}
                        className="p-1 text-gray-400 hover:text-red-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Step Type
                      </label>
                      <select
                        value={step.type}
                        onChange={(e) => updateStep(index, { type: e.target.value as any })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                      >
                        {stepTypes.map(type => (
                          <option key={type.value} value={type.value}>
                            {type.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Configuration
                      </label>
                      {renderStepConfig(step, index)}
                    </div>
                  </div>

                  {index < steps.length - 1 && (
                    <div className="flex justify-center mt-4">
                      <ArrowDown className="w-5 h-5 text-gray-400" />
                    </div>
                  )}
                </div>
              ))}

              {steps.length === 0 && (
                <div className="text-center py-8 border-2 border-dashed border-gray-300 rounded-lg">
                  <CheckSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">No steps added yet</p>
                  <button
                    type="button"
                    onClick={addStep}
                    className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Add First Step
                  </button>
                </div>
              )}
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-800">{error}</p>
            </div>
          )}

          <div className="flex justify-end space-x-4 pt-6 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || steps.length === 0}
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              {isSubmitting ? 'Creating...' : template ? 'Update Template' : 'Create Template'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default WorkflowBuilder;