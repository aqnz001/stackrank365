import React, { useState } from 'react';
import { X, CheckCircle, XCircle, FileText, Send, AlertCircle } from 'lucide-react';
import { Interview } from '../../hooks/useInterviews';
import toast from 'react-hot-toast';

interface InterviewDecisionModalProps {
  interview: Interview;
  application: any;
  onClose: () => void;
  onDecision: (decision: 'accepted' | 'rejected' | 'offer_extended', notes: string) => Promise<void>;
}

const InterviewDecisionModal: React.FC<InterviewDecisionModalProps> = ({
  interview,
  application,
  onClose,
  onDecision,
}) => {
  const [decision, setDecision] = useState<'accepted' | 'rejected' | 'offer_extended' | null>(null);
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!decision) {
      toast.error('Please select a decision');
      return;
    }

    if (!notes.trim()) {
      toast.error('Please provide notes for your decision');
      return;
    }

    try {
      setLoading(true);
      await onDecision(decision, notes);
      toast.success('Decision recorded successfully');
      onClose();
    } catch (error) {
      console.error('Error recording decision:', error);
      toast.error('Failed to record decision');
    } finally {
      setLoading(false);
    }
  };

  const getDecisionColor = (type: string) => {
    switch (type) {
      case 'accepted':
        return 'bg-green-50 border-green-300 text-green-900';
      case 'offer_extended':
        return 'bg-blue-50 border-blue-300 text-blue-900';
      case 'rejected':
        return 'bg-red-50 border-red-300 text-red-900';
      default:
        return 'bg-gray-50 border-gray-300 text-gray-900';
    }
  };

  const interviewRecommendation = interview.feedback?.recommendation;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Post-Interview Decision</h2>
            <p className="text-sm text-gray-600 mt-1">
              Make your final decision for {application.candidateName}
            </p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="font-medium text-blue-900 mb-2 flex items-center">
              <FileText className="w-4 h-4 mr-2" />
              Interview Summary
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-blue-700">Position:</span>
                <span className="text-blue-900 font-medium">{interview.jobTitle}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-blue-700">Interview Date:</span>
                <span className="text-blue-900 font-medium">
                  {interview.scheduledAt.toLocaleDateString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-blue-700">Interview Type:</span>
                <span className="text-blue-900 font-medium capitalize">
                  {interview.interviewType.replace('_', ' ')}
                </span>
              </div>
              {interview.feedback?.rating && (
                <div className="flex justify-between">
                  <span className="text-blue-700">Rating:</span>
                  <span className="text-blue-900 font-medium">
                    {interview.feedback.rating}/5
                  </span>
                </div>
              )}
              {interviewRecommendation && (
                <div className="flex justify-between">
                  <span className="text-blue-700">Interviewer Recommendation:</span>
                  <span className="text-blue-900 font-medium capitalize">
                    {interviewRecommendation === 'proceed' && 'Proceed to next round'}
                    {interviewRecommendation === 'hire' && 'Recommend for hire'}
                    {interviewRecommendation === 'reject' && 'Do not proceed'}
                    {interviewRecommendation === 'undecided' && 'Need more information'}
                  </span>
                </div>
              )}
            </div>
          </div>

          {interview.feedback?.notes && (
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-2">Interview Feedback Notes</h4>
              <p className="text-sm text-gray-700 whitespace-pre-wrap">
                {interview.feedback.notes}
              </p>
            </div>
          )}

          <div>
            <h3 className="font-medium text-gray-900 mb-3 flex items-center">
              <AlertCircle className="w-4 h-4 mr-2" />
              Select Your Decision
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <button
                onClick={() => setDecision('accepted')}
                className={`p-4 border-2 rounded-lg transition-all ${
                  decision === 'accepted'
                    ? getDecisionColor('accepted') + ' shadow-md'
                    : 'border-gray-200 hover:border-green-300 hover:bg-green-50'
                }`}
              >
                <CheckCircle className="w-6 h-6 mx-auto mb-2 text-green-600" />
                <div className="font-medium text-center">Accept</div>
                <div className="text-xs text-center mt-1 text-gray-600">
                  Move candidate forward
                </div>
              </button>

              <button
                onClick={() => setDecision('offer_extended')}
                className={`p-4 border-2 rounded-lg transition-all ${
                  decision === 'offer_extended'
                    ? getDecisionColor('offer_extended') + ' shadow-md'
                    : 'border-gray-200 hover:border-blue-300 hover:bg-blue-50'
                }`}
              >
                <Send className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                <div className="font-medium text-center">Extend Offer</div>
                <div className="text-xs text-center mt-1 text-gray-600">
                  Send formal job offer
                </div>
              </button>

              <button
                onClick={() => setDecision('rejected')}
                className={`p-4 border-2 rounded-lg transition-all ${
                  decision === 'rejected'
                    ? getDecisionColor('rejected') + ' shadow-md'
                    : 'border-gray-200 hover:border-red-300 hover:bg-red-50'
                }`}
              >
                <XCircle className="w-6 h-6 mx-auto mb-2 text-red-600" />
                <div className="font-medium text-center">Reject</div>
                <div className="text-xs text-center mt-1 text-gray-600">
                  Do not proceed
                </div>
              </button>
            </div>
          </div>

          {decision && (
            <div>
              <label className="block text-sm font-medium text-gray-900 mb-2">
                Decision Notes <span className="text-red-500">*</span>
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder={
                  decision === 'accepted'
                    ? 'Document why you are accepting this candidate (e.g., strong technical skills, good culture fit, relevant experience...)'
                    : decision === 'offer_extended'
                    ? 'Document offer details and next steps (e.g., salary offered, start date, benefits...)'
                    : 'Document your reasons for rejection (e.g., skills gap, experience mismatch, better candidates available...)'
                }
              />
              <p className="text-xs text-gray-500 mt-1">
                These notes will be stored with the application for future reference and audit purposes.
              </p>
            </div>
          )}

          {decision && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <div className="flex items-start">
                <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5 mr-2 flex-shrink-0" />
                <div className="text-sm text-yellow-800">
                  <p className="font-medium mb-1">Important Note:</p>
                  {decision === 'accepted' && (
                    <p>
                      This will update the application status to show the candidate has been accepted.
                      The candidate will receive a notification about this decision.
                    </p>
                  )}
                  {decision === 'offer_extended' && (
                    <p>
                      This will mark the application as having an extended offer. The candidate will
                      be notified, and you should follow up with formal offer documentation.
                    </p>
                  )}
                  {decision === 'rejected' && (
                    <p>
                      This will mark the application as rejected. The candidate will receive a
                      professional rejection notification. This action cannot be easily undone.
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t border-gray-200 bg-gray-50 flex justify-end gap-3 sticky bottom-0">
          <button
            onClick={onClose}
            disabled={loading}
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!decision || !notes.trim() || loading}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                Processing...
              </>
            ) : (
              'Confirm Decision'
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default InterviewDecisionModal;
