import React, { useState } from 'react';
import { useInterviews } from '../../hooks/useInterviews';
import { useApplications } from '../../hooks/useApplications';
import { useRecruiterBids } from '../../hooks/useRecruiterBids';
import { X, Calendar, Clock, MapPin, Video, Phone, Users, User } from 'lucide-react';

interface InterviewSchedulerProps {
  applicationId?: string;
  recruiterBidId?: string;
  candidateId: string;
  onClose: () => void;
}

const InterviewScheduler: React.FC<InterviewSchedulerProps> = ({
  applicationId,
  recruiterBidId,
  candidateId,
  onClose,
}) => {
  const { scheduleInterview } = useInterviews();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    interviewType: 'video' as const,
    date: '',
    time: '',
    durationMinutes: 60,
    location: '',
    meetingLink: '',
    notes: '',
  });

  const interviewTypes = [
    { value: 'phone', label: 'Phone Interview', icon: <Phone className="w-4 h-4" /> },
    { value: 'video', label: 'Video Interview', icon: <Video className="w-4 h-4" /> },
    { value: 'in_person', label: 'In-Person Interview', icon: <MapPin className="w-4 h-4" /> },
    { value: 'technical', label: 'Technical Interview', icon: <Users className="w-4 h-4" /> },
    { value: 'panel', label: 'Panel Interview', icon: <Users className="w-4 h-4" /> },
  ];

  const durations = [
    { value: 30, label: '30 minutes' },
    { value: 45, label: '45 minutes' },
    { value: 60, label: '1 hour' },
    { value: 90, label: '1.5 hours' },
    { value: 120, label: '2 hours' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      const scheduledAt = new Date(`${formData.date}T${formData.time}`);
      
      if (scheduledAt <= new Date()) {
        throw new Error('Interview must be scheduled for a future date and time');
      }

      await scheduleInterview({
        applicationId,
        recruiterBidId,
        candidateId,
        interviewType: formData.interviewType,
        scheduledAt,
        durationMinutes: formData.durationMinutes,
        location: formData.location || undefined,
        meetingLink: formData.meetingLink || undefined,
        notes: formData.notes || undefined,
      });

      onClose();
    } catch (err) {
      console.error('Error scheduling interview:', err);
      setError(err instanceof Error ? err.message : 'Failed to schedule interview');
    } finally {
      setIsSubmitting(false);
    }
  };

  const generateMeetingLink = () => {
    // In a real implementation, this would integrate with Zoom, Teams, etc.
    const meetingId = Math.random().toString(36).substring(2, 15);
    setFormData(prev => ({
      ...prev,
      meetingLink: `https://meet.google.com/${meetingId}`,
    }));
  };

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-bold text-gray-900">Schedule Interview</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 p-2"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Interview Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Interview Type
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {interviewTypes.map(type => (
                <label key={type.value} className="cursor-pointer">
                  <input
                    type="radio"
                    name="interviewType"
                    value={type.value}
                    checked={formData.interviewType === type.value}
                    onChange={(e) => setFormData(prev => ({ ...prev, interviewType: e.target.value as any }))}
                    className="sr-only"
                  />
                  <div className={`p-3 border-2 rounded-lg transition-all ${
                    formData.interviewType === type.value
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}>
                    <div className="flex items-center">
                      {type.icon}
                      <span className="ml-2 font-medium">{type.label}</span>
                    </div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Date and Time */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="w-4 h-4 inline mr-1" />
                Date
              </label>
              <input
                type="date"
                required
                value={formData.date}
                onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                min={new Date().toISOString().split('T')[0]}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Clock className="w-4 h-4 inline mr-1" />
                Time
              </label>
              <input
                type="time"
                required
                value={formData.time}
                onChange={(e) => setFormData(prev => ({ ...prev, time: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>

          {/* Duration */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Duration
            </label>
            <select
              value={formData.durationMinutes}
              onChange={(e) => setFormData(prev => ({ ...prev, durationMinutes: parseInt(e.target.value) }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            >
              {durations.map(duration => (
                <option key={duration.value} value={duration.value}>
                  {duration.label}
                </option>
              ))}
            </select>
          </div>

          {/* Location or Meeting Link */}
          {formData.interviewType === 'in_person' ? (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <MapPin className="w-4 h-4 inline mr-1" />
                Location
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="Office address or meeting location"
              />
            </div>
          ) : (formData.interviewType === 'video' || formData.interviewType === 'phone') && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Video className="w-4 h-4 inline mr-1" />
                Meeting Link
              </label>
              <div className="flex space-x-2">
                <input
                  type="url"
                  value={formData.meetingLink}
                  onChange={(e) => setFormData(prev => ({ ...prev, meetingLink: e.target.value }))}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  placeholder="https://zoom.us/j/123456789 or phone number"
                />
                <button
                  type="button"
                  onClick={generateMeetingLink}
                  className="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
                >
                  Generate
                </button>
              </div>
            </div>
          )}

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Notes (Optional)
            </label>
            <textarea
              rows={3}
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              placeholder="Additional notes or instructions for the interview..."
            />
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-800">{error}</p>
            </div>
          )}

          <div className="flex justify-end space-x-4 pt-6 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              {isSubmitting ? 'Scheduling...' : 'Schedule Interview'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default InterviewScheduler;