import React, { useState } from 'react';
import { useInterviews } from '../../hooks/useInterviews';
import { Interview } from '../../hooks/useInterviews';
import { useApplications } from '../../hooks/useApplications';
import InterviewDecisionModal from './InterviewDecisionModal';
import {
  Calendar,
  Clock,
  MapPin,
  Video,
  Phone,
  Users,
  CheckCircle,
  XCircle,
  Edit,
  MessageSquare,
  FileText,
  Star,
  Gavel
} from 'lucide-react';

interface InterviewCardProps {
  interview: Interview;
  showActions?: boolean;
}

const InterviewCard: React.FC<InterviewCardProps> = ({ interview, showActions = true }) => {
  const { updateInterviewStatus, rescheduleInterview, addInterviewFeedback } = useInterviews();
  const { applications, updateApplicationWithDecision } = useApplications();
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);
  const [showDecisionModal, setShowDecisionModal] = useState(false);
  const [feedback, setFeedback] = useState({
    rating: 5,
    notes: '',
    recommendation: 'proceed',
    strengths: '',
    concerns: '',
  });

  const relatedApplication = applications.find(app => app.id === interview.applicationId);

  const getInterviewTypeIcon = () => {
    switch (interview.interviewType) {
      case 'phone': return <Phone className="w-5 h-5" />;
      case 'video': return <Video className="w-5 h-5" />;
      case 'in_person': return <MapPin className="w-5 h-5" />;
      case 'technical': return <FileText className="w-5 h-5" />;
      case 'panel': return <Users className="w-5 h-5" />;
      default: return <Calendar className="w-5 h-5" />;
    }
  };

  const getStatusConfig = () => {
    switch (interview.status) {
      case 'scheduled':
        return { color: 'blue', icon: <Calendar className="w-4 h-4" />, label: 'Scheduled' };
      case 'confirmed':
        return { color: 'green', icon: <CheckCircle className="w-4 h-4" />, label: 'Confirmed' };
      case 'completed':
        return { color: 'purple', icon: <CheckCircle className="w-4 h-4" />, label: 'Completed' };
      case 'cancelled':
        return { color: 'red', icon: <XCircle className="w-4 h-4" />, label: 'Cancelled' };
      case 'rescheduled':
        return { color: 'yellow', icon: <Edit className="w-4 h-4" />, label: 'Rescheduled' };
      case 'no_show':
        return { color: 'red', icon: <XCircle className="w-4 h-4" />, label: 'No Show' };
      default:
        return { color: 'gray', icon: <Clock className="w-4 h-4" />, label: 'Unknown' };
    }
  };

  const statusConfig = getStatusConfig();

  const handleStatusUpdate = async (newStatus: Interview['status']) => {
    try {
      await updateInterviewStatus(interview.id, newStatus);

      const statusMessages = {
        confirmed: 'Interview confirmed successfully!',
        completed: 'Interview marked as completed!',
        cancelled: 'Interview cancelled',
        rescheduled: 'Interview rescheduled',
        no_show: 'Interview marked as no show'
      };

      const notification = document.createElement('div');
      notification.className = 'fixed top-4 right-4 bg-green-100 border border-green-200 text-green-800 px-4 py-3 rounded-lg shadow-lg z-50';
      notification.innerHTML = `
        <div class="flex items-center">
          <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
          </svg>
          ${statusMessages[newStatus] || 'Interview status updated!'}
        </div>
      `;
      document.body.appendChild(notification);
      setTimeout(() => {
        if (document.body.contains(notification)) {
          document.body.removeChild(notification);
        }
      }, 3000);
    } catch (error) {
      console.error('Error updating interview status:', error);

      const errorNotification = document.createElement('div');
      errorNotification.className = 'fixed top-4 right-4 bg-red-100 border border-red-200 text-red-800 px-4 py-3 rounded-lg shadow-lg z-50';
      errorNotification.innerHTML = `
        <div class="flex items-center">
          <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path>
          </svg>
          Failed to update interview status
        </div>
      `;
      document.body.appendChild(errorNotification);
      setTimeout(() => {
        if (document.body.contains(errorNotification)) {
          document.body.removeChild(errorNotification);
        }
      }, 3000);
    }
  };

  const handleSubmitFeedback = async () => {
    try {
      console.log('Submitting interview feedback:', feedback);
      await addInterviewFeedback(interview.id, feedback);
      setShowFeedbackForm(false);
      
      // Show success notification
      const notification = document.createElement('div');
      notification.className = 'fixed top-4 right-4 bg-green-100 border border-green-200 text-green-800 px-4 py-3 rounded-lg shadow-lg z-50';
      notification.innerHTML = `
        <div class="flex items-center">
          <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
          </svg>
          Interview feedback submitted successfully!
        </div>
      `;
      document.body.appendChild(notification);
      setTimeout(() => {
        document.body.removeChild(notification);
      }, 3000);
    } catch (error) {
      console.error('Error submitting feedback:', error);
      alert('Failed to submit feedback');
    }
  };

  const isUpcoming = interview.scheduledAt > new Date();
  const isPast = interview.scheduledAt <= new Date();

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-blue-100 rounded-lg">
            {getInterviewTypeIcon()}
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">
              {interview.interviewType.charAt(0).toUpperCase() + interview.interviewType.slice(1)} Interview
            </h3>
            <p className="text-gray-600">{interview.jobTitle}</p>
            <p className="text-sm text-gray-500">
              with {interview.candidateName}
            </p>
          </div>
        </div>

        <span className={`flex items-center px-3 py-1 rounded-full text-sm font-medium bg-${statusConfig.color}-100 text-${statusConfig.color}-800`}>
          {statusConfig.icon}
          <span className="ml-1">{statusConfig.label}</span>
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div className="flex items-center text-gray-600">
          <Calendar className="w-4 h-4 mr-2" />
          <span>{interview.scheduledAt.toLocaleDateString()}</span>
        </div>
        <div className="flex items-center text-gray-600">
          <Clock className="w-4 h-4 mr-2" />
          <span>
            {interview.scheduledAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} 
            ({interview.durationMinutes} min)
          </span>
        </div>
        
        {interview.location && (
          <div className="flex items-center text-gray-600">
            <MapPin className="w-4 h-4 mr-2" />
            <span>{interview.location}</span>
          </div>
        )}
        
        {interview.meetingLink && (
          <div className="flex items-center text-gray-600">
            <Video className="w-4 h-4 mr-2" />
            <a 
              href={interview.meetingLink}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 hover:text-blue-700 truncate"
            >
              Join Meeting
            </a>
          </div>
        )}
      </div>

      {interview.notes && (
        <div className="mb-4 p-3 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-700">{interview.notes}</p>
        </div>
      )}

      {interview.feedback && Object.keys(interview.feedback).length > 0 && (
        <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
          <h4 className="font-medium text-green-900 mb-2">Interview Feedback</h4>
          <div className="flex items-center mb-2">
            <Star className="w-4 h-4 text-yellow-500 mr-1" />
            <span className="text-sm text-gray-700">
              Rating: {interview.feedback.rating}/5
            </span>
          </div>
          {interview.feedback.notes && (
            <p className="text-sm text-gray-700">{interview.feedback.notes}</p>
          )}
        </div>
      )}

      {showActions && (
        <div className="flex justify-between items-center pt-4 border-t border-gray-100">
          <div className="flex space-x-2">
            {interview.status === 'scheduled' && isUpcoming && (
              <>
                <button
                  onClick={() => handleStatusUpdate('confirmed')}
                  className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700"
                >
                  Confirm
                </button>
                <button
                  onClick={() => handleStatusUpdate('cancelled')}
                  className="px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700"
                >
                  Cancel
                </button>
              </>
            )}
            
            {interview.status === 'confirmed' && isPast && (
              <>
                <button
                  onClick={() => handleStatusUpdate('completed')}
                  className="px-3 py-1 bg-purple-600 text-white rounded text-sm hover:bg-purple-700"
                >
                  Mark Complete
                </button>
                <button
                  onClick={() => handleStatusUpdate('no_show')}
                  className="px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700"
                >
                  No Show
                </button>
              </>
            )}

            {interview.status === 'completed' && !interview.feedback && (
              <button
                onClick={() => setShowFeedbackForm(true)}
                className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700"
              >
                Add Feedback
              </button>
            )}

            {interview.status === 'completed' && interview.feedback && relatedApplication && (!relatedApplication.interviewDecision || relatedApplication.interviewDecision === 'pending') && (
              <button
                onClick={() => setShowDecisionModal(true)}
                className="flex items-center px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700"
              >
                <Gavel className="w-4 h-4 mr-1" />
                Make Decision
              </button>
            )}
          </div>

          <div className="flex space-x-2">
            <button className="p-2 text-gray-400 hover:text-gray-600">
              <MessageSquare className="w-4 h-4" />
            </button>
            <button className="p-2 text-gray-400 hover:text-gray-600">
              <Edit className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Feedback Form Modal */}
      {showFeedbackForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 z-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Interview Feedback</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Overall Rating
                </label>
                <div className="flex space-x-1">
                  {[1, 2, 3, 4, 5].map(rating => (
                    <button
                      key={rating}
                      type="button"
                      onClick={() => setFeedback(prev => ({ ...prev, rating }))}
                      className={`p-1 transition-colors ${feedback.rating >= rating ? 'text-yellow-500' : 'text-gray-300 hover:text-yellow-400'}`}
                    >
                      <Star className="w-6 h-6 fill-current" />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Recommendation
                </label>
                <select
                  value={feedback.recommendation}
                  onChange={(e) => setFeedback(prev => ({ ...prev, recommendation: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="proceed">Proceed to next round</option>
                  <option value="hire">Recommend for hire</option>
                  <option value="reject">Do not proceed</option>
                  <option value="undecided">Need more information</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Notes
                </label>
                <textarea
                  rows={3}
                  value={feedback.notes}
                  onChange={(e) => setFeedback(prev => ({ ...prev, notes: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Overall interview feedback..."
                />
              </div>
            </div>

            <div className="flex justify-end space-x-3 mt-6">
              <button
                onClick={() => setShowFeedbackForm(false)}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmitFeedback}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Submit Feedback
              </button>
            </div>
          </div>
        </div>
      )}

      {showDecisionModal && relatedApplication && (
        <InterviewDecisionModal
          interview={interview}
          application={relatedApplication}
          onClose={() => setShowDecisionModal(false)}
          onDecision={async (decision, notes) => {
            await updateApplicationWithDecision(interview.applicationId!, decision, notes);
          }}
        />
      )}
    </div>
  );
};

export default InterviewCard;