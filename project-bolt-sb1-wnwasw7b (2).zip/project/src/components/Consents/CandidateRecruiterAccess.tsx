import React from 'react';
import { useConsentCodes } from '../../hooks/useConsentCodes';
import { useConsentRequests } from '../../hooks/useConsentRequests';
import ConsentCard from './ConsentCard';

const CandidateRecruiterAccess: React.FC = () => {
  const { generate } = useConsentCodes();
  const { consents, loading, approveConsent, declineConsent, revokeConsent, blockRecruiter } = useConsentRequests() as any;
  const [lastCode, setLastCode] = React.useState<{ code: string; expiresAt: Date } | null>(null);

  const onGenerate = async () => {
    const res = await generate();
    setLastCode({ code: res.code, expiresAt: res.expiresAt });
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">One-Time Code</h3>
        <p className="text-sm text-gray-600 mb-4">Generate a short code and share it privately with a recruiter. The code expires in 30 minutes.</p>
        <button onClick={onGenerate} className="px-3 py-2 bg-blue-600 text-white rounded">Generate Code</button>
        {lastCode && (
          <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded">
            <div className="text-sm text-blue-900">Code: <span className="font-mono font-semibold">{lastCode.code}</span> • Expires: {lastCode.expiresAt.toLocaleTimeString()}</div>
          </div>
        )}
      </div>

      <div className="bg-white rounded-xl shadow-sm border p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Pending Requests</h3>
        {loading ? (
          <div className="text-sm text-gray-600">Loading…</div>
        ) : consents.filter((c:any)=>c.status==='requested').length === 0 ? (
          <div className="text-sm text-gray-600">No pending requests</div>
        ) : (
          consents.filter((c:any)=>c.status==='requested').map((c:any)=> (
            <ConsentCard key={c.id} consent={c} />
          ))
        )}
      </div>

      <div className="bg-white rounded-xl shadow-sm border p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Approved Recruiters</h3>
        {loading ? (
          <div className="text-sm text-gray-600">Loading…</div>
        ) : consents.filter((c:any)=>c.status==='approved').length === 0 ? (
          <div className="text-sm text-gray-600">No approved consents</div>
        ) : (
          consents.filter((c:any)=>c.status==='approved').map((c:any)=> (
            <ConsentCard key={c.id} consent={c} />
          ))
        )}
      </div>
    </div>
  );
};

export default CandidateRecruiterAccess;

