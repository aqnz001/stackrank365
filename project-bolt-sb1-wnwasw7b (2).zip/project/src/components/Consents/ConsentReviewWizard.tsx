import React, { useMemo, useState } from 'react';
import { Consent } from '../../types';
import { stripPoliciesMarker, extractPoliciesFromMessage } from '../../hooks/useConsentPolicies';
import { X, CheckCircle, FileText, Shield, Briefcase, Building } from 'lucide-react';
import { useConsentRequests } from '../../hooks/useConsentRequests';

interface Props {
  consent: Consent;
  isOpen: boolean;
  onClose: () => void;
}

const ConsentReviewWizard: React.FC<Props> = ({ consent, isOpen, onClose }) => {
  const { approveConsent, declineConsent } = useConsentRequests() as any;
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [agreePrivacy, setAgreePrivacy] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const policyPayload = useMemo(() => extractPoliciesFromMessage(consent.message), [consent.message]);
  const displayMessage = useMemo(() => stripPoliciesMarker(consent.message), [consent.message]);

  if (!isOpen) return null;

  const onConfirm = async () => {
    if (!(agreeTerms && agreePrivacy)) return;
    setSubmitting(true);
    try {
      await approveConsent(consent.id);
      onClose();
    } catch (e) {
      alert('Failed to approve consent');
    } finally {
      setSubmitting(false);
    }
  };

  const stepTitles = ['Role & Details', 'Terms & Conditions', 'Data & Privacy'];

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <div className="flex items-center gap-2">
              <Shield className="w-6 h-6" />
              <div>
                <h3 className="text-xl font-semibold">Review Consent Request</h3>
                <p className="text-blue-100 text-sm">Step {step} of {stepTitles.length}: {stepTitles[step - 1]}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 text-white/80 hover:text-white" aria-label="Close">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="px-6 py-6">
            {/* Progress Indicator */}
            <div className="flex items-center justify-center gap-3 mb-8">
              {stepTitles.map((_, i) => (
                <div key={i} className="flex items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    i + 1 <= step ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
                  }`}>
                    {i + 1 < step ? <CheckCircle className="w-4 h-4" /> : i + 1}
                  </div>
                  {i < stepTitles.length - 1 && (
                    <div className={`w-12 h-1 mx-2 ${i + 1 < step ? 'bg-blue-600' : 'bg-gray-200'}`} />
                  )}
                </div>
              ))}
            </div>

            {/* Step Content */}
            <div className="min-h-[400px]">
              {step === 1 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <Building className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">Role & Details</h4>
                    <p className="text-gray-600">Review the recruiter's request details</p>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                      <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center text-white">
                        <Building className="w-6 h-6"/>
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900">{consent.recruiterCompany}</div>
                        <div className="text-sm text-gray-600">{consent.recruiterName}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-gray-800 p-4 bg-gray-50 rounded-lg">
                      <Briefcase className="w-5 h-5 text-blue-600" />
                      <span className="font-medium">{consent.jobTitle}</span>
                    </div>

                    {displayMessage && (
                      <div className="bg-gray-50 border border-gray-300 rounded-lg p-4">
                        <div className="text-sm font-medium text-gray-900 mb-2">Recruiter's Message</div>
                        <div className="text-sm text-gray-800 whitespace-pre-wrap">{displayMessage}</div>
                      </div>
                    )}

                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Shield className="w-5 h-5 text-blue-600" />
                        <div className="font-semibold text-blue-900">What happens if you approve</div>
                      </div>
                      <ul className="list-disc list-inside space-y-1 text-sm text-blue-800">
                        <li>Your anonymized profile summary may be shared with the employer</li>
                        <li>Only one recruiter per job can be approved</li>
                        <li>Your identity remains hidden until the employer accepts the bid</li>
                        <li>You may revoke consent until bid acceptance</li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <FileText className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">{policyPayload?.terms?.title || 'Terms & Conditions'}</h4>
                    <p className="text-gray-600">Review and accept the terms and conditions</p>
                  </div>

                  <div className="prose prose-sm max-w-none whitespace-pre-wrap text-gray-800 border border-gray-300 rounded-lg p-4 bg-gray-50 max-h-[300px] overflow-y-auto" style={{fontFamily:'inherit'}}>
                    {policyPayload?.terms?.content || 'No terms provided.'}
                  </div>

                  <label className="flex items-start gap-3 p-4 border-2 border-gray-300 rounded-lg cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-all">
                    <input
                      type="checkbox"
                      checked={agreeTerms}
                      onChange={e=>setAgreeTerms(e.target.checked)}
                      className="mt-1 w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                    />
                    <span className="text-sm text-gray-800 font-medium">
                      I have read and agree to the Terms & Conditions
                    </span>
                  </label>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <Shield className="w-12 h-12 text-green-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">{policyPayload?.privacy?.title || 'Data & Privacy'}</h4>
                    <p className="text-gray-600">Review and accept the data & privacy policy</p>
                  </div>

                  <div className="prose prose-sm max-w-none whitespace-pre-wrap text-gray-800 border border-gray-300 rounded-lg p-4 bg-gray-50 max-h-[300px] overflow-y-auto" style={{fontFamily:'inherit'}}>
                    {policyPayload?.privacy?.content || 'No privacy policy provided.'}
                  </div>

                  <label className="flex items-start gap-3 p-4 border-2 border-gray-300 rounded-lg cursor-pointer hover:border-green-500 hover:bg-green-50 transition-all">
                    <input
                      type="checkbox"
                      checked={agreePrivacy}
                      onChange={e=>setAgreePrivacy(e.target.checked)}
                      className="mt-1 w-5 h-5 text-green-600 rounded focus:ring-2 focus:ring-green-500"
                    />
                    <span className="text-sm text-gray-800 font-medium">
                      I have read and agree to the Data & Privacy policy
                    </span>
                  </label>

                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg text-sm text-yellow-900">
                    <strong>Ready to proceed?</strong> By clicking "Confirm & Approve" below, you authorize this recruiter to represent you for this role.
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="px-6 py-4 border-t bg-gray-50 flex justify-between items-center">
            <div className="text-sm text-gray-600">Step {step} of {stepTitles.length}</div>
            <div className="flex items-center gap-3">
              {step > 1 && (
                <button
                  onClick={() => setStep((s)=> (s-1) as any)}
                  className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100 font-medium transition-colors"
                >
                  Back
                </button>
              )}
              {step < 3 && (
                <button
                  onClick={() => setStep((s)=> (s+1) as any)}
                  className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium transition-colors"
                >
                  Next
                </button>
              )}
              {step === 3 && (
                <button
                  disabled={!(agreeTerms && agreePrivacy) || submitting}
                  onClick={onConfirm}
                  className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  <CheckCircle className="w-4 h-4" />
                  {submitting ? 'Confirming…' : 'Confirm & Approve'}
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConsentReviewWizard;
