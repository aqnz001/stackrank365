import React from 'react';
import { useConsentRequests } from '../../hooks/useConsentRequests';
import { Consent } from '../../types';
import { 
  Building, 
  Calendar, 
  CheckCircle, 
  XCircle, 
  Clock,
  Briefcase,
  User
} from 'lucide-react';
import ConsentReviewWizard from './ConsentReviewWizard';

interface ConsentCardProps {
  consent: Consent;
  readOnly?: boolean; // when true, hide action buttons (for recruiter view)
}

const ConsentCard: React.FC<ConsentCardProps> = ({ consent, readOnly = false }) => {
  const { approveConsent, declineConsent, revokeConsent, blockRecruiter } = useConsentRequests() as any;
  const [showWizard, setShowWizard] = React.useState(false);

  const handleApprove = async () => {
    setShowWizard(true);
  };

  const handleDecline = async () => {
    try {
      await declineConsent(consent.id);
    } catch (error) {
      console.error('Error declining consent:', error);
      alert('Failed to decline consent. Please try again.');
    }
  };

  const handleRevoke = async () => {
    if (window.confirm('Are you sure you want to revoke this consent? This action cannot be undone.')) {
      try {
        await revokeConsent(consent.id);
      } catch (error) {
        console.error('Error revoking consent:', error);
        alert('Failed to revoke consent. Please try again.');
      }
    }
  };

  const getStatusConfig = () => {
    switch (consent.status) {
      case 'requested':
        return { 
          color: 'yellow', 
          icon: <Clock className="w-4 h-4" />, 
          label: 'Pending Response',
          showActions: true
        };
      case 'approved':
        return { 
          color: 'green', 
          icon: <CheckCircle className="w-4 h-4" />, 
          label: 'Approved',
          showActions: false
        };
      case 'declined':
        return { 
          color: 'red', 
          icon: <XCircle className="w-4 h-4" />, 
          label: 'Declined',
          showActions: false
        };
      case 'revoked':
        return { 
          color: 'gray', 
          icon: <XCircle className="w-4 h-4" />, 
          label: 'Revoked',
          showActions: false
        };
      default:
        return { 
          color: 'gray', 
          icon: <Clock className="w-4 h-4" />, 
          label: 'Processing',
          showActions: false
        };
    }
  };

  const statusConfig = getStatusConfig();

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center mr-3">
            <Building className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{consent.recruiterCompany}</h3>
            <p className="text-gray-600 text-sm">{consent.recruiterName}</p>
          </div>
        </div>

        <span className={`flex items-center px-3 py-1 rounded-full text-sm font-medium bg-${statusConfig.color}-100 text-${statusConfig.color}-800`}>
          {statusConfig.icon}
          <span className="ml-1">{statusConfig.label}</span>
        </span>
      </div>

      <div className="mb-4">
        <div className="flex items-center mb-2">
          <Briefcase className="w-4 h-4 text-gray-500 mr-2" />
          <h4 className="font-medium text-gray-900">{consent.jobTitle}</h4>
        </div>
        
        <div className="flex items-center text-sm text-gray-500">
          <Calendar className="w-4 h-4 mr-1" />
          Requested: {consent.requestedAt.toLocaleDateString()}
          {consent.respondedAt && (
            <>
              <span className="mx-2">•</span>
              Responded: {consent.respondedAt.toLocaleDateString()}
            </>
          )}
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
        <h5 className="font-medium text-blue-900 mb-2">Consent Request Details</h5>
        <p className="text-blue-800 text-sm">
          {consent.recruiterName} from {consent.recruiterCompany} is requesting permission to 
          represent you for the "{consent.jobTitle}" position. If approved, they will submit 
          an anonymized summary of your profile to the employer.
        </p>
      </div>

      <div className="bg-gray-50 p-3 rounded-lg mb-4">
        <h6 className="text-sm font-medium text-gray-700 mb-2">What happens if you approve:</h6>
        <ul className="text-sm text-gray-600 space-y-1">
          <li>• Your anonymized profile summary will be shared with the employer</li>
          <li>• Only one recruiter per job - you cannot approve multiple for the same role</li>
          <li>• Your identity remains hidden until the employer accepts the recruiter's bid</li>
          <li>• You can revoke consent anytime before the bid is accepted</li>
        </ul>
      </div>

      {statusConfig.showActions && !readOnly && (
        <div className="flex justify-end space-x-3">
          <button
            onClick={handleDecline}
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <XCircle className="w-4 h-4 inline mr-1" />
            Decline
          </button>
          <button
            onClick={() => blockRecruiter(consent.id)}
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Block Recruiter
          </button>
          <button
            onClick={handleApprove}
            className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            <CheckCircle className="w-4 h-4 inline mr-1" />
            Approve
          </button>
        </div>
      )}

      {consent.status === 'approved' && !readOnly && (
        <div className="flex justify-end">
          <button onClick={handleRevoke} className="px-4 py-2 border border-red-300 text-red-600 rounded-lg hover:bg-red-50 transition-colors text-sm">
            Revoke Consent
          </button>
        </div>
      )}
      {showWizard && (
        <ConsentReviewWizard consent={consent} isOpen={showWizard} onClose={() => setShowWizard(false)} />
      )}
    </div>
  );
};

export default ConsentCard;
