import React, { useMemo, useState } from 'react';
import { useConsentPolicies } from '../../hooks/useConsentPolicies';
import { X, Shield, FileText } from 'lucide-react';

interface Props {
  onClose: () => void;
}

const ConsentPoliciesManager: React.FC<Props> = ({ onClose }) => {
  const { items, create, update, remove, listByType, getDefault } = useConsentPolicies();
  const [tab, setTab] = useState<'terms' | 'privacy'>('terms');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [setAsDefault, setSetAsDefault] = useState(true);

  const currentList = useMemo(() => listByType(tab), [listByType, tab]);
  const currentDefault = useMemo(() => getDefault(tab), [getDefault, tab]);

  const onCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;
    const item = create({ type: tab, title: title.trim() || (tab === 'terms' ? 'Terms & Conditions' : 'Data & Privacy'), content, setAsDefault });
    setTitle('');
    setContent('');
    setSetAsDefault(false);
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex items-start justify-center z-50 overflow-auto">
      <div className="bg-white w-full max-w-4xl mt-16 mb-10 rounded-xl shadow-lg border">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-semibold text-gray-900">Consent Policies</h3>
          </div>
          <button onClick={onClose} className="p-2 text-gray-500 hover:text-gray-700">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="px-4 pt-3">
          <div className="flex gap-2 mb-4">
            <button onClick={() => setTab('terms')} className={`px-3 py-1.5 rounded-md text-sm ${tab==='terms'?'bg-blue-600 text-white':'bg-gray-100 text-gray-700'}`}>Terms & Conditions</button>
            <button onClick={() => setTab('privacy')} className={`px-3 py-1.5 rounded-md text-sm ${tab==='privacy'?'bg-blue-600 text-white':'bg-gray-100 text-gray-700'}`}>Data & Privacy</button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="border rounded-md">
              <div className="p-3 border-b flex items-center justify-between">
                <div className="font-medium text-gray-800">Your {tab==='terms'?'Terms & Conditions':'Data & Privacy'} templates</div>
                {currentDefault && (
                  <span className="text-xs text-gray-600">Default: {currentDefault.title}</span>
                )}
              </div>
              <div className="max-h-[50vh] overflow-auto divide-y">
                {currentList.length === 0 ? (
                  <div className="p-3 text-sm text-gray-500">No templates yet.</div>
                ) : currentList.map(item => (
                  <div key={item.id} className="p-3 flex items-start justify-between gap-3">
                    <div>
                      <div className="font-medium text-gray-900 flex items-center gap-2">
                        <FileText className="w-4 h-4 text-gray-500" />
                        {item.title || (item.type==='terms'?'Terms':'Privacy')}
                        {item.isDefault && <span className="ml-1 text-xs text-blue-700 bg-blue-100 px-2 py-0.5 rounded">Default</span>}
                      </div>
                      <div className="text-sm text-gray-600 line-clamp-3 whitespace-pre-wrap mt-1">{item.content}</div>
                    </div>
                    <div className="flex flex-col gap-2">
                      {!item.isDefault && (
                        <button onClick={() => update(item.id, { isDefault: true })} className="px-3 py-1 text-xs border rounded hover:bg-gray-50">Set Default</button>
                      )}
                      <button onClick={() => remove(item.id)} className="px-3 py-1 text-xs border border-red-300 text-red-600 rounded hover:bg-red-50">Delete</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <form onSubmit={onCreate} className="border rounded-md">
              <div className="p-3 border-b font-medium text-gray-800">Create New</div>
              <div className="p-3 space-y-3">
                <div>
                  <label className="block text-sm text-gray-700 mb-1">Title</label>
                  <input value={title} onChange={e=>setTitle(e.target.value)} placeholder={tab==='terms'?'Terms & Conditions':'Data & Privacy'} className="w-full px-3 py-2 border rounded" />
                </div>
                <div>
                  <label className="block text-sm text-gray-700 mb-1">Content</label>
                  <textarea value={content} onChange={e=>setContent(e.target.value)} rows={10} placeholder={tab==='terms'?'Add your T&C…':'Add your Data & Privacy policy…'} className="w-full px-3 py-2 border rounded"></textarea>
                </div>
                <label className="inline-flex items-center gap-2 text-sm text-gray-700">
                  <input type="checkbox" checked={setAsDefault} onChange={e=>setSetAsDefault(e.target.checked)} />
                  Set as default for {tab==='terms'?'Terms':'Privacy'}
                </label>
                <div className="flex justify-end gap-2">
                  <button type="button" onClick={onClose} className="px-4 py-2 border rounded">Close</button>
                  <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded">Save</button>
                </div>
              </div>
            </form>
          </div>
        </div>
        <div className="h-3" />
      </div>
    </div>
  );
};

export default ConsentPoliciesManager;

