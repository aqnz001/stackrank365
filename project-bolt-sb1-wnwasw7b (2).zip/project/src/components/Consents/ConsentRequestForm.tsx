import React, { useState } from 'react';
import { useConsentRequests } from '../../hooks/useConsentRequests';
import { useConsentCodes } from '../../hooks/useConsentCodes';
import { useJobs } from '../../hooks/useJobs';
import { useBidEligibility } from '../../hooks/useBidEligibility';
import { X, User, Briefcase, Search, FileText, Shield } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useConsentPolicies, embedPoliciesInMessage } from '../../hooks/useConsentPolicies';
import ConsentPoliciesManager from './ConsentPoliciesManager';

interface ConsentRequestFormProps {
  onClose: () => void;
}

const ConsentRequestForm: React.FC<ConsentRequestFormProps> = ({ onClose }) => {
  const { createConsentRequest, inviteCandidate, consents } = useConsentRequests();
  const { verify, markUsed } = useConsentCodes();
  const { jobs } = useJobs();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [mode, setMode] = useState<'existing' | 'code' | 'invite'>('existing');
  const [selectedCandidate, setSelectedCandidate] = useState<string>('');
  const [selectedJob, setSelectedJob] = useState<string>('');
  const [message, setMessage] = useState('');
  const [consentCode, setConsentCode] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [resolvedCandidate, setResolvedCandidate] = useState<string>('');
  const [candidateQuery, setCandidateQuery] = useState('');
  const [jobQuery, setJobQuery] = useState('');
  const [showAllJobs, setShowAllJobs] = useState(false);
  const [showPoliciesManager, setShowPoliciesManager] = useState(false);
  const [selectedTermsId, setSelectedTermsId] = useState<string | 'default' | ''>('default');
  const [selectedPrivacyId, setSelectedPrivacyId] = useState<string | 'default' | ''>('default');

  const { listByType, getDefault, getById } = useConsentPolicies();
  const termsList = listByType('terms');
  const privacyList = listByType('privacy');

  const openJobs = jobs.filter(job => job.visibility === 'open');

  // Resolve candidate names/emails when missing from consents (due to RLS joins)
  const [candidateInfo, setCandidateInfo] = useState<Record<string, { name?: string; email?: string }>>({});

  // Derive candidates recruiter has interacted with via past consents
  const myCandidates = Array.from(
    (consents || []).reduce((map: Map<string, { id: string; name?: string; email?: string }>, c: any) => {
      if (!c.candidateId) return map;
      if (!map.has(c.candidateId)) {
        map.set(c.candidateId, { id: c.candidateId, name: c.candidateName, email: c.candidateEmail });
      }
      return map;
    }, new Map())
  ).map(([, v]) => v);

  // Fetch missing candidate names/emails using a batched profiles lookup (subject to RLS)
  React.useEffect(() => {
    const missing = myCandidates
      .filter(c => !c.name && !c.email && !candidateInfo[c.id])
      .map(c => c.id);
    if (missing.length === 0) return;
    (async () => {
      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('id, name, email')
          .in('id', missing);
        if (error) throw error;
        const map: Record<string, { name?: string; email?: string }> = {};
        (data || []).forEach((row: any) => {
          map[row.id] = { name: row.name || undefined, email: row.email || undefined };
        });
        if (Object.keys(map).length > 0) {
          setCandidateInfo(prev => ({ ...prev, ...map }));
        }
      } catch (e) {
        console.warn('Could not resolve candidate profiles; showing IDs. Consider adding an RLS policy to allow minimal profile read for related consents.', e);
      }
    })();
  }, [myCandidates.map(c => c.id).join('|')]);

  const filteredCandidates = myCandidates.filter(c => {
    const q = candidateQuery.trim().toLowerCase();
    if (!q) return true;
    const resolved = candidateInfo[c.id] || {};
    return (
      (c.name || resolved.name || '').toLowerCase().includes(q) ||
      (c.email || resolved.email || '').toLowerCase().includes(q) ||
      c.id.toLowerCase().includes(q)
    );
  });

  const filteredOpenJobs = openJobs.filter(j => {
    const q = jobQuery.trim().toLowerCase();
    if (!q) return true;
    return j.title.toLowerCase().includes(q) || (j.organizationName || '').toLowerCase().includes(q) || (j.location || '').toLowerCase().includes(q);
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Basic validation
      if (!selectedJob) {
        throw new Error('Please select a job');
      }
      let candidateId = selectedCandidate;
      if (mode === 'code') {
        const res = await verify(consentCode.trim());
        if (!res.ok || !res.candidateId) throw new Error(res.reason || 'Invalid/expired code');
        candidateId = res.candidateId;
        await markUsed(consentCode.trim(), 'recruiter');
      } else if (mode === 'existing') {
        if (!candidateId) throw new Error('Please select a candidate');
      } else if (mode === 'invite') {
        await inviteCandidate({ email: inviteEmail.trim(), jobId: selectedJob, message: message.trim() || undefined });
        setSuccessMessage(`Invitation sent successfully to ${inviteEmail}! The candidate will receive an email with instructions to join and provide consent.`);
        setShowSuccess(true);
        setTimeout(() => onClose(), 3000);
        return;
      }

      const selTerms = selectedTermsId && selectedTermsId !== 'default' ? getById(selectedTermsId) : getDefault('terms');
      const selPrivacy = selectedPrivacyId && selectedPrivacyId !== 'default' ? getById(selectedPrivacyId) : getDefault('privacy');
      const withPolicies = embedPoliciesInMessage(message, {
        terms: selTerms ? { title: selTerms.title, content: selTerms.content } : undefined,
        privacy: selPrivacy ? { title: selPrivacy.title, content: selPrivacy.content } : undefined,
      });

      // Find candidate info to store with the consent request
      const candidateInfo = myCandidates.find(c => c.id === candidateId);
      const candidateName = candidateInfo?.name || candidateInfo?.[candidateId]?.name;
      const candidateEmail = candidateInfo?.email || candidateInfo?.[candidateId]?.email;

      await createConsentRequest({
        candidateId,
        candidateName,
        candidateEmail,
        jobId: selectedJob,
        message: withPolicies || undefined,
      });

      const jobTitle = jobs.find(j => j.id === selectedJob)?.title || 'the job';
      const candName = candidateName || candidateEmail || 'the candidate';
      setSuccessMessage(`Consent request sent successfully to ${candName} for ${jobTitle}! The candidate will be notified and can review your request.`);
      setShowSuccess(true);
      setTimeout(() => onClose(), 3000);
    } catch (error) {
      console.error('Error sending consent request:', error);
      alert('Failed to send consent request. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Auto-select candidate when only one result is available
  React.useEffect(() => {
    if (mode !== 'existing') return;
    if (filteredCandidates.length === 1) {
      setSelectedCandidate(filteredCandidates[0].id);
    }
  }, [mode, candidateQuery, filteredCandidates.length]);

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4 overflow-y-auto">
        <div className="bg-white w-full max-w-2xl my-8 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[calc(100vh-4rem)]">
          <div className="flex items-center justify-between px-6 py-4 border-b bg-gradient-to-r from-blue-600 to-purple-600 text-white flex-shrink-0">
            <h3 className="text-lg font-semibold">Request Candidate Consent</h3>
            <button onClick={onClose} className="p-2 text-white/80 hover:text-white" aria-label="Close">
              <X className="w-6 h-6" />
            </button>
          </div>

          {showSuccess ? (
            <div className="flex flex-col items-center justify-center p-12 space-y-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900">Success!</h3>
              <p className="text-center text-gray-600 max-w-md">{successMessage}</p>
              <p className="text-sm text-gray-500">This window will close automatically...</p>
            </div>
          ) : (
        <form id="consent-form" onSubmit={handleSubmit} className="space-y-6 px-6 py-6 flex-1 overflow-y-auto">
          <div className="flex gap-2">
            <button type="button" className={`px-3 py-1 rounded ${mode==='existing'?'bg-blue-600 text-white':'bg-gray-100'}`} onClick={()=>setMode('existing')}>Select Existing</button>
            <button type="button" className={`px-3 py-1 rounded ${mode==='code'?'bg-blue-600 text-white':'bg-gray-100'}`} onClick={()=>setMode('code')}>Use One-Time Code</button>
            <button type="button" className={`px-3 py-1 rounded ${mode==='invite'?'bg-blue-600 text-white':'bg-gray-100'}`} onClick={()=>setMode('invite')}>Invite by Email</button>
          </div>

          {mode==='existing' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <User className="w-4 h-4 inline mr-1" />
                Search Your Candidates
              </label>
              <input
                type="text"
                value={candidateQuery}
                onChange={(e) => setCandidateQuery(e.target.value)}
                placeholder="Search by name, email, or ID"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
              <div className="mt-3 max-h-48 overflow-auto border border-gray-200 rounded-md divide-y">
                {filteredCandidates.length === 0 ? (
                  <div className="p-3 text-sm text-gray-500">No prior candidates found. Use a code or invite.</div>
                ) : (
                  filteredCandidates.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setSelectedCandidate(c.id)}
                      className={`w-full text-left px-3 py-2 hover:bg-gray-50 ${selectedCandidate===c.id? 'bg-blue-50': ''}`}
                    >
                  <div className="font-medium text-gray-900">{(c.name || candidateInfo[c.id]?.name || c.email || candidateInfo[c.id]?.email || c.id)}</div>
                  <div className="text-xs text-gray-600">{(c.email || candidateInfo[c.id]?.email || `${c.id.slice(0,8)}…${c.id.slice(-6)}`)}</div>
                    </button>
                  ))
                )}
              </div>
              <p className="text-sm text-gray-500 mt-1">Only candidates you’ve previously interacted with are shown.</p>
            </div>
          )}

          {mode==='code' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">One-Time Code from Candidate</label>
              <div className="flex gap-2">
                <input value={consentCode} onChange={e=>setConsentCode(e.target.value.toUpperCase())} placeholder="e.g. 7G3KXQ" className="flex-1 px-3 py-2 border rounded" />
                <button type="button" className="px-3 py-2 border rounded" onClick={async()=>{
                  const res = await verify(consentCode.trim());
                  if (res.ok && res.candidateId) { setResolvedCandidate(res.candidateId); alert('Code verified'); }
                  else { alert(res.reason || 'Invalid code'); }
                }}>Verify</button>
              </div>
              {resolvedCandidate && (<p className="text-sm text-green-700 mt-1">Code resolved to candidate ID: {resolvedCandidate}</p>)}
              <p className="text-sm text-gray-500 mt-1">Enter the short code generated by the candidate.</p>
            </div>
          )}

          {mode==='invite' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Candidate Email</label>
              <input type="email" required value={inviteEmail} onChange={e=>setInviteEmail(e.target.value)} placeholder="jane@example.com" className="w-full px-3 py-2 border rounded" />
              <p className="text-sm text-gray-500 mt-1">We will email an invite to join and approve consent for this job.</p>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Briefcase className="w-4 h-4 inline mr-1" />
              Find an Eligible Job
            </label>
            <div className="flex items-center gap-2 mb-2">
              <input
                type="text"
                value={jobQuery}
                onChange={(e) => setJobQuery(e.target.value)}
                placeholder="Search by title, company, or location"
                className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
              <label className="text-xs text-gray-700 flex items-center gap-2">
                <input type="checkbox" checked={showAllJobs} onChange={e=>setShowAllJobs(e.target.checked)} />
                Show ineligible
              </label>
            </div>
            <div className="mt-1 max-h-48 overflow-auto border border-gray-200 rounded-md divide-y">
              {filteredOpenJobs.length === 0 ? (
                <div className="p-3 text-sm text-gray-500">No open jobs match your search.</div>
              ) : (
                filteredOpenJobs.map(job => (
                  <JobPickRow key={job.id} job={job} selected={selectedJob===job.id} onSelect={(id)=>setSelectedJob(id)} showEvenIfIneligible={showAllJobs} />
                ))
              )}
            </div>
            <p className="text-sm text-gray-500 mt-1">Only open jobs are listed. Ineligible jobs are hidden by default.</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Personal Message (Optional)
            </label>
            <textarea
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              placeholder="Add a personal note to the candidate about why this opportunity is a good fit..."
            />
          </div>

          {(mode==='existing' && selectedCandidate && selectedJob) || (mode==='code' && resolvedCandidate && selectedJob) ? (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-medium text-blue-900 mb-2">Consent Request Preview</h4>
              <div className="text-sm text-blue-800">
                <p className="mb-2">
                  The candidate will receive a request asking for permission to represent them 
                  for the selected job. They will see:
                </p>
                <ul className="list-disc list-inside space-y-1">
                  <li>Your company name and contact information</li>
                  <li>The job title and company</li>
                  <li>Your personal message (if provided)</li>
                  <li>Details about the representation process</li>
                </ul>
              </div>
            </div>
          ) : null}

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h4 className="font-medium text-yellow-900 mb-2">Important Notes</h4>
            <ul className="text-sm text-yellow-800 space-y-1">
              <li>• Candidates can only approve one recruiter per job</li>
              <li>• Identity remains anonymous until employer accepts your bid</li>
              <li>• Consent can be revoked before bid acceptance</li>
              <li>• You must have candidate's permission before requesting consent</li>
            </ul>
          </div>

          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-gray-800 font-medium">
                <Shield className="w-4 h-4 text-blue-600" /> Consent Policies to include
              </div>
              <button type="button" onClick={() => setShowPoliciesManager(true)} className="text-sm text-blue-600 hover:underline">Manage Policies</button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <label className="block text-sm text-gray-700 mb-1">Terms & Conditions</label>
            <select value={selectedTermsId} onChange={e=>setSelectedTermsId(e.target.value)} className="w-full px-3 py-2 border rounded">
                  <option value="default">Use default {getDefault('terms') ? `(${getDefault('terms')!.title})` : ''}</option>
                  {termsList.map(t => (
                    <option key={t.id} value={t.id}>{t.title}</option>
                  ))}
                  {!termsList.length && <option disabled value="">No templates yet</option>}
                </select>
              </div>
              <div>
                <label className="block text-sm text-gray-700 mb-1">Data & Privacy</label>
            <select value={selectedPrivacyId} onChange={e=>setSelectedPrivacyId(e.target.value)} className="w-full px-3 py-2 border rounded">
                  <option value="default">Use default {getDefault('privacy') ? `(${getDefault('privacy')!.title})` : ''}</option>
                  {privacyList.map(p => (
                    <option key={p.id} value={p.id}>{p.title}</option>
                  ))}
                  {!privacyList.length && <option disabled value="">No templates yet</option>}
                </select>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-2">Selected policies will be embedded with the consent for the candidate to review and accept.</p>
          </div>
        </form>
          )}

        {!showSuccess && (
        <div className="px-6 py-4 border-t bg-gray-50 flex justify-end space-x-4 flex-shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            form="consent-form"
            disabled={isSubmitting}
            className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50"
          >
            {isSubmitting ? 'Sending...' : (mode==='invite' ? 'Send Invite' : 'Send Consent Request')}
          </button>
        </div>
        )}
        {showPoliciesManager && (
          <ConsentPoliciesManager onClose={() => setShowPoliciesManager(false)} />
        )}
        </div>
      </div>
    </div>
  );
};

export default ConsentRequestForm;
// Inline child component to evaluate job eligibility and render a row
const JobPickRow = (props) => {
  const { job, selected, onSelect, showEvenIfIneligible } = props || {};
  const { canBid, reason, loading, slotsLeft } = useBidEligibility(job);
  if (!showEvenIfIneligible && !loading && !canBid) return null;
  const disabled = loading ? true : !canBid;
  return (
    <button
      type="button"
      onClick={() => !disabled && onSelect(job.id)}
      className={`w-full text-left px-3 py-2 hover:bg-gray-50 ${selected? 'bg-blue-50' : ''} ${disabled? 'opacity-60 cursor-not-allowed' : ''}`}
      title={!loading && !canBid ? reason : ''}
    >
      <div className="flex items-center justify-between">
        <div>
          <div className="font-medium text-gray-900">{job.title}</div>
          <div className="text-xs text-gray-600">{job.organizationName} • {job.location}</div>
        </div>
        <div className="text-xs">
          {loading ? (
            <span className="text-gray-500">Checking…</span>
          ) : canBid ? (
            <span className="px-2 py-0.5 rounded bg-green-100 text-green-800">Eligible{Number.isFinite(slotsLeft) ? ` • ${slotsLeft} slots` : ''}</span>
          ) : (
            <span className="px-2 py-0.5 rounded bg-yellow-100 text-yellow-800">{reason}</span>
          )}
        </div>
      </div>
    </button>
  );
};
