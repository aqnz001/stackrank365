import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  Home,
  Briefcase,
  Users,
  MessageSquare,
  User,
  Menu,
  X,
  Bell,
  Search
} from 'lucide-react';

interface MobileNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const MobileNavigation: React.FC<MobileNavigationProps> = ({ activeTab, onTabChange }) => {
  const { user } = useAuth();
  const [showMenu, setShowMenu] = useState(false);

  const getNavigationItems = () => {
    // Remove explicit Home from mobile nav; brand/title navigates home.
    const baseItems = [
      { id: 'jobs', label: 'Jobs', icon: <Briefcase className="w-5 h-5" /> },
    ];

    switch (user?.role) {
      case 'employer':
        return [
          ...baseItems,
          { id: 'applications', label: 'Applications', icon: <Users className="w-5 h-5" /> },
          { id: 'bids', label: 'Bids', icon: <MessageSquare className="w-5 h-5" /> },
        ];
      case 'recruiter':
        return [
          ...baseItems,
          { id: 'consents', label: 'Consents', icon: <Users className="w-5 h-5" /> },
        ];
      case 'candidate':
        return [
          ...baseItems,
          { id: 'consents', label: 'Consents', icon: <MessageSquare className="w-5 h-5" /> },
        ];
      default:
        return baseItems;
    }
  };

  const navigationItems = getNavigationItems();

  return (
    <>
      {/* Mobile Header */}
      <div className="lg:hidden bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="p-2 text-gray-600 hover:text-gray-900"
            >
              {showMenu ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
            <div className="flex items-center">
              <Briefcase className="w-6 h-6 text-blue-600" />
              <span className="ml-2 text-lg font-bold text-gray-900">JobBoard</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <button className="p-2 text-gray-600 hover:text-gray-900">
              <Search className="w-5 h-5" />
            </button>
            <button className="p-2 text-gray-600 hover:text-gray-900 relative">
              <Bell className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                3
              </span>
            </button>
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
              <span className="text-white text-sm font-medium">
                {user?.name?.charAt(0)?.toUpperCase()}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {showMenu && (
        <div className="lg:hidden fixed inset-0 z-50 bg-gray-600 bg-opacity-50">
          <div className="fixed inset-y-0 left-0 w-64 bg-white shadow-xl">
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Briefcase className="w-6 h-6 text-blue-600" />
                  <span className="ml-2 text-lg font-bold text-gray-900">JobBoard Pro</span>
                </div>
                <button
                  onClick={() => setShowMenu(false)}
                  className="p-2 text-gray-600 hover:text-gray-900"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <nav className="p-4">
              <div className="space-y-2">
                {navigationItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      onTabChange(item.id);
                      setShowMenu(false);
                    }}
                    className={`w-full flex items-center space-x-3 px-3 py-3 rounded-lg text-left transition-colors ${
                      activeTab === item.id
                        ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-600'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    {item.icon}
                    <span className="font-medium">{item.label}</span>
                  </button>
                ))}
              </div>

              <div className="mt-8 pt-4 border-t border-gray-200">
                <div className="flex items-center space-x-3 px-3 py-2">
                  <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-medium">
                      {user?.name?.charAt(0)?.toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-900">{user?.name}</div>
                    <div className="text-xs text-gray-500 capitalize">{user?.role}</div>
                  </div>
                </div>
              </div>
            </nav>
          </div>
        </div>
      )}

      {/* Bottom Navigation */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2">
        <div className="flex justify-around">
          {navigationItems.slice(0, 4).map((item) => (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex flex-col items-center py-2 px-3 rounded-lg transition-colors ${
                activeTab === item.id
                  ? 'text-blue-600'
                  : 'text-gray-600'
              }`}
            >
              {item.icon}
              <span className="text-xs mt-1 font-medium">{item.label}</span>
            </button>
          ))}
          <button
            onClick={() => setShowMenu(true)}
            className="flex flex-col items-center py-2 px-3 rounded-lg text-gray-600"
          >
            <Menu className="w-5 h-5" />
            <span className="text-xs mt-1 font-medium">More</span>
          </button>
        </div>
      </div>
    </>
  );
};

export default MobileNavigation;
