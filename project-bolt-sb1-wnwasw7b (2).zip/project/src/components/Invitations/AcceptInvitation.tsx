import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { CheckCircle, XCircle, Mail, Building2, UserPlus, Loader2, User, Lock, Eye, EyeOff } from 'lucide-react';

interface InvitationData {
  id: string;
  org_id: string;
  invitee_email: string;
  role: string;
  status: string;
  organization?: {
    name: string;
    type: string;
  };
}

const AcceptInvitation: React.FC<{ invitationId: string }> = ({ invitationId }) => {
  const { user, signOut, refreshUser } = useAuth();
  const [invitation, setInvitation] = useState<InvitationData | null>(null);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [showRegistration, setShowRegistration] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [registrationForm, setRegistrationForm] = useState({
    name: '',
    password: '',
    confirmPassword: '',
  });

  useEffect(() => {
    loadInvitation();
  }, [invitationId]);

  const loadInvitation = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data: invitationData, error: invError } = await supabase
        .from('team_invitations')
        .select('*')
        .eq('id', invitationId)
        .maybeSingle();

      if (invError) throw invError;

      if (!invitationData) {
        throw new Error('Invitation not found');
      }

      if (invitationData.status !== 'pending') {
        throw new Error(`This invitation has already been ${invitationData.status}`);
      }

      const { data: orgData } = await supabase
        .from('organizations')
        .select('name, type')
        .eq('id', invitationData.org_id)
        .maybeSingle();

      setInvitation({
        ...invitationData,
        organization: orgData || undefined,
      });
    } catch (err: any) {
      setError(err.message || 'Failed to load invitation');
    } finally {
      setLoading(false);
    }
  };

  const acceptInvitation = async () => {
    if (!invitation || !user) return;

    if (user.email?.toLowerCase() !== invitation.invitee_email.toLowerCase()) {
      setError(`This invitation is for ${invitation.invitee_email}. Please sign in with that email address.`);
      return;
    }

    setProcessing(true);
    setError(null);

    try {
      const { error: updateError } = await supabase
        .from('profiles')
        .update({
          organization_id: invitation.org_id,
          role: invitation.role,
        })
        .eq('id', user.id);

      if (updateError) throw updateError;

      const { error: inviteError } = await supabase
        .from('team_invitations')
        .update({ status: 'accepted', updated_at: new Date().toISOString() })
        .eq('id', invitationId);

      if (inviteError) throw inviteError;

      await refreshUser();

      setSuccess(true);

      setTimeout(() => {
        window.location.hash = '#dashboard';
      }, 500);
    } catch (err: any) {
      setError(err.message || 'Failed to accept invitation');
    } finally {
      setProcessing(false);
    }
  };

  const declineInvitation = async () => {
    if (!invitation) return;

    if (!confirm('Are you sure you want to decline this invitation?')) return;

    setProcessing(true);
    setError(null);

    try {
      const { error: inviteError } = await supabase
        .from('team_invitations')
        .update({ status: 'declined', updated_at: new Date().toISOString() })
        .eq('id', invitationId);

      if (inviteError) throw inviteError;

      setSuccess(true);
      setTimeout(() => {
        window.location.hash = '';
      }, 1500);
    } catch (err: any) {
      setError(err.message || 'Failed to decline invitation');
    } finally {
      setProcessing(false);
    }
  };

  const switchAccount = async () => {
    await signOut();
    window.location.hash = '';
  };

  const handleRegistration = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!invitation) return;

    if (registrationForm.password !== registrationForm.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (registrationForm.password.length < 8) {
      setError('Password must be at least 8 characters');
      return;
    }

    if (!registrationForm.name.trim()) {
      setError('Please enter your full name');
      return;
    }

    setProcessing(true);
    setError(null);

    try {
      const { data: authData, error: signUpError } = await supabase.auth.signUp({
        email: invitation.invitee_email,
        password: registrationForm.password,
        options: {
          data: {
            name: registrationForm.name.trim(),
            role: invitation.role,
          },
        },
      });

      if (signUpError) throw signUpError;
      if (!authData.user) throw new Error('Registration failed');

      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          name: registrationForm.name.trim(),
          role: invitation.role,
          organization_id: invitation.org_id,
          status: 'active',
        })
        .eq('id', authData.user.id);

      if (profileError) throw profileError;

      const { error: inviteError } = await supabase
        .from('team_invitations')
        .update({ status: 'accepted', updated_at: new Date().toISOString() })
        .eq('id', invitationId);

      if (inviteError) throw inviteError;

      setSuccess(true);

      setTimeout(() => {
        window.location.hash = '#dashboard';
      }, 1000);
    } catch (err: any) {
      setError(err.message || 'Registration failed');
    } finally {
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full text-center">
          <Loader2 className="w-12 h-12 text-blue-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading invitation...</p>
        </div>
      </div>
    );
  }

  if (error && !invitation) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full">
          <XCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-4">
            Invalid Invitation
          </h2>
          <p className="text-gray-600 text-center mb-6">{error}</p>
          <button
            onClick={() => (window.location.hash = '')}
            className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Go to Home
          </button>
        </div>
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-4">
            Success!
          </h2>
          <p className="text-gray-600 text-center">
            Redirecting you to your dashboard...
          </p>
        </div>
      </div>
    );
  }

  if (!user) {
    if (showRegistration) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full">
            <UserPlus className="w-16 h-16 text-blue-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 text-center mb-2">
              Complete Your Registration
            </h2>
            <p className="text-gray-600 text-center mb-6">
              Join <strong>{invitation?.organization?.name}</strong> as {invitation?.role}
            </p>

            <form onSubmit={handleRegistration} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="email"
                    value={invitation?.invitee_email || ''}
                    disabled
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={registrationForm.name}
                    onChange={(e) => setRegistrationForm({ ...registrationForm, name: e.target.value })}
                    placeholder="Enter your full name"
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Password <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={registrationForm.password}
                    onChange={(e) => setRegistrationForm({ ...registrationForm, password: e.target.value })}
                    placeholder="At least 8 characters"
                    className="w-full pl-10 pr-12 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Confirm Password <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={registrationForm.confirmPassword}
                    onChange={(e) => setRegistrationForm({ ...registrationForm, confirmPassword: e.target.value })}
                    placeholder="Re-enter your password"
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                  <p className="text-sm text-red-800">{error}</p>
                </div>
              )}

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRegistration(false)}
                  disabled={processing}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 disabled:opacity-50"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={processing}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center"
                >
                  {processing ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      Creating Account...
                    </>
                  ) : (
                    'Create Account & Join'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full">
          <Mail className="w-16 h-16 text-blue-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-4">
            Team Invitation
          </h2>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <p className="text-sm text-gray-700 mb-2">
              <strong>Organization:</strong> {invitation?.organization?.name || 'Unknown'}
            </p>
            <p className="text-sm text-gray-700 mb-2">
              <strong>Role:</strong> {invitation?.role}
            </p>
            <p className="text-sm text-gray-700">
              <strong>Email:</strong> {invitation?.invitee_email}
            </p>
          </div>
          <p className="text-gray-600 text-center mb-6">
            Create an account or sign in with <strong>{invitation?.invitee_email}</strong> to accept this invitation.
          </p>
          <button
            onClick={() => setShowRegistration(true)}
            className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 mb-3"
          >
            Create Account
          </button>
          <button
            onClick={() => {
              sessionStorage.setItem('pendingInvitationUrl', window.location.href);
              const origin = window.location.origin;
              window.location.href = origin;
            }}
            className="w-full px-4 py-2 border border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50 mb-3"
          >
            Sign In (Existing User)
          </button>
          <button
            onClick={declineInvitation}
            disabled={processing}
            className="w-full px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 disabled:opacity-50"
          >
            Decline Invitation
          </button>
        </div>
      </div>
    );
  }

  const emailMatch = user.email?.toLowerCase() === invitation?.invitee_email.toLowerCase();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full">
        <UserPlus className="w-16 h-16 text-blue-600 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-6">
          You're Invited!
        </h2>

        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-6 mb-6">
          <div className="flex items-start mb-4">
            <Building2 className="w-5 h-5 text-blue-600 mt-0.5 mr-3 flex-shrink-0" />
            <div>
              <p className="text-sm text-gray-500">Organization</p>
              <p className="font-semibold text-gray-900">
                {invitation?.organization?.name || 'Unknown Organization'}
              </p>
            </div>
          </div>

          <div className="flex items-start mb-4">
            <UserPlus className="w-5 h-5 text-blue-600 mt-0.5 mr-3 flex-shrink-0" />
            <div>
              <p className="text-sm text-gray-500">Role</p>
              <p className="font-semibold text-gray-900 capitalize">{invitation?.role}</p>
            </div>
          </div>

          <div className="flex items-start">
            <Mail className="w-5 h-5 text-blue-600 mt-0.5 mr-3 flex-shrink-0" />
            <div>
              <p className="text-sm text-gray-500">Invited Email</p>
              <p className="font-semibold text-gray-900">{invitation?.invitee_email}</p>
            </div>
          </div>
        </div>

        {!emailMatch && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
            <p className="text-sm text-yellow-800 mb-2">
              <strong>Email Mismatch:</strong>
            </p>
            <p className="text-sm text-yellow-700 mb-3">
              You're signed in as <strong>{user.email}</strong>, but this invitation is for{' '}
              <strong>{invitation?.invitee_email}</strong>.
            </p>
            <button
              onClick={switchAccount}
              className="text-sm text-blue-600 hover:text-blue-700 font-medium"
            >
              Sign in with a different account
            </button>
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <p className="text-sm text-red-800">{error}</p>
          </div>
        )}

        <div className="flex gap-3">
          <button
            onClick={declineInvitation}
            disabled={processing}
            className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 disabled:opacity-50"
          >
            Decline
          </button>
          <button
            onClick={acceptInvitation}
            disabled={processing || !emailMatch}
            className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center"
          >
            {processing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
                Processing...
              </>
            ) : (
              'Accept Invitation'
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AcceptInvitation;
