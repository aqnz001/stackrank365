import React, { useState } from 'react';
import { X, Star } from 'lucide-react';
import { useApplications } from '../../hooks/useApplications';
import type { Application } from '../../types';
import toast from 'react-hot-toast';

interface ShortlistModalProps {
  application: Application;
  onClose: () => void;
  onSuccess: () => void;
}

const ShortlistModal: React.FC<ShortlistModalProps> = ({
  application,
  onClose,
  onSuccess,
}) => {
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const { updateApplicationStatus } = useApplications();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!notes.trim()) {
      toast.error('Please add notes explaining why you are shortlisting this candidate');
      return;
    }

    setSubmitting(true);

    try {
      await updateApplicationStatus(application.id, 'shortlisted', {
        shortlistNotes: notes.trim(),
        notifyCandidate: true,
      });

      toast.success('Candidate shortlisted successfully');
      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error shortlisting candidate:', error);
      toast.error('Failed to shortlist candidate. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-600" />
            <h2 className="text-xl font-bold text-gray-900">Shortlist Candidate</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex items-start">
              <Star className="w-5 h-5 text-yellow-600 mr-3 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-yellow-900 mb-1">
                  Shortlisting {application.candidateName}
                </h3>
                <p className="text-sm text-yellow-700">
                  Add notes explaining why this candidate stands out. These notes will help you make the final hiring decision later.
                </p>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Shortlist Notes <span className="text-red-500">*</span>
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={5}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent resize-none"
              placeholder="Why are you shortlisting this candidate? E.g., Strong technical skills in React and Node.js, great culture fit based on interview, 5+ years relevant experience..."
            />
            <p className="text-xs text-gray-500 mt-1">
              Be specific about what makes this candidate a good fit for the role
            </p>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="text-sm font-medium text-blue-900 mb-2">What happens next?</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• The candidate will be moved to your shortlist</li>
              <li>• They will receive a notification about being shortlisted</li>
              <li>• You can review all shortlisted candidates in the job's candidate dashboard</li>
              <li>• From there, you can extend an offer, schedule more interviews, or reject</li>
            </ul>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || !notes.trim()}
              className="px-6 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
            >
              {submitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Shortlisting...
                </>
              ) : (
                <>
                  <Star className="w-4 h-4 mr-2" />
                  Shortlist Candidate
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ShortlistModal;
