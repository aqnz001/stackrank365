import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useFileUpload, UploadedFile } from '../../hooks/useFileUpload';
import { useCandidateProfile } from '../../hooks/useCandidateProfile';
import { useParsedResume } from '../../hooks/useParsedResume';
import { useDraftApplications, DraftApplicationData } from '../../hooks/useDraftApplications';
import FileUploadZone from '../FileUpload/FileUploadZone';
import { Job } from '../../types';
import { X, Upload, FileText, User, Mail, Phone, MapPin, RefreshCw, AlertCircle, CheckCircle2, Clock, Save } from 'lucide-react';
import { composeCoverLetter } from '../../utils/coverLetter';
import { supabase } from '../../lib/supabase';
import { ApplicationAssistant, ApplicationAssistantButton } from './ApplicationAssistant';
import toast from 'react-hot-toast';

interface JobApplicationFormProps {
  job: Job;
  onClose: () => void;
  onSubmit: (applicationData: any) => void;
}

const JobApplicationForm: React.FC<JobApplicationFormProps> = ({ job, onClose, onSubmit }) => {
  const { user } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [uploadedResume, setUploadedResume] = useState<UploadedFile | null>(null);
  const { profile, save } = useCandidateProfile();
  const savedResumes = profile?.resumes || [];
  const { getSignedUrl } = useFileUpload();
  const [useSaved, setUseSaved] = useState<boolean>(savedResumes.length > 0);
  const [selectedResumeId, setSelectedResumeId] = useState<string | ''>(profile?.primaryResumeId || (savedResumes[0]?.id || ''));
  const { parsedData: selectedParsedData, loading: loadingParsedData } = useParsedResume(
    useSaved && selectedResumeId ? selectedResumeId : (uploadedResume?.id || undefined)
  );

  // Debug logging
  React.useEffect(() => {
    console.log('JobApplicationForm - Resume Selection State:', {
      useSaved,
      selectedResumeId,
      uploadedResumeId: uploadedResume?.id,
      fileIdBeingQueried: useSaved && selectedResumeId ? selectedResumeId : (uploadedResume?.id || undefined),
      parsedData: selectedParsedData,
      loadingParsedData,
      parsingStatus: selectedParsedData?.parsingStatus
    });
  }, [useSaved, selectedResumeId, uploadedResume?.id, selectedParsedData, loadingParsedData]);
  const [formData, setFormData] = useState({
    coverLetter: '',
    phone: '',
    location: '',
    salaryExpectation: '',
    availabilityDate: '',
    workAuthorization: 'yes',
    willingToRelocate: 'no',
    additionalInfo: '',
  });
  const [generating, setGenerating] = useState(false);
  const [step, setStep] = useState(1);
  const [error, setError] = useState<string | null>(null);
  const [showAssistant, setShowAssistant] = useState(false);
  const [resumeTextForAssistant, setResumeTextForAssistant] = useState<string>('');
  const [isPollingParsing, setIsPollingParsing] = useState(false);
  const [parsingMessage, setParsingMessage] = useState<string>('');
  const [savingDraft, setSavingDraft] = useState(false);
  const [loadingDraft, setLoadingDraft] = useState(true);
  const { getDraftForJob, saveDraft, deleteDraftForJob } = useDraftApplications(user?.id);

  // Load draft on mount
  React.useEffect(() => {
    const loadDraft = async () => {
      if (!user?.id) return;

      try {
        const draft = await getDraftForJob(job.id, user.id);
        if (draft) {
          const draftData = draft.draftData;
          setStep(draftData.step);
          setUseSaved(draftData.useSaved);
          setSelectedResumeId(draftData.selectedResumeId);
          if (draftData.uploadedResumeData) {
            setUploadedResume(draftData.uploadedResumeData as UploadedFile);
          }
          setFormData(draftData.formData);
          toast.success('Draft application loaded');
        }
      } catch (err) {
        console.error('Error loading draft:', err);
      } finally {
        setLoadingDraft(false);
      }
    };

    loadDraft();
  }, [job.id, user?.id]);

  // Prefill from candidate profile on mount (only if no draft loaded)
  React.useEffect(() => {
    if (!profile || !loadingDraft) return;
    setFormData(prev => ({
      ...prev,
      location: prev.location || profile.currentStatus?.location || '',
      salaryExpectation: prev.salaryExpectation || (profile.rolePreferences?.minimumSalary || ''),
      workAuthorization: prev.workAuthorization || ((profile.rolePreferences?.rightToWorkNZ || '').toLowerCase().startsWith('y') ? 'yes' : 'no'),
      additionalInfo: prev.additionalInfo || (profile.currentStatus?.jobSeekingStatus || ''),
    }));
    const locs = profile.rolePreferences?.workLocations || [];
    if (locs.length > 1) {
      setFormData(prev => ({ ...prev, willingToRelocate: prev.willingToRelocate || 'yes' }));
    }
    // Auto-select resume when only one exists
    if ((profile.resumes || []).length === 1) {
      setUseSaved(true);
      setSelectedResumeId(profile.resumes![0].id);
    }
  }, [profile?.currentStatus?.location, profile?.rolePreferences?.minimumSalary, profile?.rolePreferences?.rightToWorkNZ, profile?.resumes?.length]);

  // Use parsed data from database for AI assistant
  React.useEffect(() => {
    if (selectedParsedData?.parsedText) {
      setResumeTextForAssistant(selectedParsedData.parsedText);
    } else if (selectedParsedData && selectedParsedData.parsingStatus === 'completed') {
      const parsed = selectedParsedData;
      let textContent = `SKILLS:\n${(parsed.parsedSkills || []).join(', ')}\n\n`;
      textContent += `EXPERIENCE:\n`;
      (parsed.parsedExperiences || []).forEach((exp: any) => {
        textContent += `${exp.jobTitle || 'Position'} at ${exp.company || 'Company'}\n`;
        if (exp.description) textContent += `${exp.description}\n`;
        textContent += `\n`;
      });
      setResumeTextForAssistant(textContent);
    } else if (selectedParsedData?.parsingStatus === 'pending') {
      setResumeTextForAssistant('Your resume is being processed. This will be available shortly.');
    } else if (selectedParsedData?.parsingStatus === 'failed') {
      setResumeTextForAssistant('Resume parsing failed. You can still submit your application.');
    } else {
      setResumeTextForAssistant('');
    }

    // Update parsing message based on status
    if (selectedParsedData?.parsingStatus === 'completed') {
      setParsingMessage('Resume processed successfully!');
      setIsPollingParsing(false);
    } else if (selectedParsedData?.parsingStatus === 'failed') {
      setParsingMessage('Resume parsing failed');
      setIsPollingParsing(false);
    } else if (selectedParsedData?.parsingStatus === 'pending') {
      setParsingMessage('Processing resume...');
      if (!isPollingParsing && uploadedResume?.id) {
        startParsingPolling(uploadedResume.id);
      }
    } else {
      setParsingMessage('');
    }
  }, [selectedParsedData]);

  // Reset parsing message when resume selection changes
  React.useEffect(() => {
    setParsingMessage('');
  }, [selectedResumeId, uploadedResume?.id, useSaved]);

  // Polling function for resume parsing status
  const startParsingPolling = (fileId: string) => {
    let pollCount = 0;
    const maxPolls = 30; // Poll for max 30 seconds

    const pollInterval = setInterval(async () => {
      pollCount++;

      if (pollCount >= maxPolls) {
        clearInterval(pollInterval);
        setIsPollingParsing(false);
        setParsingMessage('Parsing is taking longer than expected');
        return;
      }

      try {
        const { data, error } = await supabase
          .from('resume_parsed_data')
          .select('*')
          .eq('file_upload_id', fileId)
          .maybeSingle();

        if (error) {
          console.error('Error polling for parsed data:', error);
          return;
        }

        if (data && (data.parsing_status === 'completed' || data.parsing_status === 'failed')) {
          clearInterval(pollInterval);
          setIsPollingParsing(false);

          if (data.parsing_status === 'completed') {
            setParsingMessage('Resume processed successfully!');
          } else {
            setParsingMessage('Resume parsing failed');
          }

          // Trigger a refetch of the parsed data
          window.location.hash = `refresh-${Date.now()}`;
        }
      } catch (err) {
        console.error('Polling error:', err);
      }
    }, 1000); // Poll every second

    // Store interval ID for cleanup
    return () => clearInterval(pollInterval);
  };

  const handleResumeUpload = (file: UploadedFile) => {
    console.log('Resume uploaded:', file.name, file.id);
    setUploadedResume(file);
    setParsingMessage('Processing resume...');
    setIsPollingParsing(true);

    // Add this resume to profile as well
    try {
      const meta: any = { id: file.id, name: file.name, url: file.url, path: file.path, size: file.size, uploadedAt: new Date().toISOString() };
      const base = profile || {
        workExperience: [],
        currentStatus: { location: '', roleClassifications: [], jobSeekingStatus: '', availability: '' },
        qualifications: { highestQualification: '', skills: [] },
        rolePreferences: { workTypes: [], workLocations: [], rightToWorkNZ: '', salaryType: 'Annual', minimumSalary: '' },
        resumes: [],
        primaryResumeId: undefined,
      };
      const updated = { ...base, resumes: [...(base.resumes || []), meta], primaryResumeId: base.primaryResumeId || meta.id };
      save(updated);
      setUseSaved(true);
      setSelectedResumeId(meta.id);
    } catch {}

    // Start polling for parsing completion
    startParsingPolling(file.id);
  };

  const handleResumeUploadError = (error: string) => {
    console.error('Resume upload error:', error);
    alert(`Resume upload failed: ${error}`);
  };

  // Generate cover letter using parsed data from database
  const generateCoverLetter = async () => {
    try {
      setGenerating(true);

      if (!selectedParsedData) {
        alert('Please select a saved resume or upload one first.');
        return;
      }

      if (selectedParsedData.parsingStatus === 'pending') {
        alert('Your resume is still being processed. Please wait a moment and try again.');
        return;
      }

      if (selectedParsedData.parsingStatus === 'failed') {
        alert('Resume parsing failed. Please try uploading your resume again.');
        return;
      }

      const parsed = {
        skills: selectedParsedData.parsedSkills || [],
        experiences: selectedParsedData.parsedExperiences || [],
      };

      const resumeText = selectedParsedData.parsedText || '';
      const draft = composeCoverLetter(job, parsed, resumeText);
      setFormData(prev => ({ ...prev, coverLetter: draft }));
    } finally {
      setGenerating(false);
    }
  };

  // Manual refresh for parsing status
  const refreshParsingStatus = async () => {
    if (useSaved && selectedResumeId) {
      setIsPollingParsing(true);
      setParsingMessage('Checking status...');

      try {
        const { data, error } = await supabase
          .from('resume_parsed_data')
          .select('*')
          .eq('file_upload_id', selectedResumeId)
          .maybeSingle();

        if (error) {
          console.error('Error refreshing parsed data:', error);
          setParsingMessage('Error checking status');
          setIsPollingParsing(false);
          return;
        }

        if (data) {
          if (data.parsing_status === 'completed') {
            setParsingMessage('Resume processed successfully!');
          } else if (data.parsing_status === 'failed') {
            setParsingMessage('Resume parsing failed');
          } else if (data.parsing_status === 'pending') {
            setParsingMessage('Still processing...');
            startParsingPolling(selectedResumeId);
          }
        } else {
          setParsingMessage('No parsing data found');
        }
      } catch (err) {
        console.error('Refresh error:', err);
        setParsingMessage('Error checking status');
      } finally {
        setIsPollingParsing(false);
      }
    } else if (uploadedResume) {
      startParsingPolling(uploadedResume.id);
    }
  };

  // Check if AI generation is available - only for saved, already-parsed resumes
  const isAiGenerationAvailable = () => {
    // AI features only work with saved resumes that have been parsed
    if (!useSaved) return false;
    if (!selectedResumeId) return false;
    if (!selectedParsedData) return false;
    if (selectedParsedData.parsingStatus !== 'completed') return false;
    return true;
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSubmitting(true);

    try {
      const selectedResume = useSaved ? savedResumes.find(r => r.id === selectedResumeId) : null;

      console.log('=== Application Submission Debug ===');
      console.log('useSaved:', useSaved);
      console.log('selectedResumeId:', selectedResumeId);
      console.log('selectedResume:', selectedResume);
      console.log('uploadedResume:', uploadedResume);
      console.log('Resume path to be saved:', selectedResume ? (selectedResume.path || selectedResume.url || '') : (uploadedResume?.path || ''));

      const applicationData = {
        jobId: job.id,
        candidateId: user?.id,
        candidateName: user?.name,
        candidateEmail: user?.email,
        source: 'direct',
        status: 'submitted',
        coverLetter: formData.coverLetter,
        phone: formData.phone,
        location: formData.location,
        salaryExpectation: formData.salaryExpectation ? parseInt(formData.salaryExpectation) : null,
        availabilityDate: formData.availabilityDate || null,
        workAuthorization: formData.workAuthorization,
        willingToRelocate: formData.willingToRelocate === 'yes',
        additionalInfo: formData.additionalInfo,
        resumeUrl: selectedResume ? (selectedResume.path || selectedResume.url || '') : (uploadedResume?.path || ''),
        resumeFileName: selectedResume ? selectedResume.name : (uploadedResume?.name || ''),
        createdAt: new Date(),
      };

      console.log('Final application data:', applicationData);

      await onSubmit(applicationData);

      // Delete draft after successful submission
      if (user?.id) {
        await deleteDraftForJob(job.id, user.id);
      }

      setShowSuccess(true);
      setTimeout(() => onClose(), 3000);
    } catch (error) {
      console.error('Error submitting application:', error);
      alert('Failed to submit application. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveDraft = async () => {
    if (!user?.id) return;

    setSavingDraft(true);
    try {
      const draftData: DraftApplicationData = {
        step,
        useSaved,
        selectedResumeId,
        uploadedResumeData: uploadedResume ? {
          id: uploadedResume.id,
          name: uploadedResume.name,
          url: uploadedResume.url,
          path: uploadedResume.path,
        } : null,
        formData,
      };

      const result = await saveDraft(job.id, user.id, draftData, step);
      if (result) {
        toast.success('Draft saved successfully');
      } else {
        toast.error('Failed to save draft');
      }
    } catch (err) {
      console.error('Error saving draft:', err);
      toast.error('Failed to save draft');
    } finally {
      setSavingDraft(false);
    }
  };

  const validateStep = (s: number): string | null => {
    switch (s) {
      case 1:
        if (!formData.phone?.trim()) return 'Phone number is required';
        if (!formData.location?.trim()) return 'Current location is required';
        return null;
      case 2:
        if (useSaved) {
          if (!selectedResumeId) return 'Please select a saved resume';
        } else if (!uploadedResume) {
          return 'Please upload your resume';
        }
        return null;
      case 3:
        // Cover letter is optional
        return null;
      default:
        return null;
    }
  };

  const onNext = () => {
    const err = validateStep(step);
    if (err) { setError(err); return; }
    setError(null);
    setStep(s => Math.min(3, s + 1));
  };

  const onBack = () => {
    setError(null);
    setStep(s => Math.max(1, s - 1));
  };

  return (
    <>
      <ApplicationAssistant
        resumeText={resumeTextForAssistant}
        coverLetter={formData.coverLetter}
        jobDetails={{
          title: job.title,
          company: job.organizationName || '',
          description: job.description || '',
        }}
        isOpen={showAssistant}
        onClose={() => setShowAssistant(false)}
      />

    <div className="fixed inset-0 z-50">
      <div className={`absolute inset-0 bg-black/40 transition-opacity duration-300 ${showAssistant ? 'opacity-50' : ''}`} onClick={onClose} />
      <div className={`absolute inset-0 flex items-center justify-center p-4 transition-all duration-300 ${showAssistant ? 'pr-[400px]' : ''}`}>
        <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <div>
              <h3 className="text-xl font-semibold">Apply for {job.title}</h3>
              <p className="text-blue-100 text-sm">
                {job.organizationName}
                {job.employmentType ? <> • {job.employmentType.replace('-', ' ')}</> : null}
                {job.salaryRange ? <> • ${job.salaryRange.min.toLocaleString()} - ${job.salaryRange.max.toLocaleString()}</> : null}
                {job.location ? <> • {job.location}</> : null}
              </p>
            </div>
            <button onClick={onClose} className="p-2 text-white/80 hover:text-white" aria-label="Close">
              <X className="w-6 h-6" />
            </button>
          </div>

          {showSuccess && (
            <div className="flex flex-col items-center justify-center py-12 px-6 space-y-4">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
                <svg className="w-12 h-12 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-2xl font-semibold text-gray-900">Application Submitted!</h3>
              <p className="text-center text-gray-600 max-w-md">
                Your application for <span className="font-semibold">{job.title}</span> at {job.organizationName} has been successfully submitted.
              </p>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
                <p className="text-sm text-blue-900">
                  <strong>What happens next:</strong>
                </p>
                <ul className="text-sm text-blue-800 mt-2 space-y-1 list-disc list-inside">
                  <li>The employer will review your application</li>
                  <li>You'll be notified if they want to schedule an interview</li>
                  <li>Track your application status in My Applications</li>
                </ul>
              </div>
              <p className="text-sm text-gray-500 mt-4">This window will close automatically...</p>
            </div>
          )}

          {!showSuccess && (
            <>
          {/* Step indicator */}
          <div className="px-6 py-3 border-b flex items-center gap-2 text-sm text-gray-600">
            <span className={`px-2 py-0.5 rounded ${step===1?'bg-blue-600 text-white':'bg-gray-100'}`}>1. Your Details</span>
            <span className={`px-2 py-0.5 rounded ${step===2?'bg-blue-600 text-white':'bg-gray-100'}`}>2. Resume & Letter</span>
            <span className={`px-2 py-0.5 rounded ${step===3?'bg-blue-600 text-white':'bg-gray-100'}`}>3. Additional</span>
          </div>

        {/* Job info moved into header subtext */}

        <div className="px-6 pb-6 space-y-6">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded p-3 text-sm text-red-800">{error}</div>
          )}

          {step === 1 && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <h5 className="font-medium text-gray-900 mb-4">Personal Information</h5>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <User className="w-4 h-4 inline mr-1" />
                    Full Name
                  </label>
                  <input type="text" value={user?.name || ''} disabled className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Mail className="w-4 h-4 inline mr-1" /> Email
                  </label>
                  <input type="email" value={user?.email || ''} disabled className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Phone className="w-4 h-4 inline mr-1" /> Phone Number
                  </label>
                  <input type="tel" value={formData.phone} onChange={(e)=>setFormData(p=>({...p, phone:e.target.value}))} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder="Enter your phone number" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <MapPin className="w-4 h-4 inline mr-1" /> Current Location
                  </label>
                  <input type="text" value={formData.location} onChange={(e)=>setFormData(p=>({...p, location:e.target.value}))} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder="City, State/Country" />
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2"><FileText className="w-4 h-4 inline mr-1" /> Resume/CV</label>
                <div className="mb-3 p-3 border rounded-md bg-gray-50">
                  <div className="flex items-center gap-4 mb-2">
                    <label className="inline-flex items-center gap-2 text-sm"><input type="radio" name="resumeSource" checked={useSaved} onChange={()=>setUseSaved(true)} /> Use saved resume</label>
                    <label className="inline-flex items-center gap-2 text-sm"><input type="radio" name="resumeSource" checked={!useSaved} onChange={()=>setUseSaved(false)} /> Upload new</label>
                  </div>
                  {useSaved ? (
                    <select className="w-full border rounded px-3 py-2" value={selectedResumeId} onChange={e=>setSelectedResumeId(e.target.value)}>
                      {(savedResumes || []).map(r => (<option key={r.id} value={r.id}>{r.name}</option>))}
                    </select>
                  ) : (
                    <FileUploadZone options={{ bucket: 'resumes', fileType: 'resume', maxSize: 10 * 1024 * 1024 }} onUploadComplete={handleResumeUpload} onUploadError={handleResumeUploadError} />
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Cover Letter</label>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <p className="text-xs text-gray-500">Use AI to draft a cover letter from your selected resume and this job.</p>
                    {parsingMessage && (
                      <div className="flex items-center gap-1 text-xs">
                        {selectedParsedData?.parsingStatus === 'pending' || isPollingParsing ? (
                          <>
                            <Clock className="w-3 h-3 text-blue-600 animate-pulse" />
                            <span className="text-blue-600">{parsingMessage}</span>
                          </>
                        ) : selectedParsedData?.parsingStatus === 'completed' ? (
                          <>
                            <CheckCircle2 className="w-3 h-3 text-green-600" />
                            <span className="text-green-600">{parsingMessage}</span>
                          </>
                        ) : selectedParsedData?.parsingStatus === 'failed' ? (
                          <>
                            <AlertCircle className="w-3 h-3 text-red-600" />
                            <span className="text-red-600">{parsingMessage}</span>
                          </>
                        ) : null}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {(isPollingParsing || !isAiGenerationAvailable()) && (
                      <button
                        type="button"
                        onClick={refreshParsingStatus}
                        disabled={isPollingParsing}
                        className="text-xs p-1.5 rounded border border-gray-300 hover:bg-gray-50 disabled:opacity-50"
                        title="Refresh parsing status"
                      >
                        <RefreshCw className={`w-3 h-3 ${isPollingParsing ? 'animate-spin' : ''}`} />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={generateCoverLetter}
                      disabled={generating || !isAiGenerationAvailable()}
                      className="text-xs px-2 py-1 rounded border border-gray-300 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                      title={!isAiGenerationAvailable() ? 'Waiting for resume to be processed...' : ''}
                    >
                      {generating ? 'Generating…' : 'Generate with AI'}
                    </button>
                  </div>
                </div>
                {!useSaved && (
                  <div className="mb-2 p-2 bg-blue-50 border border-blue-200 rounded text-xs text-blue-800 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                    <span>
                      AI features are only available for saved resumes. To use AI cover letter generation and the AI assistant, please select a saved resume from your profile.
                    </span>
                  </div>
                )}
                {useSaved && !isAiGenerationAvailable() && (
                  <div className="mb-2 p-2 bg-blue-50 border border-blue-200 rounded text-xs text-blue-800 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                    <span>
                      This saved resume hasn't been processed yet. AI features will be available once the resume has been processed in your profile.
                    </span>
                  </div>
                )}
                <textarea rows={6} value={formData.coverLetter} onChange={(e)=>setFormData(p=>({...p, coverLetter:e.target.value}))} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder="Tell us why you're a great fit..." />
              </div>

              {useSaved && isAiGenerationAvailable() && (resumeTextForAssistant || formData.coverLetter) && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-sm text-blue-900 mb-2">
                    Need help reviewing your application materials?
                  </p>
                  <button
                    type="button"
                    onClick={() => setShowAssistant(true)}
                    className="text-sm px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                  >
                    Ask AI Assistant
                  </button>
                </div>
              )}
            </>
          )}

          {step === 3 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Salary Expectation (Optional)</label>
                <input type="number" value={formData.salaryExpectation} onChange={(e)=>setFormData(p=>({...p, salaryExpectation:e.target.value}))} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder="Annual salary expectation" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Availability Date</label>
                <input type="date" value={formData.availabilityDate} onChange={(e)=>setFormData(p=>({...p, availabilityDate:e.target.value}))} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Work Authorization</label>
                <select value={formData.workAuthorization} onChange={(e)=>setFormData(p=>({...p, workAuthorization:e.target.value}))} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                  <option value="yes">Authorized to work</option>
                  <option value="no">Not authorized to work</option>
                  <option value="visa">Requires visa sponsorship</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Willing to Relocate?</label>
                <select value={formData.willingToRelocate} onChange={(e)=>setFormData(p=>({...p, willingToRelocate:e.target.value}))} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                  <option value="no">No</option>
                  <option value="yes">Yes</option>
                  <option value="maybe">Open to discussion</option>
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Additional Information (Optional)</label>
                <textarea rows={3} value={formData.additionalInfo} onChange={(e)=>setFormData(p=>({...p, additionalInfo:e.target.value}))} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500" placeholder="Any additional information you'd like to share..." />
              </div>
            </div>
          )}

          <div className="flex justify-between items-center pt-6 border-t">
            <div className="flex items-center gap-2">
              <button type="button" onClick={onClose} className="px-6 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors">Cancel</button>
              <button
                type="button"
                onClick={handleSaveDraft}
                disabled={savingDraft}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors disabled:opacity-50 flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                {savingDraft ? 'Saving...' : 'Save Draft'}
              </button>
            </div>
            <div className="space-x-2">
              {step > 1 && (<button type="button" onClick={onBack} className="px-6 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors">Back</button>)}
              {step < 3 && (<button type="button" onClick={onNext} className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">Next</button>)}
              {step === 3 && (
                <button type="button" disabled={isSubmitting} onClick={() => { const err = validateStep(3); if (err) { setError(err); return; } setError(null); handleSubmit(); }} className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50">
                  {isSubmitting ? 'Submitting...' : 'Submit Application'}
                </button>
              )}
            </div>
          </div>
        </div>
          </>
          )}
        </div>
      </div>
    </div>
    </>
  );
};

export default JobApplicationForm;
