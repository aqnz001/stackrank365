import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, Send, X, Loader, Bot, User } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface ApplicationAssistantProps {
  applicationId?: string;
  resumeText?: string;
  coverLetter?: string;
  jobDetails?: {
    title: string;
    company: string;
    description: string;
  };
  onClose?: () => void;
  isOpen?: boolean;
}

export const ApplicationAssistant: React.FC<ApplicationAssistantProps> = ({
  applicationId,
  resumeText,
  coverLetter,
  jobDetails,
  onClose,
  isOpen = false,
}) => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const hasResume = resumeText && resumeText.length > 50;
      const hasCoverLetter = coverLetter && coverLetter.length > 20;

      let availableContent = [];
      if (hasResume) availableContent.push('resume');
      if (hasCoverLetter) availableContent.push('cover letter');

      const contentInfo = availableContent.length > 0
        ? ` I have access to your ${availableContent.join(' and ')}.`
        : ' Please make sure you have uploaded your resume or written a cover letter for me to review.';

      setMessages([{
        id: '1',
        role: 'assistant',
        content: `Hi! I'm your AI application assistant.${contentInfo} I can help you review your application materials, answer questions, and provide suggestions for improvement. What would you like to know?`,
        timestamp: new Date(),
      }]);
    }
  }, [isOpen, resumeText, coverLetter]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input.trim(),
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);
    setError(null);

    try {
      const contextType = resumeText && coverLetter ? 'both' : resumeText ? 'resume' : coverLetter ? 'cover_letter' : 'general';

      console.log('Sending to assistant:', {
        hasResume: !!resumeText,
        resumeLength: resumeText?.length || 0,
        hasCoverLetter: !!coverLetter,
        coverLetterLength: coverLetter?.length || 0,
        contextType,
        question: userMessage.content
      });

      const { data: { session } } = await supabase.auth.getSession();
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/application-assistant`;

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.access_token || ''}`,
        },
        body: JSON.stringify({
          question: userMessage.content,
          resumeText,
          coverLetter,
          jobDetails,
          contextType,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to get response');
      }

      const data = await response.json();

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.answer,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, assistantMessage]);

      if (applicationId && user) {
        await supabase.from('application_ai_conversations').insert({
          application_id: applicationId,
          user_id: user.id,
          question: userMessage.content,
          answer: data.answer,
          context_type: contextType,
        });
      }
    } catch (err) {
      console.error('Error asking question:', err);
      setError(err instanceof Error ? err.message : 'Failed to get response. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const suggestedQuestions = [
    'What are the key strengths in my resume?',
    'How well does my cover letter match the job requirements?',
    'What skills should I emphasize more?',
    'Are there any gaps I should address?',
    'How can I improve my application?',
  ];

  const handleSuggestedQuestion = (question: string) => {
    setInput(question);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 z-[60] flex items-center justify-end pointer-events-none">
      <div className="pointer-events-auto w-full max-w-md bg-white shadow-2xl border-l border-gray-300 flex flex-col h-full animate-slide-in-right">
        <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5" />
            <h3 className="font-semibold">Application Assistant</h3>
          </div>
          {onClose && (
            <button
              onClick={onClose}
              className="p-1 hover:bg-white/20 rounded transition-colors"
              aria-label="Close assistant"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {message.role === 'assistant' && (
                <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-5 h-5 text-white" />
                </div>
              )}
              <div
                className={`max-w-[80%] rounded-lg px-4 py-2 ${
                  message.role === 'user'
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-800 border border-gray-200'
                }`}
              >
                <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                <p className={`text-xs mt-1 ${message.role === 'user' ? 'text-blue-100' : 'text-gray-500'}`}>
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
              {message.role === 'user' && (
                <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center flex-shrink-0">
                  <User className="w-5 h-5 text-white" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex gap-3 justify-start">
              <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div className="bg-white text-gray-800 border border-gray-200 rounded-lg px-4 py-2">
                <Loader className="w-5 h-5 animate-spin" />
              </div>
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg px-4 py-2 text-sm text-red-800">
              {error}
            </div>
          )}

          {messages.length === 1 && !loading && (
            <div className="space-y-2">
              <p className="text-xs text-gray-600 font-medium">Suggested questions:</p>
              {suggestedQuestions.map((question, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSuggestedQuestion(question)}
                  className="block w-full text-left text-sm px-3 py-2 bg-white border border-gray-200 rounded-lg hover:bg-blue-50 hover:border-blue-300 transition-colors"
                >
                  {question}
                </button>
              ))}
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        <form onSubmit={handleSubmit} className="p-4 border-t bg-white">
          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask a question about your application..."
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              disabled={loading}
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              aria-label="Send message"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export const ApplicationAssistantButton: React.FC<{
  onClick: () => void;
  className?: string;
}> = ({ onClick, className = '' }) => {
  return (
    <button
      onClick={onClick}
      className={`fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 flex items-center justify-center z-40 ${className}`}
      aria-label="Open application assistant"
    >
      <MessageCircle className="w-6 h-6" />
    </button>
  );
};

export default ApplicationAssistant;
