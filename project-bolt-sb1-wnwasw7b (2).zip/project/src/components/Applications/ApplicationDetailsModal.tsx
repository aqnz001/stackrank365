import React from 'react';
import { X, User, Mail, Phone, MapPin, FileText, Calendar, UserCheck, Building, Star, Award, Clock, CheckCircle } from 'lucide-react';
import type { Application } from '../../types';
import { useFileUpload } from '../../hooks/useFileUpload';

interface ApplicationDetailsModalProps {
  application: Application;
  isOpen: boolean;
  onClose: () => void;
}

const ApplicationDetailsModal: React.FC<ApplicationDetailsModalProps> = ({ application, isOpen, onClose }) => {
  const { getSignedUrl } = useFileUpload();
  const [resumeUrl, setResumeUrl] = React.useState<string>('');
  const [resumeBlobUrl, setResumeBlobUrl] = React.useState<string>('');
  const [loadingResume, setLoadingResume] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const attemptedRef = React.useRef<string>('');
  const fetchingRef = React.useRef<boolean>(false);

  React.useEffect(() => {
    const effectId = Math.random().toString(36).substr(2, 9);
    console.log(`[${effectId}] Effect started`);
    let timeoutId: NodeJS.Timeout;
    let currentBlobUrl: string | null = null;
    let aborted = false;

    const fetchResume = async () => {
      console.log(`[${effectId}] fetchResume called - isOpen:`, isOpen, 'resumeUrl:', application?.resumeUrl, 'attempted:', attemptedRef.current, 'fetching:', fetchingRef.current);

      if (!isOpen) {
        setResumeUrl('');
        setResumeBlobUrl('');
        setError(null);
        setLoadingResume(false);
        attemptedRef.current = '';
        fetchingRef.current = false;
        return;
      }

      if (!application?.resumeUrl) {
        console.log('No resume URL in application');
        setResumeUrl('');
        setResumeBlobUrl('');
        setError(null);
        setLoadingResume(false);
        return;
      }

      if (attemptedRef.current === application.resumeUrl || fetchingRef.current) {
        console.log('Already attempted/fetching this resume, skipping');
        return;
      }

      console.log('Fetching resume from path:', application.resumeUrl);
      fetchingRef.current = true;
      setLoadingResume(true);
      setError(null);
      attemptedRef.current = application.resumeUrl;

      timeoutId = setTimeout(() => {
        if (!aborted && fetchingRef.current) {
          setError('Request timed out. Please try again.');
          setLoadingResume(false);
          fetchingRef.current = false;
        }
      }, 10000);

      try {
        const url = await getSignedUrl(application.resumeUrl, 'resumes', 60 * 60);
        console.log('Resume signed URL generated successfully:', url);
        clearTimeout(timeoutId);

        if (aborted) {
          console.log(`[${effectId}] Operation aborted`);
          fetchingRef.current = false;
          return;
        }

        setResumeUrl(url);

        try {
          console.log('Attempting to fetch PDF from signed URL...');
          const response = await fetch(url);
          console.log('Fetch response:', {
            ok: response.ok,
            status: response.status,
            statusText: response.statusText
          });

          if (!response.ok) {
            console.error('Fetch failed, falling back to direct URL');
            setResumeBlobUrl(url);
          } else {
            const blob = await response.blob();
            console.log('Blob created:', { size: blob.size, type: blob.type });

            const blobUrl = URL.createObjectURL(blob);
            currentBlobUrl = blobUrl;
            setResumeBlobUrl(blobUrl);
            console.log('Blob URL created:', blobUrl);
          }
        } catch (fetchError: any) {
          console.error('Fetch error, using direct URL:', fetchError);
          setResumeBlobUrl(url);
        }
      } catch (e:any) {
        clearTimeout(timeoutId);
        console.error('Error loading resume:', e);
        const errorMsg = e?.message || 'Failed to load resume';
        if (!aborted) setError(`${errorMsg}. Path: ${application.resumeUrl}`);
      } finally {
        if (!aborted) {
          setLoadingResume(false);
          fetchingRef.current = false;
        }
      }
    };
    fetchResume();
    return () => {
      console.log(`[${effectId}] Cleanup running, isOpen=${isOpen}`);
      if (!isOpen) {
        console.log(`[${effectId}] Modal closing, aborting operation`);
        aborted = true;
        fetchingRef.current = false;
        attemptedRef.current = '';
      } else {
        console.log(`[${effectId}] Strict Mode cleanup, NOT aborting`);
      }
      if (timeoutId) clearTimeout(timeoutId);
      if (currentBlobUrl) {
        URL.revokeObjectURL(currentBlobUrl);
      }
    };
  }, [isOpen, application?.resumeUrl]);

  if (!isOpen) return null;

  const createdStr = application.createdAt ? new Date(application.createdAt).toLocaleString() : '';

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="bg-white w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-600" />
              <h3 className="text-base font-semibold text-gray-900">Application Details</h3>
            </div>
            <button onClick={onClose} className="p-2 text-gray-500 hover:text-gray-700" aria-label="Close">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6 max-h-[80vh] overflow-auto">
            {/* Applicant Profile */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center">
                  <User className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <div className="font-semibold text-gray-900">{application.candidateName || application.candidateEmail}</div>
                    {application.status === 'shortlisted' && (
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 border border-yellow-300">
                        <Award className="w-3 h-3 mr-1" />
                        Shortlisted
                      </span>
                    )}
                  </div>
                  {application.source === 'recruiter' && (
                    <div className="flex items-center gap-2 mt-1">
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-purple-100 text-purple-800">
                        <UserCheck className="w-3 h-3 mr-1" />
                        From Recruiter Bid
                      </span>
                    </div>
                  )}
                  <div className="text-xs text-gray-500 flex items-center mt-1"><Calendar className="w-3.5 h-3.5 mr-1" /> Applied {createdStr}</div>
                </div>
              </div>
              <div className="grid grid-cols-1 gap-2 text-sm text-gray-700">
                {application.candidateEmail && (
                  <div className="flex items-center"><Mail className="w-4 h-4 mr-2" /> {application.candidateEmail}</div>
                )}
                {application.phone && (
                  <div className="flex items-center"><Phone className="w-4 h-4 mr-2" /> {application.phone}</div>
                )}
                {application.location && (
                  <div className="flex items-center"><MapPin className="w-4 h-4 mr-2" /> {application.location}</div>
                )}
              </div>

              {application.coverLetter && (
                <div className="mt-2">
                  <div className="font-medium text-gray-900 mb-1">Cover Letter</div>
                  <div className="text-sm text-gray-700 whitespace-pre-wrap bg-gray-50 border rounded p-3">
                    {application.coverLetter}
                  </div>
                </div>
              )}

              <div className="mt-2 grid grid-cols-2 gap-2 text-xs text-gray-600">
                {typeof application.salaryExpectation === 'number' && (
                  <div><span className="text-gray-500">Salary:</span> ${application.salaryExpectation.toLocaleString()}</div>
                )}
                {application.availabilityDate && (
                  <div><span className="text-gray-500">Availability:</span> {new Date(application.availabilityDate).toLocaleDateString()}</div>
                )}
                {application.workAuthorization && (
                  <div><span className="text-gray-500">Work Auth:</span> {application.workAuthorization}</div>
                )}
                {typeof application.willingToRelocate === 'boolean' && (
                  <div><span className="text-gray-500">Relocation:</span> {application.willingToRelocate ? 'Yes' : 'No'}</div>
                )}
              </div>

              {application.additionalInfo && (
                <div className="mt-2">
                  <div className="font-medium text-gray-900 mb-1">Additional Information</div>
                  <div className="text-sm text-gray-700 whitespace-pre-wrap bg-gray-50 border rounded p-3">
                    {application.additionalInfo}
                  </div>
                </div>
              )}

              {application.status === 'shortlisted' && (
                <div className="mt-4 p-4 bg-gradient-to-br from-yellow-50 to-amber-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-start">
                    <Star className="w-5 h-5 text-yellow-600 mr-2 mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <h4 className="font-semibold text-yellow-900 mb-1">Shortlisted Candidate</h4>
                      {application.shortlist_notes && (
                        <div className="mb-2">
                          <div className="text-xs font-medium text-yellow-700 mb-1">Shortlist Notes:</div>
                          <p className="text-sm text-yellow-800">{application.shortlist_notes}</p>
                        </div>
                      )}
                      {application.shortlisted_at && (
                        <div className="text-xs text-yellow-700 flex items-center">
                          <Clock className="w-3 h-3 mr-1" />
                          Shortlisted on {new Date(application.shortlisted_at).toLocaleString()}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {application.interview_decision && application.interview_decision !== 'pending' && (
                <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <h4 className="font-semibold text-blue-900 mb-1">Interview Decision</h4>
                      <div className="mb-2">
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                          application.interview_decision === 'accepted' ? 'bg-green-100 text-green-800' :
                          application.interview_decision === 'offer_extended' ? 'bg-blue-100 text-blue-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {application.interview_decision === 'accepted' && 'Accepted'}
                          {application.interview_decision === 'offer_extended' && 'Offer Extended'}
                          {application.interview_decision === 'rejected' && 'Rejected'}
                        </span>
                      </div>
                      {application.decision_notes && (
                        <div className="mb-2">
                          <div className="text-xs font-medium text-blue-700 mb-1">Decision Notes:</div>
                          <p className="text-sm text-blue-800">{application.decision_notes}</p>
                        </div>
                      )}
                      {application.decision_made_at && (
                        <div className="text-xs text-blue-700 flex items-center">
                          <Clock className="w-3 h-3 mr-1" />
                          Decision made on {new Date(application.decision_made_at).toLocaleString()}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Resume */}
            <div className="space-y-3">
              <div className="font-medium text-gray-900">Resume</div>
              {/* Debug info */}
              {process.env.NODE_ENV === 'development' && (
                <div className="text-xs text-gray-500 mb-2 p-2 bg-gray-50 rounded">
                  Debug: loading={loadingResume.toString()}, error={!!error ? 'yes' : 'no'}, resumeUrl={resumeUrl ? 'set' : 'none'}, resumeBlobUrl={resumeBlobUrl ? 'set' : 'none'}
                </div>
              )}
              {error && (
                <div className="text-sm text-red-700 bg-red-50 border border-red-200 rounded p-3">
                  <div className="font-medium mb-1">Failed to load resume</div>
                  <div className="text-xs">{error}</div>
                  <div className="text-xs mt-2 text-gray-600">
                    This may be due to: file not found in storage, incorrect path, or permission issues.
                  </div>
                </div>
              )}
              {loadingResume && !error && (
                <div className="flex items-center justify-center h-[60vh] border rounded-lg bg-gray-50">
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-3"></div>
                    <div className="text-sm text-gray-600">Loading resume...</div>
                  </div>
                </div>
              )}
              {!loadingResume && !error && resumeBlobUrl && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-600">Preview</div>
                    <a
                      href={resumeUrl}
                      download={application.resumeFileName || 'resume.pdf'}
                      className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                    >
                      <FileText className="w-4 h-4" />
                      Download Resume
                    </a>
                  </div>
                  <div className="border rounded-lg overflow-hidden h-[60vh] bg-gray-100">
                    <iframe
                      src={resumeBlobUrl}
                      title="Resume Preview"
                      className="w-full h-full"
                    />
                  </div>
                </div>
              )}
              {!loadingResume && !error && !resumeUrl && !application?.resumeUrl && (
                <div className="flex items-center justify-center h-[60vh] border rounded-lg bg-gray-50">
                  <div className="text-center text-gray-500">
                    <FileText className="w-12 h-12 mx-auto mb-2 opacity-30" />
                    <div className="text-sm">No resume provided</div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApplicationDetailsModal;

