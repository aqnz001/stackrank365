import React from 'react';
import { X } from 'lucide-react';
import { useApplications } from '../../hooks/useApplications';
import ApplicationCard from './ApplicationCard';

interface MyApplicationsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const MyApplicationsModal: React.FC<MyApplicationsModalProps> = ({ isOpen, onClose }) => {
  const { applications, loading } = useApplications();
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="relative bg-white w-full max-w-4xl rounded-xl shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b">
            <h3 className="text-base font-semibold text-gray-900">My Applications</h3>
            <button onClick={onClose} className="p-2 text-gray-500 hover:text-gray-700" aria-label="Close">
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="p-5 max-h-[75vh] overflow-auto space-y-3">
            {loading && (
              <div className="text-sm text-gray-600">Loading applications…</div>
            )}
            {!loading && applications.length === 0 && (
              <div className="text-sm text-gray-600">You have not submitted any applications yet.</div>
            )}
            {!loading && applications.map((app) => (
              <ApplicationCard key={app.id} application={app} showActions={false} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MyApplicationsModal;

