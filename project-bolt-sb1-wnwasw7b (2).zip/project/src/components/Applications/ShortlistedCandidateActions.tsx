import React, { useState } from 'react';
import { CheckCircle, XCircle, FileText, Calendar, Eye } from 'lucide-react';
import type { Application } from '../../types';
import CandidateSelectionModal from './CandidateSelectionModal';
import RejectFromShortlistModal from './RejectFromShortlistModal';
import InterviewScheduler from '../Interviews/InterviewScheduler';
import ViewNotesModal from './ViewNotesModal';

interface ShortlistedCandidateActionsProps {
  application: Application;
  jobId: string;
  onUpdate: () => void;
}

const ShortlistedCandidateActions: React.FC<ShortlistedCandidateActionsProps> = ({
  application,
  jobId,
  onUpdate,
}) => {
  const [showOfferModal, setShowOfferModal] = useState(false);
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [showInterviewScheduler, setShowInterviewScheduler] = useState(false);
  const [showViewNotes, setShowViewNotes] = useState(false);

  return (
    <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <CheckCircle className="w-5 h-5 text-blue-600 mr-2" />
            Shortlisted Candidate
          </h3>
          <p className="text-sm text-gray-600 mt-1">
            Take action on this shortlisted candidate
          </p>
        </div>
      </div>

      {application.shortlist_notes && (
        <div className="mb-4 p-3 bg-white rounded-lg border border-blue-100">
          <div className="flex items-center justify-between mb-1">
            <div className="text-xs font-medium text-gray-500">Shortlist Notes</div>
            <button
              onClick={() => setShowViewNotes(true)}
              className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1"
            >
              <Eye className="w-3 h-3" />
              View/Edit
            </button>
          </div>
          <p className="text-sm text-gray-700 line-clamp-2">{application.shortlist_notes}</p>
          {application.shortlisted_at && (
            <div className="text-xs text-gray-500 mt-2">
              Shortlisted on {new Date(application.shortlisted_at).toLocaleString()}
            </div>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
        <button
          onClick={() => setShowOfferModal(true)}
          className="flex items-center justify-center px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
        >
          <CheckCircle className="w-5 h-5 mr-2" />
          Extend Offer
        </button>

        <button
          onClick={() => setShowRejectModal(true)}
          className="flex items-center justify-center px-4 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium"
        >
          <XCircle className="w-5 h-5 mr-2" />
          Reject Candidate
        </button>

        <button
          onClick={() => setShowInterviewScheduler(true)}
          className="flex items-center justify-center px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
        >
          <Calendar className="w-5 h-5 mr-2" />
          Schedule Interview
        </button>

        <button
          onClick={() => setShowViewNotes(true)}
          className="flex items-center justify-center px-4 py-3 border-2 border-blue-300 text-blue-700 rounded-lg hover:bg-blue-50 transition-colors font-medium"
        >
          <FileText className="w-5 h-5 mr-2" />
          {application.shortlist_notes ? 'View/Edit Notes' : 'Add Notes'}
        </button>
      </div>


      <div className="mt-4 p-3 bg-blue-100 rounded-lg">
        <div className="flex items-start">
          <FileText className="w-4 h-4 text-blue-700 mr-2 mt-0.5 flex-shrink-0" />
          <p className="text-xs text-blue-800">
            <strong>Next Steps:</strong> Review this candidate and either extend a job offer to hire them,
            schedule additional interviews for further evaluation, or reject them if they're not the right fit.
          </p>
        </div>
      </div>

      {showOfferModal && (
        <CandidateSelectionModal
          application={application}
          jobId={jobId}
          onClose={() => setShowOfferModal(false)}
          onSuccess={() => {
            setShowOfferModal(false);
            onUpdate();
          }}
        />
      )}

      {showRejectModal && (
        <RejectFromShortlistModal
          application={application}
          onClose={() => setShowRejectModal(false)}
          onSuccess={() => {
            setShowRejectModal(false);
            onUpdate();
          }}
        />
      )}

      {showInterviewScheduler && (
        <InterviewScheduler
          application={application}
          isOpen={showInterviewScheduler}
          onClose={() => setShowInterviewScheduler(false)}
          onSuccess={() => {
            setShowInterviewScheduler(false);
            onUpdate();
          }}
        />
      )}

      {showViewNotes && (
        <ViewNotesModal
          application={application}
          onClose={() => setShowViewNotes(false)}
          onSuccess={() => {
            setShowViewNotes(false);
            onUpdate();
          }}
        />
      )}
    </div>
  );
};

export default ShortlistedCandidateActions;
