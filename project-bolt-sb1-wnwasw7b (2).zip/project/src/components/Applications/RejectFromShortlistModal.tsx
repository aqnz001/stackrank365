import React, { useState } from 'react';
import { X, XCircle, AlertTriangle } from 'lucide-react';
import { useApplications } from '../../hooks/useApplications';
import type { Application } from '../../types';
import toast from 'react-hot-toast';

interface RejectFromShortlistModalProps {
  application: Application;
  onClose: () => void;
  onSuccess: () => void;
}

const RejectFromShortlistModal: React.FC<RejectFromShortlistModalProps> = ({
  application,
  onClose,
  onSuccess,
}) => {
  const [rejectionReason, setRejectionReason] = useState('');
  const [notifyCandidate, setNotifyCandidate] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const { updateApplicationStatus } = useApplications();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!rejectionReason.trim()) {
      toast.error('Please provide a reason for rejection');
      return;
    }

    setSubmitting(true);

    try {
      await updateApplicationStatus(application.id, 'rejected', {
        decisionNotes: rejectionReason,
        notifyCandidate,
      });

      toast.success('Candidate rejected successfully');
      onSuccess();
    } catch (error) {
      console.error('Error rejecting candidate:', error);
      toast.error('Failed to reject candidate. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Reject Shortlisted Candidate</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <div className="flex items-start">
              <XCircle className="w-5 h-5 text-red-600 mr-3 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-red-900 mb-1">
                  Rejecting {application.candidateName}
                </h3>
                <p className="text-sm text-red-700">
                  This candidate will be moved from shortlisted status to rejected.
                  {notifyCandidate && ' The candidate will receive a professional rejection notification.'}
                </p>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Reason for Rejection <span className="text-red-500">*</span>
            </label>
            <textarea
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              rows={5}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none"
              placeholder="Please document the reason for rejection (e.g., found better qualified candidate, skills gap, compensation expectations, etc.)"
            />
            <p className="text-xs text-gray-500 mt-1">
              This information will be stored for audit purposes and internal records only.
            </p>
          </div>

          <div className="flex items-start">
            <input
              type="checkbox"
              id="notifyCandidate"
              checked={notifyCandidate}
              onChange={(e) => setNotifyCandidate(e.target.checked)}
              className="mt-1 h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded"
            />
            <label htmlFor="notifyCandidate" className="ml-2 block text-sm text-gray-700">
              Send rejection notification to candidate
              <span className="block text-xs text-gray-500 mt-1">
                We recommend notifying candidates to maintain a positive employer brand
              </span>
            </label>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex items-start">
              <AlertTriangle className="w-5 h-5 text-yellow-600 mr-3 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-yellow-800">
                <p className="font-medium mb-1">Important Notes:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>This action will update the application status to rejected</li>
                  <li>The rejection reason will be documented in the audit trail</li>
                  <li>You can still view this application in your rejected applications list</li>
                  <li>This action can be reversed if needed by updating the status later</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || !rejectionReason.trim()}
              className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
            >
              {submitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Processing...
                </>
              ) : (
                <>
                  <XCircle className="w-4 h-4 mr-2" />
                  Confirm Rejection
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RejectFromShortlistModal;
