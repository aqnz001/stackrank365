import React, { useState } from 'react';
import { X, FileText, Edit2, Save } from 'lucide-react';
import { useApplications } from '../../hooks/useApplications';
import type { Application } from '../../types';
import toast from 'react-hot-toast';

interface ViewNotesModalProps {
  application: Application;
  onClose: () => void;
  onSuccess: () => void;
}

const ViewNotesModal: React.FC<ViewNotesModalProps> = ({
  application,
  onClose,
  onSuccess,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [notes, setNotes] = useState(application.shortlist_notes || '');
  const [submitting, setSubmitting] = useState(false);
  const { updateApplicationStatus } = useApplications();

  const handleSave = async () => {
    if (!notes.trim()) {
      toast.error('Notes cannot be empty');
      return;
    }

    setSubmitting(true);

    try {
      await updateApplicationStatus(application.id, 'shortlisted', {
        shortlistNotes: notes.trim(),
      });

      toast.success('Notes updated successfully');
      setIsEditing(false);
      onSuccess();
    } catch (error) {
      console.error('Error updating notes:', error);
      toast.error('Failed to update notes. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <h2 className="text-xl font-bold text-gray-900">Shortlist Notes</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="text-sm text-blue-900 mb-2">
              <strong>Candidate:</strong> {application.candidateName}
            </div>
            {application.shortlisted_at && (
              <div className="text-sm text-blue-800">
                <strong>Shortlisted on:</strong> {new Date(application.shortlisted_at).toLocaleString()}
              </div>
            )}
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-gray-700">
                Notes
              </label>
              {!isEditing ? (
                <button
                  onClick={() => setIsEditing(true)}
                  className="flex items-center gap-1 text-sm text-blue-600 hover:text-blue-700"
                >
                  <Edit2 className="w-4 h-4" />
                  Edit
                </button>
              ) : (
                <button
                  onClick={() => {
                    setNotes(application.shortlist_notes || '');
                    setIsEditing(false);
                  }}
                  className="text-sm text-gray-600 hover:text-gray-700"
                >
                  Cancel
                </button>
              )}
            </div>

            {isEditing ? (
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={8}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                placeholder="Add notes about this candidate..."
              />
            ) : (
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 min-h-[200px]">
                <p className="text-gray-700 whitespace-pre-wrap">
                  {application.shortlist_notes || 'No notes available'}
                </p>
              </div>
            )}
          </div>

          {isEditing && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              <p className="text-sm text-yellow-800">
                Update these notes to reflect any new insights or evaluation criteria about this candidate.
              </p>
            </div>
          )}

          <div className="flex justify-end space-x-3 pt-4 border-t">
            {isEditing ? (
              <>
                <button
                  onClick={() => {
                    setNotes(application.shortlist_notes || '');
                    setIsEditing(false);
                  }}
                  disabled={submitting}
                  className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  disabled={submitting || !notes.trim()}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                >
                  {submitting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      Save Notes
                    </>
                  )}
                </button>
              </>
            ) : (
              <button
                onClick={onClose}
                className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
              >
                Close
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViewNotesModal;
