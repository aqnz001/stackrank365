import React, { useState } from 'react';
import { Application } from '../../types';
import { mockJobs } from '../../data/mockData';
import {
  User,
  Mail,
  Calendar,
  FileText,
  Eye,
  CheckCircle,
  XCircle,
  Clock,
  UserCheck,
  Building,
  Award,
  Star
} from 'lucide-react';
import ShortlistedCandidateActions from './ShortlistedCandidateActions';
import CandidateSelectionModal from './CandidateSelectionModal';

interface ApplicationCardProps {
  application: Application;
  showActions?: boolean;
  onView?: () => void;
  onShortlist?: () => void;
  onReject?: () => void;
  onUpdate?: () => void;
}

const ApplicationCard: React.FC<ApplicationCardProps> = ({
  application,
  showActions = true,
  onView,
  onShortlist,
  onReject,
  onUpdate
}) => {
  const [showSelectionModal, setShowSelectionModal] = useState(false);

  const job = mockJobs.find(j => j.id === application.jobId);
  // Prefer job details from joined data if available
  const anyApp = application as any;
  const jobTitle = anyApp.jobTitle || job?.title;
  const orgName = anyApp.organizationName || job?.organizationName;
  const jobLocation = anyApp.jobLocation || job?.location;

  const getStatusConfig = () => {
    switch (application.status) {
      case 'submitted':
        return { color: 'blue', icon: <Clock className="w-4 h-4" />, label: 'New Application' };
      case 'shortlisted':
        return { color: 'yellow', icon: <Award className="w-4 h-4" />, label: 'Shortlisted' };
      case 'rejected':
        return { color: 'red', icon: <XCircle className="w-4 h-4" />, label: 'Rejected' };
      case 'hired':
        return { color: 'purple', icon: <CheckCircle className="w-4 h-4" />, label: 'Hired' };
      default:
        return { color: 'gray', icon: <Clock className="w-4 h-4" />, label: 'Processing' };
    }
  };

  const statusConfig = getStatusConfig();

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <div className="flex items-center mb-3">
            <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center mr-3">
              <User className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">{application.candidateName}</h3>
              {application.source === 'recruiter' && (
                <div className="flex items-center gap-2 mt-1">
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-purple-100 text-purple-800">
                    <UserCheck className="w-3 h-3 mr-1" />
                    From Recruiter Bid
                  </span>
                  {application.recruiterBidId && (
                    <span className="text-[11px] text-gray-500">
                      (Bid #{application.recruiterBidId.substring(0, 8)})
                    </span>
                  )}
                </div>
              )}
              <div className="flex items-center text-sm text-gray-500">
                <Mail className="w-4 h-4 mr-1" />
                {application.candidateEmail}
              </div>
            </div>
          </div>

          <div className="mb-4">
            <h4 className="font-medium text-gray-900">{jobTitle || 'Job'}</h4>
            {(orgName || jobLocation) && (
              <p className="text-gray-600 text-sm">{orgName}{orgName && jobLocation ? ' • ' : ''}{jobLocation}</p>
            )}
          </div>

          <div className="flex items-center text-sm text-gray-500 mb-3">
            <Calendar className="w-4 h-4 mr-1" />
            Applied on {application.createdAt.toLocaleDateString()}
            <span className="mx-2">•</span>
            <span className="capitalize">{application.source} application</span>
          </div>

          {application.coverLetter && (
            <div className="mb-4">
              <div className="flex items-center text-sm text-gray-700 mb-2">
                <FileText className="w-4 h-4 mr-1" />
                Cover Letter
              </div>
              <p className="text-gray-600 text-sm line-clamp-2 bg-gray-50 p-3 rounded-lg">
                {application.coverLetter}
              </p>
            </div>
          )}
        </div>

        <div className="ml-6 flex flex-col items-end space-y-3">
          <div className="flex flex-col items-end gap-2">
            <span className={`flex items-center px-3 py-1 rounded-full text-sm font-medium ${
              application.status === 'shortlisted'
                ? 'bg-yellow-100 text-yellow-800 border border-yellow-300'
                : `bg-${statusConfig.color}-100 text-${statusConfig.color}-800`
            }`}>
              {statusConfig.icon}
              <span className="ml-1">{statusConfig.label}</span>
            </span>
            {application.status === 'shortlisted' && application.shortlist_notes && (
              <div className="text-xs text-gray-500 max-w-xs text-right">
                <Star className="w-3 h-3 inline mr-1" />
                Note: {application.shortlist_notes.substring(0, 50)}{application.shortlist_notes.length > 50 ? '...' : ''}
              </div>
            )}
          </div>

          {showActions && (
            <div className="flex flex-col space-y-2">
              <button
                onClick={onView}
                className="flex items-center px-3 py-1 text-sm bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors"
              >
                <Eye className="w-4 h-4 mr-1" />
                View Details
              </button>
              
              {application.status === 'submitted' && (
                <div className="flex space-x-2">
                  <button
                    onClick={onShortlist}
                    className="px-3 py-1 text-sm bg-green-600 text-white rounded hover:bg-green-700 transition-colors"
                  >
                    Shortlist
                  </button>
                  <button
                    onClick={onReject}
                    className="px-3 py-1 text-sm bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
                  >
                    Reject
                  </button>
                </div>
              )}

              {application.status === 'shortlisted' && (
                <button
                  onClick={() => setShowSelectionModal(true)}
                  className="flex items-center px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
                >
                  <Award className="w-4 h-4 mr-1" />
                  Select for Hire
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {application.status === 'shortlisted' && showActions && (
        <div className="mt-4 pt-4 border-t border-gray-100">
          <ShortlistedCandidateActions
            application={application}
            jobId={application.jobId}
            onUpdate={() => {
              if (onUpdate) onUpdate();
            }}
          />
        </div>
      )}

      {application.resumeUrl && (
        <div className="mt-4 pt-4 border-t border-gray-100">
          <button className="flex items-center text-sm text-blue-600 hover:text-blue-700">
            <FileText className="w-4 h-4 mr-1" />
            View Resume ({application.resumeFileName || 'Resume'})
          </button>
        </div>
      )}

      {showSelectionModal && (
        <CandidateSelectionModal
          application={application}
          jobId={application.jobId}
          onClose={() => setShowSelectionModal(false)}
          onSuccess={() => {
            setShowSelectionModal(false);
            if (onUpdate) onUpdate();
          }}
        />
      )}
    </div>
  );
};

export default ApplicationCard;
