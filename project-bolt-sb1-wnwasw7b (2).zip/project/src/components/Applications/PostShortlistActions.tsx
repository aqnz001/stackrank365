import React, { useState } from 'react';
import { Calendar, Clock, Video, Phone, MapPin, Building, CheckCircle, AlertCircle } from 'lucide-react';
import { useInterviews } from '../../hooks/useInterviews';
import type { Application } from '../../types';

interface PostShortlistActionsProps {
  application: Application;
  onComplete: () => void;
}

const PostShortlistActions: React.FC<PostShortlistActionsProps> = ({
  application,
  onComplete,
}) => {
  const [showScheduleInterview, setShowScheduleInterview] = useState(false);
  const [interviewType, setInterviewType] = useState<'phone' | 'video' | 'in_person' | 'technical' | 'panel'>('video');
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [duration, setDuration] = useState(60);
  const [location, setLocation] = useState('');
  const [meetingLink, setMeetingLink] = useState('');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const { scheduleInterview } = useInterviews();

  const handleScheduleInterview = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const scheduledAt = new Date(`${scheduledDate}T${scheduledTime}`);

      await scheduleInterview({
        applicationId: application.id,
        candidateId: application.candidateId,
        interviewType,
        scheduledAt,
        durationMinutes: duration,
        location: interviewType === 'in_person' ? location : undefined,
        meetingLink: interviewType === 'video' ? meetingLink : undefined,
        notes,
      });

      setShowScheduleInterview(false);
      onComplete();
    } catch (error) {
      console.error('Error scheduling interview:', error);
      alert('Failed to schedule interview. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (!showScheduleInterview) {
    return (
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start">
          <AlertCircle className="w-5 h-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <h4 className="font-medium text-blue-900 mb-1">Next Steps Required</h4>
            <p className="text-sm text-blue-700 mb-3">
              This candidate has been shortlisted. Schedule an interview to move forward with the hiring process.
            </p>
            <button
              onClick={() => setShowScheduleInterview(true)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
            >
              Schedule Interview
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Schedule Interview</h3>
        <button
          onClick={() => setShowScheduleInterview(false)}
          className="text-gray-400 hover:text-gray-600"
        >
          ×
        </button>
      </div>

      <form onSubmit={handleScheduleInterview} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Interview Type
          </label>
          <div className="grid grid-cols-2 gap-3">
            {[
              { value: 'video', icon: Video, label: 'Video Call' },
              { value: 'phone', icon: Phone, label: 'Phone Call' },
              { value: 'in_person', icon: MapPin, label: 'In Person' },
              { value: 'technical', icon: Building, label: 'Technical' },
            ].map((type) => (
              <button
                key={type.value}
                type="button"
                onClick={() => setInterviewType(type.value as any)}
                className={`flex items-center justify-center px-4 py-3 rounded-lg border-2 transition-all ${
                  interviewType === type.value
                    ? 'border-blue-600 bg-blue-50 text-blue-700'
                    : 'border-gray-200 hover:border-gray-300 text-gray-700'
                }`}
              >
                <type.icon className="w-5 h-5 mr-2" />
                <span className="font-medium">{type.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Date
            </label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="date"
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                required
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Time
            </label>
            <div className="relative">
              <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="time"
                value={scheduledTime}
                onChange={(e) => setScheduledTime(e.target.value)}
                required
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Duration (minutes)
          </label>
          <select
            value={duration}
            onChange={(e) => setDuration(Number(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value={30}>30 minutes</option>
            <option value={45}>45 minutes</option>
            <option value={60}>1 hour</option>
            <option value={90}>1.5 hours</option>
            <option value={120}>2 hours</option>
          </select>
        </div>

        {interviewType === 'video' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Video Meeting Link
            </label>
            <input
              type="url"
              value={meetingLink}
              onChange={(e) => setMeetingLink(e.target.value)}
              placeholder="https://zoom.us/j/..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        )}

        {interviewType === 'in_person' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Location
            </label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Office address or meeting location"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Additional Notes
          </label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={3}
            placeholder="Any additional information for the candidate..."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
          />
        </div>

        <div className="flex justify-end space-x-3 pt-4 border-t">
          <button
            type="button"
            onClick={() => setShowScheduleInterview(false)}
            className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
          >
            {submitting ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                Scheduling...
              </>
            ) : (
              <>
                <CheckCircle className="w-4 h-4 mr-2" />
                Schedule Interview
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default PostShortlistActions;
