import React, { useState } from 'react';
import { X, CheckCircle, TrendingUp, DollarSign, Calendar, AlertTriangle, FileText } from 'lucide-react';
import { useCandidateSelections } from '../../hooks/useCandidateSelections';
import { useScheduledPayments } from '../../hooks/usePaymentSchedules';
import type { Application } from '../../types';

interface CandidateSelectionModalProps {
  application: Application;
  jobId: string;
  onClose: () => void;
  onSuccess: () => void;
}

const CandidateSelectionModal: React.FC<CandidateSelectionModalProps> = ({
  application,
  jobId,
  onClose,
  onSuccess,
}) => {
  const [offerExtendedDate, setOfferExtendedDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [startDate, setStartDate] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);

  const { selectCandidate } = useCandidateSelections();
  const { payments } = useScheduledPayments(application.recruiterBidId);

  const isRecruiterSource = application.source === 'recruiter' && application.recruiterBidId;
  const pendingPayments = payments.filter(p => p.status === 'pending');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!showConfirmation) {
      setShowConfirmation(true);
      return;
    }

    setSubmitting(true);

    try {
      await selectCandidate({
        jobId,
        applicationId: application.id,
        recruiterBidId: application.recruiterBidId,
        offerExtendedDate: new Date(offerExtendedDate),
      });

      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error selecting candidate:', error);
      alert('Failed to select candidate. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Select Candidate for Hire</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start">
              <CheckCircle className="w-5 h-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-blue-900 mb-1">
                  Selecting {application.candidateName}
                </h3>
                <p className="text-sm text-blue-700">
                  This action will mark this candidate as hired and update the job status to filled.
                  All other applications will be notified that the position has been filled.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Offer Extended Date
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="date"
                  value={offerExtendedDate}
                  onChange={(e) => setOfferExtendedDate(e.target.value)}
                  max={new Date().toISOString().split('T')[0]}
                  required
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Expected Start Date (Optional)
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  min={offerExtendedDate}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {isRecruiterSource && pendingPayments.length > 0 && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <div className="flex items-start">
                <DollarSign className="w-5 h-5 text-yellow-600 mr-3 mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <h3 className="font-semibold text-yellow-900 mb-1">
                    Recruiter Payment Schedule
                  </h3>
                  <p className="text-sm text-yellow-700 mb-3">
                    This candidate was sourced through a recruiter. The following payment milestones
                    will be triggered when you select this candidate:
                  </p>
                  <div className="space-y-2">
                    {pendingPayments.map((payment, index) => (
                      <div
                        key={payment.id}
                        className="bg-white rounded-lg p-3 flex items-center justify-between"
                      >
                        <div className="flex items-center">
                          <div className="w-6 h-6 rounded-full bg-yellow-100 text-yellow-700 flex items-center justify-center text-sm font-medium mr-3">
                            {index + 1}
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{payment.milestoneName}</p>
                            <p className="text-xs text-gray-600">{payment.milestoneTrigger}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-gray-900">
                            ${(payment.amount / 100).toFixed(2)}
                          </p>
                          <p className="text-xs text-gray-600">{payment.percentage}%</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {showConfirmation && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-start">
                <AlertTriangle className="w-5 h-5 text-red-600 mr-3 mt-0.5 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-red-900 mb-1">Confirm Selection</h3>
                  <p className="text-sm text-red-700 mb-2">
                    Are you sure you want to proceed? This action will:
                  </p>
                  <ul className="text-sm text-red-700 list-disc list-inside space-y-1">
                    <li>Mark this candidate as hired</li>
                    <li>Close the job position</li>
                    <li>Notify all other applicants that the position is filled</li>
                    {isRecruiterSource && <li>Initiate payment milestones for the recruiter</li>}
                    {isRecruiterSource && <li>Generate an invoice for recruiter fees</li>}
                  </ul>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-end space-x-3 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
            >
              Cancel
            </button>
            {showConfirmation && (
              <button
                type="button"
                onClick={() => setShowConfirmation(false)}
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
              >
                Back
              </button>
            )}
            <button
              type="submit"
              disabled={submitting}
              className={`px-6 py-2 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center ${
                showConfirmation
                  ? 'bg-green-600 hover:bg-green-700 text-white'
                  : 'bg-blue-600 hover:bg-blue-700 text-white'
              }`}
            >
              {submitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Processing...
                </>
              ) : showConfirmation ? (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Confirm Selection
                </>
              ) : (
                <>
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Proceed
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CandidateSelectionModal;
