import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { X, Shield, Globe, Linkedin } from 'lucide-react';

interface Props { isOpen: boolean; onClose: () => void }

const VerificationRequest: React.FC<Props> = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  const [companyWebsite, setCompanyWebsite] = useState('');
  const [linkedinUrl, setLinkedinUrl] = useState('');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  if (!isOpen) return null;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSubmitting(true);
    try {
      // Optional: record a request row if table exists
      try {
        await supabase.from('kyc_requests').insert({
          user_id: user.id,
          company_website: companyWebsite || null,
          linkedin_url: linkedinUrl || null,
          notes: notes || null,
          status: 'pending',
        });
      } catch { /* best-effort */ }
      // Update profile kyc_status
      await supabase.from('profiles').update({
        kyc_status: 'pending',
        kyc_requested_at: new Date().toISOString(),
        metadata: { companyWebsite, linkedinUrl, kycNotes: notes },
      } as any).eq('id', user.id);
      alert('Verification request submitted. We will review and notify you.');
      onClose();
    } catch (err) {
      console.error('KYC request error', err);
      alert('Failed to submit verification. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-blue-600" />
              <h3 className="text-base font-semibold text-gray-900">Request Recruiter Verification</h3>
            </div>
            <button onClick={onClose} className="p-2 text-gray-500 hover:text-gray-700" aria-label="Close"><X className="w-5 h-5"/></button>
          </div>
          <form onSubmit={submit} className="p-5 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Company website</label>
              <div className="relative">
                <Globe className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input value={companyWebsite} onChange={e=>setCompanyWebsite(e.target.value)} placeholder="https://youragency.com" className="w-full pl-9 pr-3 py-2 border rounded-md" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">LinkedIn</label>
              <div className="relative">
                <Linkedin className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input value={linkedinUrl} onChange={e=>setLinkedinUrl(e.target.value)} placeholder="https://www.linkedin.com/in/your-profile" className="w-full pl-9 pr-3 py-2 border rounded-md" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
              <textarea value={notes} onChange={e=>setNotes(e.target.value)} rows={3} className="w-full px-3 py-2 border rounded-md" placeholder="Anything else we should know (registrations, client references, markets)"></textarea>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={onClose} className="px-4 py-2 border rounded">Cancel</button>
              <button type="submit" disabled={submitting} className="px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50">{submitting?'Submitting…':'Submit request'}</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default VerificationRequest;

