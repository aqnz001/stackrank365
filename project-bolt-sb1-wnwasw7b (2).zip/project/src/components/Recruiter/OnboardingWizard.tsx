import React from 'react';
import { useRecruiterProfile, RecruiterProfile } from '../../hooks/useRecruiterProfile';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import FileUploadZone from '../FileUpload/FileUploadZone';
import { UploadedFile, useFileUpload } from '../../hooks/useFileUpload';
import { X, Shield, Building2, FileText, CheckCircle, CreditCard, MapPin, User, Phone, Mail, Globe, Hash, Trash2, Upload, Image as ImageIcon } from 'lucide-react';
import SubscriptionManager from '../Payments/SubscriptionManager';
import toast from 'react-hot-toast';
import { useBilling } from '../../hooks/useBilling';

interface Props { isOpen: boolean; onClose: () => void; }

const OnboardingWizard: React.FC<Props> = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  const { profile, save } = useRecruiterProfile();
  const { uploadFile, uploading } = useFileUpload();
  const { refetch: refetchBilling } = useBilling();
  const [step, setStep] = React.useState(0);
  const [data, setData] = React.useState<RecruiterProfile>({
    companyName: '',
    website: '',
    registrationNumber: '',
    about: '',
    logoPath: '',
    logoUrl: '',
    publishProfile: false,
    addressLine1: '',
    city: '',
    country: '',
    postalCode: '',
    contactName: '',
    contactEmail: '',
    contactPhone: '',
    publishEmail: false,
    documents: [],
    acceptedTerms: false,
    bankStatus: 'missing',
    bankName: '',
    bankAccountNumber: '',
    bankAccountHolderName: '',
    bankAddressLine1: '',
    bankAddressLine2: '',
    bankAccountHolderAddressLine1: '',
    bankAccountHolderAddressLine2: '',
    bankAccountHolderAddressLine3: '',
    branchName: '',
    bankAccountCountry: '',
    currency: '',
    clearingCode: '',
    iban: '',
    swiftCode: ''
  });
  const [billingData, setBillingData] = React.useState({
    billingEmail: '',
    billingCompanyName: '',
    taxId: '',
    billingAddressLine1: '',
    billingAddressLine2: '',
    billingCity: '',
    billingState: '',
    billingPostalCode: '',
    billingCountry: 'US',
  });
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const readOnly = !!(profile?.acceptedTerms && profile?.acceptedAt);

  React.useEffect(() => {
    if (isOpen) {
      setData(profile || {
        companyName: '',
        website: '',
        registrationNumber: '',
        about: '',
        logoPath: '',
        logoUrl: '',
        publishProfile: false,
        addressLine1: '',
        city: '',
        country: '',
        postalCode: '',
        contactName: '',
        contactEmail: '',
        contactPhone: '',
        publishEmail: false,
        documents: [],
        acceptedTerms: false,
        bankStatus: 'missing',
        bankName: '',
        bankAccountNumber: '',
        bankAccountHolderName: '',
        bankAddressLine1: '',
        bankAddressLine2: '',
        bankAccountHolderAddressLine1: '',
        bankAccountHolderAddressLine2: '',
        bankAccountHolderAddressLine3: '',
        branchName: '',
        bankAccountCountry: '',
        currency: '',
        clearingCode: '',
        iban: '',
        swiftCode: ''
      });

      // Load existing billing data if available
      const loadBillingData = async () => {
        if (user?.organizationId) {
          const { data: billing } = await supabase
            .from('billing_accounts')
            .select('*')
            .eq('organization_id', user.organizationId)
            .maybeSingle();

          if (billing) {
            setBillingData({
              billingEmail: billing.billing_email || '',
              billingCompanyName: billing.company_name || '',
              taxId: billing.tax_id || '',
              billingAddressLine1: billing.billing_address?.line1 || '',
              billingAddressLine2: billing.billing_address?.line2 || '',
              billingCity: billing.billing_address?.city || '',
              billingState: billing.billing_address?.state || '',
              billingPostalCode: billing.billing_address?.postal_code || '',
              billingCountry: billing.billing_address?.country || 'US',
            });
          }
        }
      };
      loadBillingData();
    }
  }, [isOpen, profile, user?.organizationId]);
  
  if (!isOpen) return null;

  const addDoc = (file: UploadedFile) => {
    console.log('Adding document:', file.name);
    setData(d => ({ 
      ...d, 
      documents: [...(d.documents || []), { 
        id: file.id, 
        name: file.name, 
        path: file.path, 
        url: file.url, 
        type: file.type 
      }] 
    }));
  };

  const removeDoc = (id: string) => {
    console.log('Removing document:', id);
    setData(d => ({ ...d, documents: (d.documents || []).filter(x => x.id !== id) }));
  };

  const handleLogoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      toast.error('File size must be less than 2MB');
      return;
    }

    const allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!allowed.includes(file.type)) {
      toast.error('Please upload a JPEG, PNG, GIF, or WebP image');
      return;
    }

    try {
      const uploadedFile = await uploadFile(file, {
        bucket: 'company-logos',
        fileType: 'company_logo',
        organizationId: user?.organizationId || undefined,
      });
      setData(d => ({
        ...d,
        logoPath: uploadedFile.path,
        logoUrl: uploadedFile.url
      }));
      toast.success('Logo uploaded successfully');
    } catch (err) {
      toast.error('Failed to upload logo');
      console.error('Logo upload error:', err);
    }
  };

  const next = () => {
    setError(null);
    setStep(s => Math.min(stepTitles.length - 1, s + 1));
  };
  const prev = () => setStep(s => Math.max(0, s-1));

  const validateStep = (stepNum: number): string | null => {
    switch (stepNum) {
      case 0:
        if (!data.companyName?.trim()) return 'Company name is required';
        if (!data.contactName?.trim()) return 'Contact name is required';
        if (!data.contactEmail?.trim()) return 'Contact email is required';
        if (!data.contactPhone?.trim()) return 'Contact phone is required';
        return null;
      case 1:
        if (!data.addressLine1?.trim()) return 'Address is required';
        if (!data.city?.trim()) return 'City is required';
        if (!data.country?.trim()) return 'Country is required';
        return null;
      case 2:
        if (!data.documents || data.documents.length === 0) return 'At least one business document is required';
        return null;
      case 3:
        // Only these banking details are mandatory
        if (!data.bankName?.trim()) return 'Bank name is required';
        if (!data.bankAccountNumber?.trim()) return 'Bank account number is required';
        if (!data.bankAccountHolderName?.trim()) return 'Account holder name is required';
        if (!data.branchName?.trim()) return 'Branch name is required';
        return null;
      case 4:
        // Billing information validation
        if (!billingData.billingEmail?.trim()) return 'Billing email is required';
        if (!billingData.billingCompanyName?.trim()) return 'Company name is required';
        if (!billingData.taxId?.trim()) return 'Tax ID is required';
        if (!billingData.billingAddressLine1?.trim()) return 'Billing address is required';
        if (!billingData.billingCity?.trim()) return 'Billing city is required';
        if (!billingData.billingPostalCode?.trim()) return 'Billing postal code is required';
        if (!billingData.billingCountry?.trim()) return 'Billing country is required';
        return null;
      case 6:
        if (!data.acceptedTerms) return 'You must accept the Terms & Conditions';
        return null;
      default:
        return null;
    }
  };

  const handleNext = async () => {
    const validationError = validateStep(step);
    if (validationError) {
      setError(validationError);
      return;
    }

    // Auto-save billing data when leaving step 4 (Billing Information)
    if (step === 4) {
      try {
        await saveBillingData();
        toast.success('Billing information saved');
        // Refetch billing data so the subscription manager sees the updated info
        await refetchBilling();
      } catch (e) {
        console.error('Failed to save billing data:', e);
        toast.error('Failed to save billing information');
        return;
      }
    }

    next();
  };

  const saveBillingData = async () => {
    if (!user?.organizationId) return;

    // Only save if at least email is provided
    if (!billingData.billingEmail) return;

    try {
      console.log('Saving billing account');

      // Check if billing account already exists
      const { data: existing } = await supabase
        .from('billing_accounts')
        .select('id')
        .eq('organization_id', user.organizationId)
        .maybeSingle();

      const billingPayload = {
        organization_id: user.organizationId,
        billing_email: billingData.billingEmail,
        company_name: billingData.billingCompanyName || null,
        tax_id: billingData.taxId || null,
        billing_address: {
          line1: billingData.billingAddressLine1 || null,
          line2: billingData.billingAddressLine2 || null,
          city: billingData.billingCity || null,
          state: billingData.billingState || null,
          postal_code: billingData.billingPostalCode || null,
          country: billingData.billingCountry || 'US',
        },
      };

      if (existing) {
        // Update existing billing account
        const { error: billingError } = await supabase
          .from('billing_accounts')
          .update(billingPayload)
          .eq('id', existing.id);

        if (billingError) {
          console.error('Error updating billing account:', billingError);
          throw billingError;
        }
        console.log('Billing account updated successfully');
      } else {
        // Insert new billing account
        const { error: billingError } = await supabase
          .from('billing_accounts')
          .insert(billingPayload);

        if (billingError) {
          console.error('Error creating billing account:', billingError);
          throw billingError;
        }
        console.log('Billing account created successfully');
      }
    } catch (e) {
      console.error('Billing save error:', e);
      throw e;
    }
  };

  const saveDraft = async () => {
    if (!user) return;

    setSubmitting(true);
    setError(null);

    try {
      console.log('Saving recruiter onboarding draft');
      const payload: RecruiterProfile = { ...data, acceptedTerms: false };
      await save(payload);

      // Sync with organizations table for company profile fields
      if (user.organizationId && data.companyName) {
        await supabase
          .from('organizations')
          .update({
            name: data.companyName,
            website: data.website || null,
            about: data.about || null,
            logo_path: data.logoPath || null,
            publish_profile: data.publishProfile || false,
            contact_email: data.contactEmail || null,
            publish_email: data.publishEmail || false,
            country: data.country || null,
            city: data.city || null,
            postal_code: data.postalCode || null,
          })
          .eq('id', user.organizationId);
      }

      // Save billing data if any is entered
      await saveBillingData();

      toast.success('Draft saved successfully. You can continue later.');
    } catch (e) {
      console.error('Draft save error:', e);
      toast.error('Failed to save draft. Please try again.');
      setError(e instanceof Error ? e.message : 'Failed to save draft.');
    } finally {
      setSubmitting(false);
    }
  };

  const submit = async () => {
    if (!user) return;

    const validationError = validateStep(4);
    if (validationError) {
      setError(validationError);
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      console.log('Submitting recruiter onboarding');
      const payload: RecruiterProfile = { ...data, acceptedTerms: true, acceptedAt: new Date().toISOString(), bankStatus: 'pending' };
      console.log('Payload to save:', payload);
      await save(payload);
      console.log('Profile saved, updating profiles.kyc_status to pending for user:', user.id);

      // Save billing information
      try {
        await saveBillingData();
        console.log('Billing account saved successfully');
      } catch (billingError) {
        console.error('Error saving billing account:', billingError);
        toast.error('Saved profile, but failed to save billing information.');
      }

      // Update user's KYC status to pending for admin review and ensure role is recruiter
      const { data: profileUpdateData, error: profileError } = await supabase
        .from('profiles')
        .update({ kyc_status: 'pending', role: 'recruiter' as any })
        .eq('id', user.id)
        .select('id, kyc_status');
      console.log('profiles update result:', { profileUpdateData, profileError });

      if (profileError) {
        console.error('Error updating KYC status:', profileError);
        toast.error('Saved, but failed to submit for review. Please try again.');
        throw profileError;
      }

      // Sync with organizations table for company profile fields
      if (user.organizationId) {
        const { error: orgError } = await supabase
          .from('organizations')
          .update({
            name: data.companyName,
            website: data.website || null,
            about: data.about || null,
            logo_path: data.logoPath || null,
            publish_profile: data.publishProfile || false,
            contact_email: data.contactEmail || null,
            publish_email: data.publishEmail || false,
            country: data.country || null,
            city: data.city || null,
            postal_code: data.postalCode || null,
          })
          .eq('id', user.organizationId);

        if (orgError) {
          console.error('Error syncing with organizations table:', orgError);
        }
      }

      console.log('Onboarding completed successfully');
      toast.success('Your profile was submitted for review.');
      onClose();
      
      // Show success notification
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('Onboarding Complete', {
          body: 'Your recruiter profile has been submitted for review. We will notify you once verified.',
          icon: '/icons/icon-192x192.png',
        });
      }
    } catch (e) {
      console.error('Onboarding submission error:', e);
      setError(e instanceof Error ? e.message : 'Failed to save onboarding. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const countries = [
    'New Zealand', 'Australia', 'United States', 'United Kingdom', 
    'Canada', 'Germany', 'France', 'Netherlands', 'Singapore', 'Other'
  ];

  const stepTitles = [
    'Company Information',
    'Business Address',
    'Documentation',
    'Banking & Tax Details',
    'Billing Information',
    'Subscription Plan',
    'Terms & Conditions'
  ];

  // Read-only viewer when onboarding has been submitted
  if (readOnly) {
    return (
      <div className="fixed inset-0 z-50">
        <div className="absolute inset-0 bg-black/40" onClick={onClose} />
        <div className="absolute inset-0 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <div className="flex items-center gap-2">
              <Shield className="w-6 h-6" />
              <div>
                <h3 className="text-xl font-semibold">Recruiter Profile</h3>
                <p className="text-blue-100 text-sm">Submitted for review</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                {(() => {
                  const s = (user?.kycStatus || 'pending') as 'verified' | 'pending' | 'rejected';
                  const badge = s === 'verified' ? 'bg-green-100 text-green-800' : s === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800';
                  const label = s.charAt(0).toUpperCase() + s.slice(1);
                  return (<span className={`px-2 py-1 rounded text-xs font-medium ${badge}`}>Profile: {label}</span>);
                })()}
                {(() => {
                  const s = (profile?.bankStatus || 'missing') as 'verified' | 'pending' | 'missing';
                  const badge = s === 'verified' ? 'bg-green-100 text-green-800' : s === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800';
                  const label = s.charAt(0).toUpperCase() + s.slice(1);
                  return (<span className={`px-2 py-1 rounded text-xs font-medium ${badge}`}>Banking: {label}</span>);
                })()}
              </div>
              <button onClick={onClose} className="p-2 text-white/80 hover:text-white" aria-label="Close">
                <X className="w-6 h-6"/>
              </button>
            </div>
          </div>

            <div className="px-6 py-6 space-y-8">
              {error && (
                <div className="mb-2 bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-800">
                  {error}
                </div>
              )}
              <section>
                <h4 className="text-lg font-semibold text-gray-900 mb-3">Company Information</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-800">
                  <div><span className="text-gray-600">Company Name:</span> {profile?.companyName || '-'}</div>
                  <div><span className="text-gray-600">Website:</span> {profile?.website || '-'}</div>
                  <div><span className="text-gray-600">Registration #:</span> {profile?.registrationNumber || '-'}</div>
                  <div><span className="text-gray-600">Contact Name:</span> {profile?.contactName || '-'}</div>
                  <div><span className="text-gray-600">Contact Email:</span> {profile?.contactEmail || '-'}</div>
                  <div><span className="text-gray-600">Contact Phone:</span> {profile?.contactPhone || '-'}</div>
                </div>
              </section>

              <section>
                <h4 className="text-lg font-semibold text-gray-900 mb-3">Business Address</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-800">
                  <div><span className="text-gray-600">Address Line 1:</span> {profile?.addressLine1 || '-'}</div>
                  <div><span className="text-gray-600">City:</span> {profile?.city || '-'}</div>
                  <div><span className="text-gray-600">Country:</span> {profile?.country || '-'}</div>
                </div>
              </section>

              <section>
                <h4 className="text-lg font-semibold text-gray-900 mb-3">Documents</h4>
                {(profile?.documents?.length || 0) === 0 ? (
                  <p className="text-sm text-gray-600">No documents uploaded</p>
                ) : (
                  <ul className="list-disc list-inside text-sm text-gray-800">
                    {(profile?.documents || []).map((doc) => (
                      <li key={doc.id}>
                        {doc.name} {doc.url ? (<a className="text-blue-600 underline ml-2" href={doc.url} target="_blank" rel="noreferrer">View</a>) : null}
                      </li>
                    ))}
                  </ul>
                )}
              </section>

              <section>
                <h4 className="text-lg font-semibold text-gray-900 mb-3">Banking</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-800">
                  <div><span className="text-gray-600">Bank Name:</span> {profile?.bankName || '-'}</div>
                  <div><span className="text-gray-600">Account Number:</span> {profile?.bankAccountNumber || '-'}</div>
                  <div><span className="text-gray-600">Account Holder:</span> {profile?.bankAccountHolderName || '-'}</div>
                  <div><span className="text-gray-600">Branch Name:</span> {profile?.branchName || '-'}</div>
                  <div><span className="text-gray-600">Status:</span> {profile?.bankStatus || 'pending'}</div>
                </div>
              </section>

              <section className="flex justify-end">
                <button onClick={onClose} className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                  Close
                </button>
              </section>

              <section className="flex justify-between items-center">
                <div className="text-sm text-gray-500">
                  {profile?.acceptedAt ? `Submitted: ${new Date(profile.acceptedAt).toLocaleString()}` : ''}
                </div>
                <div className="flex gap-2">
                  {user?.kycStatus !== 'verified' && (
                    <button
                      onClick={async () => {
                        if (!profile || !user) return;
                        setSubmitting(true);
                        setError(null);
                        try {
                          const updated: RecruiterProfile = { ...profile, acceptedTerms: false, acceptedAt: undefined, bankStatus: 'missing' };
                          await save(updated);
                          try { await supabase.from('profiles').update({ kyc_status: null }).eq('id', user.id); } catch {}
                        } catch (e: any) {
                          setError(e?.message || 'Failed to unsubmit profile');
                        } finally {
                          setSubmitting(false);
                        }
                      }}
                      disabled={submitting}
                      className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50"
                    >
                      {submitting ? 'Working...' : 'Unsubmit for Editing'}
                    </button>
                  )}
                  <button onClick={onClose} className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                    Close
                  </button>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <div className="flex items-center gap-2">
              <Shield className="w-6 h-6" />
              <div>
                <h3 className="text-xl font-semibold">Recruiter Onboarding</h3>
                <p className="text-blue-100 text-sm">Step {step + 1} of {stepTitles.length}: {stepTitles[step]}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                {(() => {
                  const s = (user?.kycStatus || 'pending') as 'verified' | 'pending' | 'rejected';
                  const badge = s === 'verified' ? 'bg-green-100 text-green-800' : s === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800';
                  const label = s.charAt(0).toUpperCase() + s.slice(1);
                  return (<span className={`px-2 py-1 rounded text-xs font-medium ${badge}`}>Profile: {label}</span>);
                })()}
                {(() => {
                  const s = (profile?.bankStatus || 'missing') as 'verified' | 'pending' | 'missing';
                  const badge = s === 'verified' ? 'bg-green-100 text-green-800' : s === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800';
                  const label = s.charAt(0).toUpperCase() + s.slice(1);
                  return (<span className={`px-2 py-1 rounded text-xs font-medium ${badge}`}>Banking: {label}</span>);
                })()}
              </div>
              <button onClick={onClose} className="p-2 text-white/80 hover:text-white" aria-label="Close">
                <X className="w-6 h-6"/>
              </button>
            </div>
          </div>

          <div className="px-6 py-6">
            {/* Progress Indicator */}
            <div className="flex items-center justify-center gap-3 mb-8">
              {stepTitles.map((_, i) => (
                <div key={i} className="flex items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    i <= step ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
                  }`}>
                    {i < step ? <CheckCircle className="w-4 h-4" /> : i + 1}
                  </div>
                  {i < stepTitles.length - 1 && (
                    <div className={`w-12 h-1 mx-2 ${i < step ? 'bg-blue-600' : 'bg-gray-200'}`} />
                  )}
                </div>
              ))}
            </div>

            {/* Step Content */}
            <div className="min-h-[400px]">
              {step === 0 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <Building2 className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">Company Information</h4>
                    <p className="text-gray-600">Tell us about your recruitment business</p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <Building2 className="w-4 h-4 inline mr-1" />
                        Company Name *
                      </label>
                      <input 
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                        value={data.companyName || ''} 
                        onChange={e => setData(d => ({ ...d, companyName: e.target.value }))} 
                        placeholder="Your recruitment agency name" 
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <Globe className="w-4 h-4 inline mr-1" />
                        Company Website
                      </label>
                      <input 
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                        value={data.website || ''} 
                        onChange={e => setData(d => ({ ...d, website: e.target.value }))} 
                        placeholder="https://yourcompany.com" 
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <Hash className="w-4 h-4 inline mr-1" />
                        Business Registration Number
                      </label>
                      <input 
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                        value={data.registrationNumber || ''} 
                        onChange={e => setData(d => ({ ...d, registrationNumber: e.target.value }))} 
                        placeholder="Company registration number" 
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <User className="w-4 h-4 inline mr-1" />
                        Contact Person Name *
                      </label>
                      <input 
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                        value={data.contactName || ''} 
                        onChange={e => setData(d => ({ ...d, contactName: e.target.value }))} 
                        placeholder="Primary contact person" 
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <Mail className="w-4 h-4 inline mr-1" />
                        Contact Email *
                      </label>
                      <input 
                        type="email"
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                        value={data.contactEmail || ''} 
                        onChange={e => setData(d => ({ ...d, contactEmail: e.target.value }))} 
                        placeholder="contact@yourcompany.com" 
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <Phone className="w-4 h-4 inline mr-1" />
                        Contact Phone *
                      </label>
                      <input 
                        type="tel"
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                        value={data.contactPhone || ''} 
                        onChange={e => setData(d => ({ ...d, contactPhone: e.target.value }))} 
                        placeholder="+1 (555) 123-4567" 
                      />
                    </div>
                  </div>

                  {/* Company Logo Upload */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <ImageIcon className="w-4 h-4 inline mr-1" />
                      Company Logo
                    </label>
                    <div className="flex items-center gap-4">
                      {data.logoUrl && (
                        <div className="w-20 h-20 rounded-lg overflow-hidden border border-gray-300">
                          <img src={data.logoUrl} alt="Company logo" className="w-full h-full object-cover" />
                        </div>
                      )}
                      <div className="flex-1">
                        <input
                          type="file"
                          id="logo-upload"
                          accept="image/*"
                          onChange={handleLogoUpload}
                          className="hidden"
                          disabled={uploading}
                        />
                        <label
                          htmlFor="logo-upload"
                          className="inline-flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 cursor-pointer disabled:opacity-50"
                        >
                          <Upload className="w-4 h-4" />
                          {uploading ? 'Uploading...' : data.logoUrl ? 'Change Logo' : 'Upload Logo'}
                        </label>
                        <p className="text-xs text-gray-500 mt-1">Recommended: Square image, max 2MB</p>
                      </div>
                    </div>
                  </div>

                  {/* Company Description */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      About Your Company
                    </label>
                    <textarea
                      rows={4}
                      className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      value={data.about || ''}
                      onChange={e => setData(d => ({ ...d, about: e.target.value }))}
                      placeholder="Describe your recruitment agency, services, and areas of expertise..."
                    />
                  </div>

                  {/* Privacy Settings */}
                  <div className="space-y-3 p-4 bg-gray-50 rounded-lg">
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={data.publishProfile || false}
                        onChange={e => setData(d => ({ ...d, publishProfile: e.target.checked }))}
                        className="mt-1 w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                      />
                      <div>
                        <span className="text-sm font-medium text-gray-900">Make company profile public</span>
                        <p className="text-xs text-gray-600">Allow your company profile to be visible to candidates and employers</p>
                      </div>
                    </label>
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={data.publishEmail || false}
                        onChange={e => setData(d => ({ ...d, publishEmail: e.target.checked }))}
                        className="mt-1 w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                      />
                      <div>
                        <span className="text-sm font-medium text-gray-900">Show contact email publicly</span>
                        <p className="text-xs text-gray-600">Display your contact email on your public profile</p>
                      </div>
                    </label>
                  </div>
                </div>
              )}

              {step === 1 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <MapPin className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">Business Address</h4>
                    <p className="text-gray-600">Provide your registered business address</p>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Street Address *
                      </label>
                      <input 
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                        value={data.addressLine1 || ''} 
                        onChange={e => setData(d => ({ ...d, addressLine1: e.target.value }))} 
                        placeholder="123 Business Street" 
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          City *
                        </label>
                        <input
                          className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          value={data.city || ''}
                          onChange={e => setData(d => ({ ...d, city: e.target.value }))}
                          placeholder="City name"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Country *
                        </label>
                        <select
                          className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          value={data.country || ''}
                          onChange={e => setData(d => ({ ...d, country: e.target.value }))}
                        >
                          <option value="">Select country</option>
                          {countries.map(country => (
                            <option key={country} value={country}>{country}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Postal/Zip Code
                        </label>
                        <input
                          className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          value={data.postalCode || ''}
                          onChange={e => setData(d => ({ ...d, postalCode: e.target.value }))}
                          placeholder="Postal code"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <FileText className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">Business Documentation</h4>
                    <p className="text-gray-600">Upload required business documents for verification</p>
                  </div>
                  
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                    <h5 className="font-medium text-blue-900 mb-2">Required Documents</h5>
                    <ul className="text-sm text-blue-800 space-y-1">
                      <li>• Business registration certificate</li>
                      <li>• Professional liability insurance</li>
                      <li>• Tax identification documents</li>
                      <li>• Any relevant licenses or certifications</li>
                    </ul>
                  </div>
                  
                  <FileUploadZone 
                    options={{ 
                      bucket: 'documents', 
                      fileType: 'document', 
                      maxSize: 10 * 1024 * 1024,
                      allowedTypes: ['application/pdf', 'image/jpeg', 'image/png']
                    }} 
                    onUploadComplete={addDoc}
                    multiple={true}
                  />
                  
                  {(data.documents && data.documents.length > 0) && (
                    <div className="space-y-2">
                      <h5 className="font-medium text-gray-900">Uploaded Documents</h5>
                      {data.documents.map(doc => (
                        <div key={doc.id} className="flex items-center justify-between border border-gray-200 rounded-lg p-3 bg-gray-50">
                          <div className="flex items-center space-x-3">
                            <FileText className="w-5 h-5 text-gray-500" />
                            <div>
                              <div className="text-sm font-medium text-gray-900">{doc.name}</div>
                              <div className="text-xs text-gray-500">{doc.type}</div>
                            </div>
                          </div>
                          <button 
                            onClick={() => removeDoc(doc.id)} 
                            className="p-2 text-gray-500 hover:text-red-600 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {step === 3 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <CreditCard className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">Banking Details</h4>
                    <p className="text-gray-600">Provide banking information for payments. All fields are required.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Bank Name</label>
                      <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={data.bankName || ''} onChange={e=>setData(d=>({...d, bankName: e.target.value}))} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Bank Account Number</label>
                      <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={data.bankAccountNumber || ''} onChange={e=>setData(d=>({...d, bankAccountNumber: e.target.value}))} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Bank Account Holder Name</label>
                      <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={data.bankAccountHolderName || ''} onChange={e=>setData(d=>({...d, bankAccountHolderName: e.target.value}))} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Branch Name</label>
                      <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={data.branchName || ''} onChange={e=>setData(d=>({...d, branchName: e.target.value}))} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Bank Address Line 1</label>
                      <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={data.bankAddressLine1 || ''} onChange={e=>setData(d=>({...d, bankAddressLine1: e.target.value}))} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Bank Address Line 2</label>
                      <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={data.bankAddressLine2 || ''} onChange={e=>setData(d=>({...d, bankAddressLine2: e.target.value}))} />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">Bank Account Country</label>
                      <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={data.bankAccountCountry || ''} onChange={e=>setData(d=>({...d, bankAccountCountry: e.target.value}))} placeholder="e.g. New Zealand" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Currency</label>
                      <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={data.currency || ''} onChange={e=>setData(d=>({...d, currency: e.target.value}))} placeholder="e.g. NZD" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Clearing Code</label>
                      <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={data.clearingCode || ''} onChange={e=>setData(d=>({...d, clearingCode: e.target.value}))} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">IBAN</label>
                      <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={data.iban || ''} onChange={e=>setData(d=>({...d, iban: e.target.value}))} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">SWIFT Code</label>
                      <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={data.swiftCode || ''} onChange={e=>setData(d=>({...d, swiftCode: e.target.value}))} />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Account Holder Address Line 1</label>
                      <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={data.bankAccountHolderAddressLine1 || ''} onChange={e=>setData(d=>({...d, bankAccountHolderAddressLine1: e.target.value}))} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Account Holder Address Line 2</label>
                      <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={data.bankAccountHolderAddressLine2 || ''} onChange={e=>setData(d=>({...d, bankAccountHolderAddressLine2: e.target.value}))} />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">Account Holder Address Line 3</label>
                      <input className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" value={data.bankAccountHolderAddressLine3 || ''} onChange={e=>setData(d=>({...d, bankAccountHolderAddressLine3: e.target.value}))} />
                    </div>
                  </div>
                </div>
              )}

              {step === 4 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <CreditCard className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">Billing Information</h4>
                    <p className="text-gray-600">Enter your billing details for subscription payments</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <Mail className="w-4 h-4 inline mr-1" />
                        Billing Email *
                      </label>
                      <input
                        type="email"
                        required
                        value={billingData.billingEmail}
                        onChange={(e) => setBillingData(prev => ({ ...prev, billingEmail: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        placeholder="billing@company.com"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <Building2 className="w-4 h-4 inline mr-1" />
                        Company Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={billingData.billingCompanyName}
                        onChange={(e) => setBillingData(prev => ({ ...prev, billingCompanyName: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        placeholder="Company Inc."
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <Hash className="w-4 h-4 inline mr-1" />
                        Tax ID / VAT Number *
                      </label>
                      <input
                        type="text"
                        required
                        value={billingData.taxId}
                        onChange={(e) => setBillingData(prev => ({ ...prev, taxId: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        placeholder="12-3456789"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <MapPin className="w-4 h-4 inline mr-1" />
                        Country *
                      </label>
                      <select
                        required
                        value={billingData.billingCountry}
                        onChange={(e) => setBillingData(prev => ({ ...prev, billingCountry: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      >
                        <option value="US">United States</option>
                        <option value="CA">Canada</option>
                        <option value="GB">United Kingdom</option>
                        <option value="AU">Australia</option>
                        <option value="NZ">New Zealand</option>
                        <option value="SG">Singapore</option>
                        <option value="IN">India</option>
                        <option value="DE">Germany</option>
                        <option value="FR">France</option>
                      </select>
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Address Line 1 *
                      </label>
                      <input
                        type="text"
                        required
                        value={billingData.billingAddressLine1}
                        onChange={(e) => setBillingData(prev => ({ ...prev, billingAddressLine1: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        placeholder="123 Main Street"
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Address Line 2
                      </label>
                      <input
                        type="text"
                        value={billingData.billingAddressLine2}
                        onChange={(e) => setBillingData(prev => ({ ...prev, billingAddressLine2: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        placeholder="Suite 100"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        City *
                      </label>
                      <input
                        type="text"
                        required
                        value={billingData.billingCity}
                        onChange={(e) => setBillingData(prev => ({ ...prev, billingCity: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        placeholder="San Francisco"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        State / Province
                      </label>
                      <input
                        type="text"
                        value={billingData.billingState}
                        onChange={(e) => setBillingData(prev => ({ ...prev, billingState: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        placeholder="CA"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Postal / ZIP Code *
                      </label>
                      <input
                        type="text"
                        required
                        value={billingData.billingPostalCode}
                        onChange={(e) => setBillingData(prev => ({ ...prev, billingPostalCode: e.target.value }))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        placeholder="94103"
                      />
                    </div>
                  </div>
                </div>
              )}

              {step === 5 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <CreditCard className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">Subscription Plan</h4>
                    <p className="text-gray-600">Choose a plan now or skip and add it later in Billing.</p>
                  </div>
                  <div className="border border-gray-200 rounded-lg">
                    <SubscriptionManager onPlanSelect={() => setStep(s => Math.min(s + 1, stepTitles.length - 1))} />
                  </div>
                </div>
              )}

              {step === 6 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-3" />
                    <h4 className="text-lg font-semibold text-gray-900">Terms & Conditions</h4>
                    <p className="text-gray-600">Review and accept our recruiter agreement</p>
                  </div>
                  
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 max-h-64 overflow-y-auto">
                    <h5 className="font-medium text-gray-900 mb-3">Recruiter Agreement Summary</h5>
                    <div className="text-sm text-gray-700 space-y-2">
                      <p>By accepting these terms, you agree to:</p>
                      <ul className="list-disc list-inside space-y-1 ml-4">
                        <li>Provide accurate and truthful information about candidates</li>
                        <li>Obtain proper consent before representing candidates</li>
                        <li>Maintain confidentiality of candidate and client information</li>
                        <li>Comply with all applicable employment and privacy laws</li>
                        <li>Pay platform fees as outlined in the fee schedule</li>
                        <li>Provide guarantee periods as specified in your bids</li>
                        <li>Maintain professional standards and ethical practices</li>
                      </ul>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <label className="flex items-start gap-3">
                      <input 
                        type="checkbox" 
                        checked={data.acceptedTerms || false} 
                        onChange={e => setData(d => ({ ...d, acceptedTerms: e.target.checked }))}
                        className="mt-1 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                      <span className="text-sm text-gray-700">
                        I have read and agree to the{' '}
                        <a href="#" className="text-blue-600 hover:text-blue-700 underline">
                          Recruiter Agreement
                        </a>
                        {' '}and{' '}
                        <a href="#" className="text-blue-600 hover:text-blue-700 underline">
                          Privacy Policy
                        </a>
                      </span>
                    </label>
                    
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                      <h5 className="font-medium text-green-900 mb-2">What happens next?</h5>
                      <ul className="text-sm text-green-800 space-y-1">
                        <li>• Your profile will be reviewed by our team (typically 1-2 business days)</li>
                        <li>• You'll receive an email notification once verified</li>
                        <li>• After verification, you can start placing bids on open jobs</li>
                        <li>• You'll need to set up banking details for payment processing</li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Error Display */}
            {error && (
              <div className="mt-4 bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-center">
                  <X className="w-5 h-5 text-red-600 mr-2" />
                  <p className="text-red-800">{error}</p>
                </div>
              </div>
            )}

            {/* Navigation */}
            <div className="flex justify-between items-center pt-6 border-t border-gray-200 mt-8">
              <button
                onClick={prev}
                disabled={step === 0}
                className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Previous
              </button>

              <div className="flex items-center gap-3">
                <button
                  onClick={saveDraft}
                  disabled={submitting || readOnly}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm"
                >
                  Save Draft
                </button>
                <div className="text-sm text-gray-500">
                  Step {step + 1} of {stepTitles.length}
                </div>
              </div>

              {step < stepTitles.length - 1 ? (
                <button
                  onClick={handleNext}
                  className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Next
                </button>
              ) : (
                <button
                  onClick={submit}
                  disabled={submitting || !data.acceptedTerms}
                  className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  {submitting ? 'Submitting...' : 'Complete Onboarding'}
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OnboardingWizard;
