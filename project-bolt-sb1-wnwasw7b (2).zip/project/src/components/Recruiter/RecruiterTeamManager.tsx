import React from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';

const RecruiterTeamManager: React.FC<{ onClose?: () => void }> = ({ onClose }) => {
  const { user } = useAuth();
  const [members, setMembers] = React.useState<any[]>([]);
  const [email, setEmail] = React.useState('');
  const [loading, setLoading] = React.useState(true);
  const [inviting, setInviting] = React.useState(false);

  const load = async () => {
    if (!user?.organizationId) { setMembers([]); setLoading(false); return; }
    setLoading(true);
    const { data, error } = await supabase
      .from('profiles')
      .select('id, email, name, role')
      .eq('organization_id', user.organizationId)
      .eq('role', 'recruiter')
      .order('created_at', { ascending: false });
    if (!error) setMembers(data || []);
    setLoading(false);
  };
  React.useEffect(()=>{ load(); }, [user?.organizationId]);

  const invite = async () => {
    if (!email.trim() || !user?.organizationId) return;
    setInviting(true);
    try {
      // Create invitation record
      const { data: invitation, error } = await supabase
        .from('team_invitations')
        .insert({
          org_id: user.organizationId,
          invited_by: user.id,
          invitee_email: email.trim().toLowerCase(),
          role: 'recruiter',
          status: 'pending'
        } as any)
        .select('id')
        .single();

      if (error) {
        console.warn('team_invitations table missing, falling back to console log:', error.message);
        console.log('Invite recruiter team member:', email.trim(), 'org', user.organizationId);
        throw error;
      }

      // Get organization name
      const { data: org } = await supabase
        .from('organizations')
        .select('name')
        .eq('id', user.organizationId)
        .single();

      // Send invitation email via edge function
      let invitationLink = '';
      try {
        const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-team-invitation`;
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            invitationId: invitation.id,
            inviteeEmail: email.trim().toLowerCase(),
            inviterName: user.name,
            organizationName: org?.name || 'Your Organization',
            role: 'recruiter',
            appUrl: window.location.origin,
          }),
        });

        const result = await response.json();
        console.log('Email send result:', result);
        invitationLink = result.invitationLink;
      } catch (emailError) {
        console.warn('Failed to send email, but invitation was created:', emailError);
      }

      setEmail('');
      load();

      // Show invitation link to user for manual sharing
      if (invitationLink) {
        alert(`Invitation created! Share this link with ${email.trim()}:\n\n${invitationLink}\n\nNote: Email delivery requires SMTP configuration. For now, please share this link manually.`);
      } else {
        alert('Invitation created! The invitation has been recorded in the system.');
      }
    } catch (e: any) {
      alert(e?.message || 'Failed to invite');
    } finally {
      setInviting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Team Members</h3>
        {onClose && <button onClick={onClose} className="px-2 py-1 border rounded text-sm">Close</button>}
      </div>
      <div className="bg-gray-50 border rounded p-3 flex items-center gap-2">
        <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="invitee@agency.com" className="flex-1 border rounded px-3 py-2" />
        <button onClick={invite} disabled={inviting} className="px-3 py-2 bg-blue-600 text-white rounded">{inviting?'Sending…':'Invite'}</button>
      </div>
      {loading ? (
        <div className="text-sm text-gray-600">Loading…</div>
      ) : (
        <div className="overflow-auto border rounded">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left px-3 py-2">Name</th>
                <th className="text-left px-3 py-2">Email</th>
                <th className="text-left px-3 py-2">Role</th>
              </tr>
            </thead>
            <tbody>
              {members.map(m => (
                <tr key={m.id} className="border-t">
                  <td className="px-3 py-2 font-medium text-gray-900">{m.name || '—'}</td>
                  <td className="px-3 py-2">{m.email}</td>
                  <td className="px-3 py-2">{m.role}</td>
                </tr>
              ))}
              {members.length === 0 && (
                <tr><td className="px-3 py-6 text-center text-gray-600" colSpan={3}>No team members yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default RecruiterTeamManager;

