import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useAnalytics } from '../../hooks/useAnalytics';
import { useAuditLog } from '../../hooks/useAuditLog';
import AnalyticsDashboard from '../Admin/AnalyticsDashboard';
import UserManagement from '../Admin/UserManagement';
import AuditLogViewer from '../Admin/AuditLogViewer';
import PlatformSettings from '../Admin/PlatformSettings';
import { usePendingRecruiters } from '../../hooks/usePendingRecruiters';
import type { RecruiterProfile } from '../../hooks/useRecruiterProfile';
import { supabase } from '../../lib/supabase';
import toast from 'react-hot-toast';
import { useRecruiterBankStatuses } from '../../hooks/useRecruiterBankStatuses';
import { 
  Users, 
  Briefcase, 
  DollarSign, 
  TrendingUp,
  Shield,
  AlertTriangle,
  CheckCircle,
  Clock,
  Settings,
  BarChart3,
  Activity,
  FileText
} from 'lucide-react';
import AdminEscrowManager from '../Admin/AdminEscrowManager';
import AdminSubscriptionsManager from '../Admin/AdminSubscriptionsManager';
import AdminUsersOrgs from '../Admin/AdminUsersOrgs';
import AdminEscrowSchedule from '../Admin/AdminEscrowSchedule';
import BatchResumeParser from '../Admin/BatchResumeParser';

const AdminDashboard: React.FC = () => {
  const { user } = useAuth();
  const { platformMetrics, loading: analyticsLoading } = useAnalytics();
  const { auditLogs } = useAuditLog();
  const [activeTab, setActiveTab] = useState('overview');
  const [statusFilter, setStatusFilter] = useState<'pending'|'verified'|'rejected'>('pending');
  const { items: pendingRecruiters, loading: pendingLoading, error: pendingError, refetch } = usePendingRecruiters(statusFilter);
  const [actioningId, setActioningId] = useState<string | null>(null);
  const [showSummary, setShowSummary] = useState<null | { id: string; name: string | null; email: string | null; submittedAt: string | null }>(null);
  const [diagOpen, setDiagOpen] = useState(false);
  const [diagLoading, setDiagLoading] = useState(false);
  const [diagResults, setDiagResults] = useState<Array<{ status: 'pending'|'verified'|'rejected'; count: number; error?: string | null }>>([]);
  const [diagSample, setDiagSample] = useState<{ id: string; email: string; role: string; kyc_status: string } | null>(null);
  const [diagError, setDiagError] = useState<string | null>(null);
  const [showEscrowManager, setShowEscrowManager] = useState(false);

  const runDiagnostics = async () => {
    setDiagOpen(true);
    setDiagLoading(true);
    setDiagError(null);
    setDiagResults([]);
    try {
      const statuses: Array<'pending'|'verified'|'rejected'> = ['pending','verified','rejected'];
      const results: Array<{ status: 'pending'|'verified'|'rejected'; count: number; error?: string | null }> = [];
      for (const s of statuses) {
        const { count, error } = await supabase
          .from('profiles')
          .select('*', { head: true, count: 'exact' })
          .eq('role', 'recruiter')
          .eq('kyc_status', s);
        results.push({ status: s, count: count || 0, error: (error as any)?.message || null });
      }
      setDiagResults(results);

      const { data: sample, error: sampleErr } = await supabase
        .from('profiles')
        .select('id, email, role, kyc_status')
        .eq('role', 'recruiter')
        .limit(1);
      if (sampleErr) setDiagError((sampleErr as any).message || String(sampleErr));
      setDiagSample((sample && sample[0]) ? sample[0] as any : null);
    } catch (e: any) {
      setDiagError(e?.message || 'Diagnostics failed');
    } finally {
      setDiagLoading(false);
    }
  };

  // Load full recruiter profile from recruiter_profiles for admin view
  const [showFullProfile, setShowFullProfile] = useState(false);
  const [fullProfile, setFullProfile] = useState<RecruiterProfile | null>(null);
  const [fullProfileName, setFullProfileName] = useState<string>('');
  const openFullProfile = async (userId: string, displayName: string) => {
    try {
      setFullProfile(null);
      setFullProfileName(displayName);
      const { data, error } = await supabase
        .from('recruiter_profiles')
        .select('profile_json')
        .eq('user_id', userId)
        .maybeSingle();
      console.log('Admin view recruiter_profiles fetch:', { userId, data, error });
      if (error) {
        toast.error(error.message || 'Failed to load recruiter profile');
        return;
      }
      if (!data || !data.profile_json) {
        toast('No recruiter profile data found for this user', { icon: 'ℹ️' });
        return;
      }
      setFullProfile(data.profile_json as RecruiterProfile);
      setShowFullProfile(true);
    } catch (e: any) {
      console.error('Admin profile fetch error:', e);
      toast.error(e?.message || 'Error loading profile');
    }
  };

  const stats = platformMetrics ? [
    { icon: <Users className="w-6 h-6" />, label: 'Total Users', value: platformMetrics.totalUsers.toLocaleString(), change: '+12%', color: 'blue' },
    { icon: <Briefcase className="w-6 h-6" />, label: 'Active Jobs', value: platformMetrics.totalJobs.toLocaleString(), change: '+8%', color: 'green' },
    { icon: <DollarSign className="w-6 h-6" />, label: 'Revenue (MTD)', value: `$${platformMetrics.totalRevenue.toLocaleString()}`, change: '+15%', color: 'purple' },
    { icon: <TrendingUp className="w-6 h-6" />, label: 'Success Rate', value: `${platformMetrics.conversionRate}%`, change: '+3%', color: 'orange' },
  ] : [
    { icon: <Users className="w-6 h-6" />, label: 'Total Users', value: '2,847', change: '+12%', color: 'blue' },
    { icon: <Briefcase className="w-6 h-6" />, label: 'Active Jobs', value: '156', change: '+8%', color: 'green' },
    { icon: <DollarSign className="w-6 h-6" />, label: 'Revenue (MTD)', value: '$28,340', change: '+15%', color: 'purple' },
    { icon: <TrendingUp className="w-6 h-6" />, label: 'Success Rate', value: '89%', change: '+3%', color: 'orange' },
  ];

  const pendingVerifications = pendingRecruiters.map(r => ({
    id: r.id,
    name: r.name || r.email || r.id,
    type: 'Recruiter',
    requestedAt: r.submittedAt ? new Date(r.submittedAt).toLocaleDateString() : '—',
    documents: 0,
  }));
  const { statuses: bankStatuses, refetch: refetchBankStatuses } = useRecruiterBankStatuses(pendingVerifications.map(v => v.id));
  const { items: verifiedRecruiters, loading: verifiedLoading, error: verifiedError, refetch: refetchVerified } = usePendingRecruiters('verified');
  const { statuses: bankVerifiedStatuses, refetch: refetchBankVerifiedStatuses } = useRecruiterBankStatuses(verifiedRecruiters.map(v => v.id));
  const [bankingFilter, setBankingFilter] = useState<'needs'|'verified'|'all'>('needs');
  const totalVerifiedCount = verifiedRecruiters.length;
  const needsBankCount = verifiedRecruiters.filter(r => (bankVerifiedStatuses[r.id] || 'missing') !== 'verified').length;
  const hasBankVerifiedCount = verifiedRecruiters.filter(r => bankVerifiedStatuses[r.id] === 'verified').length;

  const disputes = [
    { id: 1, jobTitle: 'Senior Developer', employer: 'TechCorp', recruiter: 'Elite Recruiters', amount: '$25,000', status: 'pending' },
    { id: 2, jobTitle: 'Product Manager', employer: 'StartupXYZ', recruiter: 'Talent Pro', amount: '$18,000', status: 'under_review' },
  ];

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'analytics', label: 'Analytics' },
    { id: 'users', label: 'Users' },
    { id: 'users-orgs', label: 'Users & Orgs' },
    { id: 'verification', label: 'Verification Queue' },
    { id: 'resume-parser', label: 'Resume Parser' },
    { id: 'banking', label: 'Banking Verification' },
    { id: 'audit', label: 'Audit Logs' },
    { id: 'disputes', label: 'Disputes' },
    { id: 'plans', label: 'Subscription Plans' },
    { id: 'escrow-schedule', label: 'Escrow Schedule' },
    { id: 'settings', label: 'Platform Settings' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
            <p className="text-gray-600 mt-1">Manage platform operations and users</p>
          </div>
          <div className="flex items-center space-x-3">
            <div className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium">
              {pendingLoading ? '…' : pendingVerifications.length} Pending Reviews
            </div>
            <Shield className="w-6 h-6 text-gray-400" />
            <button onClick={()=>setShowEscrowManager(true)} className="px-3 py-1.5 text-sm border rounded hover:bg-gray-50">Escrow Manager</button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div className={`p-3 rounded-lg bg-${stat.color}-100`}>
                  <div className={`text-${stat.color}-600`}>
                    {stat.icon}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-green-600 font-medium">{stat.change}</div>
                </div>
              </div>
              <div className="mt-4">
                <h3 className="text-2xl font-bold text-gray-900">{stat.value}</h3>
                <p className="text-gray-600 text-sm">{stat.label}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-8">
        <nav className="-mb-px flex space-x-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              {tab.label}
              {tab.id === 'banking' && (
                <span className="ml-2 text-xs px-2 py-0.5 rounded-full bg-yellow-100 text-yellow-800 align-middle">
                  {needsBankCount}
                </span>
              )}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Pending Verifications</h3>
              <div className="space-y-4">
                {pendingVerifications.map((verification) => (
                  <div key={verification.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">{verification.name}</p>
                      <p className="text-sm text-gray-600">{verification.type} • {verification.documents} documents</p>
                      <p className="text-xs text-gray-500">{verification.requestedAt}</p>
                    </div>
                    <div className="flex space-x-2">
                      <button
                        className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700"
                        onClick={async () => {
                          try {
                            const { error } = await supabase.from('profiles').update({ kyc_status: 'verified' }).eq('id', verification.id);
                            if (error) throw error as any;
                            toast.success('Profile approved');
                          } catch (e:any) {
                            toast.error(e?.message || 'Failed to approve');
                          }
                        }}
                      >
                        Approve
                      </button>
                      <button
                        className="px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700"
                        onClick={async () => {
                          try {
                            const { error } = await supabase.from('profiles').update({ kyc_status: 'rejected' }).eq('id', verification.id);
                            if (error) throw error as any;
                            toast('Profile rejected', { icon: '⚠️' });
                          } catch (e:any) {
                            toast.error(e?.message || 'Failed to reject');
                          }
                        }}
                      >
                        Reject
                      </button>
                      <button
                        className="px-3 py-1 bg-indigo-600 text-white rounded text-sm hover:bg-indigo-700"
                        onClick={() => setActiveTab('banking')}
                        title="Go to Banking Verification"
                      >
                        Verify Banking
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Active Disputes</h3>
              <div className="space-y-4">
                {disputes.map((dispute) => (
                  <div key={dispute.id} className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-gray-900">{dispute.jobTitle}</p>
                        <p className="text-sm text-gray-600">{dispute.employer} vs {dispute.recruiter}</p>
                        <p className="text-sm font-medium text-gray-900">{dispute.amount}</p>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        dispute.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {dispute.status.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'analytics' && <AnalyticsDashboard />}

      {activeTab === 'users' && (
        <UserManagement />
      )}

      {activeTab === 'users-orgs' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <AdminUsersOrgs />
        </div>
      )}

      {activeTab === 'audit' && <AuditLogViewer />}

      {activeTab === 'verification' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Verification Queue</h3>
            <div className="flex gap-2">
              <button
                onClick={() => refetch()}
                className="px-3 py-1 rounded-full text-sm border bg-white text-gray-700 border-gray-300"
                title="Refresh list"
              >
                Refresh
              </button>
              <button
                onClick={() => setActiveTab('banking')}
                className="px-3 py-1 rounded-full text-sm border bg-white text-gray-700 border-gray-300"
                title="Go to Banking Verification"
              >
                Banking Verification
              </button>
              <button
                onClick={runDiagnostics}
                className="px-3 py-1 rounded-full text-sm border bg-white text-gray-700 border-gray-300"
                title="Run policy diagnostics"
              >
                Diagnostics
              </button>
              {(['pending','verified','rejected'] as const).map(s => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={`px-3 py-1 rounded-full text-sm border ${statusFilter===s?'bg-blue-600 text-white border-blue-600':'bg-white text-gray-700 border-gray-300'}`}
                >
                  {s.charAt(0).toUpperCase()+s.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {diagOpen && (
            <div className="mb-4 p-4 border border-gray-200 rounded-lg bg-gray-50">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-gray-900">Diagnostics</h4>
                <button onClick={()=>setDiagOpen(false)} className="text-sm text-gray-600 hover:text-gray-800">Close</button>
              </div>
              {diagLoading ? (
                <div className="text-sm text-gray-500">Running diagnostics…</div>
              ) : (
                <div className="space-y-2 text-sm">
                  {diagError && (
                    <div className="text-red-700 bg-red-50 border border-red-200 rounded p-2">{diagError}</div>
                  )}
                  <div className="text-gray-800">
                    Status counts (recruiters only):
                  </div>
                  <ul className="list-disc list-inside text-gray-700">
                    {diagResults.map(r => (
                      <li key={r.status}>
                        {r.status}: {r.count} {r.error ? (<span className="text-red-700">(error: {r.error})</span>) : null}
                      </li>
                    ))}
                  </ul>
                  <div className="text-gray-800 mt-2">Sample recruiter row (if visible to this user):</div>
                  <pre className="text-xs bg-white border border-gray-200 rounded p-2 overflow-auto">{JSON.stringify(diagSample, null, 2)}</pre>
                  <div className="text-xs text-gray-500 mt-1">
                    If counts are zero and/or errors mention permission denied, update RLS to allow admins to select profiles and recruiters to update their own kyc_status.
                  </div>
                </div>
              )}
            </div>
          )}
          <div className="space-y-6">
            {pendingLoading && (
              <div className="text-sm text-gray-500">Loading pending recruiter profiles…</div>
            )}
            {pendingError && (
              <div className="text-sm text-red-700 bg-red-50 border border-red-200 rounded p-2">{pendingError}</div>
            )}
            {!pendingLoading && pendingVerifications.length === 0 && !pendingError && (
              <div className="text-sm text-gray-500">No pending recruiter submissions found.</div>
            )}
            {pendingVerifications.map((verification) => (
              <div key={verification.id} className="border border-gray-200 rounded-lg p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900">{verification.name}</h4>
                    <p className="text-gray-600">{verification.type} Account</p>
                    <p className="text-sm text-gray-500 mt-2">
                      Submitted: {verification.requestedAt} • {verification.documents} documents
                    </p>
                    
                    <div className="mt-4">
                      <h5 className="text-sm font-medium text-gray-700 mb-2">Documents:</h5>
                      <div className="flex space-x-2">
                        <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">Business License</span>
                        <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">Tax ID</span>
                        <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">Insurance</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-3 ml-6">
                    <button 
                      className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                      onClick={() => setShowSummary({ id: verification.id, name: verification.name, email: pendingRecruiters.find(p=>p.id===verification.id)?.email || null, submittedAt: pendingRecruiters.find(p=>p.id===verification.id)?.submittedAt || null })}
                    >
                      View Details
                    </button>
                    <button
                      className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                      onClick={() => openFullProfile(verification.id, verification.name)}
                    >
                      View Full Profile
                    </button>
                    <button 
                      className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
                      disabled={!!actioningId}
                      onClick={async () => {
                        setActioningId(verification.id);
                        try {
                          const { error } = await supabase.from('profiles').update({ kyc_status: 'verified' }).eq('id', verification.id);
                          if (error) throw error as any;
                          await refetch();
                          toast.success('Profile approved');
                        } catch (e:any) {
                          toast.error(e?.message || 'Failed to approve profile');
                        } finally {
                          setActioningId(null);
                        }
                      }}
                    >
                      <CheckCircle className="w-4 h-4 inline mr-1" />
                      Approve
                    </button>
                    <button 
                      className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50"
                      disabled={!!actioningId}
                      onClick={async () => {
                        setActioningId(verification.id);
                        try {
                          const { error } = await supabase.from('profiles').update({ kyc_status: 'rejected' }).eq('id', verification.id);
                          if (error) throw error as any;
                          await refetch();
                          toast('Profile rejected', { icon: '⚠️' });
                        } catch (e:any) {
                          toast.error(e?.message || 'Failed to reject profile');
                        } finally {
                          setActioningId(null);
                        }
                      }}
                    >
                      <AlertTriangle className="w-4 h-4 inline mr-1" />
                      Reject
                    </button>
                    <button
                      className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50"
                      disabled={!!actioningId}
                      onClick={async () => {
                        setActioningId(verification.id);
                        try {
                          console.log('[Banking] Verify (queue) requested', { userId: verification.id });
                          const { data: rp, error: rpErr } = await supabase
                            .from('recruiter_profiles')
                            .select('profile_json')
                            .eq('user_id', verification.id)
                            .maybeSingle();
                          if (rpErr) throw rpErr as any;
                          if (!rp || !rp.profile_json) throw new Error('No recruiter profile found');
                          const updated = { ...(rp.profile_json as any), bankStatus: 'verified' };
                          const { error: upErr } = await supabase
                            .from('recruiter_profiles')
                            .update({ profile_json: updated })
                            .eq('user_id', verification.id);
                          if (upErr) throw upErr as any;
                          toast.success('Banking verified');
                          await Promise.all([refetchBankStatuses(), refetchBankVerifiedStatuses()]);
                          console.log('[Banking] Verify (queue) refreshed');
                        } catch (e:any) {
                          toast.error(e?.message || 'Failed to verify banking');
                        } finally {
                          setActioningId(null);
                        }
                      }}
                    >
                      Verify Banking
                    </button>
                    <button
                      className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 disabled:opacity-50"
                      disabled={!!actioningId}
                      onClick={async () => {
                        setActioningId(verification.id);
                        try {
                          console.log('[Banking] Set Pending (queue) requested', { userId: verification.id });
                          const { data: rp, error: rpErr } = await supabase
                            .from('recruiter_profiles')
                            .select('profile_json')
                            .eq('user_id', verification.id)
                            .maybeSingle();
                          if (rpErr) throw rpErr as any;
                          if (!rp || !rp.profile_json) throw new Error('No recruiter profile found');
                          const updated = { ...(rp.profile_json as any), bankStatus: 'pending' };
                          const { error: upErr } = await supabase
                            .from('recruiter_profiles')
                            .update({ profile_json: updated })
                            .eq('user_id', verification.id);
                          if (upErr) throw upErr as any;
                          toast('Banking set to pending', { icon: 'ℹ️' });
                          await Promise.all([refetchBankStatuses(), refetchBankVerifiedStatuses()]);
                          console.log('[Banking] Set Pending (queue) refreshed');
                        } catch (e:any) {
                          toast.error(e?.message || 'Failed to update banking status');
                        } finally {
                          setActioningId(null);
                        }
                      }}
                    >
                      Set Banking Pending
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'banking' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Banking Verification</h3>
            <div className="flex gap-2">
              <button
                onClick={() => { refetchVerified(); }}
                className="px-3 py-1 rounded-full text-sm border bg-white text-gray-700 border-gray-300"
                title="Refresh list"
              >
                Refresh
              </button>
              {(['needs','verified','all'] as const).map(f => (
                <button
                  key={f}
                  onClick={() => setBankingFilter(f)}
                  className={`px-3 py-1 rounded-full text-sm border ${bankingFilter===f?'bg-blue-600 text-white border-blue-600':'bg-white text-gray-700 border-gray-300'}`}
                  title={f==='needs' ? 'Needs action' : f==='verified' ? 'Banking verified' : 'All verified recruiters'}
                >
                  {f==='needs' ? `Needs Action (${needsBankCount})` : f==='verified' ? `Verified (${hasBankVerifiedCount})` : `All (${totalVerifiedCount})`}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-6">
            {verifiedLoading && (
              <div className="text-sm text-gray-500">Loading verified recruiter profiles…</div>
            )}
            {verifiedError && (
              <div className="text-sm text-red-700 bg-red-50 border border-red-200 rounded p-2">{verifiedError}</div>
            )}
            {!verifiedLoading && verifiedRecruiters.length === 0 && !verifiedError && (
              <div className="text-sm text-gray-500">No KYC-verified recruiters found.</div>
            )}
            {verifiedRecruiters
              .filter(r => bankingFilter==='all' ? true : bankingFilter==='verified' ? (bankVerifiedStatuses[r.id] === 'verified') : ((bankVerifiedStatuses[r.id] || 'missing') !== 'verified'))
              .map((r) => (
              <div key={r.id} className="border border-gray-200 rounded-lg p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900">{r.name || r.email || r.id}</h4>
                    <p className="text-gray-600">Recruiter Account</p>
                    <div className="mt-2">
                      {(() => {
                        const s = bankVerifiedStatuses[r.id] || 'missing';
                        const badge = s === 'verified' ? 'bg-green-100 text-green-800' : s === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-700';
                        const label = s.charAt(0).toUpperCase() + s.slice(1);
                        return (
                          <span className={`px-2 py-1 rounded text-xs font-medium ${badge}`}>Banking: {label}</span>
                        );
                      })()}
                    </div>
                  </div>
                  <div className="flex space-x-3 ml-6">
                    <button
                      className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                      onClick={() => openFullProfile(r.id, r.name || r.email || r.id)}
                    >
                      View Full Profile
                    </button>
                    <button
                      className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50"
                      disabled={!!actioningId}
                      onClick={async () => {
                        setActioningId(r.id);
                        try {
                          console.log('[Banking] Verify (banking tab) requested', { userId: r.id });
                          const { data: rp, error: rpErr } = await supabase
                            .from('recruiter_profiles')
                            .select('profile_json')
                            .eq('user_id', r.id)
                            .maybeSingle();
                          if (rpErr) throw rpErr as any;
                          if (!rp || !rp.profile_json) throw new Error('No recruiter profile found');
                          const updated = { ...(rp.profile_json as any), bankStatus: 'verified' };
                          const { error: upErr } = await supabase
                            .from('recruiter_profiles')
                            .update({ profile_json: updated })
                            .eq('user_id', r.id);
                          if (upErr) throw upErr as any;
                          toast.success('Banking verified');
                          await Promise.all([refetchVerified(), refetchBankVerifiedStatuses()]);
                          console.log('[Banking] Verify (banking tab) refreshed');
                        } catch (e:any) {
                          toast.error(e?.message || 'Failed to verify banking');
                        } finally {
                          setActioningId(null);
                        }
                      }}
                    >
                      Verify Banking
                    </button>
                    <button
                      className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 disabled:opacity-50"
                      disabled={!!actioningId}
                      onClick={async () => {
                        setActioningId(r.id);
                        try {
                          console.log('[Banking] Set Pending (banking tab) requested', { userId: r.id });
                          const { data: rp, error: rpErr } = await supabase
                            .from('recruiter_profiles')
                            .select('profile_json')
                            .eq('user_id', r.id)
                            .maybeSingle();
                          if (rpErr) throw rpErr as any;
                          if (!rp || !rp.profile_json) throw new Error('No recruiter profile found');
                          const updated = { ...(rp.profile_json as any), bankStatus: 'pending' };
                          const { error: upErr } = await supabase
                            .from('recruiter_profiles')
                            .update({ profile_json: updated })
                            .eq('user_id', r.id);
                          if (upErr) throw upErr as any;
                          toast('Banking set to pending', { icon: 'ℹ️' });
                          await Promise.all([refetchVerified(), refetchBankVerifiedStatuses()]);
                          console.log('[Banking] Set Pending (banking tab) refreshed');
                        } catch (e:any) {
                          toast.error(e?.message || 'Failed to update banking status');
                        } finally {
                          setActioningId(null);
                        }
                      }}
                    >
                      Set Banking Pending
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {showSummary && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-xl shadow-2xl border border-gray-200">
            <div className="flex items-center justify-between px-4 py-3 border-b">
              <h4 className="font-semibold text-gray-900">Recruiter Submission</h4>
              <button onClick={()=>setShowSummary(null)} className="text-gray-500 hover:text-gray-700">Close</button>
            </div>
            <div className="p-4 space-y-2 text-sm text-gray-800">
              <div><span className="text-gray-600">Company/Name:</span> {showSummary.name || '—'}</div>
              <div><span className="text-gray-600">Email:</span> {showSummary.email || '—'}</div>
              <div><span className="text-gray-600">Submitted:</span> {showSummary.submittedAt ? new Date(showSummary.submittedAt).toLocaleString() : '—'}</div>
              <div className="mt-3 text-gray-600">
                Full profile details require the Supabase table <code className="px-1">recruiter_profiles</code> to be configured. For now, this shows summary info from profiles.
              </div>
            </div>
            <div className="px-4 py-3 border-t flex justify-end gap-2">
              <button onClick={()=>setShowSummary(null)} className="px-4 py-2 border border-gray-300 rounded-lg">Close</button>
            </div>
          </div>
        </div>
      )}

      {showFullProfile && fullProfile && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-3xl rounded-xl shadow-2xl border border-gray-200">
            <div className="flex items-center justify-between px-4 py-3 border-b">
              <h4 className="font-semibold text-gray-900">Recruiter Profile — {fullProfileName}</h4>
              <button onClick={()=>setShowFullProfile(false)} className="text-gray-500 hover:text-gray-700">Close</button>
            </div>
            <div className="p-6 space-y-6 text-sm text-gray-800">
              <div>
                {(() => {
                  const s = (fullProfile?.bankStatus || 'missing') as 'verified'|'pending'|'missing';
                  const badge = s === 'verified' ? 'bg-green-100 text-green-800' : s === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-700';
                  const label = s.charAt(0).toUpperCase() + s.slice(1);
                  return (<span className={`px-2 py-1 rounded text-xs font-medium ${badge}`}>Banking: {label}</span>);
                })()}
              </div>
              <section>
                <h5 className="font-medium text-gray-900 mb-2">Company</h5>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div><span className="text-gray-600">Company Name:</span> {fullProfile.companyName || '-'}</div>
                  <div><span className="text-gray-600">Website:</span> {fullProfile.website || '-'}</div>
                  <div><span className="text-gray-600">Registration #:</span> {fullProfile.registrationNumber || '-'}</div>
                </div>
              </section>
              <section>
                <h5 className="font-medium text-gray-900 mb-2">Contact</h5>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div><span className="text-gray-600">Name:</span> {fullProfile.contactName || '-'}</div>
                  <div><span className="text-gray-600">Email:</span> {fullProfile.contactEmail || '-'}</div>
                  <div><span className="text-gray-600">Phone:</span> {fullProfile.contactPhone || '-'}</div>
                </div>
              </section>
              <section>
                <h5 className="font-medium text-gray-900 mb-2">Business Address</h5>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div><span className="text-gray-600">Address Line 1:</span> {fullProfile.addressLine1 || '-'}</div>
                  <div><span className="text-gray-600">City:</span> {fullProfile.city || '-'}</div>
                  <div><span className="text-gray-600">Country:</span> {fullProfile.country || '-'}</div>
                </div>
              </section>
              <section>
                <h5 className="font-medium text-gray-900 mb-2">Documents</h5>
                {(fullProfile.documents?.length || 0) === 0 ? (
                  <div className="text-gray-600">No documents uploaded</div>
                ) : (
                  <ul className="list-disc list-inside">
                    {fullProfile.documents!.map(d => (
                      <li key={d.id}>{d.name} {d.url ? (<a className="text-blue-600 underline ml-1" href={d.url} target="_blank" rel="noreferrer">View</a>) : null}</li>
                    ))}
                  </ul>
                )}
              </section>
              <section>
                <h5 className="font-medium text-gray-900 mb-2">Banking</h5>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div><span className="text-gray-600">Bank Name:</span> {fullProfile.bankName || '-'}</div>
                  <div><span className="text-gray-600">Account #:</span> {fullProfile.bankAccountNumber || '-'}</div>
                  <div><span className="text-gray-600">Account Holder:</span> {fullProfile.bankAccountHolderName || '-'}</div>
                  <div><span className="text-gray-600">Branch:</span> {fullProfile.branchName || '-'}</div>
                  <div><span className="text-gray-600">Status:</span> {fullProfile.bankStatus || 'missing'}</div>
                </div>
              </section>
              <section className="text-xs text-gray-500">
                Submitted: {fullProfile.acceptedAt ? new Date(fullProfile.acceptedAt).toLocaleString() : '—'} • Terms accepted: {fullProfile.acceptedTerms ? 'Yes' : 'No'}
              </section>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'disputes' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Dispute Management</h3>
          <div className="space-y-6">
            {disputes.map((dispute) => (
              <div key={dispute.id} className="border border-gray-200 rounded-lg p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900">{dispute.jobTitle}</h4>
                    <div className="mt-2 grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">Employer</p>
                        <p className="font-medium">{dispute.employer}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Recruiter</p>
                        <p className="font-medium">{dispute.recruiter}</p>
                      </div>
                    </div>
                    <div className="mt-2">
                      <p className="text-sm text-gray-600">Dispute Amount</p>
                      <p className="font-bold text-lg">{dispute.amount}</p>
                    </div>
                  </div>
                  
                  <div className="flex flex-col space-y-2 ml-6">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      dispute.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {dispute.status.replace('_', ' ')}
                    </span>
                    <div className="flex space-x-2">
                      <button className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700">
                        Review
                      </button>
                      <button className="px-3 py-1 bg-gray-600 text-white rounded text-sm hover:bg-gray-700">
                        Messages
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'plans' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <AdminSubscriptionsManager />
        </div>
      )}

      {activeTab === 'escrow-schedule' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <AdminEscrowSchedule />
        </div>
      )}

      {activeTab === 'resume-parser' && (
        <div className="space-y-6">
          <BatchResumeParser />
        </div>
      )}

      {activeTab === 'settings' && (
        <PlatformSettings />
      )}
      {showEscrowManager && (
        <AdminEscrowManager onClose={()=>setShowEscrowManager(false)} />
      )}
    </div>
  );
};

export default AdminDashboard;
// Modal mounts
// (App container renders AdminDashboard; we mount here for simplicity)
