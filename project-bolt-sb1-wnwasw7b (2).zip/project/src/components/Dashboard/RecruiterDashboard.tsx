import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useJobs } from '../../hooks/useJobs';
import { useRecruiterBids } from '../../hooks/useRecruiterBids';
import { useConsentRequests } from '../../hooks/useConsentRequests';
import JobSearch from '../Jobs/JobSearch';
import RecruiterBidCard from '../Bids/RecruiterBidCard';
import ConsentRequestForm from '../Consents/ConsentRequestForm';
import ConsentPoliciesManager from '../Consents/ConsentPoliciesManager';
import ConsentCard from '../Consents/ConsentCard';
import BidForm from '../Bids/BidForm';
import { useBidEligibility } from '../../hooks/useBidEligibility';
import VerificationRequest from '../Recruiter/VerificationRequest';
import OnboardingWizard from '../Recruiter/OnboardingWizard';
import { useRecruiterProfile } from '../../hooks/useRecruiterProfile';
import { 
  Search, 
  Filter, 
  TrendingUp, 
  DollarSign, 
  Clock, 
  Users,
  Eye,
  CheckCircle,
  X
} from 'lucide-react';
import { useSubscriptions } from '../../hooks/useSubscriptions';
import BillingDashboard from '../Billing/BillingDashboard';
import EmployerTeamManager from '../Organizations/EmployerTeamManager';
import ScheduledPaymentsDashboard from '../Payments/ScheduledPaymentsDashboard';

const RecruiterDashboard: React.FC = () => {
  const { user } = useAuth();
  const { jobs } = useJobs();
  const { bids, loading: bidsLoading, withdrawBid } = useRecruiterBids();
  const { consents, loading: consentsLoading } = useConsentRequests();
  const [activeTab, setActiveTab] = useState('overview');
  const { currentSubscription } = useSubscriptions();
  const [bidStatusFilter, setBidStatusFilter] = useState<string | null>(null);
  const [consentStatusFilter, setConsentStatusFilter] = useState<string | null>(null);
  const [selectedJob, setSelectedJob] = useState<any>(null);
  const [showConsentForm, setShowConsentForm] = useState(false);
  const [showBidForm, setShowBidForm] = useState(false);
  const [showPoliciesManager, setShowPoliciesManager] = useState(false);
  // Consents table state
  const [consSortKey, setConsSortKey] = useState<'candidate'|'job'|'status'|'requested'|'responded'>('requested');
  const [consSortDir, setConsSortDir] = useState<'asc'|'desc'>('desc');
  const [consQuery, setConsQuery] = useState('');
  const [selectedConsent, setSelectedConsent] = useState<any>(null);
  const [showConsentDetails, setShowConsentDetails] = useState(false);
  // Bids table state
  const [bidSortKey, setBidSortKey] = useState<'job'|'employer'|'fee'|'status'|'submitted'>('submitted');
  const [bidSortDir, setBidSortDir] = useState<'asc'|'desc'>('desc');
  const [bidQuery, setBidQuery] = useState('');
  const [selectedBid, setSelectedBid] = useState<any>(null);
  const [showBidDetails, setShowBidDetails] = useState(false);

  const openJobs = jobs.filter(job => job.visibility === 'open');
  const acceptedBids = bids.filter(bid => bid.status === 'accepted').length;
  const pendingConsents = consents.filter(consent => consent.status === 'requested').length;

  const stats = [
    { id: 'jobs', icon: <Eye className="w-6 h-6" />, label: 'Open Jobs', value: openJobs.length, color: 'blue' },
    { id: 'bids-all', icon: <Users className="w-6 h-6" />, label: 'Active Bids', value: bids.length, color: 'green' },
    { id: 'bids-accepted', icon: <CheckCircle className="w-6 h-6" />, label: 'Accepted Bids', value: acceptedBids, color: 'purple' },
    { id: 'consents-pending', icon: <DollarSign className="w-6 h-6" />, label: 'Pending Consents', value: pendingConsents, color: 'orange' },
  ] as const;

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'jobs', label: `Open Jobs (${openJobs.length})` },
    { id: 'bids', label: `My Bids (${bids.length})` },
    { id: 'payments', label: 'Payment Schedule' },
    { id: 'consents', label: `Consent Requests (${consents.length})` },
    { id: 'team', label: 'Team' },
    { id: 'billing', label: 'Billing' },
    { id: 'pipeline', label: 'Pipeline' },
  ];

  const handleStatClick = (id: typeof stats[number]['id']) => {
    switch (id) {
      case 'jobs':
        setActiveTab('jobs');
        setBidStatusFilter(null);
        setConsentStatusFilter(null);
        break;
      case 'bids-all':
        setActiveTab('bids');
        setBidStatusFilter(null);
        break;
      case 'bids-accepted':
        setActiveTab('bids');
        setBidStatusFilter('accepted');
        break;
      case 'consents-pending':
        setActiveTab('consents');
        setConsentStatusFilter('requested');
        break;
    }
  };

  // Deep-link parse on mount and hash change
  React.useEffect(() => {
    const parseHashParams = () => {
      const h = window.location.hash || '';
      if (!h.startsWith('#dashboard')) return;
      const q = h.slice('#dashboard'.length);
      const qs = q.startsWith('?') ? q.slice(1) : '';
      const params = new URLSearchParams(qs);
      const tab = params.get('tab');
      const status = params.get('status');
      if (tab && ['overview','jobs','bids','consents','pipeline'].includes(tab)) {
        setActiveTab(tab);
      }
      if (status) {
        if (tab === 'bids') setBidStatusFilter(status);
        if (tab === 'consents') setConsentStatusFilter(status);
      }
    };
    parseHashParams();
    window.addEventListener('hashchange', parseHashParams);
    return () => window.removeEventListener('hashchange', parseHashParams);
  }, []);

  // Sync tab/filters to hash
  React.useEffect(() => {
    const params = new URLSearchParams();
    params.set('tab', activeTab);
    const status = activeTab === 'bids' ? bidStatusFilter : (activeTab === 'consents' ? consentStatusFilter : null);
    if (status) params.set('status', status);
    const newHash = `#dashboard?${params.toString()}`;
    if (window.location.hash !== newHash) {
      window.history.replaceState(null, '', newHash);
    }
  }, [activeTab, bidStatusFilter, consentStatusFilter]);

  const [showVerify, setShowVerify] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const { isComplete: recruiterOnboarded, profile } = useRecruiterProfile();
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Verification banner */}
      {user?.role === 'recruiter' && (!recruiterOnboarded || user?.kycStatus !== 'verified') && (
        <div className="mb-6 p-4 rounded-md bg-yellow-50 border border-yellow-200 flex items-center justify-between">
          <div>
            <div className="font-medium text-yellow-800">
              {!recruiterOnboarded ? 'Complete onboarding to place bids' : 'Verification pending'}
            </div>
            <div className="text-sm text-yellow-700">
              {!recruiterOnboarded 
                ? 'Provide business details, upload documents, and accept terms.' 
                : 'Your profile is under review. You\'ll be notified once verified.'
              }
            </div>
          </div>
          <div className="flex gap-2">
            {!recruiterOnboarded && (
              <button 
                onClick={() => setShowOnboarding(true)} 
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                {profile ? 'Complete Profile' : 'Start Onboarding'}
              </button>
            )}
            {recruiterOnboarded && (
              <>
                {user?.kycStatus !== 'verified' && (
                  <div className="text-sm text-yellow-700 mr-2 self-center">
                    Profile submitted for review
                  </div>
                )}
                <button 
                  onClick={() => setShowOnboarding(true)} 
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  View Profile
                </button>
              </>
            )}
          </div>
        </div>
      )}
      {user?.role === 'recruiter' && recruiterOnboarded && user?.kycStatus === 'verified' && (
        <div className="mb-6 p-4 rounded-md bg-green-50 border border-green-200 flex items-center justify-between">
          <div>
            <div className="font-medium text-green-800">Your recruiter profile is approved</div>
            <div className="text-sm text-green-700">You can now request candidate consent and place bids on open jobs.</div>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => setActiveTab('jobs')} 
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              Browse Open Jobs
            </button>
            <button 
              onClick={() => setShowOnboarding(true)} 
              className="px-4 py-2 border border-green-300 text-green-800 rounded-lg hover:bg-green-100 transition-colors"
            >
              View Profile
            </button>
          </div>
        </div>
      )}
      
      <div className="mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Recruiter Dashboard</h1>
            <p className="text-gray-600 mt-1">Find opportunities and manage your bids</p>
          </div>
          <div className="flex items-center space-x-3">
            {(() => {
              const s = (user?.kycStatus || 'pending') as 'verified' | 'pending' | 'rejected';
              const kycBadge = s === 'verified' ? 'bg-green-100 text-green-800' : s === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800';
              const kycLabel = s.charAt(0).toUpperCase() + s.slice(1);
              return (<span className={`px-2 py-1 rounded text-xs font-medium ${kycBadge}`}>Profile: {kycLabel}</span>);
            })()}
            {(() => {
              const s = (profile?.bankStatus || 'missing') as 'verified' | 'pending' | 'missing';
              const bankBadge = s === 'verified' ? 'bg-green-100 text-green-800' : s === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800';
              const bankLabel = s.charAt(0).toUpperCase() + s.slice(1);
              return (<span className={`px-2 py-1 rounded text-xs font-medium ${bankBadge}`}>Banking: {bankLabel}</span>);
            })()}
            {currentSubscription && (
              <div className="flex items-center space-x-2 px-3 py-2 bg-blue-50 rounded-lg">
                <DollarSign className="w-4 h-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-800">{currentSubscription.planName}</span>
              </div>
            )}
            <button
              onClick={() => setShowConsentForm(true)}
              disabled={user?.kycStatus !== 'verified'}
              className={`inline-flex items-center px-4 py-2 rounded-lg transition-colors ${(user?.kycStatus !== 'verified') ? 'bg-gray-300 text-gray-600 cursor-not-allowed' : 'bg-green-600 text-white hover:bg-green-700'}`}
              title={(user?.kycStatus !== 'verified') ? 'Identity verification required' : ''}
            >
              <Users className="w-5 h-5 mr-2" />
              Request Consent
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          {stats.map((stat, index) => (
            <button
              key={index}
              type="button"
              onClick={() => handleStatClick(stat.id)}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 text-left hover:shadow-md transition-shadow focus:outline-none focus:ring-2 focus:ring-blue-500"
              aria-label={`View ${stat.label.toLowerCase()}`}
              title={`View ${stat.label.toLowerCase()}`}
            >
              <div className="flex items-center">
                <div className={`p-3 rounded-lg bg-${stat.color}-100`}>
                  <div className={`text-${stat.color}-600`}>
                    {stat.icon}
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-2xl font-bold text-gray-900">{stat.value}</h3>
                  <p className="text-gray-600 text-sm">{stat.label}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-8">
        <nav className="-mb-px flex space-x-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
              <div className="space-y-4">
                {bids.slice(0, 3).map((bid) => (
                  <div key={bid.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">
                        {jobs.find(j => j.id === bid.jobId)?.title}
                      </p>
                      <p className="text-sm text-gray-600">
                        {bid.feeType === 'percent' ? `${bid.feeValue}%` : `$${bid.feeValue.toLocaleString()}`} fee
                      </p>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      bid.status === 'submitted' ? 'bg-blue-100 text-blue-800' :
                      bid.status === 'accepted' ? 'bg-green-100 text-green-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {bid.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Hot Jobs</h3>
              <div className="space-y-4">
                {openJobs.slice(0, 3).map((job) => (
                  <div key={job.id} className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-gray-900">{job.title}</p>
                        <p className="text-sm text-gray-600">{job.organizationName}</p>
                        <p className="text-sm text-gray-500">{job.location}</p>
                        <Eligibility job={job} profileComplete={recruiterOnboarded} />
                      </div>
                      <PlaceBidButton job={job} profileComplete={recruiterOnboarded} onClick={() => { setSelectedJob(job); setShowBidForm(true); }} />
                      </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'jobs' && (
        <div>
          <JobSearch
            jobs={openJobs}
            showActions={false}
          />
        </div>
      )}

      {activeTab === 'team' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <EmployerTeamManager />
        </div>
      )}

      {activeTab === 'billing' && (
        <BillingDashboard />
      )}

      {activeTab === 'payments' && (
        <ScheduledPaymentsDashboard />
      )}

      {activeTab === 'bids' && (
        <div className="space-y-4">
          {bidStatusFilter && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-900 flex items-center justify-between">
              <span>Filtering bids by status: {bidStatusFilter}</span>
              <button className="px-3 py-1.5 text-xs border border-blue-300 rounded hover:bg-blue-100" onClick={() => setBidStatusFilter(null)}>Clear Filter</button>
            </div>
          )}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-4 flex items-center justify-between gap-3">
              <input
                value={bidQuery}
                onChange={e=>setBidQuery(e.target.value)}
                placeholder="Search job or employer..."
                className="w-full md:w-1/2 px-3 py-2 border rounded"
              />
              <select value={bidStatusFilter || 'all'} onChange={e=> setBidStatusFilter(e.target.value==='all'? null : e.target.value)} className="px-3 py-2 border rounded text-sm">
                {['all','submitted','shortlisted','accepted','rejected','withdrawn','expired'].map(s => (
                  <option key={s} value={s}>{s.charAt(0).toUpperCase()+s.slice(1)}</option>
                ))}
              </select>
            </div>
            <div className="overflow-auto">
              <table className="min-w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setBidSortKey(prev=>{ const k:'job'|'employer'|'fee'|'status'|'submitted'='job'; setBidSortDir(d=> prev==='job' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Job {bidSortKey==='job' ? (bidSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setBidSortKey(prev=>{ const k:'job'|'employer'|'fee'|'status'|'submitted'='employer'; setBidSortDir(d=> prev==='employer' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Employer {bidSortKey==='employer' ? (bidSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setBidSortKey(prev=>{ const k:'job'|'employer'|'fee'|'status'|'submitted'='fee'; setBidSortDir(d=> prev==='fee' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Fee {bidSortKey==='fee' ? (bidSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setBidSortKey(prev=>{ const k:'job'|'employer'|'fee'|'status'|'submitted'='status'; setBidSortDir(d=> prev==='status' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Status {bidSortKey==='status' ? (bidSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setBidSortKey(prev=>{ const k:'job'|'employer'|'fee'|'status'|'submitted'='submitted'; setBidSortDir(d=> prev==='submitted' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Submitted {bidSortKey==='submitted' ? (bidSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {(() => {
                    const jobsMap = new Map(jobs.map(j => [j.id, j]));
                    const filtered = bids.filter(b => {
                      if (bidStatusFilter && b.status !== bidStatusFilter) return false;
                      const q = bidQuery.trim().toLowerCase();
                      if (!q) return true;
                      const job = jobsMap.get(b.jobId);
                      const title = job?.title?.toLowerCase() || '';
                      const org = job?.organizationName?.toLowerCase() || '';
                      return title.includes(q) || org.includes(q);
                    });
                    const sorted = [...filtered].sort((a,b) => {
                      const aj = jobsMap.get(a.jobId); const bj = jobsMap.get(b.jobId);
                      if (bidSortKey==='job') return bidSortDir==='asc' ? (aj?.title||'').localeCompare(bj?.title||'') : (bj?.title||'').localeCompare(aj?.title||'');
                      if (bidSortKey==='employer') return bidSortDir==='asc' ? (aj?.organizationName||'').localeCompare(bj?.organizationName||'') : (bj?.organizationName||'').localeCompare(aj?.organizationName||'');
                      if (bidSortKey==='fee') return bidSortDir==='asc' ? a.feeValue - b.feeValue : b.feeValue - a.feeValue;
                      if (bidSortKey==='status') return bidSortDir==='asc' ? a.status.localeCompare(b.status) : b.status.localeCompare(a.status);
                      const ta = a.createdAt ? new Date(a.createdAt).getTime() : 0;
                      const tb = b.createdAt ? new Date(b.createdAt).getTime() : 0;
                      return bidSortDir==='asc' ? ta - tb : tb - ta;
                    });
                    const feeStr = (x: typeof bids[number]) => x.feeType==='percent' ? `${x.feeValue}%` : `$${x.feeValue.toLocaleString()}`;
                    return sorted.length === 0 ? (
                      <tr><td colSpan={6} className="px-4 py-8 text-center text-gray-600">No bids found</td></tr>
                    ) : sorted.map(b => {
                      const j = jobsMap.get(b.jobId);
                      return (
                        <tr key={b.id} className="border-t">
                          <td className="px-4 py-3 font-medium text-gray-900">{j?.title || '—'}</td>
                          <td className="px-4 py-3 text-gray-700">{j?.organizationName || '—'}</td>
                          <td className="px-4 py-3 text-gray-700">{feeStr(b)}</td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              b.status==='submitted'?'bg-blue-100 text-blue-800': b.status==='accepted'?'bg-green-100 text-green-800': b.status==='withdrawn'?'bg-gray-100 text-gray-800': b.status==='expired'?'bg-orange-100 text-orange-800':'bg-red-100 text-red-800'
                            }`}>{b.status}</span>
                          </td>
                          <td className="px-4 py-3 text-gray-700">{b.createdAt ? new Date(b.createdAt).toLocaleDateString() : '—'}</td>
                          <td className="px-4 py-3 text-right space-x-2">
                            <button className="px-3 py-1.5 text-xs bg-blue-600 text-white rounded hover:bg-blue-700" onClick={() => { setSelectedBid(b); setShowBidDetails(true); }}>View</button>
                            {b.status === 'submitted' && (
                              <button
                                onClick={() => withdrawBid(b.id).catch(console.error)}
                                className="px-3 py-1.5 text-xs border border-gray-300 rounded hover:bg-gray-50"
                              >
                                Withdraw
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    });
                  })()}
                </tbody>
              </table>
            </div>
          </div>

          {showBidDetails && selectedBid && (
            <div className="fixed inset-0 z-50">
              <div className="absolute inset-0 bg-black/40" onClick={() => { setShowBidDetails(false); setSelectedBid(null); }} />
              <div className="absolute inset-0 flex items-center justify-center p-4">
                <div className="bg-white w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden">
                  <div className="flex items-center justify-between px-6 py-4 border-b">
                    <div className="font-semibold text-gray-900">My Bid</div>
                    <button onClick={() => { setShowBidDetails(false); setSelectedBid(null); }} className="p-2 text-gray-500 hover:text-gray-700" aria-label="Close">
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="p-6 max-h-[80vh] overflow-auto">
                    <RecruiterBidCard bid={selectedBid} showActions={false} />
                    {selectedBid.status === 'submitted' && (
                      <div className="mt-4 flex justify-end">
                        <button
                          onClick={() => withdrawBid(selectedBid.id).then(()=> setShowBidDetails(false)).catch(console.error)}
                          className="px-4 py-2 text-sm border border-gray-300 rounded hover:bg-gray-50"
                        >
                          Withdraw Bid
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'consents' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">Consent Requests</h3>
            <button onClick={()=>setShowPoliciesManager(true)} className="px-3 py-1.5 text-sm border rounded hover:bg-gray-50">Manage Policies</button>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-4 flex items-center justify-between gap-3">
              <input
                value={consQuery}
                onChange={e=>setConsQuery(e.target.value)}
                placeholder="Search candidate or job..."
                className="w-full md:w-1/2 px-3 py-2 border rounded"
              />
              <select value={consentStatusFilter || 'all'} onChange={e=> setConsentStatusFilter(e.target.value==='all'? null : e.target.value)} className="px-3 py-2 border rounded text-sm">
                {['all','requested','approved','declined','revoked','blocked'].map(s => (
                  <option key={s} value={s}>{s.replace('_',' ').replace(/^./,m=>m.toUpperCase())}</option>
                ))}
              </select>
            </div>
            <div className="overflow-auto">
              <table className="min-w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setConsSortKey(prev=>{ const k:'candidate'|'job'|'status'|'requested'|'responded'='candidate'; setConsSortDir(d=> prev==='candidate' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Candidate {consSortKey==='candidate' ? (consSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setConsSortKey(prev=>{ const k:'candidate'|'job'|'status'|'requested'|'responded'='job'; setConsSortDir(d=> prev==='job' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Job {consSortKey==='job' ? (consSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setConsSortKey(prev=>{ const k:'candidate'|'job'|'status'|'requested'|'responded'='status'; setConsSortDir(d=> prev==='status' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Status {consSortKey==='status' ? (consSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setConsSortKey(prev=>{ const k:'candidate'|'job'|'status'|'requested'|'responded'='requested'; setConsSortDir(d=> prev==='requested' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Requested {consSortKey==='requested' ? (consSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {(() => {
                    const filtered = consents.filter(c => {
                      if (consentStatusFilter && c.status !== consentStatusFilter) return false;
                      const q = consQuery.trim().toLowerCase();
                      if (!q) return true;
                      return (c.candidateName||'').toLowerCase().includes(q) || (c.jobTitle||'').toLowerCase().includes(q);
                    });
                    const sorted = [...filtered].sort((a,b) => {
                      if (consSortKey==='candidate') return consSortDir==='asc' ? (a.candidateName||'').localeCompare(b.candidateName||'') : (b.candidateName||'').localeCompare(a.candidateName||'');
                      if (consSortKey==='job') return consSortDir==='asc' ? (a.jobTitle||'').localeCompare(b.jobTitle||'') : (b.jobTitle||'').localeCompare(a.jobTitle||'');
                      if (consSortKey==='status') return consSortDir==='asc' ? a.status.localeCompare(b.status) : b.status.localeCompare(a.status);
                      const ta = a.requestedAt ? new Date(a.requestedAt).getTime() : 0;
                      const tb = b.requestedAt ? new Date(b.requestedAt).getTime() : 0;
                      return consSortDir==='asc' ? ta - tb : tb - ta;
                    });
                    return sorted.length === 0 ? (
                      <tr><td colSpan={5} className="px-4 py-8 text-center text-gray-600">No consent requests found</td></tr>
                    ) : sorted.map(c => (
                      <tr key={c.id} className="border-t">
                        <td className="px-4 py-3 font-medium text-gray-900">{c.candidateName || '—'}</td>
                        <td className="px-4 py-3 text-gray-700">{c.jobTitle}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            c.status==='requested'?'bg-yellow-100 text-yellow-800': c.status==='approved'?'bg-green-100 text-green-800': c.status==='revoked'?'bg-gray-100 text-gray-800': c.status==='blocked'?'bg-red-100 text-red-800':'bg-red-100 text-red-800'
                          }`}>{c.status.replace('_',' ')}</span>
                        </td>
                        <td className="px-4 py-3 text-gray-700">{c.requestedAt ? new Date(c.requestedAt).toLocaleDateString() : '—'}</td>
                        <td className="px-4 py-3 text-right">
                          <button className="px-3 py-1.5 text-xs bg-blue-600 text-white rounded hover:bg-blue-700" onClick={() => { setSelectedConsent(c); setShowConsentDetails(true); }}>View</button>
                        </td>
                      </tr>
                    ));
                  })()}
                </tbody>
              </table>
            </div>
          </div>

          {showConsentDetails && selectedConsent && (
            <div className="fixed inset-0 z-50">
              <div className="absolute inset-0 bg-black/40" onClick={() => { setShowConsentDetails(false); setSelectedConsent(null); }} />
              <div className="absolute inset-0 flex items-center justify-center p-4">
                <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden">
                  <div className="flex items-center justify-between px-6 py-4 border-b">
                    <div className="font-semibold text-gray-900">Consent Request</div>
                    <button onClick={() => { setShowConsentDetails(false); setSelectedConsent(null); }} className="p-2 text-gray-500 hover:text-gray-700" aria-label="Close">
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="p-6 max-h-[80vh] overflow-auto">
                    <ConsentCard consent={selectedConsent} readOnly />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'pipeline' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recruitment Pipeline</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center p-6 bg-blue-50 rounded-lg">
              <Clock className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">5</div>
              <div className="text-sm text-gray-600">Pending Bids</div>
            </div>
            <div className="text-center p-6 bg-green-50 rounded-lg">
              <Users className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">2</div>
              <div className="text-sm text-gray-600">In Interview</div>
            </div>
            <div className="text-center p-6 bg-purple-50 rounded-lg">
              <CheckCircle className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">1</div>
              <div className="text-sm text-gray-600">Offer Stage</div>
            </div>
            <div className="text-center p-6 bg-orange-50 rounded-lg">
              <TrendingUp className="w-8 h-8 text-orange-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">3</div>
              <div className="text-sm text-gray-600">Placements</div>
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      {showConsentForm && (
        <ConsentRequestForm 
          onClose={() => setShowConsentForm(false)} 
        />
      )}

      {showBidForm && selectedJob && (
        <BidForm 
          job={selectedJob}
          onClose={() => {
            setShowBidForm(false);
            setSelectedJob(null);
          }} 
        />
      )}
      {showPoliciesManager && (
        <ConsentPoliciesManager onClose={()=>setShowPoliciesManager(false)} />
      )}
      {showVerify && (
        <VerificationRequest isOpen onClose={()=>setShowVerify(false)} />
      )}
      {showOnboarding && (
        <OnboardingWizard isOpen onClose={()=>setShowOnboarding(false)} />
      )}
    </div>
  );
};

export default RecruiterDashboard;

// Small inline component to show eligibility and slots
const Eligibility: React.FC<{ job: any; profileComplete: boolean }> = ({ job, profileComplete }) => {
  const { canBid, reason, slotsLeft, loading } = useBidEligibility(job, { profileComplete });
  if (loading) return <p className="text-xs text-gray-500">Checking capacity…</p>;
  return (
    <p className="text-xs mt-1">
      {canBid ? (
        <span className="text-green-700">{Number.isFinite(slotsLeft) ? `${slotsLeft} slots left` : 'Open'}</span>
      ) : (
        <span className="text-red-600">{reason}</span>
      )}
    </p>
  );
};

// Separate component so hooks stay in stable order per React rules
import type { Job } from '../../types';
const PlaceBidButton: React.FC<{ job: Job; onClick: () => void; profileComplete: boolean }> = ({ job, onClick, profileComplete }) => {
  const { canBid, loading, reason } = useBidEligibility(job, { profileComplete }) as any;
  // Hide button entirely when capacity reached
  if (reason === 'Bid capacity reached') return null;
  return (
    <button
      onClick={onClick}
      title={!canBid && !loading ? reason : ''}
      className={`px-3 py-1 rounded text-sm disabled:opacity-50 ${
        loading ? 'bg-gray-100 text-gray-700' : (canBid ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100')
      }`}
      disabled={loading || !canBid}
    >
      Bid for this Job
    </button>
  );
};
