import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApplications } from '../../hooks/useApplications';
import { useJobs } from '../../hooks/useJobs';
import { useConsentRequests } from '../../hooks/useConsentRequests';
import { useJobRecommendations } from '../../hooks/useJobRecommendations';
import { useSavedSearches } from '../../hooks/useSavedSearches';
import { useSavedJobs } from '../../hooks/useSavedJobs';
import { useAppliedJobs } from '../../hooks/useAppliedJobs';
import { useDraftApplications } from '../../hooks/useDraftApplications';
import { useInterviews } from '../../hooks/useInterviews';
import JobApplicationForm from '../Applications/JobApplicationForm';
import SavedSearches from '../Search/SavedSearches';
import JobRecommendationCard from '../Recommendations/JobRecommendationCard';
import ConsentCard from '../Consents/ConsentCard';
import CandidateProfileSetup from '../Profile/CandidateProfileSetup';
import { useCandidateProfile } from '../../hooks/useCandidateProfile';
import ApplicationDetailsModal from '../Applications/ApplicationDetailsModal';
import { useConsentCodes } from '../../hooks/useConsentCodes';
import { useFileUpload } from '../../hooks/useFileUpload';
import InterviewDetailsModal from '../Interviews/InterviewDetailsModal';
// Recruiter access merged into Consent Requests tab
import {
  Search,
  Briefcase,
  FileText,
  UserCheck,
  TrendingUp,
  Eye,
  Clock,
  Sparkles,
  Bookmark,
  Settings,
  Star,
  Users as UsersIcon,
  X,
  Save,
  Trash2,
  Calendar,
  Video
} from 'lucide-react';
import toast from 'react-hot-toast';

const CandidateDashboard: React.FC = () => {
  const { user } = useAuth();
  const { applications, createApplication } = useApplications();
  const { jobs } = useJobs();
  const { consents } = useConsentRequests();
  const { jobRecommendations, generateJobRecommendations } = useJobRecommendations();
  const { savedSearches } = useSavedSearches();
  const { drafts, deleteDraft, refetch: refetchDrafts } = useDraftApplications(user?.id);
  const { interviews } = useInterviews();
  const [activeTab, setActiveTab] = useState('recommendations');
  const [selectedJob, setSelectedJob] = useState<any>(null);
  const [showApplicationForm, setShowApplicationForm] = useState(false);
  const { ids: savedIds } = useSavedJobs();
  const savedSet = React.useMemo(() => new Set(savedIds), [savedIds]);
  const { isApplied } = useAppliedJobs();
  const { profile, isComplete } = useCandidateProfile();
  const [showProfileSetup, setShowProfileSetup] = useState(false);
  // Consents table state
  const [consSortKey, setConsSortKey] = useState<'company'|'recruiter'|'job'|'status'|'requested'>('requested');
  const [consSortDir, setConsSortDir] = useState<'asc'|'desc'>('desc');
  const [consQuery, setConsQuery] = useState('');
  const [consStatus, setConsStatus] = useState<string>('all');
  const [selectedConsent, setSelectedConsent] = useState<any>(null);
  const [showConsentDetails, setShowConsentDetails] = useState(false);
  const [selectedInterview, setSelectedInterview] = useState<any>(null);
  const [showInterviewDetails, setShowInterviewDetails] = useState(false);

  const myApplications = applications;
  const pendingConsents = consents.filter(consent => consent.status === 'requested');
  const openJobs = jobs.filter(job => job.status === 'open');
  const upcomingInterviews = interviews.filter(interview =>
    ['scheduled', 'confirmed', 'rescheduled'].includes(interview.status) &&
    interview.scheduledAt > new Date()
  );

  const stats = [
    { id: 'recommendations', icon: <Star className="w-6 h-6" />, label: 'Recommendations', value: jobRecommendations.length, color: 'orange' },
    { id: 'applications', icon: <FileText className="w-6 h-6" />, label: 'My Applications', value: myApplications.length, color: 'green' },
    { id: 'interviews', icon: <Calendar className="w-6 h-6" />, label: 'Upcoming Interviews', value: upcomingInterviews.length, color: 'teal' },
    { id: 'consents', icon: <UserCheck className="w-6 h-6" />, label: 'Consent Requests', value: pendingConsents.length, color: 'purple' },
  ] as const;

  const tabs = [
    { id: 'recommendations', label: `For You (${jobRecommendations.length})` },
    { id: 'applications', label: `My Applications (${myApplications.length})` },
    { id: 'interviews', label: `Interviews (${interviews.length})` },
    { id: 'drafts', label: `Drafts (${drafts.length})` },
    { id: 'consents', label: `Consent Requests (${pendingConsents.length})` },
    { id: 'saved-jobs', label: 'Saved Jobs' },
    { id: 'saved-searches', label: 'Saved Searches' },
    { id: 'profile', label: 'Profile' },
  ];

  const handleStatClick = (id: typeof stats[number]['id']) => {
    setActiveTab(id);
  };

  const handleJobApply = (job: any) => {
    setSelectedJob(job);
    setShowApplicationForm(true);
  };

  const handleApplicationSubmit = async (applicationData: any) => {
    try {
      await createApplication(applicationData);
      setShowApplicationForm(false);
      setSelectedJob(null);
    } catch (error) {
      console.error('Failed to submit application:', error);
      throw error;
    }
  };
  
  const handleLoadSavedSearch = (criteria: any) => {
    // Navigate to homepage search; job-search tab removed
    window.location.hash = '';
  };
  
  const handleGenerateRecommendations = async () => {
    try {
      await generateJobRecommendations();
    } catch (error) {
      console.error('Error generating recommendations:', error);
      alert('Failed to generate recommendations');
    }
  };

  // Deep-linking: #dashboard?tab=<id>
  React.useEffect(() => {
    const parseHashParams = () => {
      const h = window.location.hash || '';
      if (!h.startsWith('#dashboard')) return;
      const q = h.slice('#dashboard'.length);
      const qs = q.startsWith('?') ? q.slice(1) : '';
      const params = new URLSearchParams(qs);
      const tab = params.get('tab');
      if (tab && tabs.some(t => t.id === tab)) setActiveTab(tab);
    };
    parseHashParams();
    window.addEventListener('hashchange', parseHashParams);
    return () => window.removeEventListener('hashchange', parseHashParams);
  }, []);

  // Sync active tab to hash
  React.useEffect(() => {
    const params = new URLSearchParams();
    params.set('tab', activeTab);
    const newHash = `#dashboard?${params.toString()}`;
    if (window.location.hash !== newHash) {
      window.history.replaceState(null, '', newHash);
    }
  }, [activeTab]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {!isComplete && activeTab !== 'profile' && (
        <div className="mb-6 p-4 rounded-md bg-yellow-50 border border-yellow-200 flex items-center justify-between">
          <div>
            <div className="font-medium text-yellow-800">Complete your profile to get better recommendations</div>
            <div className="text-sm text-yellow-700">Add your career history, skills and preferences.</div>
          </div>
          <button onClick={()=>setShowProfileSetup(true)} className="px-3 py-2 bg-pink-600 text-white rounded">Complete profile</button>
        </div>
      )}
      <div className="mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Candidate Dashboard</h1>
            <p className="text-gray-600 mt-1">Find your next opportunity</p>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          {stats.map((stat, index) => {
            const colorClasses = {
              orange: { bg: 'bg-orange-100', text: 'text-orange-600', gradient: 'from-orange-50 to-orange-100' },
              green: { bg: 'bg-green-100', text: 'text-green-600', gradient: 'from-green-50 to-green-100' },
              teal: { bg: 'bg-teal-100', text: 'text-teal-600', gradient: 'from-teal-50 to-teal-100' },
              purple: { bg: 'bg-purple-100', text: 'text-purple-600', gradient: 'from-purple-50 to-purple-100' },
            };
            const colors = colorClasses[stat.color as keyof typeof colorClasses] || colorClasses.green;

            return (
              <button
                key={index}
                type="button"
                onClick={() => handleStatClick(stat.id)}
                className={`bg-gradient-to-br ${colors.gradient} rounded-2xl shadow-sm border-2 border-gray-200 p-6 text-left hover:shadow-lg hover:border-gray-300 transition-all focus:outline-none focus:ring-2 focus:ring-blue-500 group`}
                aria-label={`View ${stat.label.toLowerCase()}`}
                title={`View ${stat.label.toLowerCase()}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-gray-600 text-sm font-medium mb-2">{stat.label}</p>
                    <h3 className="text-4xl font-bold text-gray-900 group-hover:scale-105 transition-transform">{stat.value}</h3>
                  </div>
                  <div className={`p-4 rounded-xl ${colors.bg} shadow-sm group-hover:scale-110 transition-transform`}>
                    <div className={`${colors.text}`}>
                      {stat.icon}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Alert for pending consents */}
        {pendingConsents.length > 0 && (
          <div className="mt-6 bg-gradient-to-r from-amber-50 to-amber-100 border-2 border-amber-300 rounded-xl p-5 shadow-sm">
            <div className="flex items-center">
              <div className="p-2 bg-amber-200 rounded-lg mr-3">
                <UserCheck className="w-6 h-6 text-amber-700" />
              </div>
              <p className="text-amber-900 font-medium">
                You have {pendingConsents.length} pending consent request{pendingConsents.length !== 1 ? 's' : ''} from recruiters.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="border-b-2 border-gray-200 mb-8">
        <nav className="-mb-0.5 flex space-x-1 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-3 px-4 border-b-2 font-semibold text-sm whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'border-blue-600 text-blue-600 bg-blue-50'
                  : 'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300 hover:bg-gray-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}

      {activeTab === 'recommendations' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Job Recommendations</h2>
              <p className="text-gray-600">Jobs matched to your profile and preferences</p>
            </div>
            <button
              onClick={handleGenerateRecommendations}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Refresh Recommendations
            </button>
          </div>
          
          {jobRecommendations.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-lg shadow-sm border border-gray-200">
              <Sparkles className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Recommendations Yet</h3>
              <p className="text-gray-600 mb-4">
                Complete your profile to get personalized job recommendations
              </p>
              <button
                onClick={handleGenerateRecommendations}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Generate Recommendations
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {jobRecommendations.map((recommendation) => (
                <JobRecommendationCard
                  key={recommendation.id}
                  recommendation={recommendation}
                  onApply={() => handleJobApply(recommendation.job)}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Job Search removed */}

      {activeTab === 'saved-searches' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Saved Searches</h2>
            <p className="text-gray-600">Manage your saved job searches and alerts</p>
          </div>
          
          <SavedSearches onLoadSearch={handleLoadSavedSearch} />
        </div>
      )}

      {activeTab === 'saved-jobs' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Saved Jobs</h2>
            <p className="text-gray-600">Jobs you bookmarked to review later</p>
          </div>
          {savedIds === undefined ? null : (
            savedIds.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-lg shadow-sm border border-gray-200">
                <Bookmark className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No saved jobs yet</h3>
                <p className="text-gray-600 mb-4">Tap the star icon on any job to save it for later.</p>
                <button onClick={() => { window.location.hash = ''; }} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Browse jobs</button>
              </div>
            ) : (
              <div className="space-y-3">
                {jobs
                  .filter(j => savedSet.has(j.id) && j.status === 'open' && j.visibility === 'open')
                  .map(job => (
                  <div key={job.id} className="bg-white rounded-lg border border-gray-200 p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-semibold text-gray-900">{job.title}</h4>
                        <p className="text-sm text-gray-600">{job.organizationName} • {job.location}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => { try { localStorage.setItem('viewJobId', job.id); } catch {}; window.location.hash = ''; }}
                          className="px-3 py-1.5 text-xs bg-blue-600 text-white rounded hover:bg-blue-700"
                        >
                          View
                        </button>
                        {isApplied(job.id) ? (
                          <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-700">Applied</span>
                        ) : (
                          <button onClick={() => handleJobApply(job)} className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700">Apply</button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )
          )}
        </div>
      )}

      {activeTab === 'applications' && (
        <CandidateApplicationsTable />
      )}

      {activeTab === 'interviews' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">My Interviews</h2>
            <p className="text-gray-600">View and manage your scheduled interviews</p>
          </div>

          {interviews.length === 0 ? (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
              <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No Interviews</h3>
              <p className="text-gray-600">Your scheduled interviews will appear here</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {interviews.map((interview) => {
                const isPast = interview.scheduledAt < new Date();
                const statusColor = interview.status === 'confirmed' ? 'green' : interview.status === 'scheduled' ? 'blue' : interview.status === 'cancelled' ? 'red' : 'yellow';

                return (
                  <div
                    key={interview.id}
                    className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => {
                      setSelectedInterview(interview);
                      setShowInterviewDetails(true);
                    }}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <div className={`p-2 rounded-lg bg-${statusColor}-100 text-${statusColor}-600`}>
                            {interview.interviewType === 'video' ? <Video className="w-5 h-5" /> : <Calendar className="w-5 h-5" />}
                          </div>
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900">{interview.jobTitle || 'Interview'}</h3>
                            <p className="text-sm text-gray-500 capitalize">{interview.interviewType.replace('_', ' ')} Interview</p>
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {interview.scheduledAt.toLocaleDateString()}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {interview.scheduledAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium capitalize bg-${statusColor}-100 text-${statusColor}-800`}>
                            {interview.status.replace('_', ' ')}
                          </span>
                          {isPast && <span className="text-gray-500 text-xs">(Past)</span>}
                        </div>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedInterview(interview);
                          setShowInterviewDetails(true);
                        }}
                        className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm font-medium"
                      >
                        View Details
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {activeTab === 'drafts' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Draft Applications</h2>
            <p className="text-gray-600">Continue where you left off</p>
          </div>

          {drafts.length === 0 ? (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
              <Save className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No Draft Applications</h3>
              <p className="text-gray-600">Save your progress when applying to jobs to continue later</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {drafts.map((draft) => {
                const job = jobs.find(j => j.id === draft.jobId);
                if (!job) return null;

                return (
                  <div key={draft.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-gray-900 mb-1">{job.title}</h3>
                        <p className="text-sm text-gray-600 mb-2">{job.company}</p>
                        <div className="flex items-center gap-4 text-sm text-gray-500">
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            Step {draft.lastSavedStep} of 3
                          </span>
                          <span>
                            Last saved: {new Date(draft.updatedAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            setSelectedJob(job);
                            setShowApplicationForm(true);
                          }}
                          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm font-medium"
                        >
                          Continue
                        </button>
                        <button
                          onClick={async () => {
                            if (confirm('Delete this draft application?')) {
                              const success = await deleteDraft(draft.id);
                              if (success) {
                                toast.success('Draft deleted');
                                refetchDrafts();
                              } else {
                                toast.error('Failed to delete draft');
                              }
                            }
                          }}
                          className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Recruiter Access removed (merged into Consent Requests) */}

      {activeTab === 'consents' && (
        <div className="space-y-4">
          <ConsentOneTimeCodePanel />
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-4 flex items-center justify-between gap-3">
              <input
                value={consQuery}
                onChange={e=>setConsQuery(e.target.value)}
                placeholder="Search recruiter or job..."
                className="w-full md:w-1/2 px-3 py-2 border rounded"
              />
              <select value={consStatus} onChange={e=>setConsStatus(e.target.value)} className="px-3 py-2 border rounded text-sm">
                {['all','requested','approved','declined','revoked','blocked'].map(s => (
                  <option key={s} value={s}>{s.replace('_',' ').replace(/^./,m=>m.toUpperCase())}</option>
                ))}
              </select>
            </div>
            <div className="overflow-auto">
              <table className="min-w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setConsSortKey(prev=>{ const k:'company'|'recruiter'|'job'|'status'|'requested'='company'; setConsSortDir(d=> prev==='company' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Company {consSortKey==='company' ? (consSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setConsSortKey(prev=>{ const k:'company'|'recruiter'|'job'|'status'|'requested'='recruiter'; setConsSortDir(d=> prev==='recruiter' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Recruiter {consSortKey==='recruiter' ? (consSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setConsSortKey(prev=>{ const k:'company'|'recruiter'|'job'|'status'|'requested'='job'; setConsSortDir(d=> prev==='job' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Job {consSortKey==='job' ? (consSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setConsSortKey(prev=>{ const k:'company'|'recruiter'|'job'|'status'|'requested'='status'; setConsSortDir(d=> prev==='status' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Status {consSortKey==='status' ? (consSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setConsSortKey(prev=>{ const k:'company'|'recruiter'|'job'|'status'|'requested'='requested'; setConsSortDir(d=> prev==='requested' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Requested {consSortKey==='requested' ? (consSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {(() => {
                    const filtered = consents.filter(c => {
                      if (consStatus !== 'all' && c.status !== consStatus) return false;
                      const q = consQuery.trim().toLowerCase();
                      if (!q) return true;
                      return c.recruiterCompany.toLowerCase().includes(q) || c.recruiterName.toLowerCase().includes(q) || (c.jobTitle||'').toLowerCase().includes(q);
                    });
                    const sorted = [...filtered].sort((a,b) => {
                      if (consSortKey==='company') return consSortDir==='asc' ? a.recruiterCompany.localeCompare(b.recruiterCompany) : b.recruiterCompany.localeCompare(a.recruiterCompany);
                      if (consSortKey==='recruiter') return consSortDir==='asc' ? a.recruiterName.localeCompare(b.recruiterName) : b.recruiterName.localeCompare(a.recruiterName);
                      if (consSortKey==='job') return consSortDir==='asc' ? (a.jobTitle||'').localeCompare(b.jobTitle||'') : (b.jobTitle||'').localeCompare(a.jobTitle||'');
                      if (consSortKey==='status') return consSortDir==='asc' ? a.status.localeCompare(b.status) : b.status.localeCompare(a.status);
                      const ta = a.requestedAt ? new Date(a.requestedAt).getTime() : 0;
                      const tb = b.requestedAt ? new Date(b.requestedAt).getTime() : 0;
                      return consSortDir==='asc' ? ta - tb : tb - ta;
                    });
                    return sorted.length === 0 ? (
                      <tr><td colSpan={6} className="px-4 py-8 text-center text-gray-600">No consent requests found</td></tr>
                    ) : sorted.map(c => (
                      <tr key={c.id} className="border-t">
                        <td className="px-4 py-3 font-medium text-gray-900">{c.recruiterCompany}</td>
                        <td className="px-4 py-3 text-gray-700">{c.recruiterName}</td>
                        <td className="px-4 py-3 text-gray-700">{c.jobTitle}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            c.status==='requested'?'bg-yellow-100 text-yellow-800': c.status==='approved'?'bg-green-100 text-green-800': c.status==='revoked'?'bg-gray-100 text-gray-800': c.status==='blocked'?'bg-red-100 text-red-800':'bg-red-100 text-red-800'
                          }`}>{c.status.replace('_',' ')}</span>
                        </td>
                        <td className="px-4 py-3 text-gray-700">{c.requestedAt ? new Date(c.requestedAt).toLocaleDateString() : '—'}</td>
                        <td className="px-4 py-3 text-right">
                          <button className="px-3 py-1.5 text-xs bg-blue-600 text-white rounded hover:bg-blue-700" onClick={() => { setSelectedConsent(c); setShowConsentDetails(true); }}>View</button>
                        </td>
                      </tr>
                    ));
                  })()}
                </tbody>
              </table>
            </div>
          </div>

          {showConsentDetails && selectedConsent && (
            <div className="fixed inset-0 z-50">
              <div className="absolute inset-0 bg-black/40" onClick={() => { setShowConsentDetails(false); setSelectedConsent(null); }} />
              <div className="absolute inset-0 flex items-center justify-center p-4">
                <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden">
                  <div className="flex items-center justify-between px-6 py-4 border-b">
                    <div className="font-semibold text-gray-900">Consent Request</div>
                    <button onClick={() => { setShowConsentDetails(false); setSelectedConsent(null); }} className="p-2 text-gray-500 hover:text-gray-700" aria-label="Close">
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="p-6 max-h-[80vh] overflow-auto">
                    <ConsentCard consent={selectedConsent} />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'profile' && (
        <CandidateProfileSummary onEdit={()=>setShowProfileSetup(true)} />
      )}

      {/* Application Form Modal */}
      {showApplicationForm && selectedJob && (
        <JobApplicationForm
          job={selectedJob}
          onClose={() => {
            setShowApplicationForm(false);
            setSelectedJob(null);
          }}
          onSubmit={handleApplicationSubmit}
        />
      )}

      {showProfileSetup && (
        <CandidateProfileSetup isOpen onClose={()=>setShowProfileSetup(false)} onSaved={()=>setShowProfileSetup(false)} />
      )}

      {showInterviewDetails && selectedInterview && (
        <InterviewDetailsModal
          interview={selectedInterview}
          onClose={() => {
            setShowInterviewDetails(false);
            setSelectedInterview(null);
          }}
        />
      )}
    </div>
  );
};

export default CandidateDashboard;
// Inline components: applications table, consent one-time code panel, profile summary
const CandidateApplicationsTable: React.FC = () => {
  const { applications } = useApplications();
  const { jobs } = useJobs();
  const [sortKey, setSortKey] = React.useState<'date'|'job'|'status'>('date');
  const [sortDir, setSortDir] = React.useState<'asc'|'desc'>('desc');
  const [statusFilter, setStatusFilter] = React.useState<string>('all');
  const [selected, setSelected] = React.useState<any | null>(null);

  const rows = React.useMemo(() => {
    const list = applications.map(a => ({
      ...a,
      jobTitle: jobs.find(j => j.id === a.jobId)?.title || '—',
      org: jobs.find(j => j.id === a.jobId)?.organizationName || '—',
      appliedAt: a.createdAt ? new Date(a.createdAt) : null,
    }));
    const filtered = statusFilter==='all' ? list : list.filter(x => x.status === statusFilter);
    const sorted = [...filtered].sort((a,b) => {
      if (sortKey==='date') { const ta=a.appliedAt?.getTime()||0; const tb=b.appliedAt?.getTime()||0; return sortDir==='asc'? ta-tb : tb-ta; }
      if (sortKey==='job') return sortDir==='asc' ? a.jobTitle.localeCompare(b.jobTitle) : b.jobTitle.localeCompare(a.jobTitle);
      return sortDir==='asc' ? a.status.localeCompare(b.status) : b.status.localeCompare(a.status);
    });
    return sorted;
  }, [applications, jobs, sortKey, sortDir, statusFilter]);

  const toggleSort = (k: 'date'|'job'|'status') => {
    if (sortKey===k) setSortDir(d=>d==='asc'?'desc':'asc'); else { setSortKey(k); setSortDir('asc'); }
  };

  if (applications.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-lg shadow-sm border border-gray-200">
        <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">No Applications Yet</h3>
        <p className="text-gray-600 mb-4">Start applying to jobs to see your applications here</p>
        <button onClick={()=>{ window.location.hash=''; }} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Browse Jobs</button>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="text-sm text-gray-700">{rows.length} applications</div>
        <div className="flex items-center gap-2">
          <select value={statusFilter} onChange={e=>setStatusFilter(e.target.value)} className="px-2 py-1 border rounded text-sm">
            {['all','submitted','shortlisted','rejected','hired','withdrawn'].map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase()+s.slice(1)}</option>)}
          </select>
        </div>
      </div>
      <div className="overflow-auto">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-left px-3 py-2 cursor-pointer" onClick={()=>toggleSort('job')}>Job {sortKey==='job' ? (sortDir==='asc'?'▲':'▼') : ''}</th>
              <th className="text-left px-3 py-2">Company</th>
              <th className="text-left px-3 py-2 cursor-pointer" onClick={()=>toggleSort('date')}>Applied {sortKey==='date' ? (sortDir==='asc'?'▲':'▼') : ''}</th>
              <th className="text-left px-3 py-2 cursor-pointer" onClick={()=>toggleSort('status')}>Status {sortKey==='status' ? (sortDir==='asc'?'▲':'▼') : ''}</th>
              <th className="px-3 py-2 text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(a => (
              <tr key={a.id} className="border-t">
                <td className="px-3 py-2 font-medium text-gray-900">{a.jobTitle}</td>
                <td className="px-3 py-2 text-gray-700">{a.org}</td>
                <td className="px-3 py-2 text-gray-700">{a.appliedAt ? a.appliedAt.toLocaleDateString() : '—'}</td>
                <td className="px-3 py-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    a.status==='submitted'?'bg-blue-100 text-blue-800': a.status==='shortlisted'?'bg-green-100 text-green-800': a.status==='hired'?'bg-purple-100 text-purple-800': a.status==='withdrawn'?'bg-gray-100 text-gray-800':'bg-red-100 text-red-800'
                  }`}>{a.status}</span>
                </td>
                <td className="px-3 py-2 text-right"><button onClick={()=>setSelected(a)} className="px-3 py-1.5 text-xs bg-blue-600 text-white rounded hover:bg-blue-700">View</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {selected && (<ApplicationDetailsModal application={selected} isOpen={!!selected} onClose={()=>setSelected(null)} />)}
    </div>
  );
};

const ConsentOneTimeCodePanel: React.FC = () => {
  const { generate } = useConsentCodes();
  const [code, setCode] = React.useState<{ code: string; expiresAt: Date } | null>(null);
  return (
    <div className="bg-white rounded-xl shadow-sm border p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2"><UsersIcon className="w-5 h-5 text-blue-600" /><h3 className="font-medium text-gray-900">One-Time Code</h3></div>
        <button onClick={async()=>{ const res = await generate(); setCode(res); }} className="px-3 py-1.5 text-sm bg-blue-600 text-white rounded hover:bg-blue-700">Generate Code</button>
      </div>
      <p className="text-sm text-gray-600 mt-1">Share this short code privately with a recruiter. Expires in 30 minutes.</p>
      {code && (<div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded text-sm text-blue-900">Code: <span className="font-mono font-semibold">{code.code}</span> • Expires: {code.expiresAt.toLocaleTimeString()}</div>)}
    </div>
  );
};

// (imports consolidated at top)
const CandidateProfileSummary: React.FC<{ onEdit: () => void }> = ({ onEdit }) => {
  const { profile } = useCandidateProfile();
  const { getSignedUrl } = useFileUpload();
  const [links, setLinks] = React.useState<Record<string,string>>({});
  React.useEffect(()=>{
    let mounted = true;
    (async ()=>{
      const map: Record<string,string> = {};
      for (const r of (profile?.resumes || [])) {
        try { map[r.id] = await getSignedUrl(r.path, 'resumes', 3600); } catch { map[r.id] = r.url || '#'; }
      }
      if (mounted) setLinks(map);
    })();
    return ()=>{ mounted = false; };
  }, [profile?.resumes?.length]);
  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Candidate Profile</h3>
          <button onClick={onEdit} className="px-3 py-2 text-sm bg-pink-600 text-white rounded">{profile ? 'Edit profile' : 'Create profile'}</button>
        </div>
        {!profile ? (
          <p className="mt-2 text-gray-600 text-sm">You haven't created a candidate profile yet.</p>
        ) : (
          <div className="mt-4 space-y-4 text-sm text-gray-700">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div><span className="font-medium">Location:</span> {profile.currentStatus.location || '-'}</div>
              <div><span className="font-medium">Work types:</span> {(profile.rolePreferences.workTypes||[]).join(', ') || '-'}</div>
              <div><span className="font-medium">Skills:</span> {(profile.qualifications.skills||[]).join(', ') || '-'}</div>
              <div><span className="font-medium">Minimum salary:</span> {profile.rolePreferences.minimumSalary || '-'}</div>
            </div>
            <div>
              <div className="font-medium mb-1">Resumes</div>
              {(profile.resumes || []).length === 0 ? (
                <div className="text-gray-600">No resumes uploaded yet.</div>
              ) : (
                <ul className="space-y-2">
                  {profile.resumes!.map(r => (
                    <li key={r.id} className="flex items-center justify-between border rounded p-2">
                      <div>
                        <div className="font-medium text-gray-900">{r.name}</div>
                        <div className="text-xs text-gray-500">Uploaded {new Date(r.uploadedAt || Date.now()).toLocaleDateString()}</div>
                      </div>
                      <a href={links[r.id] || r.url || '#'} target="_blank" rel="noreferrer" className="px-3 py-1.5 text-xs bg-blue-600 text-white rounded hover:bg-blue-700">View</a>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
