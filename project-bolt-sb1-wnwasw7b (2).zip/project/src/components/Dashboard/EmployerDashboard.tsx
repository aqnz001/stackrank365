import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useJobs } from '../../hooks/useJobs';
import { useApplications } from '../../hooks/useApplications';
import { useRecruiterBids } from '../../hooks/useRecruiterBids';
import { useSubscriptions } from '../../hooks/useSubscriptions';
import { pricingTiers } from '../../data/mockData';
import JobPostForm from '../Jobs/JobPostForm';
import JobEditForm from '../Jobs/JobEditForm';
import BillingDashboard from '../Billing/BillingDashboard';
import JobSearch from '../Jobs/JobSearch';
import ApplicationCard from '../Applications/ApplicationCard';
import ApplicationDetailsModal from '../Applications/ApplicationDetailsModal';
import RecruiterBidCard from '../Bids/RecruiterBidCard';
import JobAnalytics from '../Jobs/JobAnalytics';
import InterviewScheduler from '../Interviews/InterviewScheduler';
import InterviewCard from '../Interviews/InterviewCard';
import DocumentShareForm from '../Documents/DocumentShareForm';
import WorkflowDashboard from '../Workflow/WorkflowDashboard';
import StatusTracker from '../Status/StatusTracker';
import CompanyProfileModal from '../Organizations/CompanyProfileModal';
import EmployerTeamManager from '../Organizations/EmployerTeamManager';
import { JobCandidatesDashboard, CandidateComparisonModal, CandidateAssistantPopup } from '../Candidates';
import { useInterviews } from '../../hooks/useInterviews';
import { useEmployerPayments } from '../../hooks/useEmployerPayments';
import { 
  Plus, 
  Briefcase, 
  Users, 
  Eye, 
  TrendingUp,
  DollarSign,
  Clock,
  CheckCircle,
  Calendar,
  Share,
  GitBranch,
  Crown,
  AlertTriangle,
  X
} from 'lucide-react';

const EmployerDashboard: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [showJobForm, setShowJobForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [editingJob, setEditingJob] = useState<any>(null);
  const { jobs: myJobs, loading: jobsLoading, error: jobsError } = useJobs();
  const { applications, updateApplicationStatus, refetch: refetchApplications } = useApplications();
  const { bids } = useRecruiterBids();
  const { interviews } = useInterviews();
  const { currentSubscription, checkUsageLimit, getUsageSummary } = useSubscriptions();
  const [showCompanyProfile, setShowCompanyProfile] = useState(false);
  const [showInterviewScheduler, setShowInterviewScheduler] = useState(false);
  const [selectedApplication, setSelectedApplication] = useState<any>(null);
  const [showAppDetails, setShowAppDetails] = useState(false);
  const [showDocumentShare, setShowDocumentShare] = useState(false);
  const [shareRecipient, setShareRecipient] = useState<any>(null);
  const [jobFilterId, setJobFilterId] = useState<string | null>(null);
  // Jobs table state (sorting + filters)
  const [jobsSortKey, setJobsSortKey] = useState<'title'|'location'|'type'|'status'|'apps'|'shortlisted'|'bids'|'interviews'>('title');
  const [jobsSortDir, setJobsSortDir] = useState<'asc'|'desc'>('asc');
  const [titleFilter, setTitleFilter] = useState('');
  const [locationFilter, setLocationFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [applicationStatusFilter, setApplicationStatusFilter] = useState<string | null>(null);
  // Applications table
  const [appSortKey, setAppSortKey] = useState<'candidate'|'job'|'status'|'applied'>('applied');
  const [appSortDir, setAppSortDir] = useState<'asc'|'desc'>('desc');
  const [appQuery, setAppQuery] = useState('');
  const [appStatus, setAppStatus] = useState<string>('all');
  // Bids table
  const [bidSortKey, setBidSortKey] = useState<'company'|'recruiter'|'fee'|'status'|'submitted'>('submitted');
  const [bidSortDir, setBidSortDir] = useState<'asc'|'desc'>('desc');
  const [bidStatus, setBidStatus] = useState<string>('all');
  const [bidQuery, setBidQuery] = useState('');
  const [selectedBid, setSelectedBid] = useState<any>(null);
  const [showBidDetails, setShowBidDetails] = useState(false);
  // Interviews table
  const [intSortKey, setIntSortKey] = useState<'when'|'job'|'status'>('when');
  const [intSortDir, setIntSortDir] = useState<'asc'|'desc'>('asc');
  const [intStatus, setIntStatus] = useState<string>('all');
  const [intQuery, setIntQuery] = useState('');
  const [selectedInterview, setSelectedInterview] = useState<any>(null);
  const [showInterviewDetails, setShowInterviewDetails] = useState(false);
  // Candidate analysis state
  const [selectedJobForAnalysis, setSelectedJobForAnalysis] = useState<any>(null);
  const [candidatesForComparison, setCandidatesForComparison] = useState<any[]>([]);
  const [showComparisonModal, setShowComparisonModal] = useState(false);

  const totalApplications = applications.length;
  const totalBids = bids.length;
  const shortlistedCount = applications.filter(a => a.status === 'shortlisted').length;
  const upcomingInterviews = interviews.filter(i =>
    i.scheduledAt > new Date() && i.status !== 'cancelled'
  ).length;

  const usageSummary = getUsageSummary();
  const canPostJobs = checkUsageLimit('job_posts_per_month', 1);
  const stats = [
    { id: 'jobs', icon: <Briefcase className="w-6 h-6" />, label: 'Active Jobs', value: myJobs.length, color: 'blue' },
    { id: 'applications', icon: <Users className="w-6 h-6" />, label: 'Applications', value: totalApplications, color: 'green' },
    { id: 'bids', icon: <Eye className="w-6 h-6" />, label: 'Recruiter Bids', value: totalBids, color: 'purple' },
    { id: 'interviews', icon: <Calendar className="w-6 h-6" />, label: 'Interviews', value: upcomingInterviews, color: 'orange' },
  ] as const;

  const { payments: employerPayments } = useEmployerPayments();
  const pendingPayments = employerPayments.filter(p => p.status === 'pending').length;

  useEffect(() => {
    if (selectedInterview && interviews.length > 0) {
      const updatedInterview = interviews.find(i => i.id === selectedInterview.id);
      if (updatedInterview) {
        setSelectedInterview(updatedInterview);
      }
    }
  }, [interviews]);

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'jobs', label: `My Jobs (${myJobs.length})` },
    { id: 'applications', label: `Applications (${totalApplications})` },
    { id: 'bids', label: `Recruiter Bids (${totalBids})` },
    { id: 'payments', label: `Payments (${pendingPayments})` },
    { id: 'interviews', label: `Interviews (${upcomingInterviews})` },
    { id: 'workflows', label: 'Workflows' },
    { id: 'analytics', label: 'Analytics' },
    { id: 'team', label: 'Team' },
    { id: 'billing', label: 'Billing' },
  ];

  const handleStatClick = (id: typeof stats[number]['id']) => {
    setJobFilterId(null);
    setApplicationStatusFilter(null);
    setActiveTab(id);
  };

  // Parse deep-link parameters from hash on mount
  React.useEffect(() => {
    const parseHashParams = () => {
      const h = window.location.hash || '';
      if (!h.startsWith('#dashboard')) return;
      const q = h.slice('#dashboard'.length);
      const qs = q.startsWith('?') ? q.slice(1) : '';
      if (!qs) return;
      const params = new URLSearchParams(qs);
      const tab = params.get('tab');
      const job = params.get('job');
      const status = params.get('status');
      if (tab && ['overview','jobs','applications','bids','interviews','workflows','analytics','team','billing'].includes(tab)) {
        setActiveTab(tab);
      }
      if (job) setJobFilterId(job);
      if (status) setApplicationStatusFilter(status);
    };
    parseHashParams();
    window.addEventListener('hashchange', parseHashParams);
    return () => window.removeEventListener('hashchange', parseHashParams);
  }, []);

  // Sync current tab/filters to URL hash
  React.useEffect(() => {
    const params = new URLSearchParams();
    params.set('tab', activeTab);
    if (jobFilterId) params.set('job', jobFilterId);
    if (applicationStatusFilter) params.set('status', applicationStatusFilter);
    const newHash = `#dashboard?${params.toString()}`;
    if (window.location.hash !== newHash) {
      window.history.replaceState(null, '', newHash);
    }
  }, [activeTab, jobFilterId, applicationStatusFilter]);

  const handleJobEdit = (job: any) => {
    setEditingJob(job);
    setShowEditForm(true);
  };

  const handleJobToggleVisibility = async (job: any) => {
    // TODO: Implement visibility toggle
    console.log('Toggle visibility for job:', job.id);
  };

  const handleJobDelete = async (job: any) => {
    if (window.confirm('Are you sure you want to delete this job?')) {
      // TODO: Implement job deletion
      console.log('Delete job:', job.id);
    }
  };
  const handleApplicationAction = async (applicationId: string, action: string) => {
    try {
      await updateApplicationStatus(applicationId, action);
    } catch (error) {
      console.error('Failed to update application:', error);
      alert('Failed to update application status');
    }
  };

  const handleScheduleInterview = (application: any) => {
    console.log('Scheduling interview for application:', application.id);
    setSelectedApplication(application);
    setShowInterviewScheduler(true);
  };

  const handleShareDocument = (recipient: any) => {
    console.log('Initiating document share with recipient:', recipient);
    setShareRecipient(recipient);
    setShowDocumentShare(true);
  };

  const handlePostJob = () => {
    if (!canPostJobs && currentSubscription) {
      alert('You have reached your monthly job posting limit. Please upgrade your plan or wait until next month.');
      return;
    }
    setShowJobForm(true);
  };
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Employer Dashboard</h1>
            <p className="text-gray-600 mt-1">Manage your job postings and candidates</p>
          </div>
          <div className="flex items-center space-x-3">
            {currentSubscription && (
              <div className="flex items-center space-x-2 px-3 py-2 bg-blue-50 rounded-lg">
                <Crown className="w-4 h-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-800">{currentSubscription.planName}</span>
              </div>
            )}
            <button
              onClick={handlePostJob}
              disabled={!canPostJobs && currentSubscription}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Plus className="w-5 h-5 mr-2" />
              Post Job
            </button>
          </div>
        </div>

        {/* Subscription Prompt */}
        {!currentSubscription && (
          <div className="mt-4 bg-indigo-50 border border-indigo-200 rounded-lg p-4 flex items-center justify-between">
            <div>
              <div className="font-medium text-indigo-900">Add a subscription to unlock plan features</div>
              <div className="text-sm text-indigo-800">Choose a plan to enable included job posts and premium tools. You can still post with pay‑as‑you‑go.</div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setShowCompanyProfile(true)} className="px-3 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 text-sm">Add Subscription</button>
              <button onClick={() => setActiveTab('billing')} className="px-3 py-2 border border-indigo-300 rounded hover:bg-indigo-100 text-sm text-indigo-900">View Billing</button>
            </div>
          </div>
        )}

        {/* Usage Warning */}
        {currentSubscription && !canPostJobs && (
          <div className="mt-4 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex items-center">
              <AlertTriangle className="w-5 h-5 text-yellow-600 mr-2" />
              <p className="text-yellow-800">
                You have reached your monthly job posting limit ({usageSummary.job_posts_per_month || 0} posts used). 
                <button 
                  onClick={() => setActiveTab('billing')}
                  className="ml-1 text-yellow-900 underline hover:text-yellow-700"
                >
                  Upgrade your plan
                </button> or wait until next month.
              </p>
            </div>
          </div>
        )}
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          {stats.map((stat, index) => (
            <button
              key={index}
              type="button"
              onClick={() => handleStatClick(stat.id)}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 text-left hover:shadow-md transition-shadow focus:outline-none focus:ring-2 focus:ring-blue-500"
              aria-label={`View ${stat.label.toLowerCase()}`}
              title={`View ${stat.label.toLowerCase()}`}
            >
              <div className="flex items-center">
                <div className={`p-3 rounded-lg bg-${stat.color}-100`}>
                  <div className={`text-${stat.color}-600`}>
                    {stat.icon}
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-2xl font-bold text-gray-900">{stat.value}</h3>
                  <p className="text-gray-600 text-sm">{stat.label}</p>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Error Display */}
        {jobsError && (
          <div className="mt-6 bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-red-800">Error loading jobs: {jobsError}</p>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200 mb-8">
        <nav className="-mb-px flex space-x-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Applications</h3>
              <div className="space-y-4">
                {applications.slice(0, 3).map((application) => (
                  <div key={application.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900">{application.candidateName}</p>
                      <p className="text-sm text-gray-600">Applied to {myJobs.find(j => j.id === application.jobId)?.title}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        application.status === 'submitted' ? 'bg-blue-100 text-blue-800' :
                        application.status === 'shortlisted' ? 'bg-yellow-100 text-yellow-800 border border-yellow-300' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {application.status}
                      </span>
                      {application.status === 'shortlisted' && (
                        <button
                          onClick={() => handleScheduleInterview(application)}
                          className="px-2 py-1 bg-blue-600 text-white rounded text-xs hover:bg-blue-700"
                        >
                          Schedule
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Pending Recruiter Bids</h3>
              <div className="space-y-4">
                {bids.filter(bid => bid.status === 'submitted').slice(0, 3).map((bid) => (
                  <div key={bid.id} className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-gray-900">{bid.recruiterCompany}</p>
                        <p className="text-sm text-gray-600">
                          {bid.feeType === 'percent' ? `${bid.feeValue}%` : `$${bid.feeValue.toLocaleString()}`} success fee
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <button className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700">
                          Accept
                        </button>
                        <button className="px-3 py-1 bg-gray-600 text-white rounded text-sm hover:bg-gray-700">
                          Reject
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'jobs' && (
        <>
          {selectedJobForAnalysis ? (
            <div className="space-y-6">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setSelectedJobForAnalysis(null)}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  ← Back to My Jobs
                </button>
                <h3 className="text-xl font-semibold text-gray-900">
                  Analyzing Candidates: {selectedJobForAnalysis.title}
                </h3>
              </div>
              <JobCandidatesDashboard
                job={selectedJobForAnalysis}
                applications={applications.filter(a => a.jobId === selectedJobForAnalysis.id)}
                onSelectForComparison={(candidates) => {
                  setCandidatesForComparison(candidates);
                  setShowComparisonModal(true);
                }}
                onViewApplication={(app) => {
                  setSelectedApplication(app);
                  setShowAppDetails(true);
                }}
                onUpdateStatus={handleApplicationAction}
                onRefresh={refetchApplications}
              />
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200">
              {jobsLoading ? (
                <div className="flex justify-center items-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                </div>
              ) : myJobs.length === 0 ? (
                <div className="text-center py-12">
                  <Briefcase className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No jobs posted yet</h3>
                  <p className="text-gray-600 mb-4">Get started by posting your first job</p>
                  <button onClick={() => setShowJobForm(true)} className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                    <Plus className="w-5 h-5 mr-2" /> Post Your First Job
                  </button>
                </div>
              ) : (
            <div>
              <div className="px-6 py-4 border-b">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">My Jobs</h3>
                    <p className="text-sm text-gray-600 mt-1">Click on any job title with candidates to analyze and rank them</p>
                  </div>
                    <button onClick={() => setShowJobForm(true)} className="inline-flex items-center px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm">
                      <Plus className="w-4 h-4 mr-2" /> New Job
                    </button>
                  </div>
                </div>
              {/* Filters */}
              <div className="px-6 pb-2 grid grid-cols-1 md:grid-cols-4 gap-2">
                <input value={titleFilter} onChange={e=>setTitleFilter(e.target.value)} placeholder="Filter by title" className="px-3 py-2 border rounded" />
                <input value={locationFilter} onChange={e=>setLocationFilter(e.target.value)} placeholder="Filter by location" className="px-3 py-2 border rounded" />
                <select value={typeFilter} onChange={e=>setTypeFilter(e.target.value)} className="px-3 py-2 border rounded">
                  <option value="all">All types</option>
                  <option value="full-time">Full time</option>
                  <option value="part-time">Part time</option>
                  <option value="contract">Contract</option>
                  <option value="temporary">Temporary</option>
                </select>
                <select value={statusFilter} onChange={e=>setStatusFilter(e.target.value)} className="px-3 py-2 border rounded">
                  <option value="all">All status</option>
                  <option value="open">Open</option>
                  <option value="draft">Draft</option>
                  <option value="on_hold">On hold</option>
                  <option value="filled">Filled</option>
                  <option value="closed">Closed</option>
                </select>
              </div>
              {/* Table */}
              <div className="overflow-auto">
                <table className="min-w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      {[
                        { key:'title', label:'Job Title' },
                        { key:'location', label:'Location' },
                        { key:'type', label:'Type' },
                        { key:'status', label:'Status' },
                        { key:'apps', label:'Applications' },
                        { key:'shortlisted', label:'Shortlisted' },
                        { key:'bids', label:'Bids' },
                        { key:'interviews', label:'Interviews' },
                        { key:'actions', label:'Actions' },
                      ].map(col => (
                        <th key={col.key} className="text-left px-6 py-3 font-medium text-gray-700 select-none">
                          {col.key !== 'actions' ? (
                            <button
                              className="inline-flex items-center gap-1 hover:text-blue-600"
                              onClick={() => {
                                if (jobsSortKey === (col.key as any)) setJobsSortDir(d => d==='asc'?'desc':'asc');
                                else { setJobsSortKey(col.key as any); setJobsSortDir('asc'); }
                              }}
                            >
                              {col.label}
                              <span className="text-xs">
                                {jobsSortKey === col.key ? (jobsSortDir==='asc'?'▲':'▼') : ''}
                              </span>
                            </button>
                          ) : col.label}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {myJobs
                      .map(job => {
                        const appCount = applications.filter(a => a.jobId === job.id).length;
                        const shortlistedCount = applications.filter(a => a.jobId === job.id && a.status === 'shortlisted').length;
                        const bidCount = bids.filter(b => b.jobId === job.id).length;
                        const interviewCount = interviews.filter(iv => {
                          if ((iv as any).applicationId) {
                            const a = applications.find(x => x.id === (iv as any).applicationId);
                            return a?.jobId === job.id;
                          } else if ((iv as any).recruiterBidId) {
                            const b = bids.find(x => x.id === (iv as any).recruiterBidId);
                            return b?.jobId === job.id;
                          }
                          return false;
                        }).length;
                        return { job, appCount, shortlistedCount, bidCount, interviewCount };
                      })
                      .filter(row => (titleFilter? row.job.title.toLowerCase().includes(titleFilter.toLowerCase()) : true))
                      .filter(row => (locationFilter? (row.job.location || '').toLowerCase().includes(locationFilter.toLowerCase()) : true))
                      .filter(row => (typeFilter==='all'? true : (row.job.employmentType === typeFilter)))
                      .filter(row => (statusFilter==='all'? true : (row.job.status === statusFilter)))
                      .sort((a,b) => {
                        const dir = jobsSortDir==='asc'? 1 : -1;
                        switch (jobsSortKey) {
                          case 'title': return dir * a.job.title.localeCompare(b.job.title);
                          case 'location': return dir * (a.job.location||'').localeCompare(b.job.location||'');
                          case 'type': return dir * (a.job.employmentType||'').localeCompare(b.job.employmentType||'');
                          case 'status': return dir * (a.job.status||'').localeCompare(b.job.status||'');
                          case 'apps': return dir * (a.appCount - b.appCount);
                          case 'shortlisted': return dir * (a.shortlistedCount - b.shortlistedCount);
                          case 'bids': return dir * (a.bidCount - b.bidCount);
                          case 'interviews': return dir * (a.interviewCount - b.interviewCount);
                          default: return 0;
                        }
                      })
                      .map(({ job, appCount, shortlistedCount, bidCount, interviewCount }) => (
                        <tr key={job.id} className="border-t">
                          <td className="px-6 py-3">
                            {appCount > 0 ? (
                              <button
                                onClick={() => setSelectedJobForAnalysis(job)}
                                className="font-medium text-blue-600 hover:text-blue-800 hover:underline text-left"
                                title="Click to analyze candidates"
                              >
                                {job.title}
                              </button>
                            ) : (
                              <div className="font-medium text-gray-900">{job.title}</div>
                            )}
                          </td>
                          <td className="px-6 py-3 text-gray-700">{job.location || '—'}</td>
                          <td className="px-6 py-3 text-gray-700">{(job.employmentType || '').replace('-', ' ')}</td>
                          <td className="px-6 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            job.status==='open' ? 'bg-green-100 text-green-700' :
                            (job.status==='on_hold' || job.status==='draft') ? 'bg-yellow-100 text-yellow-800' :
                            job.status==='filled' ? 'bg-purple-100 text-purple-800' : 'bg-gray-100 text-gray-700'
                          }`}>{(job.status || '').replace('_',' ') || '—'}</span>
                          </td>
                          <td className="px-6 py-3">
                            <button className="text-blue-600 hover:underline" onClick={() => { setJobFilterId(job.id); setApplicationStatusFilter(null); setActiveTab('applications'); }}> {appCount} </button>
                          </td>
                          <td className="px-6 py-3">
                            <button className="text-blue-600 hover:underline" onClick={() => { setJobFilterId(job.id); setApplicationStatusFilter('shortlisted'); setActiveTab('applications'); }}> {shortlistedCount} </button>
                          </td>
                          <td className="px-6 py-3">
                            <button className="text-blue-600 hover:underline" onClick={() => { setJobFilterId(job.id); setActiveTab('bids'); }}> {bidCount} </button>
                          </td>
                          <td className="px-6 py-3">
                            <button className="text-blue-600 hover:underline" onClick={() => { setActiveTab('interviews'); }}> {interviewCount} </button>
                          </td>
                          <td className="px-6 py-3">
                            <button className="px-3 py-1.5 text-sm text-blue-700 hover:text-blue-800" onClick={() => handleJobEdit(job)}>Edit</button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
            </div>
          )}
        </>
      )}

      {activeTab === 'applications' && (
        <div className="space-y-4">
          {jobFilterId && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-900 flex items-center justify-between">
              <span>Filtering applications for selected job</span>
              <button className="px-3 py-1.5 text-xs border border-blue-300 rounded hover:bg-blue-100" onClick={() => setJobFilterId(null)}>Clear Filter</button>
            </div>
          )}
          {applicationStatusFilter && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-900 flex items-center justify-between">
              <span>Filtering by status: {applicationStatusFilter}</span>
              <button className="px-3 py-1.5 text-xs border border-blue-300 rounded hover:bg-blue-100" onClick={() => setApplicationStatusFilter(null)}>Clear Status</button>
            </div>
          )}

          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-4 flex items-center justify-between gap-3">
              <input
                value={appQuery}
                onChange={e=>setAppQuery(e.target.value)}
                placeholder="Search candidate or job..."
                className="w-full md:w-1/2 px-3 py-2 border rounded"
              />
              <select value={appStatus} onChange={e=>setAppStatus(e.target.value)} className="px-3 py-2 border rounded text-sm">
                {['all','submitted','shortlisted','rejected','hired','withdrawn'].map(s => (
                  <option key={s} value={s}>{s.charAt(0).toUpperCase()+s.slice(1)}</option>
                ))}
              </select>
            </div>

            <div className="overflow-auto">
              <table className="min-w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setAppSortKey(prev=>{ const k:'candidate'|'job'|'status'|'applied' = 'candidate'; setAppSortDir(d=> prev==='candidate' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Candidate {appSortKey==='candidate' ? (appSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setAppSortKey(prev=>{ const k:'candidate'|'job'|'status'|'applied' = 'job'; setAppSortDir(d=> prev==='job' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Job {appSortKey==='job' ? (appSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setAppSortKey(prev=>{ const k:'candidate'|'job'|'status'|'applied' = 'status'; setAppSortDir(d=> prev==='status' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Status {appSortKey==='status' ? (appSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setAppSortKey(prev=>{ const k:'candidate'|'job'|'status'|'applied' = 'applied'; setAppSortDir(d=> prev==='applied' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Applied {appSortKey==='applied' ? (appSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {(() => {
                    // construct rows
                    const source = (jobFilterId || applicationStatusFilter)
                      ? applications.filter(a => (jobFilterId ? a.jobId === jobFilterId : true) && (applicationStatusFilter ? a.status === applicationStatusFilter : true))
                      : applications;
                    const filtered = source.filter(a => {
                      if (appStatus !== 'all' && a.status !== appStatus) return false;
                      const q = appQuery.trim().toLowerCase();
                      if (!q) return true;
                      const jobTitle = (a as any).jobTitle || '';
                      return (a.candidateName || '').toLowerCase().includes(q) || jobTitle.toLowerCase().includes(q);
                    });
                    const sorted = [...filtered].sort((a:any,b:any) => {
                      if (appSortKey==='candidate') return appSortDir==='asc' ? (a.candidateName||'').localeCompare(b.candidateName||'') : (b.candidateName||'').localeCompare(a.candidateName||'');
                      if (appSortKey==='job') return appSortDir==='asc' ? ((a.jobTitle||'').localeCompare(b.jobTitle||'')) : ((b.jobTitle||'').localeCompare(a.jobTitle||''));
                      if (appSortKey==='status') return appSortDir==='asc' ? a.status.localeCompare(b.status) : b.status.localeCompare(a.status);
                      const ta = a.createdAt ? new Date(a.createdAt).getTime() : 0;
                      const tb = b.createdAt ? new Date(b.createdAt).getTime() : 0;
                      return appSortDir==='asc' ? ta - tb : tb - ta;
                    });
                    return sorted.map((a:any) => (
                      <tr key={a.id} className="border-t">
                        <td className="px-4 py-3 font-medium text-gray-900">{a.candidateName}</td>
                        <td className="px-4 py-3 text-gray-700">{a.jobTitle || '—'}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            a.status==='submitted'?'bg-blue-100 text-blue-800': a.status==='shortlisted'?'bg-green-100 text-green-800': a.status==='hired'?'bg-purple-100 text-purple-800': a.status==='withdrawn'?'bg-gray-100 text-gray-800':'bg-red-100 text-red-800'
                          }`}>{a.status}</span>
                        </td>
                        <td className="px-4 py-3 text-gray-700">{a.createdAt ? new Date(a.createdAt).toLocaleDateString() : '—'}</td>
                        <td className="px-4 py-3 text-right space-x-2">
                          <button className="px-3 py-1.5 text-xs bg-blue-600 text-white rounded hover:bg-blue-700" onClick={() => { setSelectedApplication(a); setShowAppDetails(true); }}>View</button>
                          {a.status === 'shortlisted' && (
                            <button
                              onClick={() => handleScheduleInterview(a)}
                              className="px-3 py-1.5 text-xs border border-gray-300 rounded hover:bg-gray-50"
                            >
                              Schedule
                            </button>
                          )}
                        </td>
                      </tr>
                    ));
                  })()}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'bids' && (
        <div className="space-y-4">
          {jobFilterId && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-900 flex items-center justify-between">
              <span>Filtering bids for selected job</span>
              <button className="px-3 py-1.5 text-xs border border-blue-300 rounded hover:bg-blue-100" onClick={() => setJobFilterId(null)}>Clear Filter</button>
            </div>
          )}

          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-4 flex items-center justify-between gap-3">
              <input
                value={bidQuery}
                onChange={e=>setBidQuery(e.target.value)}
                placeholder="Search company or recruiter..."
                className="w-full md:w-1/2 px-3 py-2 border rounded"
              />
              <select value={bidStatus} onChange={e=>setBidStatus(e.target.value)} className="px-3 py-2 border rounded text-sm">
                {['all','submitted','shortlisted','accepted','rejected','withdrawn','expired'].map(s => (
                  <option key={s} value={s}>{s.charAt(0).toUpperCase()+s.slice(1)}</option>
                ))}
              </select>
            </div>
            <div className="overflow-auto">
              <table className="min-w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setBidSortKey(prev=>{ const k:'company'|'recruiter'|'fee'|'status'|'submitted'='company'; setBidSortDir(d=> prev==='company' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Company {bidSortKey==='company' ? (bidSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setBidSortKey(prev=>{ const k:'company'|'recruiter'|'fee'|'status'|'submitted'='recruiter'; setBidSortDir(d=> prev==='recruiter' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Recruiter {bidSortKey==='recruiter' ? (bidSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setBidSortKey(prev=>{ const k:'company'|'recruiter'|'fee'|'status'|'submitted'='fee'; setBidSortDir(d=> prev==='fee' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Fee {bidSortKey==='fee' ? (bidSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setBidSortKey(prev=>{ const k:'company'|'recruiter'|'fee'|'status'|'submitted'='status'; setBidSortDir(d=> prev==='status' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Status {bidSortKey==='status' ? (bidSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setBidSortKey(prev=>{ const k:'company'|'recruiter'|'fee'|'status'|'submitted'='submitted'; setBidSortDir(d=> prev==='submitted' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Submitted {bidSortKey==='submitted' ? (bidSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {(() => {
                    const source = jobFilterId ? bids.filter(b => b.jobId === jobFilterId) : bids;
                    const filtered = source.filter(b => {
                      if (bidStatus !== 'all' && b.status !== bidStatus) return false;
                      const q = bidQuery.trim().toLowerCase();
                      if (!q) return true;
                      return b.recruiterCompany.toLowerCase().includes(q) || b.recruiterName.toLowerCase().includes(q);
                    });
                    const sorted = [...filtered].sort((a,b) => {
                      if (bidSortKey==='company') return bidSortDir==='asc' ? a.recruiterCompany.localeCompare(b.recruiterCompany) : b.recruiterCompany.localeCompare(a.recruiterCompany);
                      if (bidSortKey==='recruiter') return bidSortDir==='asc' ? a.recruiterName.localeCompare(b.recruiterName) : b.recruiterName.localeCompare(a.recruiterName);
                      if (bidSortKey==='fee') return bidSortDir==='asc' ? (a.feeType==='percent'?a.feeValue:a.feeValue) - (b.feeType==='percent'?b.feeValue:b.feeValue) : (b.feeType==='percent'?b.feeValue:b.feeValue) - (a.feeType==='percent'?a.feeValue:a.feeValue);
                      if (bidSortKey==='status') return bidSortDir==='asc' ? a.status.localeCompare(b.status) : b.status.localeCompare(a.status);
                      const ta = a.createdAt ? new Date(a.createdAt).getTime() : 0;
                      const tb = b.createdAt ? new Date(b.createdAt).getTime() : 0;
                      return bidSortDir==='asc' ? ta - tb : tb - ta;
                    });
                    const formatFee = (b: typeof bids[number]) => b.feeType==='percent' ? `${b.feeValue}%` : `$${b.feeValue.toLocaleString()}`;
                    return sorted.map(b => (
                      <tr key={b.id} className="border-t">
                        <td className="px-4 py-3 font-medium text-gray-900">{b.recruiterCompany}</td>
                        <td className="px-4 py-3 text-gray-700">{b.recruiterName}</td>
                        <td className="px-4 py-3 text-gray-700">{formatFee(b)}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            b.status==='submitted'?'bg-blue-100 text-blue-800': b.status==='accepted'?'bg-green-100 text-green-800': b.status==='withdrawn'?'bg-gray-100 text-gray-800': b.status==='expired'?'bg-orange-100 text-orange-800':'bg-red-100 text-red-800'
                          }`}>{b.status}</span>
                        </td>
                        <td className="px-4 py-3 text-gray-700">{b.createdAt ? new Date(b.createdAt).toLocaleDateString() : '—'}</td>
                        <td className="px-4 py-3 text-right">
                          <button className="px-3 py-1.5 text-xs bg-blue-600 text-white rounded hover:bg-blue-700" onClick={() => { setSelectedBid(b); setShowBidDetails(true); }}>View</button>
                        </td>
                      </tr>
                    ));
                  })()}
                </tbody>
              </table>
            </div>
          </div>

          {/* Bid Details Modal */}
          {showBidDetails && selectedBid && (
            <div className="fixed inset-0 z-50">
              <div className="absolute inset-0 bg-black/40" onClick={() => { setShowBidDetails(false); setSelectedBid(null); }} />
              <div className="absolute inset-0 flex items-center justify-center p-4">
                <div className="bg-white w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden">
                  <div className="flex items-center justify-between px-6 py-4 border-b">
                    <div className="font-semibold text-gray-900">Recruiter Bid</div>
                    <button onClick={() => { setShowBidDetails(false); setSelectedBid(null); }} className="p-2 text-gray-500 hover:text-gray-700" aria-label="Close">
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="p-6 max-h-[80vh] overflow-auto">
                    <RecruiterBidCard 
                      bid={selectedBid}
                      showActions
                      onAccept={() => setShowBidDetails(false)}
                      onReject={() => setShowBidDetails(false)}
                      onViewDetails={() => {}}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'interviews' && (
        <div className="space-y-4">
          {(() => {
            const completedWithFeedback = interviews.filter(i => i.status === 'completed' && i.feedback);
            const needingDecision = completedWithFeedback.filter(i => {
              const app = applications.find(a => a.id === i.applicationId);
              return app && (!app.interviewDecision || app.interviewDecision === 'pending');
            });

            return needingDecision.length > 0 && (
              <div className="bg-orange-50 border-l-4 border-orange-400 p-4 rounded-lg">
                <div className="flex items-start">
                  <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 mr-3 flex-shrink-0" />
                  <div>
                    <h3 className="text-sm font-semibold text-orange-900">
                      {needingDecision.length} Interview{needingDecision.length === 1 ? '' : 's'} Awaiting Decision
                    </h3>
                    <p className="text-sm text-orange-800 mt-1">
                      You have completed interviews that need a hiring decision. Click "Make Decision" to accept, reject, or extend an offer.
                    </p>
                  </div>
                </div>
              </div>
            );
          })()}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-4 flex items-center justify-between gap-3">
              <input
                value={intQuery}
                onChange={e=>setIntQuery(e.target.value)}
                placeholder="Search job or candidate..."
                className="w-full md:w-1/2 px-3 py-2 border rounded"
              />
              <select value={intStatus} onChange={e=>setIntStatus(e.target.value)} className="px-3 py-2 border rounded text-sm">
                {['all','scheduled','confirmed','rescheduled','completed','cancelled','no_show'].map(s => (
                  <option key={s} value={s}>{s.replace('_',' ').replace(/^./,m=>m.toUpperCase())}</option>
                ))}
              </select>
            </div>
            <div className="overflow-auto">
              <table className="min-w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setIntSortKey(prev=>{ const k:'when'|'job'|'status'='when'; setIntSortDir(d=> prev==='when' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      When {intSortKey==='when' ? (intSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setIntSortKey(prev=>{ const k:'when'|'job'|'status'='job'; setIntSortDir(d=> prev==='job' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Job {intSortKey==='job' ? (intSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="text-left px-4 py-3 cursor-pointer" onClick={()=> setIntSortKey(prev=>{ const k:'when'|'job'|'status'='status'; setIntSortDir(d=> prev==='status' ? (d==='asc'?'desc':'asc') : 'asc'); return k; })}>
                      Status {intSortKey==='status' ? (intSortDir==='asc'?'▲':'▼') : ''}
                    </th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {(() => {
                    const filtered = interviews.filter(i => {
                      if (intStatus !== 'all' && i.status !== intStatus) return false;
                      const q = intQuery.trim().toLowerCase();
                      if (!q) return true;
                      return (i.jobTitle || '').toLowerCase().includes(q) || (i.candidateName || '').toLowerCase().includes(q);
                    });
                    const sorted = [...filtered].sort((a,b) => {
                      if (intSortKey==='when') { const ta=a.scheduledAt.getTime(); const tb=b.scheduledAt.getTime(); return intSortDir==='asc'? ta-tb : tb-ta; }
                      if (intSortKey==='job') return intSortDir==='asc' ? (a.jobTitle||'').localeCompare(b.jobTitle||'') : (b.jobTitle||'').localeCompare(a.jobTitle||'');
                      return intSortDir==='asc' ? a.status.localeCompare(b.status) : b.status.localeCompare(a.status);
                    });
                    return sorted.length === 0 ? (
                      <tr><td colSpan={4} className="px-4 py-8 text-center text-gray-600">No interviews found</td></tr>
                    ) : sorted.map(i => {
                      const relatedApp = applications.find(app => app.id === i.applicationId);
                      const needsDecision = i.status === 'completed' && i.feedback && relatedApp && (!relatedApp.interviewDecision || relatedApp.interviewDecision === 'pending');
                      return (
                        <tr key={i.id} className="border-t">
                          <td className="px-4 py-3 text-gray-700">
                            {i.scheduledAt.toLocaleString()}
                            {needsDecision && (
                              <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-orange-100 text-orange-800">
                                Decision Pending
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-3 font-medium text-gray-900">
                            {i.jobTitle || '—'}
                            <div className="text-xs text-gray-500">{i.candidateName}</div>
                          </td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              i.status==='scheduled'?'bg-blue-100 text-blue-800': i.status==='confirmed'?'bg-green-100 text-green-800': i.status==='rescheduled'?'bg-yellow-100 text-yellow-800': i.status==='completed'?'bg-purple-100 text-purple-800': i.status==='cancelled'?'bg-red-100 text-red-800':'bg-gray-100 text-gray-800'
                            }`}>{i.status.replace('_',' ')}</span>
                          </td>
                          <td className="px-4 py-3 text-right">
                            <button
                              className={`px-3 py-1.5 text-xs rounded hover:opacity-90 ${
                                needsDecision ? 'bg-green-600 text-white font-medium' : 'bg-blue-600 text-white'
                              }`}
                              onClick={() => { setSelectedInterview(i); setShowInterviewDetails(true); }}
                            >
                              {needsDecision ? 'Make Decision' : 'View'}
                            </button>
                          </td>
                        </tr>
                      );
                    });
                  })()}
                </tbody>
              </table>
            </div>
          </div>

          {/* Interview Details Modal */}
          {showInterviewDetails && selectedInterview && (
            <div className="fixed inset-0 z-50">
              <div className="absolute inset-0 bg-black/40" onClick={() => { setShowInterviewDetails(false); setSelectedInterview(null); }} />
              <div className="absolute inset-0 flex items-center justify-center p-4">
                <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden">
                  <div className="flex items-center justify-between px-6 py-4 border-b">
                    <div className="font-semibold text-gray-900">Interview</div>
                    <button onClick={() => { setShowInterviewDetails(false); setSelectedInterview(null); }} className="p-2 text-gray-500 hover:text-gray-700" aria-label="Close">
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="p-6 max-h-[80vh] overflow-auto">
                    <InterviewCard interview={selectedInterview} showActions={true} />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'workflows' && (
        <WorkflowDashboard />
      )}

      {activeTab === 'analytics' && (
        <JobAnalytics
          jobs={myJobs}
          applications={applications}
          recruiterBids={bids}
        />
      )}

      {activeTab === 'team' && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <EmployerTeamManager />
        </div>
      )}

      {activeTab === 'billing' && (
        <BillingDashboard />
      )}

      {activeTab === 'payments' && (
        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Platform Payments</h2>
            <p className="text-gray-600 mb-6">
              Track your payments to the platform for recruiter placements. Payment is made once when a candidate is hired.
            </p>

            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left px-4 py-3 font-medium text-gray-700">Job</th>
                    <th className="text-left px-4 py-3 font-medium text-gray-700">Candidate</th>
                    <th className="text-left px-4 py-3 font-medium text-gray-700">Recruiter</th>
                    <th className="text-left px-4 py-3 font-medium text-gray-700">Amount</th>
                    <th className="text-left px-4 py-3 font-medium text-gray-700">Status</th>
                    <th className="text-left px-4 py-3 font-medium text-gray-700">Payment Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {employerPayments.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                        No payments found
                      </td>
                    </tr>
                  ) : (
                    employerPayments.map((payment) => {
                      const bid = bids.find(b => b.id === payment.recruiterBidId);
                      const job = myJobs.find(j => j.id === payment.jobId);
                      const application = applications.find(a => a.id === payment.applicationId);

                      return (
                        <tr key={payment.id} className="hover:bg-gray-50">
                          <td className="px-4 py-3 text-gray-900">{job?.title || 'Unknown Job'}</td>
                          <td className="px-4 py-3 text-gray-900">
                            {application?.candidateName || 'Unknown'}
                            <div className="text-xs text-gray-500">{application?.candidateEmail}</div>
                          </td>
                          <td className="px-4 py-3 text-gray-900">
                            {(bid as any)?.recruiterName || 'Unknown'}
                            <div className="text-xs text-gray-500">{(bid as any)?.recruiterCompany}</div>
                          </td>
                          <td className="px-4 py-3 font-medium text-gray-900">
                            ${(payment.amount / 100).toFixed(2)}
                          </td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              payment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                              payment.status === 'paid' ? 'bg-green-100 text-green-800' :
                              payment.status === 'failed' ? 'bg-red-100 text-red-800' :
                              'bg-gray-100 text-gray-800'
                            }`}>
                              {payment.status}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-gray-600">
                            {payment.paymentDate ? payment.paymentDate.toLocaleDateString() : '—'}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {employerPayments.length > 0 && (
              <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-start">
                  <DollarSign className="w-5 h-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                  <div className="text-sm text-blue-700">
                    <p className="font-medium mb-1">Payment Information</p>
                    <p>
                      Payments are made once when you hire a candidate sourced through a recruiter.
                      The platform manages the distribution to recruiters over 3 months (15%, 15%, 70%).
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Job Post Form Modal */}
      {showJobForm && (
        <JobPostForm onClose={() => setShowJobForm(false)} />
      )}

     {/* Job Edit Form Modal */}
     {showEditForm && editingJob && (
       <JobEditForm 
         job={editingJob}
         onClose={() => {
           setShowEditForm(false);
           setEditingJob(null);
         }}
         onSave={() => {
           // Refresh will happen automatically via useJobs hook
         }}
       />
     )}

      {/* Interview Scheduler Modal */}
      {showInterviewScheduler && selectedApplication && (
        <InterviewScheduler
          applicationId={selectedApplication.id}
          candidateId={selectedApplication.candidateId}
          onClose={() => {
            setShowInterviewScheduler(false);
            setSelectedApplication(null);
          }}
        />
      )}

      {showAppDetails && selectedApplication && (
        <ApplicationDetailsModal
          application={selectedApplication}
          isOpen={showAppDetails}
          onClose={() => { setShowAppDetails(false); setSelectedApplication(null); }}
        />
      )}

      {/* Document Share Modal */}
      {showDocumentShare && shareRecipient && (
        <DocumentShareForm
          recipientId={shareRecipient.id}
          recipientName={shareRecipient.name}
          onClose={() => {
            setShowDocumentShare(false);
            setShareRecipient(null);
          }}
        />
      )}

      {/* Company Profile + Subscription Wizard */}
      {showCompanyProfile && (
        <CompanyProfileModal onClose={() => setShowCompanyProfile(false)} />
      )}

      {/* Candidate Comparison Modal */}
      {showComparisonModal && candidatesForComparison.length > 0 && (
        <CandidateComparisonModal
          candidates={candidatesForComparison}
          isOpen={showComparisonModal}
          onClose={() => {
            setShowComparisonModal(false);
            setCandidatesForComparison([]);
          }}
          onScheduleInterview={(appId) => {
            const app = applications.find(a => a.id === appId);
            if (app) {
              setSelectedApplication(app);
              setShowInterviewScheduler(true);
              setShowComparisonModal(false);
            }
          }}
          onShortlist={(appId) => {
            handleApplicationAction(appId, 'shortlisted');
          }}
        />
      )}

      {/* Candidate Assistant Popup - Always available */}
      {selectedJobForAnalysis && (
        <CandidateAssistantPopup
          job={selectedJobForAnalysis}
          applications={applications.filter(a => a.jobId === selectedJobForAnalysis.id)}
          bids={bids.filter(b => b.jobId === selectedJobForAnalysis.id)}
          onViewCandidate={(appId) => {
            const app = applications.find(a => a.id === appId);
            if (app) {
              setSelectedApplication(app);
              setShowAppDetails(true);
            }
          }}
          onCompareCandidates={(appIds) => {
            const candidates = applications.filter(a => appIds.includes(a.id));
            setCandidatesForComparison(candidates);
            setShowComparisonModal(true);
          }}
        />
      )}
    </div>
  );
};

export default EmployerDashboard;
