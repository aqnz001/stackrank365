import React, { useState } from 'react';
import { X, User, Mail, Phone, MapPin, DollarSign, Calendar, Award, TrendingUp, CheckCircle, AlertCircle } from 'lucide-react';
import type { Application } from '../../types';
import type { RankedCandidate } from '../../utils/candidateRanking';

interface CandidateComparisonModalProps {
  candidates: (Application | RankedCandidate)[];
  isOpen: boolean;
  onClose: () => void;
  onScheduleInterview?: (applicationId: string) => void;
  onShortlist?: (applicationId: string) => void;
}

const CandidateComparisonModal: React.FC<CandidateComparisonModalProps> = ({
  candidates,
  isOpen,
  onClose,
  onScheduleInterview,
  onShortlist,
}) => {
  const [syncScroll, setSyncScroll] = useState(true);

  if (!isOpen || candidates.length === 0) return null;

  const isRankedCandidate = (candidate: Application | RankedCandidate): candidate is RankedCandidate => {
    return 'score' in candidate;
  };

  const getBestValue = (field: keyof Application, candidates: Application[]) => {
    if (field === 'salaryExpectation') {
      const values = candidates.map(c => c.salaryExpectation).filter(v => v !== undefined) as number[];
      return values.length > 0 ? Math.min(...values) : undefined;
    }
    return undefined;
  };

  const compareValues = (value: any, bestValue: any): 'best' | 'comparable' | 'lower' => {
    if (value === bestValue) return 'best';
    if (typeof value === 'number' && typeof bestValue === 'number') {
      const diff = Math.abs(value - bestValue) / bestValue;
      if (diff < 0.15) return 'comparable';
      return value < bestValue ? 'best' : 'lower';
    }
    return 'comparable';
  };

  const getComparisonColor = (comparison: 'best' | 'comparable' | 'lower'): string => {
    if (comparison === 'best') return 'bg-green-50 border-green-200';
    if (comparison === 'comparable') return 'bg-amber-50 border-amber-200';
    return 'bg-gray-50 border-gray-200';
  };

  const bestSalary = getBestValue('salaryExpectation', candidates);

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="bg-white w-full max-w-7xl rounded-xl shadow-2xl overflow-hidden" style={{ maxHeight: '90vh' }}>
          <div className="flex items-center justify-between px-6 py-4 border-b bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-6 h-6" />
              <div>
                <h3 className="text-xl font-semibold">Candidate Comparison</h3>
                <p className="text-sm text-blue-100">Compare {candidates.length} candidates side by side</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={syncScroll}
                  onChange={(e) => setSyncScroll(e.target.checked)}
                  className="rounded"
                />
                Sync scroll
              </label>
              <button onClick={onClose} className="p-2 text-white/80 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="overflow-x-auto overflow-y-auto" style={{ maxHeight: 'calc(90vh - 80px)' }}>
            <div className="flex">
              <div className="w-48 sticky left-0 bg-gray-50 border-r flex-shrink-0">
                <div className="h-16 border-b flex items-center px-4">
                  <span className="font-semibold text-gray-900">Criteria</span>
                </div>
                {['Overview', 'Contact', 'Score Breakdown', 'Skills Match', 'Experience', 'Location', 'Salary', 'Availability', 'Additional Info'].map((section, idx) => (
                  <div key={idx} className="border-b">
                    <div className="px-4 py-3 font-medium text-gray-700 bg-gray-100">{section}</div>
                    {section === 'Overview' && (
                      <>
                        <div className="px-4 py-2 text-sm text-gray-600">Name</div>
                        <div className="px-4 py-2 text-sm text-gray-600">Status</div>
                        <div className="px-4 py-2 text-sm text-gray-600">Source</div>
                      </>
                    )}
                    {section === 'Contact' && (
                      <>
                        <div className="px-4 py-2 text-sm text-gray-600">Email</div>
                        <div className="px-4 py-2 text-sm text-gray-600">Phone</div>
                      </>
                    )}
                    {section === 'Score Breakdown' && isRankedCandidate(candidates[0]) && (
                      <>
                        <div className="px-4 py-2 text-sm text-gray-600">Overall</div>
                        <div className="px-4 py-2 text-sm text-gray-600">Skills</div>
                        <div className="px-4 py-2 text-sm text-gray-600">Experience</div>
                        <div className="px-4 py-2 text-sm text-gray-600">Education</div>
                        <div className="px-4 py-2 text-sm text-gray-600">Location</div>
                        <div className="px-4 py-2 text-sm text-gray-600">Salary</div>
                      </>
                    )}
                  </div>
                ))}
              </div>

              {candidates.map((candidate, idx) => (
                <div key={candidate.id} className="flex-1 min-w-[300px] border-r">
                  <div className="h-16 border-b bg-blue-50 flex items-center justify-center px-4">
                    <div className="text-center">
                      <div className="font-semibold text-gray-900">Candidate {idx + 1}</div>
                      {isRankedCandidate(candidate) && (
                        <div className="text-xs text-blue-600">Rank #{candidate.score.rank}</div>
                      )}
                    </div>
                  </div>

                  <div className="border-b">
                    <div className="px-4 py-3 font-medium text-gray-700 bg-gray-100">Overview</div>
                    <div className="px-4 py-2 text-sm">
                      <div className="font-medium text-gray-900">{candidate.candidateName}</div>
                    </div>
                    <div className="px-4 py-2 text-sm">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        candidate.status === 'submitted' ? 'bg-blue-100 text-blue-800' :
                        candidate.status === 'shortlisted' ? 'bg-green-100 text-green-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {candidate.status}
                      </span>
                    </div>
                    <div className="px-4 py-2 text-sm">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        candidate.source === 'recruiter' ? 'bg-purple-100 text-purple-800' :
                        'bg-green-100 text-green-800'
                      }`}>
                        {candidate.source === 'recruiter' ? 'Recruiter' : 'Direct'}
                      </span>
                    </div>
                  </div>

                  <div className="border-b">
                    <div className="px-4 py-3 font-medium text-gray-700 bg-gray-100">Contact</div>
                    <div className="px-4 py-2 text-sm">
                      <div className="flex items-center gap-2 text-gray-700">
                        <Mail className="w-4 h-4 text-gray-400" />
                        {candidate.candidateEmail}
                      </div>
                    </div>
                    <div className="px-4 py-2 text-sm">
                      <div className="flex items-center gap-2 text-gray-700">
                        <Phone className="w-4 h-4 text-gray-400" />
                        {candidate.phone || 'Not provided'}
                      </div>
                    </div>
                  </div>

                  {isRankedCandidate(candidate) && (
                    <div className="border-b">
                      <div className="px-4 py-3 font-medium text-gray-700 bg-gray-100">Score Breakdown</div>
                      <div className="px-4 py-2">
                        <div className={`text-xl font-bold inline-flex items-center px-3 py-1 rounded-full ${
                          candidate.score.totalScore >= 80 ? 'bg-green-100 text-green-800' :
                          candidate.score.totalScore >= 60 ? 'bg-blue-100 text-blue-800' :
                          'bg-yellow-100 text-yellow-800'
                        }`}>
                          {candidate.score.totalScore}%
                        </div>
                      </div>
                      <div className="px-4 py-2 text-sm text-gray-700">{candidate.score.breakdown.skillsScore}%</div>
                      <div className="px-4 py-2 text-sm text-gray-700">{candidate.score.breakdown.experienceScore}%</div>
                      <div className="px-4 py-2 text-sm text-gray-700">{candidate.score.breakdown.educationScore}%</div>
                      <div className="px-4 py-2 text-sm text-gray-700">{candidate.score.breakdown.locationScore}%</div>
                      <div className="px-4 py-2 text-sm text-gray-700">{candidate.score.breakdown.salaryScore}%</div>
                    </div>
                  )}

                  <div className="border-b">
                    <div className="px-4 py-3 font-medium text-gray-700 bg-gray-100">Skills Match</div>
                    <div className="px-4 py-2 text-sm text-gray-700">
                      {isRankedCandidate(candidate) ? (
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-blue-600 h-2 rounded-full"
                              style={{ width: `${candidate.score.breakdown.skillsScore}%` }}
                            />
                          </div>
                          <span className="font-medium">{candidate.score.breakdown.skillsScore}%</span>
                        </div>
                      ) : (
                        'Calculating...'
                      )}
                    </div>
                  </div>

                  <div className="border-b">
                    <div className="px-4 py-3 font-medium text-gray-700 bg-gray-100">Experience</div>
                    <div className="px-4 py-2 text-sm text-gray-700">
                      {candidate.workAuthorization || 'Not specified'}
                    </div>
                  </div>

                  <div className="border-b">
                    <div className="px-4 py-3 font-medium text-gray-700 bg-gray-100">Location</div>
                    <div className="px-4 py-2 text-sm">
                      <div className="flex items-center gap-2 text-gray-700">
                        <MapPin className="w-4 h-4 text-gray-400" />
                        {candidate.location || 'Not provided'}
                      </div>
                      {candidate.willingToRelocate && (
                        <div className="text-xs text-green-600 mt-1 flex items-center gap-1">
                          <CheckCircle className="w-3 h-3" />
                          Willing to relocate
                        </div>
                      )}
                    </div>
                  </div>

                  <div className={`border-b ${candidate.salaryExpectation && bestSalary ? getComparisonColor(compareValues(candidate.salaryExpectation, bestSalary)) : ''}`}>
                    <div className="px-4 py-3 font-medium text-gray-700 bg-gray-100">Salary</div>
                    <div className="px-4 py-2 text-sm">
                      {candidate.salaryExpectation ? (
                        <div className="flex items-center gap-2">
                          <DollarSign className="w-4 h-4 text-gray-400" />
                          <span className="font-semibold text-gray-900">
                            ${candidate.salaryExpectation.toLocaleString()}
                          </span>
                          {candidate.salaryExpectation === bestSalary && (
                            <CheckCircle className="w-4 h-4 text-green-600" />
                          )}
                        </div>
                      ) : (
                        <span className="text-gray-500">Not provided</span>
                      )}
                    </div>
                  </div>

                  <div className="border-b">
                    <div className="px-4 py-3 font-medium text-gray-700 bg-gray-100">Availability</div>
                    <div className="px-4 py-2 text-sm">
                      {candidate.availabilityDate ? (
                        <div className="flex items-center gap-2 text-gray-700">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          {new Date(candidate.availabilityDate).toLocaleDateString()}
                        </div>
                      ) : (
                        <span className="text-green-600 flex items-center gap-1">
                          <CheckCircle className="w-4 h-4" />
                          Immediate
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="border-b">
                    <div className="px-4 py-3 font-medium text-gray-700 bg-gray-100">Additional Info</div>
                    <div className="px-4 py-2 text-sm text-gray-700 max-h-32 overflow-y-auto">
                      {candidate.additionalInfo || candidate.coverLetter ? (
                        <p className="whitespace-pre-wrap">{candidate.additionalInfo || candidate.coverLetter?.substring(0, 200)}</p>
                      ) : (
                        <span className="text-gray-500 italic">No additional information</span>
                      )}
                    </div>
                  </div>

                  <div className="px-4 py-4 space-y-2 bg-gray-50">
                    {onShortlist && candidate.status !== 'shortlisted' && (
                      <button
                        onClick={() => onShortlist(candidate.id)}
                        className="w-full px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center justify-center gap-2"
                      >
                        <Award className="w-4 h-4" />
                        Shortlist
                      </button>
                    )}
                    {onScheduleInterview && (
                      <button
                        onClick={() => onScheduleInterview(candidate.id)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100 flex items-center justify-center gap-2"
                      >
                        <Calendar className="w-4 h-4" />
                        Schedule Interview
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CandidateComparisonModal;
