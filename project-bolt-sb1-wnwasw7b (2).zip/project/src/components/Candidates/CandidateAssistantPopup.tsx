import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, Minimize2, Maximize2, X, Bot, User, Sparkles } from 'lucide-react';
import type { Job, Application, RecruiterBid } from '../../types';
import { supabase } from '../../lib/supabase';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  actions?: Array<{ label: string; onClick: () => void }>;
}

interface CandidateAssistantPopupProps {
  job: Job;
  applications: Application[];
  bids?: RecruiterBid[];
  onViewCandidate?: (applicationId: string) => void;
  onCompareCandidates?: (applicationIds: string[]) => void;
}

const CandidateAssistantPopup: React.FC<CandidateAssistantPopupProps> = ({
  job,
  applications,
  bids = [],
  onViewCandidate,
  onCompareCandidates,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messages.length === 0 && isOpen) {
      addMessage('assistant', `Hi! I'm your recruitment assistant for the ${job.title} position. I can help you analyze candidates, answer questions about applications, and compare profiles. What would you like to know?`);
    }
  }, [isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const addMessage = (role: 'user' | 'assistant', content: string, actions?: Array<{ label: string; onClick: () => void }>) => {
    const message: Message = {
      id: Date.now().toString(),
      role,
      content,
      timestamp: new Date(),
      actions,
    };
    setMessages(prev => [...prev, message]);
  };

  const analyzeWithAI = async (query: string, application: Application, parsedData?: any): Promise<string> => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('No active session');
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-candidate`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            query,
            applicationData: application,
            parsedResumeData: parsedData,
            jobDetails: {
              title: job.title,
              company: job.organizationName,
              description: job.description,
              requirements: job.requirements,
            },
          }),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to get AI analysis');
      }

      const result = await response.json();
      return result.analysis || 'Unable to generate analysis at this time.';
    } catch (error) {
      console.error('AI analysis error:', error);
      return buildFallbackSummary(application, parsedData);
    }
  };

  const buildFallbackSummary = (application: Application, parsedData?: any): string => {
    let summary = `**${application.candidateName} - Candidate Profile**\n\n`;
    summary += `**Status**: ${application.status} | **Applied**: ${new Date(application.createdAt).toLocaleDateString()}\n`;
    summary += `**Source**: ${application.source === 'recruiter' ? 'Recruiter Submission' : 'Direct Application'}\n\n`;

    if (parsedData && parsedData.parsing_status === 'completed') {
      const skills = parsedData.parsed_skills || [];
      const experiences = parsedData.parsed_experiences || [];

      summary += `**Key Qualifications:**\n`;

      if (skills.length > 0) {
        summary += `• ${skills.length} documented skills including ${skills.slice(0, 3).join(', ')}\n`;
      }

      if (experiences.length > 0) {
        summary += `• ${experiences.length} professional role${experiences.length > 1 ? 's' : ''}\n`;
        const latestRole = experiences[0];
        summary += `• Most recent: ${latestRole.jobTitle || 'Position'} at ${latestRole.company || 'Company'}\n`;
      }
      summary += `\n`;
    } else {
      summary += `*Resume analysis pending - full profile will be available once parsing completes.*\n\n`;
    }

    if (application.salaryExpectation) {
      summary += `**Compensation Expectation**: $${application.salaryExpectation.toLocaleString()}/year\n`;
    }

    if (application.location) {
      summary += `**Location**: ${application.location}`;
      if (application.willingToRelocate) summary += ` (Open to relocation)`;
      summary += `\n`;
    }

    if (application.coverLetter) {
      summary += `\n**Candidate Motivation**: Review cover letter for detailed interest in role and company alignment.\n`;
    }

    summary += `\n**Next Steps**: Review full application details and consider for ${application.status === 'submitted' ? 'shortlist' : 'interview'}.`;

    return summary;
  };

  const parseQuery = (query: string): { type: string; params: any } => {
    const lowerQuery = query.toLowerCase().trim();

    if (lowerQuery.includes('how many') || lowerQuery.includes('total') || lowerQuery.includes('count')) {
      if (lowerQuery.includes('shortlist')) {
        return { type: 'count_shortlisted', params: {} };
      }
      if (lowerQuery.includes('recruiter') || lowerQuery.includes('bid')) {
        return { type: 'count_recruiter', params: {} };
      }
      if (lowerQuery.includes('direct')) {
        return { type: 'count_direct', params: {} };
      }
      return { type: 'count_total', params: {} };
    }

    if (lowerQuery.includes('top') || lowerQuery.includes('best') || lowerQuery.includes('highest')) {
      const numberMatch = lowerQuery.match(/(\d+)/);
      const count = numberMatch ? parseInt(numberMatch[1]) : 3;
      return { type: 'top_candidates', params: { count } };
    }

    if (lowerQuery.includes('compare')) {
      return { type: 'compare_prompt', params: {} };
    }

    if (lowerQuery.includes('skill') || lowerQuery.includes('experience with')) {
      const skillMatches = job.skills?.filter(skill =>
        lowerQuery.includes(skill.toLowerCase())
      ) || [];

      if (skillMatches.length > 0) {
        return { type: 'find_by_skill', params: { skills: skillMatches } };
      }

      const skillWords = lowerQuery.match(/with\s+([a-z]+(\s+[a-z]+)?)/i);
      if (skillWords) {
        return { type: 'find_by_skill', params: { skills: [skillWords[1]] } };
      }
    }

    if (lowerQuery.includes('available') || lowerQuery.includes('start')) {
      if (lowerQuery.includes('immediate') || lowerQuery.includes('now') || lowerQuery.includes('soon')) {
        return { type: 'available_immediately', params: {} };
      }
      const daysMatch = lowerQuery.match(/(\d+)\s*(day|week|month)/);
      if (daysMatch) {
        return { type: 'available_within', params: { timeframe: daysMatch[0] } };
      }
    }

    if (lowerQuery.includes('salary') || lowerQuery.includes('budget') || lowerQuery.includes('compensation')) {
      const amountMatch = lowerQuery.match(/(\d+)[k,]?/);
      if (amountMatch) {
        const amount = parseInt(amountMatch[1]) * (lowerQuery.includes('k') ? 1000 : 1);
        if (lowerQuery.includes('under') || lowerQuery.includes('below') || lowerQuery.includes('less')) {
          return { type: 'salary_under', params: { amount } };
        }
        if (lowerQuery.includes('over') || lowerQuery.includes('above') || lowerQuery.includes('more')) {
          return { type: 'salary_over', params: { amount } };
        }
      }
      return { type: 'salary_info', params: {} };
    }

    if (lowerQuery.includes('location') || lowerQuery.includes('where') || lowerQuery.includes('from')) {
      const locationMatch = lowerQuery.match(/from\s+([a-z\s]+)/i);
      if (locationMatch) {
        return { type: 'find_by_location', params: { location: locationMatch[1].trim() } };
      }
      return { type: 'location_summary', params: {} };
    }

    if (lowerQuery.includes('recruiter') && (lowerQuery.includes('who') || lowerQuery.includes('which'))) {
      return { type: 'recruiter_summary', params: {} };
    }

    if (lowerQuery.includes('status') || lowerQuery.includes('stage')) {
      return { type: 'status_summary', params: {} };
    }

    if (lowerQuery.includes('help') || lowerQuery.includes('what can')) {
      return { type: 'help', params: {} };
    }

    if (lowerQuery.includes('resume') || lowerQuery.includes('summarise') || lowerQuery.includes('summarize') || lowerQuery.includes('tell me about')) {
      const nameMatch = lowerQuery.match(/(?:resume|summarise|summarize|about)\s+([a-z0-9]+(?:['']?s)?)/i);
      if (nameMatch) {
        return { type: 'resume_summary', params: { candidateName: nameMatch[1].trim() } };
      }
    }

    return { type: 'general', params: { query } };
  };

  const processQuery = async (query: string) => {
    const parsed = parseQuery(query);

    switch (parsed.type) {
      case 'count_total':
        return {
          response: `You have **${applications.length} total applications** for this ${job.title} position.`,
        };

      case 'count_shortlisted':
        const shortlisted = applications.filter(a => a.status === 'shortlisted');
        return {
          response: `You have **${shortlisted.length} shortlisted candidates** out of ${applications.length} total applications.`,
        };

      case 'count_recruiter':
        const recruiterApps = applications.filter(a => a.source === 'recruiter');
        return {
          response: `**${recruiterApps.length} applications** came from recruiter bids, and **${bids.length} total bids** have been submitted for this job.`,
        };

      case 'count_direct':
        const directApps = applications.filter(a => a.source === 'direct');
        return {
          response: `**${directApps.length} direct applications** have been submitted by candidates.`,
        };

      case 'top_candidates': {
        const count = Math.min(parsed.params.count, applications.length);
        const topCandidates = applications.slice(0, count);
        const candidateList = topCandidates.map((app, idx) =>
          `${idx + 1}. **${app.candidateName}** - ${app.status} (${app.source})`
        ).join('\n');

        const actions = topCandidates.length >= 2 ? [{
          label: `Compare Top ${Math.min(3, topCandidates.length)}`,
          onClick: () => {
            if (onCompareCandidates) {
              onCompareCandidates(topCandidates.slice(0, 3).map(c => c.id));
            }
          }
        }] : [];

        return {
          response: `Here are the top ${count} candidate${count > 1 ? 's' : ''}:\n\n${candidateList}`,
          actions,
        };
      }

      case 'find_by_skill': {
        const skills = parsed.params.skills;
        const matching = applications.filter(app => {
          const text = `${app.coverLetter || ''} ${app.additionalInfo || ''}`.toLowerCase();
          return skills.some((skill: string) => text.includes(skill.toLowerCase()));
        });

        if (matching.length === 0) {
          return {
            response: `No candidates found with explicit mention of **${skills.join(', ')}** in their applications. You may want to review resumes or conduct skills assessments during interviews.`,
          };
        }

        const candidateList = matching.slice(0, 5).map((app, idx) =>
          `${idx + 1}. **${app.candidateName}** - ${app.status}`
        ).join('\n');

        return {
          response: `Found **${matching.length} candidates** who mention **${skills.join(', ')}**:\n\n${candidateList}${matching.length > 5 ? '\n\n...and more.' : ''}`,
        };
      }

      case 'available_immediately': {
        const immediate = applications.filter(app => {
          if (!app.availabilityDate) return true;
          const diffDays = Math.ceil((app.availabilityDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
          return diffDays <= 7;
        });

        const candidateList = immediate.slice(0, 5).map((app, idx) =>
          `${idx + 1}. **${app.candidateName}** - ${app.availabilityDate ? new Date(app.availabilityDate).toLocaleDateString() : 'Immediate'}`
        ).join('\n');

        return {
          response: `**${immediate.length} candidates** are available immediately or within a week:\n\n${candidateList}`,
        };
      }

      case 'salary_under': {
        const amount = parsed.params.amount;
        const matching = applications.filter(app =>
          app.salaryExpectation && app.salaryExpectation <= amount
        );

        return {
          response: `**${matching.length} candidates** have salary expectations at or below $${amount.toLocaleString()}.`,
        };
      }

      case 'salary_info': {
        const withSalary = applications.filter(a => a.salaryExpectation);
        if (withSalary.length === 0) {
          return { response: 'No candidates have provided salary expectations yet.' };
        }

        const salaries = withSalary.map(a => a.salaryExpectation!);
        const avg = Math.round(salaries.reduce((sum, s) => sum + s, 0) / salaries.length);
        const min = Math.min(...salaries);
        const max = Math.max(...salaries);

        return {
          response: `Salary expectations among ${withSalary.length} candidates:\n• Average: **$${avg.toLocaleString()}**\n• Range: $${min.toLocaleString()} - $${max.toLocaleString()}`,
        };
      }

      case 'find_by_location': {
        const location = parsed.params.location;
        const matching = applications.filter(app =>
          app.location?.toLowerCase().includes(location.toLowerCase())
        );

        if (matching.length === 0) {
          const willRelocate = applications.filter(a => a.willingToRelocate);
          return {
            response: `No candidates currently in ${location}, but **${willRelocate.length} candidates** are willing to relocate.`,
          };
        }

        return {
          response: `**${matching.length} candidates** are from or near **${location}**.`,
        };
      }

      case 'location_summary': {
        const locations: Record<string, number> = {};
        applications.forEach(app => {
          if (app.location) {
            const loc = app.location.split(',')[0].trim();
            locations[loc] = (locations[loc] || 0) + 1;
          }
        });

        const topLocations = Object.entries(locations)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 5)
          .map(([loc, count]) => `• **${loc}**: ${count}`)
          .join('\n');

        return {
          response: `Candidate locations:\n${topLocations}`,
        };
      }

      case 'recruiter_summary': {
        const recruiterApps = applications.filter(a => a.source === 'recruiter' && a.recruiterBidId);
        if (recruiterApps.length === 0) {
          return { response: 'No candidates have been submitted through recruiter bids yet.' };
        }

        return {
          response: `**${recruiterApps.length} candidates** were submitted by recruiters through accepted bids.`,
        };
      }

      case 'status_summary': {
        const statusCounts: Record<string, number> = {};
        applications.forEach(app => {
          statusCounts[app.status] = (statusCounts[app.status] || 0) + 1;
        });

        const summary = Object.entries(statusCounts)
          .map(([status, count]) => `• **${status}**: ${count}`)
          .join('\n');

        return {
          response: `Application status breakdown:\n${summary}`,
        };
      }

      case 'compare_prompt':
        return {
          response: 'To compare candidates, please select 2-3 candidates from the dashboard and click the "Compare" button, or ask me to show the "top 3 candidates".',
        };

      case 'help':
        return {
          response: `I can help you with:\n\n• **Counting**: "How many applications?", "How many from recruiters?"\n• **Finding**: "Show me candidates with Python experience", "Who's available immediately?"\n• **Analyzing**: "What's the average salary?", "Where are candidates from?"\n• **Comparing**: "Show me the top 3 candidates"\n• **Resumes**: "Summarise James1's resume", "Tell me about Sarah's resume"\n\nJust ask naturally, and I'll help you find what you need!`,
        };

      case 'resume_summary': {
        const candidateName = parsed.params.candidateName.replace(/['']s$/, '');
        const matchingApp = applications.find(app =>
          app.candidateName.toLowerCase().includes(candidateName.toLowerCase())
        );

        if (!matchingApp) {
          return {
            response: `I couldn't find a candidate with a name matching "${candidateName}". Please check the spelling or try asking about another candidate.`,
          };
        }

        try {
          const { data: parsedData, error } = await supabase
            .from('resume_parsed_data')
            .select('*')
            .eq('user_id', matchingApp.candidateId)
            .order('parsed_at', { ascending: false })
            .limit(1)
            .maybeSingle();

          if (error) {
            console.error('Error fetching resume data:', error);
          }

          const analysis = await analyzeWithAI(
            `Provide a comprehensive summary and analysis of ${candidateName}'s qualifications, experience, and fit for the ${job.title} position. Include key strengths, relevant experience, and a recommendation on next steps.`,
            matchingApp,
            parsedData
          );

          return { response: analysis };
        } catch (err) {
          console.error('Error processing resume summary:', err);
          const summary = buildFallbackSummary(matchingApp, null);
          return { response: summary };
        }
      }

      default:
        return {
          response: `I'm not sure how to help with that. Try asking about candidate counts, skills, availability, salary, locations, or candidate resumes. Type "help" for examples.`,
        };
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isProcessing) return;

    const userMessage = input.trim();
    setInput('');
    addMessage('user', userMessage);
    setIsProcessing(true);

    await new Promise(resolve => setTimeout(resolve, 500));

    const result = await processQuery(userMessage);
    addMessage('assistant', result.response, result.actions);
    setIsProcessing(false);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all flex items-center justify-center z-40"
        title="Open Assistant"
      >
        <MessageSquare className="w-6 h-6" />
      </button>
    );
  }

  return (
    <div
      className={`fixed z-40 bg-white rounded-xl shadow-2xl border border-gray-200 flex flex-col transition-all ${
        isMinimized
          ? 'bottom-6 right-6 w-80 h-16'
          : 'bottom-6 right-6 w-96 h-[600px]'
      }`}
    >
      <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-xl">
        <div className="flex items-center gap-2">
          <Bot className="w-5 h-5" />
          <span className="font-semibold">Recruitment Assistant</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1 hover:bg-white/20 rounded"
          >
            {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
          </button>
          <button
            onClick={() => setIsOpen(false)}
            className="p-1 hover:bg-white/20 rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {!isMinimized && (
        <>
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.role === 'user' ? 'bg-blue-600' : 'bg-purple-600'
                }`}>
                  {message.role === 'user' ? (
                    <User className="w-4 h-4 text-white" />
                  ) : (
                    <Sparkles className="w-4 h-4 text-white" />
                  )}
                </div>
                <div className={`flex-1 ${message.role === 'user' ? 'text-right' : ''}`}>
                  <div
                    className={`inline-block px-4 py-2 rounded-lg ${
                      message.role === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                    style={{ whiteSpace: 'pre-line' }}
                    dangerouslySetInnerHTML={{
                      __html: message.content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                    }}
                  />
                  {message.actions && message.actions.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {message.actions.map((action, idx) => (
                        <button
                          key={idx}
                          onClick={action.onClick}
                          className="px-3 py-1 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700"
                        >
                          {action.label}
                        </button>
                      ))}
                    </div>
                  )}
                  <div className="text-xs text-gray-500 mt-1">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
            ))}
            {isProcessing && (
              <div className="flex gap-3">
                <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-white animate-pulse" />
                </div>
                <div className="bg-gray-100 px-4 py-2 rounded-lg">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <form onSubmit={handleSubmit} className="p-4 border-t">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about candidates..."
                className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                disabled={isProcessing}
              />
              <button
                type="submit"
                disabled={!input.trim() || isProcessing}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </form>
        </>
      )}
    </div>
  );
};

export default CandidateAssistantPopup;
