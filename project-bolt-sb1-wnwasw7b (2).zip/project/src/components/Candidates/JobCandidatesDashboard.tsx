import React, { useState, useMemo } from 'react';
import { Users, Trophy, Filter, Settings, Eye, MessageSquare, X, TrendingUp, UserCheck, Target, Star, Award, FileText } from 'lucide-react';
import type { Job, Application } from '../../types';
import { rankCandidates, getPresetWeights, type RankingWeights, type RankedCandidate } from '../../utils/candidateRanking';
import ShortlistModal from '../Applications/ShortlistModal';
import ViewNotesModal from '../Applications/ViewNotesModal';

interface JobCandidatesDashboardProps {
  job: Job;
  applications: Application[];
  onSelectForComparison: (applications: Application[]) => void;
  onViewApplication: (application: Application) => void;
  onUpdateStatus: (applicationId: string, status: string) => void;
  onRefresh?: () => void;
}

const JobCandidatesDashboard: React.FC<JobCandidatesDashboardProps> = ({
  job,
  applications,
  onSelectForComparison,
  onViewApplication,
  onUpdateStatus,
  onRefresh,
}) => {
  const [weights, setWeights] = useState<RankingWeights>(getPresetWeights('Balanced'));
  const [showWeightsModal, setShowWeightsModal] = useState(false);
  const [selectedCandidates, setSelectedCandidates] = useState<Set<string>>(new Set());
  const [sourceFilter, setSourceFilter] = useState<'all' | 'direct' | 'recruiter'>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showShortlistedOnly, setShowShortlistedOnly] = useState(false);
  const [candidateToShortlist, setCandidateToShortlist] = useState<Application | null>(null);
  const [candidateToViewNotes, setCandidateToViewNotes] = useState<Application | null>(null);

  const rankedCandidates = useMemo(() => {
    let filtered = applications;

    if (sourceFilter !== 'all') {
      filtered = filtered.filter(app => app.source === sourceFilter);
    }

    if (showShortlistedOnly) {
      filtered = filtered.filter(app => app.status === 'shortlisted');
    } else if (statusFilter !== 'all') {
      filtered = filtered.filter(app => app.status === statusFilter);
    }

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(app =>
        app.candidateName.toLowerCase().includes(query) ||
        app.candidateEmail.toLowerCase().includes(query) ||
        app.location?.toLowerCase().includes(query)
      );
    }

    return rankCandidates(filtered, job, weights);
  }, [applications, job, weights, sourceFilter, statusFilter, searchQuery]);

  const statistics = useMemo(() => {
    const total = applications.length;
    const direct = applications.filter(a => a.source === 'direct').length;
    const recruiter = applications.filter(a => a.source === 'recruiter').length;
    const shortlisted = applications.filter(a => a.status === 'shortlisted').length;
    const avgScore = rankedCandidates.length > 0
      ? Math.round(rankedCandidates.reduce((sum, c) => sum + c.score.totalScore, 0) / rankedCandidates.length)
      : 0;

    return { total, direct, recruiter, shortlisted, avgScore };
  }, [applications, rankedCandidates]);

  const handleToggleSelect = (candidateId: string) => {
    const newSelected = new Set(selectedCandidates);
    if (newSelected.has(candidateId)) {
      newSelected.delete(candidateId);
    } else {
      if (newSelected.size >= 3) {
        alert('You can select up to 3 candidates for comparison');
        return;
      }
      newSelected.add(candidateId);
    }
    setSelectedCandidates(newSelected);
  };

  const handleCompareSelected = () => {
    const selected = rankedCandidates.filter(c => selectedCandidates.has(c.id));
    if (selected.length < 2) {
      alert('Please select at least 2 candidates to compare');
      return;
    }
    onSelectForComparison(selected);
    setSelectedCandidates(new Set());
  };

  const handleApplyPreset = (presetName: string) => {
    setWeights(getPresetWeights(presetName));
    setShowWeightsModal(false);
  };

  const getScoreColor = (score: number): string => {
    if (score >= 80) return 'text-green-700 bg-green-100';
    if (score >= 60) return 'text-blue-700 bg-blue-100';
    if (score >= 40) return 'text-yellow-700 bg-yellow-100';
    return 'text-red-700 bg-red-100';
  };

  const getRankBadge = (rank: number) => {
    if (rank === 1) return <Trophy className="w-4 h-4 text-yellow-500" />;
    if (rank === 2) return <Trophy className="w-4 h-4 text-gray-400" />;
    if (rank === 3) return <Trophy className="w-4 h-4 text-amber-600" />;
    return null;
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="px-6 py-4 border-b">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Candidates for {job.title}</h2>
              <p className="text-sm text-gray-600">Ranked by match score</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setShowShortlistedOnly(!showShortlistedOnly);
                if (!showShortlistedOnly) {
                  setStatusFilter('all');
                }
              }}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                showShortlistedOnly
                  ? 'bg-yellow-600 text-white hover:bg-yellow-700'
                  : 'border border-yellow-500 text-yellow-700 hover:bg-yellow-50'
              }`}
            >
              <Star className="w-4 h-4" />
              {showShortlistedOnly ? 'Show All' : 'Shortlisted Only'}
              {statistics.shortlisted > 0 && (
                <span className={`ml-1 px-2 py-0.5 rounded-full text-xs font-bold ${
                  showShortlistedOnly ? 'bg-yellow-500' : 'bg-yellow-100 text-yellow-900'
                }`}>
                  {statistics.shortlisted}
                </span>
              )}
            </button>
            <button
              onClick={() => setShowWeightsModal(true)}
              className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              <Settings className="w-4 h-4" />
              Ranking Config
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="bg-blue-50 rounded-lg p-3">
            <div className="text-xs font-medium text-blue-600 mb-1">Total Candidates</div>
            <div className="text-2xl font-bold text-blue-900">{statistics.total}</div>
          </div>
          <div className="bg-green-50 rounded-lg p-3">
            <div className="text-xs font-medium text-green-600 mb-1">Direct Applications</div>
            <div className="text-2xl font-bold text-green-900">{statistics.direct}</div>
          </div>
          <div className="bg-purple-50 rounded-lg p-3">
            <div className="text-xs font-medium text-purple-600 mb-1">Recruiter Sourced</div>
            <div className="text-2xl font-bold text-purple-900">{statistics.recruiter}</div>
          </div>
          <button
            onClick={() => {
              setShowShortlistedOnly(true);
              setStatusFilter('all');
            }}
            className="bg-yellow-50 rounded-lg p-3 hover:bg-yellow-100 transition-colors text-left w-full"
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-medium text-yellow-600 mb-1 flex items-center">
                  <Award className="w-3 h-3 mr-1" />
                  Shortlisted
                </div>
                <div className="text-2xl font-bold text-yellow-900">{statistics.shortlisted}</div>
              </div>
              <Star className="w-6 h-6 text-yellow-500" />
            </div>
          </button>
          <div className="bg-gray-50 rounded-lg p-3">
            <div className="text-xs font-medium text-gray-600 mb-1">Avg. Match Score</div>
            <div className="text-2xl font-bold text-gray-900">{statistics.avgScore}%</div>
          </div>
        </div>
      </div>

      {showShortlistedOnly && (
        <div className="px-6 py-3 bg-yellow-50 border-b border-yellow-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Star className="w-5 h-5 text-yellow-600 mr-2" />
              <div>
                <div className="font-medium text-yellow-900">Viewing Shortlisted Candidates Only</div>
                <div className="text-sm text-yellow-700">These candidates are ready for final decision: extend offer or reject</div>
              </div>
            </div>
            <button
              onClick={() => setShowShortlistedOnly(false)}
              className="text-yellow-600 hover:text-yellow-800 font-medium text-sm"
            >
              Clear Filter
            </button>
          </div>
        </div>
      )}

      <div className="px-6 py-4 border-b bg-gray-50 flex flex-wrap items-center gap-3">
        <input
          type="text"
          placeholder="Search candidates..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1 min-w-[200px] px-3 py-2 border rounded-lg"
        />
        <select
          value={sourceFilter}
          onChange={(e) => setSourceFilter(e.target.value as any)}
          className="px-3 py-2 border rounded-lg"
        >
          <option value="all">All Sources</option>
          <option value="direct">Direct Only</option>
          <option value="recruiter">Recruiter Only</option>
        </select>
        <select
          value={statusFilter}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            setShowShortlistedOnly(false);
          }}
          disabled={showShortlistedOnly}
          className="px-3 py-2 border rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <option value="all">All Statuses</option>
          <option value="submitted">Submitted</option>
          <option value="shortlisted">Shortlisted</option>
          <option value="rejected">Rejected</option>
          <option value="hired">Hired</option>
        </select>
        {selectedCandidates.size > 0 && (
          <button
            onClick={handleCompareSelected}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
          >
            <Target className="w-4 h-4" />
            Compare ({selectedCandidates.size})
          </button>
        )}
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">Select</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">Rank</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">Candidate</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">Source</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">Match Score</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">Skills</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-600 uppercase">Applied</th>
              <th className="px-4 py-3 text-right text-xs font-medium text-gray-600 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {rankedCandidates.map((candidate) => (
              <tr
                key={candidate.id}
                className={`hover:bg-gray-50 ${selectedCandidates.has(candidate.id) ? 'bg-blue-50' : ''}`}
              >
                <td className="px-4 py-3">
                  <input
                    type="checkbox"
                    checked={selectedCandidates.has(candidate.id)}
                    onChange={() => handleToggleSelect(candidate.id)}
                    className="w-4 h-4 text-blue-600 rounded"
                  />
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    {getRankBadge(candidate.score.rank)}
                    <span className="font-semibold text-gray-900">#{candidate.score.rank}</span>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div>
                    <div className="font-medium text-gray-900">{candidate.candidateName}</div>
                    <div className="text-xs text-gray-600">{candidate.candidateEmail}</div>
                    {candidate.location && (
                      <div className="text-xs text-gray-500">{candidate.location}</div>
                    )}
                  </div>
                </td>
                <td className="px-4 py-3">
                  {candidate.source === 'recruiter' ? (
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                      <UserCheck className="w-3 h-3 mr-1" />
                      Recruiter
                    </span>
                  ) : (
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      Direct
                    </span>
                  )}
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold ${getScoreColor(candidate.score.totalScore)}`}>
                      {candidate.score.totalScore}%
                    </span>
                    <div className="text-xs text-gray-500">
                      <div>Skills: {candidate.score.breakdown.skillsScore}%</div>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="text-xs text-gray-600">
                    {candidate.score.breakdown.skillsScore}% match
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex flex-col gap-1">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      candidate.status === 'submitted' ? 'bg-blue-100 text-blue-800' :
                      candidate.status === 'shortlisted' ? 'bg-yellow-100 text-yellow-800 border border-yellow-300' :
                      candidate.status === 'hired' ? 'bg-purple-100 text-purple-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {candidate.status === 'shortlisted' && <Award className="w-3 h-3 mr-1" />}
                      {candidate.status}
                    </span>
                    {candidate.status === 'shortlisted' && candidate.shortlist_notes && (
                      <span className="text-xs text-gray-500 italic" title={candidate.shortlist_notes}>
                        {candidate.shortlist_notes.substring(0, 30)}{candidate.shortlist_notes.length > 30 ? '...' : ''}
                      </span>
                    )}
                  </div>
                </td>
                <td className="px-4 py-3 text-sm text-gray-600">
                  {new Date(candidate.createdAt).toLocaleDateString()}
                </td>
                <td className="px-4 py-3 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <button
                      onClick={() => onViewApplication(candidate)}
                      className="p-1 text-blue-600 hover:bg-blue-50 rounded"
                      title="View details"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    {candidate.status === 'submitted' && (
                      <button
                        onClick={() => setCandidateToShortlist(candidate)}
                        className="px-2 py-1 text-xs bg-yellow-600 text-white rounded hover:bg-yellow-700"
                      >
                        Shortlist
                      </button>
                    )}
                    {candidate.status === 'shortlisted' && candidate.shortlist_notes && (
                      <button
                        onClick={() => setCandidateToViewNotes(candidate)}
                        className="p-1 text-gray-600 hover:bg-gray-50 rounded"
                        title="View shortlist notes"
                      >
                        <FileText className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {rankedCandidates.length === 0 && (
          <div className="text-center py-12">
            <Users className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-600">No candidates match your filters</p>
          </div>
        )}
      </div>

      {showWeightsModal && (
        <RankingWeightsModal
          currentWeights={weights}
          onSave={(newWeights) => {
            setWeights(newWeights);
            setShowWeightsModal(false);
          }}
          onApplyPreset={handleApplyPreset}
          onClose={() => setShowWeightsModal(false)}
        />
      )}

      {candidateToShortlist && (
        <ShortlistModal
          application={candidateToShortlist}
          onClose={() => setCandidateToShortlist(null)}
          onSuccess={() => {
            setCandidateToShortlist(null);
            if (onRefresh) onRefresh();
          }}
        />
      )}

      {candidateToViewNotes && (
        <ViewNotesModal
          application={candidateToViewNotes}
          onClose={() => setCandidateToViewNotes(null)}
          onSuccess={() => {
            setCandidateToViewNotes(null);
            if (onRefresh) onRefresh();
          }}
        />
      )}
    </div>
  );
};

interface RankingWeightsModalProps {
  currentWeights: RankingWeights;
  onSave: (weights: RankingWeights) => void;
  onApplyPreset: (presetName: string) => void;
  onClose: () => void;
}

const RankingWeightsModal: React.FC<RankingWeightsModalProps> = ({
  currentWeights,
  onSave,
  onApplyPreset,
  onClose,
}) => {
  const [weights, setWeights] = useState(currentWeights);

  const handleWeightChange = (key: keyof RankingWeights, value: number) => {
    setWeights({ ...weights, [key]: value });
  };

  const totalWeight = Object.values(weights).reduce((sum, w) => sum + w, 0);

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="bg-white w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b">
            <h3 className="text-lg font-semibold text-gray-900">Ranking Configuration</h3>
            <button onClick={onClose} className="p-2 text-gray-500 hover:text-gray-700">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 max-h-[70vh] overflow-y-auto">
            <div className="mb-6">
              <h4 className="font-medium text-gray-900 mb-3">Quick Presets</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {['Balanced', 'Skills-Focused', 'Experience-Focused', 'Budget-Conscious'].map((preset) => (
                  <button
                    key={preset}
                    onClick={() => onApplyPreset(preset)}
                    className="px-3 py-2 border border-gray-300 rounded-lg hover:bg-blue-50 hover:border-blue-500 text-sm"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium text-gray-900">Custom Weights</h4>

              {Object.entries(weights).map(([key, value]) => (
                <div key={key}>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-sm font-medium text-gray-700">
                      {key.replace(/_/g, ' ').replace('weight', '').trim().replace(/\b\w/g, l => l.toUpperCase())}
                    </label>
                    <span className="text-sm font-semibold text-gray-900">{value}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={value}
                    onChange={(e) => handleWeightChange(key as keyof RankingWeights, parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                  />
                </div>
              ))}

              <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                <div className="text-sm text-blue-900">
                  Total Weight: <span className="font-semibold">{totalWeight}%</span>
                  {totalWeight !== 100 && (
                    <span className="ml-2 text-orange-600">(Recommended: 100%)</span>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="px-6 py-4 border-t bg-gray-50 flex justify-end gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100"
            >
              Cancel
            </button>
            <button
              onClick={() => onSave(weights)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Apply Configuration
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobCandidatesDashboard;
