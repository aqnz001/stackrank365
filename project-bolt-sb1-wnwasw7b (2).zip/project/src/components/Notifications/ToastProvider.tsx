import React from 'react';
import toast, { Toaster } from 'react-hot-toast';
import { useNotifications } from '../../hooks/useNotifications';
import { useEffect } from 'react';

const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { notifications } = useNotifications();

  useEffect(() => {
    // Show toast for new notifications
    const latestNotification = notifications[0];
    if (latestNotification && !latestNotification.read) {
      // Only show toast if notification is less than 5 seconds old
      const isRecent = new Date().getTime() - latestNotification.createdAt.getTime() < 5000;
      
      if (isRecent) {
        toast.success(latestNotification.title, {
          duration: 4000,
          position: 'top-right',
          style: {
            background: '#3B82F6',
            color: 'white',
          },
          icon: '🔔',
        });
      }
    }
  }, [notifications]);

  return (
    <>
      {children}
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: '#363636',
            color: '#fff',
          },
          success: {
            duration: 3000,
            iconTheme: {
              primary: '#4AED50',
              secondary: '#FFFAEE',
            },
          },
          error: {
            duration: 4000,
            iconTheme: {
              primary: '#FF5722',
              secondary: '#FFFAEE',
            },
          },
        }}
      />
    </>
  );
};

export default ToastProvider;