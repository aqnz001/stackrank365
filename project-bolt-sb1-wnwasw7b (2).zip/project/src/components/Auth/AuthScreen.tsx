import React from 'react';
import LoginForm from './LoginForm';
import { X } from 'lucide-react';

interface AuthScreenProps {
  isOpen: boolean;
  initialMode?: 'signin' | 'signup';
  onClose: () => void;
}

const AuthScreen: React.FC<AuthScreenProps> = ({ isOpen, initialMode = 'signin', onClose }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-black/40" />
      <div className="absolute inset-0 flex items-center justify-center p-4" onKeyDown={(e) => { if (e.key === 'Escape') onClose(); }} tabIndex={-1}>
        <div className="relative bg-white w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden">
          <button
            onClick={onClose}
            className="absolute top-3 right-3 p-2 text-gray-500 hover:text-gray-700"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="max-h-[90vh] overflow-auto">
            <LoginForm initialMode={initialMode} onSuccess={onClose} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthScreen;
