import React, { useEffect, useRef, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import EmployerRegistration from './EmployerRegistration';
import { Briefcase, Eye, EyeOff, Loader } from 'lucide-react';

interface LoginFormProps {
  onSuccess?: () => void;
  initialMode?: 'signin' | 'signup';
}

const LoginForm: React.FC<LoginFormProps> = ({ onSuccess, initialMode = 'signin' }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSignUp, setIsSignUp] = useState(initialMode === 'signup');
  const [showEmployerRegistration, setShowEmployerRegistration] = useState(false);
  const [showRecruiterRegistration, setShowRecruiterRegistration] = useState(false);
  const [name, setName] = useState('');
  const [selectedRole, setSelectedRole] = useState('candidate');
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const { login, signUp, isLoading, error, user } = useAuth();
  const successCalledRef = useRef(false);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMessage(null);

    try {
      if (isSignUp) {
        await signUp(email, password, name, selectedRole);
        setSuccessMessage('Account created successfully! You can now sign in.');
        setPassword('');
        setIsSignUp(false);
      } else {
        await login(email, password);
      }
    } catch (err) {
      console.error('Form submission error:', err);
      setSuccessMessage(null);
    }
  };

  // Close modal on successful auth (when user becomes available)
  useEffect(() => {
    // Only close on successful auth: user is set, not loading, and no auth error present
    if (user && !isLoading && !error && !successCalledRef.current) {
      successCalledRef.current = true;
      onSuccess?.();
    }
  }, [user, isLoading, error, onSuccess]);

  // Show employer registration flow
  if (showEmployerRegistration) {
    return (
      <EmployerRegistration 
        userType="employer"
        onBack={() => setShowEmployerRegistration(false)}
      />
    );
  }

  // Show recruiter registration flow
  if (showRecruiterRegistration) {
    return (
      <EmployerRegistration 
        userType="recruiter"
        onBack={() => setShowRecruiterRegistration(false)}
      />
    );
  }

  const roles = [
    { value: 'candidate', label: 'Candidate', description: 'Looking for jobs' },
    { value: 'employer', label: 'Employer', description: 'Hiring talent' },
    { value: 'recruiter', label: 'Recruiter', description: 'Connecting talent' },
    { value: 'admin', label: 'Admin', description: 'Platform management' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="flex justify-center">
            <div className="w-16 h-16 bg-blue-600 rounded-xl flex items-center justify-center">
              <Briefcase className="w-8 h-8 text-white" />
            </div>
          </div>
          <h2 className="mt-6 text-3xl font-bold text-gray-900">Welcome to JobBoard Pro</h2>
          <p className="mt-2 text-sm text-gray-600">
            The professional marketplace connecting employers, recruiters, and talent
          </p>
        </div>

        <div className="bg-white py-8 px-6 shadow-xl rounded-xl">
          <form className="space-y-6" onSubmit={handleSubmit}>
            {isSignUp && (
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                  Full Name
                </label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="mt-1 appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm"
                  placeholder="Enter your full name"
                />
              </div>
            )}

            {isSignUp && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  I am a:
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {roles.map((role) => (
                    <label key={role.value} className="cursor-pointer">
                      <input
                        type="radio"
                        name="role"
                        value={role.value}
                        checked={selectedRole === role.value}
                        onChange={(e) => setSelectedRole(e.target.value)}
                        className="sr-only"
                      />
                      <div className={`p-3 rounded-lg border-2 transition-all ${
                        selectedRole === role.value
                          ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-500 ring-opacity-20'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}>
                        <div className="text-sm font-medium text-gray-900">{role.label}</div>
                        <div className="text-xs text-gray-500">{role.description}</div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Email address
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm"
                placeholder="Enter your email"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                Password
              </label>
              <div className="mt-1 relative">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="appearance-none relative block w-full px-3 py-2 pr-10 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm"
                  placeholder="Enter your password"
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-400" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-400" />
                  )}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-md p-3" role="alert">
                <p className="text-sm text-red-700 font-medium">{error}</p>
                <p className="text-xs text-red-600 mt-1">Please check your details and try again.</p>
              </div>
            )}

            {successMessage && (
              <div className="bg-green-50 border border-green-200 rounded-md p-3" role="alert">
                <p className="text-sm text-green-700 font-medium">{successMessage}</p>
                <p className="text-xs text-green-600 mt-1">Please sign in with your credentials to continue.</p>
              </div>
            )}

            <div>
              <button
                type="submit"
                disabled={isLoading}
                className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 transition-colors"
              >
                {isLoading ? (
                  <Loader className="w-4 h-4 animate-spin" />
                ) : (
                  isSignUp ? 'Create Account' : 'Sign In'
                )}
              </button>
            </div>
          </form>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">
                  {isSignUp ? 'Already have an account?' : "Don't have an account?"}
                </span>
              </div>
            </div>

            <div className="mt-4">
              <button
                type="button"
                onClick={() => setIsSignUp(!isSignUp)}
                className="w-full flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
              >
                {isSignUp ? 'Sign In Instead' : 'Create New Account'}
              </button>
              
              {!isSignUp && (
                <div className="mt-4 space-y-2">
                  <button
                    type="button"
                    onClick={() => setShowEmployerRegistration(true)}
                    className="w-full flex justify-center py-2 px-4 border border-blue-300 rounded-md shadow-sm bg-blue-50 text-sm font-medium text-blue-700 hover:bg-blue-100 transition-colors"
                  >
                    Register as Employer
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowRecruiterRegistration(true)}
                    className="w-full flex justify-center py-2 px-4 border border-purple-300 rounded-md shadow-sm bg-purple-50 text-sm font-medium text-purple-700 hover:bg-purple-100 transition-colors"
                  >
                    Register as Recruiter
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;
