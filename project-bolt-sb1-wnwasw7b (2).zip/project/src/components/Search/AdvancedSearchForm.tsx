import React, { useState, useEffect } from 'react';
import { useAdvancedSearch, SearchFilters } from '../../hooks/useAdvancedSearch';
import { useSavedSearches } from '../../hooks/useSavedSearches';
import { 
  Search, 
  MapPin, 
  DollarSign, 
  Briefcase, 
  Clock,
  Star,
  Filter,
  Save,
  X,
  Sliders
} from 'lucide-react';

interface AdvancedSearchFormProps {
  onSearch: (filters: SearchFilters) => void;
  initialFilters?: Partial<SearchFilters>;
}

const AdvancedSearchForm: React.FC<AdvancedSearchFormProps> = ({ 
  onSearch, 
  initialFilters = {} 
}) => {
  const { getPopularSearches } = useAdvancedSearch();
  const { createSavedSearch } = useSavedSearches();
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [saveSearchName, setSaveSearchName] = useState('');
  const [popularSearches, setPopularSearches] = useState<string[]>([]);

  const [filters, setFilters] = useState<SearchFilters>({
    query: '',
    location: '',
    radius: 25,
    employmentType: [],
    salaryMin: '',
    salaryMax: '',
    skills: [],
    experienceLevel: '',
    adTier: [],
    visibility: [],
    status: ['open'],
    postedWithin: '',
    companySize: [],
    industry: [],
    remoteWork: false,
    benefits: [],
    ...initialFilters,
  });

  useEffect(() => {
    getPopularSearches().then(setPopularSearches);
  }, []);

  const handleFilterChange = (key: keyof SearchFilters, value: any) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onSearch(newFilters);
  };

  const handleArrayFilterToggle = (key: keyof SearchFilters, value: string) => {
    const currentArray = filters[key] as string[];
    const newArray = currentArray.includes(value)
      ? currentArray.filter(item => item !== value)
      : [...currentArray, value];
    
    handleFilterChange(key, newArray);
  };

  const handleSkillAdd = (skill: string) => {
    if (skill.trim() && !filters.skills.includes(skill.trim())) {
      handleFilterChange('skills', [...filters.skills, skill.trim()]);
    }
  };

  const handleSkillRemove = (skill: string) => {
    handleFilterChange('skills', filters.skills.filter(s => s !== skill));
  };

  const handleSaveSearch = async () => {
    if (!saveSearchName.trim()) return;

    try {
      console.log('Saving search with criteria:', filters);
      
      await createSavedSearch({
        name: saveSearchName.trim(),
        searchCriteria: filters,
        emailAlerts: true,
        alertFrequency: 'daily',
      });
      
      setShowSaveDialog(false);
      setSaveSearchName('');
      
      // Show success notification
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('Search Saved', {
          body: `"${saveSearchName.trim()}" has been saved to your searches`,
          icon: '/icons/icon-192x192.png',
        });
      } else {
        // Use a more user-friendly notification
        const notification = document.createElement('div');
        notification.className = 'fixed top-4 right-4 bg-green-100 border border-green-200 text-green-800 px-4 py-3 rounded-lg shadow-lg z-50';
        notification.innerHTML = `
          <div class="flex items-center">
            <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
            </svg>
            Search saved successfully!
          </div>
        `;
        document.body.appendChild(notification);
        setTimeout(() => {
          document.body.removeChild(notification);
        }, 3000);
      }
    } catch (error) {
      console.error('Error saving search:', error);
      alert('Failed to save search');
    }
  };

  const clearAllFilters = () => {
    const clearedFilters: SearchFilters = {
      query: '',
      location: '',
      radius: 25,
      employmentType: [],
      salaryMin: '',
      salaryMax: '',
      skills: [],
      experienceLevel: '',
      adTier: [],
      visibility: [],
      status: ['open'],
      postedWithin: '',
      companySize: [],
      industry: [],
      remoteWork: false,
      benefits: [],
    };
    setFilters(clearedFilters);
    onSearch(clearedFilters);
  };

  const employmentTypes = [
    { value: 'full-time', label: 'Full-time' },
    { value: 'part-time', label: 'Part-time' },
    { value: 'contract', label: 'Contract' },
    { value: 'temporary', label: 'Temporary' },
  ];

  const experienceLevels = [
    { value: 'entry', label: 'Entry Level (0-2 years)' },
    { value: 'mid', label: 'Mid Level (3-5 years)' },
    { value: 'senior', label: 'Senior Level (6-10 years)' },
    { value: 'lead', label: 'Lead/Principal (10+ years)' },
  ];

  const companySizes = [
    { value: 'startup', label: 'Startup (1-50)' },
    { value: 'small', label: 'Small (51-200)' },
    { value: 'medium', label: 'Medium (201-1000)' },
    { value: 'large', label: 'Large (1000+)' },
  ];

  const industries = [
    'Technology', 'Healthcare', 'Finance', 'Education', 'Manufacturing',
    'Retail', 'Construction', 'Professional Services', 'Government', 'Non-profit'
  ];

  const benefits = [
    'Health Insurance', 'Dental Insurance', 'Vision Insurance', '401k',
    'Flexible Hours', 'Remote Work', 'Paid Time Off', 'Stock Options',
    'Professional Development', 'Gym Membership', 'Free Meals', 'Commuter Benefits'
  ];

  return (
    <div className="space-y-6">
      {/* Main Search Bar */}
      <div className="relative">
        <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        <input
          type="text"
          placeholder="Search jobs by title, company, skills, or keywords..."
          value={filters.query}
          onChange={(e) => handleFilterChange('query', e.target.value)}
          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-lg"
        />
        
        {/* Popular Searches */}
        {!filters.query && popularSearches.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-10">
            <div className="p-3">
              <p className="text-sm text-gray-600 mb-2">Popular searches:</p>
              <div className="flex flex-wrap gap-2">
                {popularSearches.slice(0, 5).map((search, index) => (
                  <button
                    key={index}
                    onClick={() => handleFilterChange('query', search)}
                    className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm hover:bg-gray-200"
                  >
                    {search}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Quick Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="flex items-center space-x-2">
          <MapPin className="w-4 h-4 text-gray-500" />
          <input
            type="text"
            placeholder="Location"
            value={filters.location}
            onChange={(e) => handleFilterChange('location', e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <div className="flex items-center space-x-2">
          <DollarSign className="w-4 h-4 text-gray-500" />
          <input
            type="number"
            placeholder="Min salary"
            value={filters.salaryMin}
            onChange={(e) => handleFilterChange('salaryMin', e.target.value)}
            className="w-32 px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
          />
          <span className="text-gray-500">to</span>
          <input
            type="number"
            placeholder="Max salary"
            value={filters.salaryMax}
            onChange={(e) => handleFilterChange('salaryMax', e.target.value)}
            className="w-32 px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={filters.remoteWork}
            onChange={(e) => handleFilterChange('remoteWork', e.target.checked)}
            className="rounded border-gray-300 text-blue-600"
          />
          <span className="text-sm text-gray-700">Remote work</span>
        </label>

        <button
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
        >
          <Sliders className="w-4 h-4 mr-2" />
          Advanced
        </button>

        <button
          onClick={() => setShowSaveDialog(true)}
          className="flex items-center px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Save className="w-4 h-4 mr-2" />
          Save Search
        </button>
      </div>

      {/* Advanced Filters */}
      {showAdvanced && (
        <div className="bg-gray-50 rounded-lg p-6 space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-gray-900">Advanced Filters</h3>
            <button
              onClick={clearAllFilters}
              className="text-sm text-gray-600 hover:text-gray-800"
            >
              Clear All
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Employment Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                <Briefcase className="w-4 h-4 inline mr-1" />
                Employment Type
              </label>
              <div className="space-y-2">
                {employmentTypes.map(type => (
                  <label key={type.value} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={filters.employmentType.includes(type.value)}
                      onChange={() => handleArrayFilterToggle('employmentType', type.value)}
                      className="rounded border-gray-300 text-blue-600"
                    />
                    <span className="ml-2 text-sm text-gray-700">{type.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Experience Level */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Experience Level
              </label>
              <select
                value={filters.experienceLevel}
                onChange={(e) => handleFilterChange('experienceLevel', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Any level</option>
                {experienceLevels.map(level => (
                  <option key={level.value} value={level.value}>{level.label}</option>
                ))}
              </select>
            </div>

            {/* Posted Within */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                <Clock className="w-4 h-4 inline mr-1" />
                Posted Within
              </label>
              <select
                value={filters.postedWithin}
                onChange={(e) => handleFilterChange('postedWithin', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Any time</option>
                <option value="1">Last 24 hours</option>
                <option value="7">Last week</option>
                <option value="30">Last month</option>
                <option value="90">Last 3 months</option>
              </select>
            </div>

            {/* Company Size */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Company Size
              </label>
              <div className="space-y-2">
                {companySizes.map(size => (
                  <label key={size.value} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={filters.companySize.includes(size.value)}
                      onChange={() => handleArrayFilterToggle('companySize', size.value)}
                      className="rounded border-gray-300 text-blue-600"
                    />
                    <span className="ml-2 text-sm text-gray-700">{size.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Industry */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Industry
              </label>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {industries.map(industry => (
                  <label key={industry} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={filters.industry.includes(industry)}
                      onChange={() => handleArrayFilterToggle('industry', industry)}
                      className="rounded border-gray-300 text-blue-600"
                    />
                    <span className="ml-2 text-sm text-gray-700">{industry}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Benefits */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Benefits & Perks
              </label>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {benefits.map(benefit => (
                  <label key={benefit} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={filters.benefits.includes(benefit)}
                      onChange={() => handleArrayFilterToggle('benefits', benefit)}
                      className="rounded border-gray-300 text-blue-600"
                    />
                    <span className="ml-2 text-sm text-gray-700">{benefit}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Skills Section */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Required Skills
            </label>
            <div className="flex flex-wrap gap-2 mb-3">
              {filters.skills.map(skill => (
                <span
                  key={skill}
                  className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-800"
                >
                  {skill}
                  <button
                    type="button"
                    onClick={() => handleSkillRemove(skill)}
                    className="ml-2 text-blue-600 hover:text-blue-800"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
            <div className="flex space-x-2">
              <input
                type="text"
                placeholder="Add a skill..."
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleSkillAdd(e.currentTarget.value);
                    e.currentTarget.value = '';
                  }
                }}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              />
              <button
                type="button"
                onClick={(e) => {
                  const input = e.currentTarget.previousElementSibling as HTMLInputElement;
                  handleSkillAdd(input.value);
                  input.value = '';
                }}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Add
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Save Search Dialog */}
      {showSaveDialog && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 z-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Save Search</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Search Name
                </label>
                <input
                  type="text"
                  value={saveSearchName}
                  onChange={(e) => setSaveSearchName(e.target.value)}
                  placeholder="e.g., Senior React Developer in SF"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => setShowSaveDialog(false)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveSearch}
                  disabled={!saveSearchName.trim()}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  Save Search
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdvancedSearchForm;