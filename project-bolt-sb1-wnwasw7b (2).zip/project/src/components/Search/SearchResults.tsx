import React, { useState } from 'react';
import { useAdvancedSearch } from '../../hooks/useAdvancedSearch';
import { useJobRecommendations } from '../../hooks/useJobRecommendations';
import JobCard from '../Jobs/JobCard';
import { getJobLifecycle } from '../../utils/jobs';
import { useRecruiterBids } from '../../hooks/useRecruiterBids';
import BidForm from '../Bids/BidForm';
import { useAuth } from '../../context/AuthContext';
import { useAppliedJobs } from '../../hooks/useAppliedJobs';
import VirtualizedList from '../Performance/VirtualizedList';
import InfiniteScroll from '../Performance/InfiniteScroll';
import { 
  Search, 
  Clock, 
  TrendingUp, 
  Star,
  Filter,
  SortAsc,
  Grid,
  List,
  Sparkles
} from 'lucide-react';

interface SearchResultsProps {
  onJobApply?: (job: any) => void;
  onJobView?: (job: any) => void;
}

const SearchResults: React.FC<SearchResultsProps> = ({ onJobApply, onJobView }) => {
  const { searchResults, loading } = useAdvancedSearch();
  const { user } = useAuth();
  const { isApplied } = useAppliedJobs();
  const { jobRecommendations } = useJobRecommendations();
  const { bids } = useRecruiterBids();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState('relevance');
  const [showFacets, setShowFacets] = useState(false);

  const sortOptions = [
    { value: 'relevance', label: 'Most Relevant' },
    { value: 'newest', label: 'Newest First' },
    { value: 'salary-high', label: 'Highest Salary' },
    { value: 'salary-low', label: 'Lowest Salary' },
    { value: 'company', label: 'Company A-Z' },
  ];

  const sortedJobs = React.useMemo(() => {
    if (!searchResults?.jobs) return [];

    const jobs = [...searchResults.jobs];
    
    switch (sortBy) {
      case 'newest':
        return jobs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      case 'salary-high':
        return jobs.sort((a, b) => (b.salaryRange?.max || 0) - (a.salaryRange?.max || 0));
      case 'salary-low':
        return jobs.sort((a, b) => (a.salaryRange?.min || 0) - (b.salaryRange?.min || 0));
      case 'company':
        return jobs.sort((a, b) => a.organizationName.localeCompare(b.organizationName));
      default:
        return jobs; // Keep original relevance order
    }
  }, [searchResults?.jobs, sortBy]);

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 animate-pulse">
            <div className="flex justify-between items-start mb-4">
              <div className="flex-1">
                <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-2/3"></div>
              </div>
              <div className="w-20 h-6 bg-gray-200 rounded"></div>
            </div>
            <div className="space-y-2">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-5/6"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!searchResults) {
    return (
      <div className="text-center py-12">
        <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">Start Your Job Search</h3>
        <p className="text-gray-600">
          Enter keywords, location, or skills to find your perfect job
        </p>
        
        {/* Show recommendations if available */}
        {jobRecommendations.length > 0 && (
          <div className="mt-8">
            <div className="flex items-center justify-center mb-4">
              <Sparkles className="w-5 h-5 text-yellow-500 mr-2" />
              <h4 className="text-lg font-semibold text-gray-900">Recommended for You</h4>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {jobRecommendations.filter(r => getJobLifecycle(r.job!).isOpen).slice(0, 6).map((recommendation) => (
                <div key={recommendation.id} className="relative">
                  <JobCard 
                    job={recommendation.job!}
                    showApplyButton={!user || (user?.role === 'candidate' && !isApplied(recommendation.job?.id))}
                    onApply={() => onJobApply?.(recommendation.job)}
                  />
                  <div className="absolute top-2 right-2 bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">
                    {Math.round(recommendation.matchScore)}% match
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  const [bidJob, setBidJob] = React.useState<any>(null);
  return (
    <div className="space-y-6">
      {/* Search Results Header */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-4 sm:space-y-0">
        <div className="flex items-center space-x-4">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">
              {searchResults.totalCount.toLocaleString()} jobs found
            </h2>
            <div className="flex items-center text-sm text-gray-500">
              <Clock className="w-4 h-4 mr-1" />
              Search completed in {searchResults.searchTime.toFixed(0)}ms
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded ${viewMode === 'grid' ? 'bg-blue-100 text-blue-600' : 'text-gray-400'}`}
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded ${viewMode === 'list' ? 'bg-blue-100 text-blue-600' : 'text-gray-400'}`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
          >
            {sortOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>

          <button
            onClick={() => setShowFacets(!showFacets)}
            className="flex items-center px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            <Filter className="w-4 h-4 mr-2" />
            Refine
          </button>
        </div>
      </div>

      <div className="flex gap-6">
        {/* Search Facets */}
        {showFacets && (
          <div className="w-64 bg-white rounded-lg shadow-sm border border-gray-200 p-4 h-fit">
            <h3 className="font-semibold text-gray-900 mb-4">Refine Results</h3>
            
            {/* Location Facets */}
            {searchResults.facets.locations.length > 0 && (
              <div className="mb-6">
                <h4 className="font-medium text-gray-700 mb-2">Locations</h4>
                <div className="space-y-1">
                  {searchResults.facets.locations.map(({ value, count }) => (
                    <button
                      key={value}
                      className="flex justify-between w-full text-left px-2 py-1 text-sm text-gray-600 hover:bg-gray-50 rounded"
                    >
                      <span>{value}</span>
                      <span className="text-gray-400">({count})</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Skills Facets */}
            {searchResults.facets.skills.length > 0 && (
              <div className="mb-6">
                <h4 className="font-medium text-gray-700 mb-2">Skills</h4>
                <div className="space-y-1">
                  {searchResults.facets.skills.map(({ value, count }) => (
                    <button
                      key={value}
                      className="flex justify-between w-full text-left px-2 py-1 text-sm text-gray-600 hover:bg-gray-50 rounded"
                    >
                      <span>{value}</span>
                      <span className="text-gray-400">({count})</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Company Facets */}
            {searchResults.facets.companies.length > 0 && (
              <div className="mb-6">
                <h4 className="font-medium text-gray-700 mb-2">Companies</h4>
                <div className="space-y-1">
                  {searchResults.facets.companies.map(({ value, count }) => (
                    <button
                      key={value}
                      className="flex justify-between w-full text-left px-2 py-1 text-sm text-gray-600 hover:bg-gray-50 rounded"
                    >
                      <span className="truncate">{value}</span>
                      <span className="text-gray-400">({count})</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Search Results */}
        <div className="flex-1">
          {searchResults.suggestions.length > 0 && (
            <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-800 mb-2">Did you mean:</p>
              <div className="flex flex-wrap gap-2">
                {searchResults.suggestions.map((suggestion, index) => (
                  <button
                    key={index}
                    className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm hover:bg-blue-200"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          )}

          {sortedJobs.length === 0 ? (
            <div className="text-center py-12">
              <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No jobs found</h3>
              <p className="text-gray-600">
                Try adjusting your search criteria or browse all available jobs
              </p>
            </div>
          ) : (
            <div className={viewMode === 'grid' 
              ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' 
              : 'space-y-4'
            }>
              {(() => {
                const bidJobIds = new Set((bids || []).map(b => b.jobId));
                const filtered = sortedJobs.filter((job) => {
                  const life = getJobLifecycle(job);
                  if (life.isOpen) return true;
                  if (user?.role === 'recruiter') return bidJobIds.has(job.id);
                  if (user?.role === 'candidate') return isApplied(job.id);
                  if (user?.role === 'employer' && user.organizationId && job.organizationId === user.organizationId) return true;
                  return false;
                });
                return filtered;
              })().map((job) => (
                <JobCard 
                  key={job.id} 
                  job={job}
                  showApplyButton={!user || (user?.role === 'candidate' && !isApplied(job.id))}
                  showBidForRecruiter
                  onBid={() => { console.log('[BidModal] open from SearchResults', { jobId: job.id, title: job.title }); setBidJob(job); }}
                  onApply={() => onJobApply?.(job)}
                  onViewDetails={() => onJobView?.(job)}
                />
              ))}
            </div>
          )}
        </div>

        {bidJob && (
          <BidForm job={bidJob} onClose={() => { console.log('[BidModal] close'); setBidJob(null); }} />
        )}
      </div>
    </div>
  );
};

export default SearchResults;
