import React, { useState } from 'react';
import { useSavedSearches } from '../../hooks/useSavedSearches';
import { 
  Search, 
  Bell, 
  BellOff, 
  Edit, 
  Trash2,
  Plus,
  Clock,
  Filter,
  Star
} from 'lucide-react';

interface SavedSearchesProps {
  onLoadSearch?: (criteria: any) => void;
}

const SavedSearches: React.FC<SavedSearchesProps> = ({ onLoadSearch }) => {
  const { 
    savedSearches, 
    loading, 
    updateSavedSearch, 
    deleteSavedSearch, 
    toggleSearchAlerts 
  } = useSavedSearches();
  const [editingSearch, setEditingSearch] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  const handleEdit = (search: any) => {
    setEditingSearch(search.id);
    setEditName(search.name);
  };

  const handleSaveEdit = async (searchId: string) => {
    try {
      console.log('Updating search name:', editName);
      await updateSavedSearch(searchId, { name: editName });
      setEditingSearch(null);
      setEditName('');
    } catch (error) {
      console.error('Error updating search name:', error);
      alert('Failed to update search name');
    }
  };

  const handleDelete = async (searchId: string, searchName: string) => {
    if (window.confirm(`Are you sure you want to delete "${searchName}"?`)) {
      try {
        console.log('Deleting saved search:', searchId);
        await deleteSavedSearch(searchId);
        
        // Show success notification
        const notification = document.createElement('div');
        notification.className = 'fixed top-4 right-4 bg-blue-100 border border-blue-200 text-blue-800 px-4 py-3 rounded-lg shadow-lg z-50';
        notification.innerHTML = `
          <div class="flex items-center">
            <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" clip-rule="evenodd"></path>
            </svg>
            Search deleted successfully
          </div>
        `;
        document.body.appendChild(notification);
        setTimeout(() => {
          document.body.removeChild(notification);
        }, 3000);
      } catch (error) {
        console.error('Error deleting search:', error);
        alert('Failed to delete search');
      }
    }
  };

  const formatSearchCriteria = (criteria: any) => {
    const parts = [];
    
    if (criteria.query) parts.push(`"${criteria.query}"`);
    if (criteria.location) parts.push(`in ${criteria.location}`);
    if (criteria.employmentType?.length) parts.push(criteria.employmentType.join(', '));
    if (criteria.salaryMin || criteria.salaryMax) {
      const salary = criteria.salaryMin && criteria.salaryMax 
        ? `$${parseInt(criteria.salaryMin).toLocaleString()} - $${parseInt(criteria.salaryMax).toLocaleString()}`
        : criteria.salaryMin 
        ? `$${parseInt(criteria.salaryMin).toLocaleString()}+`
        : `up to $${parseInt(criteria.salaryMax).toLocaleString()}`;
      parts.push(salary);
    }
    if (criteria.skills?.length) parts.push(`Skills: ${criteria.skills.slice(0, 3).join(', ')}`);
    if (criteria.remoteWork) parts.push('Remote work');
    
    return parts.join(' • ') || 'All jobs';
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 animate-pulse">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <div className="h-5 bg-gray-200 rounded w-1/3 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-2/3"></div>
              </div>
              <div className="w-20 h-8 bg-gray-200 rounded"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-900">Saved Searches</h3>
        <span className="text-sm text-gray-500">
          {savedSearches.length} saved search{savedSearches.length !== 1 ? 'es' : ''}
        </span>
      </div>

      {savedSearches.length === 0 ? (
        <div className="text-center py-8 bg-white rounded-lg shadow-sm border border-gray-200">
          <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h4 className="text-lg font-medium text-gray-900 mb-2">No Saved Searches</h4>
          <p className="text-gray-600">
            Save your search criteria to get notified when new matching jobs are posted
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {savedSearches.map((search) => (
            <div key={search.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 hover:shadow-md transition-shadow">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  {editingSearch === search.id ? (
                    <div className="flex items-center space-x-2 mb-2">
                      <input
                        type="text"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="flex-1 px-3 py-1 border border-gray-300 rounded focus:ring-blue-500 focus:border-blue-500"
                      />
                      <button
                        onClick={() => handleSaveEdit(search.id)}
                        className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700"
                      >
                        Save
                      </button>
                      <button
                        onClick={() => setEditingSearch(null)}
                        className="px-3 py-1 bg-gray-300 text-gray-700 rounded text-sm hover:bg-gray-400"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2 mb-2">
                      <h4 className="font-semibold text-gray-900">{search.name}</h4>
                      {search.emailAlerts && (
                        <div className="flex items-center text-green-600">
                          <Bell className="w-4 h-4 mr-1" />
                          <span className="text-xs">Alerts on</span>
                        </div>
                      )}
                    </div>
                  )}
                  
                  <p className="text-sm text-gray-600 mb-2">
                    {formatSearchCriteria(search.searchCriteria)}
                  </p>
                  
                  <div className="flex items-center text-xs text-gray-500">
                    <Clock className="w-3 h-3 mr-1" />
                    Created {search.createdAt.toLocaleDateString()}
                    {search.lastAlertSent && (
                      <>
                        <span className="mx-2">•</span>
                        Last alert: {search.lastAlertSent.toLocaleDateString()}
                      </>
                    )}
                  </div>
                </div>

                <div className="flex items-center space-x-2 ml-4">
                  <button
                    onClick={() => onLoadSearch?.(search.searchCriteria)}
                    className="p-2 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded"
                    title="Load search"
                  >
                    <Search className="w-4 h-4" />
                  </button>
                  
                  <button
                    onClick={() => toggleSearchAlerts(search.id, !search.emailAlerts)}
                    className={`p-2 rounded ${
                      search.emailAlerts 
                        ? 'text-green-600 hover:text-green-700 hover:bg-green-50' 
                        : 'text-gray-400 hover:text-gray-600 hover:bg-gray-50'
                    }`}
                    title={search.emailAlerts ? 'Disable alerts' : 'Enable alerts'}
                  >
                    {search.emailAlerts ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                  </button>
                  
                  <button
                    onClick={() => handleEdit(search)}
                    className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-50 rounded"
                    title="Edit search"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  
                  <button
                    onClick={() => handleDelete(search.id, search.name)}
                    className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded"
                    title="Delete search"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Alert Settings */}
              {search.emailAlerts && (
                <div className="mt-3 pt-3 border-t border-gray-100">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Email alerts:</span>
                    <select
                      value={search.alertFrequency}
                      onChange={(e) => updateSavedSearch(search.id, { 
                        alertFrequency: e.target.value as any 
                      })}
                      className="px-2 py-1 border border-gray-300 rounded text-sm focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="immediate">Immediate</option>
                      <option value="daily">Daily</option>
                      <option value="weekly">Weekly</option>
                    </select>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SavedSearches;