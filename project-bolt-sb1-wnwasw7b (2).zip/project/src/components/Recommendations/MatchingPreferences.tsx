import React, { useState } from 'react';
import { useMatchingPreferences } from '../../hooks/useMatchingPreferences';
import { 
  Settings, 
  Sliders, 
  MapPin, 
  DollarSign, 
  Briefcase,
  Star,
  Bell,
  Save,
  RotateCcw
} from 'lucide-react';

const MatchingPreferences: React.FC = () => {
  const { preferences, loading, updatePreferences } = useMatchingPreferences();
  const [isEditing, setIsEditing] = useState(false);
  const [tempPreferences, setTempPreferences] = useState(preferences);

  React.useEffect(() => {
    setTempPreferences(preferences);
  }, [preferences]);

  const handleSave = async () => {
    if (!tempPreferences) return;

    try {
      console.log('Saving matching preferences:', tempPreferences);
      await updatePreferences(tempPreferences);
      setIsEditing(false);
      
      // Show success notification
      const notification = document.createElement('div');
      notification.className = 'fixed top-4 right-4 bg-green-100 border border-green-200 text-green-800 px-4 py-3 rounded-lg shadow-lg z-50';
      notification.innerHTML = `
        <div class="flex items-center">
          <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
          </svg>
          Preferences saved successfully!
        </div>
      `;
      document.body.appendChild(notification);
      setTimeout(() => {
        document.body.removeChild(notification);
      }, 3000);
    } catch (error) {
      console.error('Error saving preferences:', error);
      alert('Failed to save preferences');
    }
  };

  const handleReset = () => {
    setTempPreferences(preferences);
    setIsEditing(false);
  };

  const resetToDefaults = () => {
    const defaults = {
      skillWeight: 0.30,
      locationWeight: 0.25,
      salaryWeight: 0.20,
      experienceWeight: 0.15,
      industryWeight: 0.10,
      maxCommuteDistance: 50,
      remoteWorkPreference: 'flexible' as const,
      salaryFlexibility: 0.15,
      notificationFrequency: 'daily' as const,
    };
    
    setTempPreferences(prev => prev ? { ...prev, ...defaults } : null);
  };

  if (loading || !preferences || !tempPreferences) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-gray-200 rounded w-1/3"></div>
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-4 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const weightSum = tempPreferences.skillWeight + tempPreferences.locationWeight + 
                   tempPreferences.salaryWeight + tempPreferences.experienceWeight + 
                   tempPreferences.industryWeight;

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center space-x-2">
          <Sliders className="w-5 h-5 text-gray-600" />
          <h3 className="text-lg font-semibold text-gray-900">Matching Preferences</h3>
        </div>
        
        <div className="flex space-x-2">
          {isEditing ? (
            <>
              <button
                onClick={handleReset}
                className="px-3 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
              >
                <RotateCcw className="w-4 h-4 mr-1 inline" />
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Save className="w-4 h-4 mr-1 inline" />
                Save
              </button>
            </>
          ) : (
            <button
              onClick={() => setIsEditing(true)}
              className="px-3 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
            >
              <Settings className="w-4 h-4 mr-1 inline" />
              Edit
            </button>
          )}
        </div>
      </div>

      <div className="space-y-6">
        {/* Matching Weights */}
        <div>
          <h4 className="font-medium text-gray-900 mb-4">Matching Criteria Weights</h4>
          <p className="text-sm text-gray-600 mb-4">
            Adjust how important each factor is when matching jobs to your profile.
          </p>
          
          {weightSum !== 1.0 && isEditing && (
            <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-yellow-800 text-sm">
                ⚠️ Weights should sum to 1.0 (currently {weightSum.toFixed(2)})
              </p>
            </div>
          )}

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Briefcase className="w-4 h-4 text-blue-600" />
                <span className="text-sm font-medium text-gray-700">Skills Match</span>
              </div>
              <div className="flex items-center space-x-3">
                {isEditing ? (
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={tempPreferences.skillWeight}
                    onChange={(e) => setTempPreferences(prev => prev ? {
                      ...prev,
                      skillWeight: parseFloat(e.target.value)
                    } : null)}
                    className="w-24"
                  />
                ) : (
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${tempPreferences.skillWeight * 100}%` }}
                    />
                  </div>
                )}
                <span className="text-sm font-medium w-12 text-right">
                  {Math.round(tempPreferences.skillWeight * 100)}%
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 text-green-600" />
                <span className="text-sm font-medium text-gray-700">Location Match</span>
              </div>
              <div className="flex items-center space-x-3">
                {isEditing ? (
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={tempPreferences.locationWeight}
                    onChange={(e) => setTempPreferences(prev => prev ? {
                      ...prev,
                      locationWeight: parseFloat(e.target.value)
                    } : null)}
                    className="w-24"
                  />
                ) : (
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-600 h-2 rounded-full"
                      style={{ width: `${tempPreferences.locationWeight * 100}%` }}
                    />
                  </div>
                )}
                <span className="text-sm font-medium w-12 text-right">
                  {Math.round(tempPreferences.locationWeight * 100)}%
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <DollarSign className="w-4 h-4 text-purple-600" />
                <span className="text-sm font-medium text-gray-700">Salary Match</span>
              </div>
              <div className="flex items-center space-x-3">
                {isEditing ? (
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={tempPreferences.salaryWeight}
                    onChange={(e) => setTempPreferences(prev => prev ? {
                      ...prev,
                      salaryWeight: parseFloat(e.target.value)
                    } : null)}
                    className="w-24"
                  />
                ) : (
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-purple-600 h-2 rounded-full"
                      style={{ width: `${tempPreferences.salaryWeight * 100}%` }}
                    />
                  </div>
                )}
                <span className="text-sm font-medium w-12 text-right">
                  {Math.round(tempPreferences.salaryWeight * 100)}%
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Star className="w-4 h-4 text-orange-600" />
                <span className="text-sm font-medium text-gray-700">Experience Match</span>
              </div>
              <div className="flex items-center space-x-3">
                {isEditing ? (
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={tempPreferences.experienceWeight}
                    onChange={(e) => setTempPreferences(prev => prev ? {
                      ...prev,
                      experienceWeight: parseFloat(e.target.value)
                    } : null)}
                    className="w-24"
                  />
                ) : (
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-orange-600 h-2 rounded-full"
                      style={{ width: `${tempPreferences.experienceWeight * 100}%` }}
                    />
                  </div>
                )}
                <span className="text-sm font-medium w-12 text-right">
                  {Math.round(tempPreferences.experienceWeight * 100)}%
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Location Preferences */}
        <div>
          <h4 className="font-medium text-gray-900 mb-4">Location Preferences</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Max Commute Distance (miles)
              </label>
              {isEditing ? (
                <input
                  type="number"
                  value={tempPreferences.maxCommuteDistance}
                  onChange={(e) => setTempPreferences(prev => prev ? {
                    ...prev,
                    maxCommuteDistance: parseInt(e.target.value)
                  } : null)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
              ) : (
                <p className="text-gray-900">{tempPreferences.maxCommuteDistance} miles</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Remote Work Preference
              </label>
              {isEditing ? (
                <select
                  value={tempPreferences.remoteWorkPreference}
                  onChange={(e) => setTempPreferences(prev => prev ? {
                    ...prev,
                    remoteWorkPreference: e.target.value as any
                  } : null)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="required">Required</option>
                  <option value="preferred">Preferred</option>
                  <option value="flexible">Flexible</option>
                  <option value="no">Office only</option>
                </select>
              ) : (
                <p className="text-gray-900 capitalize">{tempPreferences.remoteWorkPreference}</p>
              )}
            </div>
          </div>
        </div>

        {/* Salary Preferences */}
        <div>
          <h4 className="font-medium text-gray-900 mb-4">Salary Preferences</h4>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Salary Flexibility ({Math.round(tempPreferences.salaryFlexibility * 100)}%)
            </label>
            <p className="text-sm text-gray-600 mb-3">
              How flexible you are with salary ranges outside your target
            </p>
            {isEditing ? (
              <input
                type="range"
                min="0"
                max="0.5"
                step="0.05"
                value={tempPreferences.salaryFlexibility}
                onChange={(e) => setTempPreferences(prev => prev ? {
                  ...prev,
                  salaryFlexibility: parseFloat(e.target.value)
                } : null)}
                className="w-full"
              />
            ) : (
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-purple-600 h-2 rounded-full"
                  style={{ width: `${tempPreferences.salaryFlexibility * 200}%` }}
                />
              </div>
            )}
          </div>
        </div>

        {/* Notification Preferences */}
        <div>
          <h4 className="font-medium text-gray-900 mb-4">Notification Preferences</h4>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Bell className="w-4 h-4 inline mr-1" />
              Recommendation Frequency
            </label>
            {isEditing ? (
              <select
                value={tempPreferences.notificationFrequency}
                onChange={(e) => setTempPreferences(prev => prev ? {
                  ...prev,
                  notificationFrequency: e.target.value as any
                } : null)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="immediate">Immediate</option>
                <option value="daily">Daily digest</option>
                <option value="weekly">Weekly summary</option>
                <option value="never">Never</option>
              </select>
            ) : (
              <p className="text-gray-900 capitalize">{tempPreferences.notificationFrequency}</p>
            )}
          </div>
        </div>

        {isEditing && (
          <div className="flex justify-between items-center pt-4 border-t border-gray-200">
            <button
              onClick={resetToDefaults}
              className="flex items-center text-sm text-gray-600 hover:text-gray-800"
            >
              <RotateCcw className="w-4 h-4 mr-1" />
              Reset to Defaults
            </button>
            
            <div className="text-sm text-gray-600">
              Total weight: {weightSum.toFixed(2)} 
              {weightSum !== 1.0 && (
                <span className="text-yellow-600 ml-1">(should be 1.0)</span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MatchingPreferences;