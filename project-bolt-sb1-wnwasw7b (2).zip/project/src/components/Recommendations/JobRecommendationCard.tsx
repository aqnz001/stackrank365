import React from 'react';
import { useJobRecommendations } from '../../hooks/useJobRecommendations';
import { JobRecommendation } from '../../hooks/useJobRecommendations';
import JobCard from '../Jobs/JobCard';
import { 
  Star, 
  TrendingUp, 
  MapPin, 
  DollarSign, 
  Briefcase,
  X,
  Eye,
  ThumbsUp,
  ThumbsDown
} from 'lucide-react';

interface JobRecommendationCardProps {
  recommendation: JobRecommendation;
  onApply?: () => void;
  onView?: () => void;
}

const JobRecommendationCard: React.FC<JobRecommendationCardProps> = ({ 
  recommendation, 
  onApply, 
  onView 
}) => {
  const { markRecommendationViewed, dismissJobRecommendation } = useJobRecommendations();

  const handleView = async () => {
    if (!recommendation.isViewed) {
      await markRecommendationViewed(recommendation.id, 'job');
    }
    onView?.();
  };

  const handleDismiss = async () => {
    try {
      await dismissJobRecommendation(recommendation.id);
    } catch (error) {
      console.error('Error dismissing recommendation:', error);
    }
  };

  const getMatchColor = (score: number) => {
    if (score >= 90) return 'text-green-600 bg-green-100';
    if (score >= 75) return 'text-blue-600 bg-blue-100';
    if (score >= 60) return 'text-yellow-600 bg-yellow-100';
    return 'text-gray-600 bg-gray-100';
  };

  const getMatchLabel = (score: number) => {
    if (score >= 90) return 'Excellent Match';
    if (score >= 75) return 'Great Match';
    if (score >= 60) return 'Good Match';
    return 'Potential Match';
  };

  if (!recommendation.job) return null;

  return (
    <div className="relative bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
      {/* Match Score Badge */}
      <div className="absolute top-4 right-4 z-10">
        <div className={`px-3 py-1 rounded-full text-sm font-medium ${getMatchColor(recommendation.matchScore)}`}>
          <Star className="w-4 h-4 inline mr-1" />
          {Math.round(recommendation.matchScore)}% match
        </div>
      </div>

      {/* Dismiss Button */}
      <button
        onClick={handleDismiss}
        className="absolute top-4 right-20 z-10 p-1 text-gray-400 hover:text-gray-600 bg-white rounded-full shadow-sm"
      >
        <X className="w-4 h-4" />
      </button>

      {/* Job Card */}
      <div className="p-6">
        <JobCard 
          job={recommendation.job}
          showApplyButton={true}
          onApply={onApply}
        />

        {/* Match Breakdown */}
        <div className="mt-4 pt-4 border-t border-gray-100">
          <h4 className="font-medium text-gray-900 mb-3">Why this is a {getMatchLabel(recommendation.matchScore).toLowerCase()}</h4>
          
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Skills</span>
              <div className="flex items-center">
                <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full"
                    style={{ width: `${recommendation.skillMatchScore}%` }}
                  />
                </div>
                <span className="text-sm font-medium">{Math.round(recommendation.skillMatchScore)}%</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Location</span>
              <div className="flex items-center">
                <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                  <div 
                    className="bg-green-600 h-2 rounded-full"
                    style={{ width: `${recommendation.locationMatchScore}%` }}
                  />
                </div>
                <span className="text-sm font-medium">{Math.round(recommendation.locationMatchScore)}%</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Salary</span>
              <div className="flex items-center">
                <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                  <div 
                    className="bg-purple-600 h-2 rounded-full"
                    style={{ width: `${recommendation.salaryMatchScore}%` }}
                  />
                </div>
                <span className="text-sm font-medium">{Math.round(recommendation.salaryMatchScore)}%</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Experience</span>
              <div className="flex items-center">
                <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                  <div 
                    className="bg-orange-600 h-2 rounded-full"
                    style={{ width: `${recommendation.experienceMatchScore}%` }}
                  />
                </div>
                <span className="text-sm font-medium">{Math.round(recommendation.experienceMatchScore)}%</span>
              </div>
            </div>
          </div>

          {/* Match Reasons */}
          {recommendation.matchReasons && (
            <div className="space-y-2">
              {recommendation.matchReasons.skillMatch && (
                <div className="flex items-center text-sm">
                  <Briefcase className="w-4 h-4 text-blue-600 mr-2" />
                  <span className="text-gray-700">
                    Skills match: {recommendation.matchReasons.skillMatch.join(', ')}
                  </span>
                </div>
              )}
              {recommendation.matchReasons.locationMatch && (
                <div className="flex items-center text-sm">
                  <MapPin className="w-4 h-4 text-green-600 mr-2" />
                  <span className="text-gray-700">{recommendation.matchReasons.locationMatch}</span>
                </div>
              )}
              {recommendation.matchReasons.salaryMatch && (
                <div className="flex items-center text-sm">
                  <DollarSign className="w-4 h-4 text-purple-600 mr-2" />
                  <span className="text-gray-700">{recommendation.matchReasons.salaryMatch}</span>
                </div>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-between items-center mt-4">
            <button
              onClick={handleView}
              className="flex items-center text-sm text-blue-600 hover:text-blue-700"
            >
              <Eye className="w-4 h-4 mr-1" />
              View Details
            </button>
            
            <div className="flex space-x-2">
              <button className="p-2 text-gray-400 hover:text-red-600 rounded-full hover:bg-red-50">
                <ThumbsDown className="w-4 h-4" />
              </button>
              <button className="p-2 text-gray-400 hover:text-green-600 rounded-full hover:bg-green-50">
                <ThumbsUp className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobRecommendationCard;