import React from 'react';
import { X, CheckCircle, Upload, Globe2, Building } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import SubscriptionManager from '../Payments/SubscriptionManager';
import { useSubscriptions } from '../../hooks/useSubscriptions';
import { useFileUpload } from '../../hooks/useFileUpload';
import PaymentForm from '../Payments/PaymentForm';
import { formatCurrency } from '../../lib/stripe';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

interface Props { onClose: () => void }

const CompanyProfileModal: React.FC<Props> = ({ onClose }) => {
  const { user } = useAuth();
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [name, setName] = React.useState('');
  const [step, setStep] = React.useState<'profile'|'contact'|'branding'|'subscription'|'done'>('profile');
  const { currentSubscription } = useSubscriptions();
  const { plans, refetch: refetchSubscriptions } = useSubscriptions();
  const { uploadFile, uploading } = useFileUpload();
  const [email, setEmail] = React.useState('');
  const [publishEmail, setPublishEmail] = React.useState(false);
  const [website, setWebsite] = React.useState('');
  const [about, setAbout] = React.useState('');
  const [publishProfile, setPublishProfile] = React.useState(false);
  const [country, setCountry] = React.useState('');
  const [city, setCity] = React.useState('');
  const [postalCode, setPostalCode] = React.useState('');
  const [logoUrl, setLogoUrl] = React.useState<string>('');
  const [logoPath, setLogoPath] = React.useState<string>('');
  const [showUpgrade, setShowUpgrade] = React.useState(false);
  const [upgradePlanId, setUpgradePlanId] = React.useState<string>('');
  const [showUpgradePayment, setShowUpgradePayment] = React.useState(false);

  const stepOrder = ['profile', 'contact', 'branding', 'subscription', 'done'];
  const stepTitles = ['Company Info', 'Contact Details', 'Branding', 'Subscription', 'Complete'];
  const currentStepIndex = stepOrder.indexOf(step);
  const totalSteps = currentSubscription ? 3 : 4;

  React.useEffect(() => {
    const load = async () => {
      if (!user?.organizationId) { setLoading(false); return; }
      try {
        const { data, error } = await supabase
          .from('organizations')
          .select('name, contact_email, publish_email, website, about, publish_profile, country, city, postal_code, logo_path')
          .eq('id', user.organizationId)
          .maybeSingle();
        if (error) throw error;
        setName(data?.name || '');
        setEmail((data as any)?.contact_email || '');
        setPublishEmail(Boolean((data as any)?.publish_email));
        setWebsite((data as any)?.website || '');
        setAbout((data as any)?.about || '');
        setPublishProfile(Boolean((data as any)?.publish_profile));
        setCountry((data as any)?.country || '');
        setCity((data as any)?.city || '');
        setPostalCode((data as any)?.postal_code || '');
        setLogoPath((data as any)?.logo_path || '');
        if ((data as any)?.logo_path) {
          const { data: pub } = supabase.storage.from('company-logos').getPublicUrl((data as any).logo_path);
          setLogoUrl(pub.publicUrl);
        }
      } catch (e: any) {
        try {
          const { data: basic, error: err2 } = await supabase
            .from('organizations')
            .select('name')
            .eq('id', user.organizationId)
            .maybeSingle();
          if (err2) throw err2;
          setName((basic as any)?.name || '');
        } catch (e2:any) {
          setError(e2?.message || e?.message || 'Failed to load company profile');
        }
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [user?.organizationId]);

  React.useEffect(() => {
    if (step === 'subscription' && currentSubscription) {
      setStep('done');
    }
  }, [step, currentSubscription]);

  React.useEffect(() => {
    if (step === 'done') {
      refetchSubscriptions();
    }
  }, [step, refetchSubscriptions]);

  const upgradePlans = React.useMemo(() => {
    if (!currentSubscription || !plans?.length) return [] as any[];
    return plans.filter(p => p.amount > currentSubscription.planAmount && p.billingInterval === (currentSubscription.billingInterval as any));
  }, [plans?.length, currentSubscription?.id]);

  const handleUpgrade = (planId: string) => {
    setUpgradePlanId(planId);
    setShowUpgradePayment(true);
  };

  const finalizeUpgrade = async () => {
    try {
      if (!currentSubscription || !upgradePlanId) return;
      const plan = plans.find(p => p.id === upgradePlanId);
      if (!plan) return;
      const { error } = await supabase
        .from('subscriptions')
        .update({
          plan_name: plan.name,
          plan_amount: plan.amount,
          currency: plan.currency,
          billing_interval: plan.billingInterval,
          current_period_start: new Date().toISOString(),
          current_period_end: new Date(Date.now() + (plan.billingInterval === 'year' ? 365 : 30) * 24 * 60 * 60 * 1000).toISOString(),
          metadata: { ...(currentSubscription.metadata||{}), upgraded_from: currentSubscription.planName }
        } as any)
        .eq('id', currentSubscription.id);
      if (error) throw error;
      await refetchSubscriptions();
      setShowUpgradePayment(false);
      setShowUpgrade(false);
    } catch (e) {
      console.error('Upgrade finalize error', e);
      alert('Upgrade was paid but failed to update subscription record. Please contact support.');
      setShowUpgradePayment(false);
      setShowUpgrade(false);
    }
  };

  const save = async () => {
    setSaving(true);
    setError(null);
    try {
      let orgId = user?.organizationId as string | undefined;

      // Check if user already has an organization_id in the database
      if (!orgId) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('organization_id')
          .eq('id', user!.id)
          .maybeSingle();

        if (profile?.organization_id) {
          orgId = profile.organization_id;
          console.log('Found existing organization_id from profile:', orgId);
        }
      }

      // Only create new organization if truly no organization exists
      if (!orgId) {
        console.log('Creating new organization for user');
        const { data: org, error: orgErr } = await supabase
          .from('organizations')
          .insert({
            name,
            type: 'employer'
          } as any)
          .select('id')
          .single();
        if (orgErr) throw orgErr;
        orgId = org.id;
        await supabase.from('profiles').update({ organization_id: orgId } as any).eq('id', user!.id);
      }
      const { error } = await supabase
        .from('organizations')
        .update({
          name,
          website,
          about,
          publish_profile: publishProfile,
        } as any)
        .eq('id', orgId);
      if (error) throw error;
      setStep('contact');
    } catch (e: any) {
      try {
        const { error: err2 } = await supabase
          .from('organizations')
          .update({ name } as any)
          .eq('id', user.organizationId);
        if (err2) throw err2;
        setStep('contact');
      } catch (e2:any) {
        setError(e2?.message || e?.message || 'Failed to save company profile');
      }
    } finally {
      setSaving(false);
    }
  };

  const saveContact = async () => {
    setSaving(true);
    setError(null);
    try {
      let orgId = user?.organizationId as string | undefined;

      // Check if user already has an organization_id in the database
      if (!orgId) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('organization_id')
          .eq('id', user!.id)
          .maybeSingle();

        if (profile?.organization_id) {
          orgId = profile.organization_id;
          console.log('Found existing organization_id from profile:', orgId);
        }
      }

      // Only create new organization if truly no organization exists
      if (!orgId) {
        console.log('Creating new organization for user in saveContact');
        const { data: org, error: orgErr } = await supabase
          .from('organizations')
          .insert({
            name: name || 'My Organization',
            type: 'employer'
          } as any)
          .select('id')
          .single();
        if (orgErr) throw orgErr;
        orgId = org.id;
        await supabase.from('profiles').update({ organization_id: orgId } as any).eq('id', user!.id);
      }
      const { error } = await supabase
        .from('organizations')
        .update({
          contact_email: email || null,
          publish_email: publishEmail,
          country: country || null,
          city: city || null,
          postal_code: postalCode || null,
        } as any)
        .eq('id', orgId);
      if (error) throw error;
      setStep('branding');
    } catch (e:any) {
      setStep('branding');
    } finally {
      setSaving(false);
    }
  };

  const saveBranding = async () => {
    if (!currentSubscription) setStep('subscription'); else setStep('done');
  };

  const handleLogoFile = async (file?: File | null) => {
    if (!file || !user?.organizationId) return;
    try {
      setSaving(true);
      const uploaded = await uploadFile(file, { bucket: 'company-logos', fileType: 'company_logo', organizationId: user.organizationId });
      setLogoUrl(uploaded.url);
      setLogoPath(uploaded.path);
      try {
        await supabase.from('organizations').update({ logo_path: uploaded.path } as any).eq('id', user.organizationId);
      } catch {}
    } catch (e:any) {
      setError(e?.message || 'Failed to upload logo');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4 overflow-y-auto">
        <div className="bg-white w-full max-w-4xl my-8 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[calc(100vh-4rem)]">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b bg-gradient-to-r from-blue-600 to-purple-600 text-white flex-shrink-0">
            <div className="flex items-center gap-2">
              <Building className="w-6 h-6" />
              <div>
                <h3 className="text-xl font-semibold">Company Profile Setup</h3>
                {step !== 'done' && (
                  <p className="text-blue-100 text-sm">Step {currentStepIndex + 1} of {totalSteps}: {stepTitles[currentStepIndex]}</p>
                )}
              </div>
            </div>
            <button onClick={onClose} className="p-2 text-white/80 hover:text-white" aria-label="Close">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="px-6 py-6 flex-1 overflow-y-auto">
            {/* Progress Indicator */}
            {step !== 'done' && (
              <div className="flex items-center justify-center gap-3 mb-8">
                {[...Array(totalSteps)].map((_, i) => (
                  <div key={i} className="flex items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      i <= currentStepIndex ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
                    }`}>
                      {i < currentStepIndex ? <CheckCircle className="w-4 h-4" /> : i + 1}
                    </div>
                    {i < totalSteps - 1 && (
                      <div className={`w-12 h-1 mx-2 ${i < currentStepIndex ? 'bg-blue-600' : 'bg-gray-200'}`} />
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Step 1: Profile */}
            {step === 'profile' && (
              <div className="space-y-4">
                {loading ? (
                  <div className="text-sm text-gray-600">Loading…</div>
                ) : (
                  <>
                    {error && (
                      <div className="bg-red-50 border border-red-200 text-red-800 rounded p-3 text-sm">{error}</div>
                    )}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
                      <input value={name} onChange={e=>setName(e.target.value)} className="w-full border rounded px-3 py-2" placeholder="Company" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Company Website</label>
                      <div className="flex items-center gap-2">
                        <Globe2 className="w-4 h-4 text-gray-500" />
                        <input value={website} onChange={e=>setWebsite(e.target.value)} className="w-full border rounded px-3 py-2" placeholder="https://example.com" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Company Info</label>
                      <div className="bg-white border rounded">
                        <ReactQuill
                          theme="snow"
                          value={about}
                          onChange={setAbout}
                          placeholder="Tell candidates about the company..."
                          modules={{
                            toolbar: [
                              [{ 'header': [1, 2, 3, false] }],
                              ['bold', 'italic', 'underline', 'strike'],
                              [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                              ['link'],
                              ['clean']
                            ]
                          }}
                          className="bg-white"
                        />
                      </div>
                    </div>
                    <label className="inline-flex items-center gap-2 text-sm text-gray-700">
                      <input type="checkbox" checked={publishProfile} onChange={e=>setPublishProfile(e.target.checked)} />
                      Publish Profile (visible to job seekers)
                    </label>
                  </>
                )}
              </div>
            )}

            {/* Step 2: Contact */}
            {step === 'contact' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">E‑mail</label>
                  <input value={email} onChange={e=>setEmail(e.target.value)} className="w-full border rounded px-3 py-2" placeholder="contact@company.com" />
                </div>
                <label className="inline-flex items-center gap-2 text-sm text-gray-700">
                  <input type="checkbox" checked={publishEmail} onChange={e=>setPublishEmail(e.target.checked)} />
                  Publish Email (visible to job seekers)
                </label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Country</label>
                    <input value={country} onChange={e=>setCountry(e.target.value)} className="w-full border rounded px-3 py-2" placeholder="Country" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
                    <input value={city} onChange={e=>setCity(e.target.value)} className="w-full border rounded px-3 py-2" placeholder="City" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Postal Code</label>
                    <input value={postalCode} onChange={e=>setPostalCode(e.target.value)} className="w-full border rounded px-3 py-2" placeholder="Postal Code" />
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Branding */}
            {step === 'branding' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Company Logo</label>
                  <div className="flex items-center gap-3">
                    <div className="w-16 h-16 rounded bg-gray-100 border flex items-center justify-center overflow-hidden">
                      {logoUrl ? <img src={logoUrl} className="w-full h-full object-cover" alt="Logo" /> : <Upload className="w-6 h-6 text-gray-400" />}
                    </div>
                    <input type="file" accept="image/*" onChange={e=>handleLogoFile(e.target.files?.[0] || null)} />
                  </div>
                  {uploading && <div className="text-xs text-gray-500 mt-1">Uploading…</div>}
                </div>
              </div>
            )}

            {/* Step 4: Subscription */}
            {step === 'subscription' && (
              <div>
                <div className="mb-4">
                  <h4 className="text-lg font-semibold text-gray-900">Add a Subscription</h4>
                  <p className="text-gray-600">Pick a plan to enable job posting quotas and premium features.</p>
                </div>
                <SubscriptionManager onPlanSelect={async () => {
                  await refetchSubscriptions();
                  setStep('done');
                }} />
              </div>
            )}

            {/* Step 5: Done */}
            {step === 'done' && (
              <div className="text-center space-y-6">
                <CheckCircle className="w-16 h-16 text-green-600 mx-auto" />
                <h4 className="text-2xl font-semibold text-gray-900">All Set!</h4>
                <p className="text-gray-600">Your company profile is complete and ready to go.</p>
                {currentSubscription && (
                  <div className="mt-6 bg-gray-50 border border-gray-200 rounded p-4 text-left">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-gray-900">{currentSubscription.planName}</div>
                        <div className="text-sm text-gray-600">{currentSubscription.billingInterval} • {formatCurrency(currentSubscription.planAmount)}</div>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={()=>{ try { window.location.hash = '#dashboard?tab=billing'; } catch {} onClose(); }} className="px-3 py-2 border rounded text-sm">View Billing</button>
                        {upgradePlans.length > 0 && (
                          <button onClick={()=>setShowUpgrade(true)} className="px-3 py-2 bg-blue-600 text-white rounded text-sm">Upgrade Plan</button>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Footer */}
          {step !== 'done' && (
            <div className="px-6 py-4 border-t bg-gray-50 flex justify-between flex-shrink-0">
              <button
                onClick={() => {
                  if (step === 'profile') onClose();
                  else if (step === 'contact') setStep('profile');
                  else if (step === 'branding') setStep('contact');
                  else if (step === 'subscription') setStep('branding');
                }}
                className="px-4 py-2 border border-gray-300 rounded hover:bg-gray-100"
              >
                {step === 'profile' ? 'Cancel' : 'Back'}
              </button>
              <div className="flex gap-2">
                {step === 'subscription' && (
                  <button onClick={onClose} className="px-4 py-2 border border-gray-300 rounded hover:bg-gray-100">Skip for now</button>
                )}
                {step !== 'subscription' && (
                  <button
                    onClick={() => {
                      if (step === 'profile') save();
                      else if (step === 'contact') saveContact();
                      else if (step === 'branding') saveBranding();
                    }}
                    disabled={saving || loading || (step === 'profile' && !name.trim())}
                    className="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
                  >
                    {saving ? 'Saving…' : 'Continue'}
                  </button>
                )}
              </div>
            </div>
          )}

          {step === 'done' && (
            <div className="px-6 py-4 border-t bg-gray-50 flex justify-center flex-shrink-0">
              <button onClick={onClose} className="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Finish</button>
            </div>
          )}
        </div>
      </div>

      {/* Upgrade Modal */}
      {showUpgrade && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/40" onClick={()=>setShowUpgrade(false)} />
          <div className="absolute inset-0 flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden">
              <div className="flex items-center justify-between px-6 py-4 border-b">
                <div className="font-semibold text-gray-900">Upgrade Subscription</div>
                <button onClick={()=>setShowUpgrade(false)} className="p-2 text-gray-500 hover:text-gray-700" aria-label="Close"><X className="w-5 h-5"/></button>
              </div>
              <div className="p-6">
                {!currentSubscription ? (
                  <div className="text-sm text-gray-600">No active subscription.</div>
                ) : upgradePlans.length === 0 ? (
                  <div className="text-sm text-gray-600">You're already on the highest plan.</div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {upgradePlans.map((p:any) => {
                      const diff = Math.max(0, p.amount - (currentSubscription?.planAmount || 0));
                      return (
                        <div key={p.id} className="border rounded-lg p-4">
                          <div className="font-medium text-gray-900 mb-1">{p.name}</div>
                          <div className="text-sm text-gray-600 mb-3">{p.description}</div>
                          <div className="text-lg font-semibold text-blue-600 mb-3">{formatCurrency(p.amount)} / {p.billingInterval}</div>
                          <ul className="text-xs text-gray-600 space-y-1 mb-4">
                            {(p.features||[]).map((f:string, i:number)=>(<li key={i}>• {f}</li>))}
                          </ul>
                          <button onClick={()=>handleUpgrade(p.id)} className="w-full px-3 py-2 bg-blue-600 text-white rounded text-sm">Upgrade & Pay {formatCurrency(diff)}</button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Upgrade Payment Modal */}
      {showUpgradePayment && upgradePlanId && (()=>{
        const p = (plans||[]).find((x:any)=>x.id===upgradePlanId);
        const diff = p ? Math.max(0, p.amount - (currentSubscription?.planAmount || 0)) : 0;
        if (!p || diff<=0) return null;
        return (
          <PaymentForm
            amount={diff}
            description={`Upgrade to ${p.name}`}
            onSuccess={finalizeUpgrade}
            onError={(msg)=>{ console.error('Upgrade payment error', msg); setShowUpgradePayment(false); }}
            onClose={()=>setShowUpgradePayment(false)}
          />
        );
      })()}
    </div>
  );
};

export default CompanyProfileModal;
