import React from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { useSubscriptions } from '../../hooks/useSubscriptions';
import { Users, Mail, Shield, AlertCircle, Crown, UserPlus, RefreshCw } from 'lucide-react';

interface TeamMember {
  id: string;
  email: string;
  name: string | null;
  role: string;
  created_at: string;
}

interface TeamInvitation {
  id: string;
  invitee_email: string;
  status: string;
  created_at: string;
}

const EmployerTeamManager: React.FC<{ onClose?: () => void }> = ({ onClose }) => {
  const { user } = useAuth();
  const currentUserRole = user?.role || 'employer';
  const { currentSubscription, plans } = useSubscriptions();
  const [members, setMembers] = React.useState<TeamMember[]>([]);
  const [invitations, setInvitations] = React.useState<TeamInvitation[]>([]);
  const [email, setEmail] = React.useState('');
  const [loading, setLoading] = React.useState(true);
  const [inviting, setInviting] = React.useState(false);
  const [refreshing, setRefreshing] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const currentPlan = currentSubscription
    ? plans.find(p => p.name === currentSubscription.planName)
    : null;

  const teamLimit = currentPlan?.limits?.team_members ?? 1;

  // Debug log
  React.useEffect(() => {
    if (currentSubscription && currentPlan) {
      console.log('Current subscription:', currentSubscription.planName);
      console.log('Current plan limits:', currentPlan.limits);
      console.log('Team limit:', teamLimit);
    }
  }, [currentSubscription, currentPlan, teamLimit]);
  const isUnlimited = teamLimit === -1;
  const currentTeamSize = members.length;
  const canAddMore = isUnlimited || currentTeamSize < teamLimit;

  const load = async () => {
    if (!user?.organizationId) {
      setMembers([]);
      setInvitations([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);

    try {
      const [membersRes, invitationsRes] = await Promise.all([
        supabase
          .from('profiles')
          .select('id, email, name, role, created_at')
          .eq('organization_id', user.organizationId)
          .eq('role', currentUserRole)
          .order('created_at', { ascending: false }),
        supabase
          .from('team_invitations')
          .select('id, invitee_email, status, created_at')
          .eq('org_id', user.organizationId)
          .eq('role', currentUserRole)
          .eq('status', 'pending')
          .order('created_at', { ascending: false })
      ]);

      if (!membersRes.error) setMembers(membersRes.data || []);
      if (!invitationsRes.error) setInvitations(invitationsRes.data || []);
    } catch (e: any) {
      setError(e?.message || 'Failed to load team data');
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    load();
  }, [user?.organizationId]);

  const invite = async () => {
    if (!email.trim() || !user?.organizationId) return;

    if (!canAddMore) {
      setError(`Team size limit reached (${teamLimit} members). Please upgrade your plan.`);
      return;
    }

    setInviting(true);
    setError(null);

    try {
      // Create invitation record
      const { data: invitation, error: insertError } = await supabase
        .from('team_invitations')
        .insert({
          org_id: user.organizationId,
          invited_by: user.id,
          invitee_email: email.trim().toLowerCase(),
          role: currentUserRole,
          status: 'pending'
        } as any)
        .select('id')
        .single();

      if (insertError) throw insertError;

      // Get organization name
      const { data: org } = await supabase
        .from('organizations')
        .select('name')
        .eq('id', user.organizationId)
        .single();

      // Send invitation email via edge function
      let invitationLink = '';
      try {
        const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-team-invitation`;
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            invitationId: invitation.id,
            inviteeEmail: email.trim().toLowerCase(),
            inviterName: user.name,
            organizationName: org?.name || 'Your Organization',
            role: currentUserRole,
            appUrl: window.location.origin,
          }),
        });

        const result = await response.json();
        console.log('Email send result:', result);
        invitationLink = result.invitationLink;
      } catch (emailError) {
        console.warn('Failed to send email, but invitation was created:', emailError);
      }

      setEmail('');
      await load();

      // Show invitation link to user for manual sharing
      if (invitationLink) {
        alert(`Invitation created! Share this link with ${email.trim()}:\n\n${invitationLink}\n\nNote: Email delivery requires SMTP configuration. For now, please share this link manually.`);
      } else {
        alert('Invitation created! The invitation has been recorded in the system.');
      }
    } catch (e: any) {
      setError(e?.message || 'Failed to send invitation');
    } finally {
      setInviting(false);
    }
  };

  const revokeInvitation = async (invitationId: string) => {
    if (!confirm('Revoke this invitation?')) return;

    try {
      const { error } = await supabase
        .from('team_invitations')
        .update({ status: 'revoked' } as any)
        .eq('id', invitationId);

      if (error) throw error;
      await load();
    } catch (e: any) {
      setError(e?.message || 'Failed to revoke invitation');
    }
  };

  const removeMember = async (memberId: string) => {
    if (!confirm('Remove this team member? They will lose access to the organization.')) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ organization_id: null } as any)
        .eq('id', memberId);

      if (error) throw error;
      await load();
    } catch (e: any) {
      setError(e?.message || 'Failed to remove team member');
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
            <Users className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Team Members</h3>
            <p className="text-sm text-gray-600">
              {isUnlimited
                ? `${currentTeamSize} members (Unlimited)`
                : `${currentTeamSize} of ${teamLimit} members used`
              }
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="p-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-50 disabled:opacity-50"
            title="Refresh team list"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-50"
            >
              Close
            </button>
          )}
        </div>
      </div>

      {!currentSubscription && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <div className="font-medium text-yellow-900">No Active Subscription</div>
            <div className="text-sm text-yellow-800 mt-1">
              Subscribe to a plan to add team members to your organization.
            </div>
          </div>
        </div>
      )}

      {currentSubscription && !canAddMore && (
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 flex items-start gap-3">
          <Crown className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <div className="font-medium text-orange-900">Team Limit Reached</div>
            <div className="text-sm text-orange-800 mt-1">
              You've reached your plan's team member limit ({teamLimit} members). Upgrade to add more team members.
            </div>
          </div>
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-red-800">{error}</div>
        </div>
      )}

      <div className="bg-white border rounded-lg p-4 space-y-3">
        <div className="flex items-center gap-2 text-sm font-medium text-gray-900">
          <UserPlus className="w-4 h-4" />
          Invite Team Member
        </div>
        <div className="flex items-center gap-2">
          <div className="flex-1 relative">
            <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && invite()}
              placeholder="colleague@company.com"
              className="w-full border border-gray-300 rounded-lg pl-10 pr-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              disabled={!currentSubscription || !canAddMore || inviting}
            />
          </div>
          <button
            onClick={invite}
            disabled={!currentSubscription || !canAddMore || inviting || !email.trim()}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
          >
            {inviting ? 'Sending…' : 'Invite'}
          </button>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-8 text-sm text-gray-600">Loading team data…</div>
      ) : (
        <div className="space-y-4">
          {invitations.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-gray-900 mb-3 flex items-center gap-2">
                <Mail className="w-4 h-4" />
                Pending Invitations ({invitations.length})
              </h4>
              <div className="bg-white border rounded-lg divide-y">
                {invitations.map(inv => (
                  <div key={inv.id} className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                        <Mail className="w-4 h-4 text-gray-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">{inv.invitee_email}</div>
                        <div className="text-xs text-gray-500">
                          Invited {new Date(inv.created_at).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => revokeInvitation(inv.id)}
                      className="text-sm text-red-600 hover:text-red-700 font-medium"
                    >
                      Revoke
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div>
            <h4 className="text-sm font-medium text-gray-900 mb-3 flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Active Members ({members.length})
            </h4>
            {members.length > 0 ? (
              <div className="bg-white border rounded-lg divide-y">
                {members.map(member => (
                  <div key={member.id} className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                        <Users className="w-4 h-4 text-blue-600" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {member.name || 'Unnamed User'}
                          {member.id === user?.id && (
                            <span className="ml-2 text-xs text-blue-600">(You)</span>
                          )}
                        </div>
                        <div className="text-xs text-gray-500">{member.email}</div>
                      </div>
                    </div>
                    {member.id !== user?.id && (
                      <button
                        onClick={() => removeMember(member.id)}
                        className="text-sm text-red-600 hover:text-red-700 font-medium"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-gray-50 border border-dashed rounded-lg p-8 text-center">
                <Users className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <div className="text-sm text-gray-600">No team members yet</div>
                <div className="text-xs text-gray-500 mt-1">Invite colleagues to collaborate</div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default EmployerTeamManager;
