import React from 'react';
import { X, Globe2, Mail, MapPin, Briefcase, ExternalLink, Building } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface CompanyProfileViewProps {
  orgId: string;
  isOpen: boolean;
  onClose: () => void;
  onViewAllJobs?: () => void;
  onJobClick?: (jobId: string) => void;
}

type OrgRecord = {
  id: string;
  name: string;
  contact_email?: string | null;
  publish_email?: boolean | null;
  website?: string | null;
  about?: string | null;
  publish_profile?: boolean | null;
  country?: string | null;
  city?: string | null;
  postal_code?: string | null;
  logo_path?: string | null;
};

type JobRecord = {
  id: string;
  title: string;
  location: string;
  employment_type: string;
  created_at: string;
};

const CompanyProfileView: React.FC<CompanyProfileViewProps> = ({ orgId, isOpen, onClose, onViewAllJobs, onJobClick }) => {
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [org, setOrg] = React.useState<OrgRecord | null>(null);
  const [logoUrl, setLogoUrl] = React.useState<string>('');
  const [jobs, setJobs] = React.useState<JobRecord[]>([]);

  React.useEffect(() => {
    let mounted = true;
    const load = async () => {
      if (!isOpen) return;
      setLoading(true);
      setError(null);
      try {
        const { data, error } = await supabase
          .from('organizations')
          .select('id, name, contact_email, publish_email, website, about, publish_profile, country, city, postal_code, logo_path')
          .eq('id', orgId)
          .maybeSingle();
        if (error) throw error;
        if (!mounted) return;
        const rec = (data as OrgRecord) || null;
        setOrg(rec);
        if (rec?.logo_path) {
          try {
            const { data: pub } = supabase.storage.from('company-logos').getPublicUrl(rec.logo_path);
            setLogoUrl(pub.publicUrl);
          } catch {}
        } else {
          setLogoUrl('');
        }

        const { data: jobsData } = await supabase
          .from('jobs')
          .select('id, title, location, employment_type, created_at')
          .eq('organization_id', orgId)
          .eq('status', 'open')
          .order('created_at', { ascending: false })
          .limit(2);

        if (mounted && jobsData) {
          setJobs(jobsData as JobRecord[]);
        }
      } catch (e:any) {
        if (mounted) setError(e?.message || 'Failed to load company profile');
      } finally {
        if (mounted) setLoading(false);
      }
    };
    load();
    return () => { mounted = false; };
  }, [isOpen, orgId]);

  if (!isOpen) return null;

  const published = org?.publish_profile !== false; // default allow when flag absent
  const emailVisible = !!org?.publish_email && !!org?.contact_email;

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <div className="flex items-center gap-2">
              <Building className="w-6 h-6" />
              <h3 className="text-xl font-semibold">Company Profile</h3>
            </div>
            <button onClick={onClose} className="p-2 text-white/80 hover:text-white" aria-label="Close">
              <X className="w-6 h-6" />
            </button>
          </div>
          <div className="p-6 max-h-[calc(100vh-200px)] overflow-y-auto">
            {loading ? (
              <div className="text-sm text-gray-600">Loading…</div>
            ) : error ? (
              <div className="bg-red-50 border border-red-200 rounded p-3 text-red-800 text-sm">{error}</div>
            ) : !org ? (
              <div className="text-sm text-gray-600">Company not found.</div>
            ) : (
              <div className="space-y-5">
                <div className="flex items-start gap-4">
                  <div className="w-16 h-16 rounded bg-gray-100 border flex items-center justify-center overflow-hidden flex-shrink-0">
                    {logoUrl ? (
                      <img src={logoUrl} alt="Company logo" className="w-full h-full object-cover" />
                    ) : (
                      <div className="text-xs text-gray-500">No Logo</div>
                    )}
                  </div>
                  <div>
                    <div className="text-xl font-semibold text-gray-900">{org.name}</div>
                    <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 mt-1">
                      {org.website && (
                        <a href={org.website} target="_blank" rel="noreferrer" className="inline-flex items-center hover:text-blue-700">
                          <Globe2 className="w-4 h-4 mr-1" />
                          {org.website}
                        </a>
                      )}
                      {(org.country || org.city) && (
                        <span className="inline-flex items-center">
                          <MapPin className="w-4 h-4 mr-1" />
                          {[org.city, org.country].filter(Boolean).join(', ')} {org.postal_code ? ` ${org.postal_code}` : ''}
                        </span>
                      )}
                      {emailVisible && (
                        <a href={`mailto:${org.contact_email}`} className="inline-flex items-center hover:text-blue-700">
                          <Mail className="w-4 h-4 mr-1" />
                          {org.contact_email}
                        </a>
                      )}
                    </div>
                  </div>
                </div>

                {published ? (
                  <div>
                    <div className="font-medium text-gray-900 mb-1">About</div>
                    <div
                      className="text-sm text-gray-700 bg-gray-50 border rounded p-3 prose prose-sm max-w-none"
                      dangerouslySetInnerHTML={{ __html: org.about || '<p class="text-gray-500 italic">No information provided.</p>' }}
                    />
                  </div>
                ) : (
                  <div className="bg-yellow-50 border border-yellow-200 rounded p-3 text-sm text-yellow-800">
                    This company has not published a public profile.
                  </div>
                )}

                {jobs.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="font-medium text-gray-900">Latest Jobs</div>
                      {onViewAllJobs && (
                        <button
                          onClick={onViewAllJobs}
                          className="text-sm text-blue-600 hover:text-blue-700 inline-flex items-center gap-1"
                        >
                          View all jobs
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                    <div className="space-y-3">
                      {jobs.map(job => (
                        <button
                          key={job.id}
                          onClick={() => {
                            onJobClick?.(job.id);
                            onClose();
                          }}
                          className="w-full text-left bg-gray-50 border rounded-lg p-3 hover:bg-blue-50 hover:border-blue-300 transition-colors"
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1">
                              <div className="font-medium text-gray-900 hover:text-blue-600">{job.title}</div>
                              <div className="flex items-center gap-3 text-xs text-gray-600 mt-1">
                                <span className="inline-flex items-center gap-1">
                                  <MapPin className="w-3 h-3" />
                                  {job.location}
                                </span>
                                <span className="inline-flex items-center gap-1">
                                  <Briefcase className="w-3 h-3" />
                                  {job.employment_type}
                                </span>
                              </div>
                            </div>
                            <div className="text-xs text-gray-500">
                              {new Date(job.created_at).toLocaleDateString()}
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompanyProfileView;

