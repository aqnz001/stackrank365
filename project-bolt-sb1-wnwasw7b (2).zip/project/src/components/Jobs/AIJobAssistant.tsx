import React, { useState } from 'react';
import { Sparkles, Wand2, RefreshCw, Copy, Check, Plus } from 'lucide-react';
import { generateJobSuggestions, getIndustrySpecificSkills, enhanceJobDescription } from '../../utils/aiJobAssistant';

interface AIJobAssistantProps {
  jobTitle: string;
  company: string;
  industry: string;
  currentDescription: string;
  currentSkills: string;
  companyDescription?: string;
  onApplyDescription: (description: string) => void;
  onApplySkills: (skills: string) => void;
  onApplyBoth: (description: string, skills: string) => void;
}

const AIJobAssistant: React.FC<AIJobAssistantProps> = ({
  jobTitle,
  company,
  industry,
  currentDescription,
  currentSkills,
  companyDescription,
  onApplyDescription,
  onApplySkills,
  onApplyBoth
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [suggestions, setSuggestions] = useState<any>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [appendResponsibilities, setAppendResponsibilities] = useState(false);
  const [appendWhatYouBring, setAppendWhatYouBring] = useState(false);

  const stripHtmlTags = (html: string) => {
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || '';
  };

  const generate = async () => {
    if (!jobTitle.trim()) return;
    setIsGenerating(true);
    await new Promise(r => setTimeout(r, 800));
    const base = generateJobSuggestions(jobTitle);
    const industrySkills = industry ? getIndustrySpecificSkills(industry) : [];
    let enhanced = enhanceJobDescription(base.description, jobTitle, company, industry);

    if (companyDescription) {
      const plainTextDescription = stripHtmlTags(companyDescription);
      if (plainTextDescription.trim()) {
        enhanced = `${enhanced}\n\nAbout ${company || 'the Company'}:\n${plainTextDescription}`;
      }
    }

    const combinedSkills = [...new Set([...base.skills, ...industrySkills].slice(0, 10))];
    setSuggestions({
      description: enhanced,
      skills: combinedSkills,
      responsibilities: base.responsibilities,
      whatYouBring: base.whatYouBring
    });
    setIsGenerating(false);
  };

  const copy = async (text: string, field: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 1500);
    } catch {}
  };

  const formatSkills = (skills: string[]) => skills.map(s => `• ${s}`).join('\n');

  const formatSection = (title: string, items: string[]) => {
    return `\n\n${title}:\n${items.map(item => `• ${item}`).join('\n')}`;
  };

  const getCombinedDescription = () => {
    if (!suggestions) return '';
    let combined = suggestions.description;

    if (appendResponsibilities) {
      combined += formatSection('Key Responsibilities', suggestions.responsibilities);
    }

    if (appendWhatYouBring) {
      combined += formatSection('What will you bring?', suggestions.whatYouBring);
    }

    return combined;
  };

  const handleApplyDescription = () => {
    onApplyDescription(getCombinedDescription());
  };

  const handleApplyBoth = () => {
    onApplyBoth(getCombinedDescription(), formatSkills(suggestions.skills));
  };

  const hasTitle = !!jobTitle.trim();

  return (
    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center mr-3">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900">AI Job Assistant</h3>
            <p className="text-sm text-gray-600">{hasTitle ? 'Generate a job description and skills from your title' : 'Enter a job title to enable suggestions'}</p>
          </div>
        </div>
        {hasTitle && (
          <button onClick={generate} disabled={isGenerating} className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-3 rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-all font-medium flex items-center disabled:opacity-50">
            {isGenerating ? (<><RefreshCw className="w-4 h-4 mr-2 animate-spin"/>Generating...</>) : (<><Wand2 className="w-4 h-4 mr-2"/>Generate Suggestions</>)}
          </button>
        )}
      </div>

      {!hasTitle && (
        <div className="bg-white/60 rounded-lg p-4 border border-blue-100">
          <p className="text-gray-700 text-center">Tip: add a job title above to unlock AI-powered suggestions</p>
        </div>
      )}

      {suggestions && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-semibold text-gray-900">AI Suggestions</h4>
          </div>
          <div className="flex justify-center">
            <button onClick={handleApplyBoth} className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-8 py-3 rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all font-medium flex items-center">
              <Sparkles className="w-4 h-4 mr-2"/>Apply All Suggestions
            </button>
          </div>

          <div className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h5 className="font-semibold text-gray-900">Job Description</h5>
              <div className="flex gap-2">
                <button onClick={() => copy(getCombinedDescription(), 'description')} className="p-2 text-gray-500 hover:text-gray-700">{copiedField === 'description' ? <Check className="w-4 h-4 text-green-600"/> : <Copy className="w-4 h-4"/>}</button>
                <button onClick={handleApplyDescription} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-sm font-medium">Use This</button>
              </div>
            </div>
            <div className="bg-gray-50 rounded-lg p-4 max-h-60 overflow-y-auto">
              <p className="text-gray-700 text-sm whitespace-pre-line">{getCombinedDescription()}</p>
            </div>

            <div className="mt-4 space-y-3 pt-4 border-t border-gray-200">
              <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">Optional Sections to Append:</p>

              <label className="flex items-start cursor-pointer group">
                <input
                  type="checkbox"
                  checked={appendResponsibilities}
                  onChange={(e) => setAppendResponsibilities(e.target.checked)}
                  className="mt-1 mr-3 w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <Plus className="w-4 h-4 text-gray-500" />
                    <span className="font-medium text-gray-900">Add Key Responsibilities</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-0.5">Include detailed responsibilities in the job description</p>
                </div>
              </label>

              <label className="flex items-start cursor-pointer group">
                <input
                  type="checkbox"
                  checked={appendWhatYouBring}
                  onChange={(e) => setAppendWhatYouBring(e.target.checked)}
                  className="mt-1 mr-3 w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <Plus className="w-4 h-4 text-gray-500" />
                    <span className="font-medium text-gray-900">Add What will you bring?</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-0.5">Include qualifications and what we're looking for</p>
                </div>
              </label>
            </div>
          </div>

          <div className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h5 className="font-semibold text-gray-900">Desired Skills & Requirements</h5>
              <div className="flex gap-2">
                <button onClick={() => copy(formatSkills(suggestions.skills), 'skills')} className="p-2 text-gray-500 hover:text-gray-700">{copiedField === 'skills' ? <Check className="w-4 h-4 text-green-600"/> : <Copy className="w-4 h-4"/>}</button>
                <button onClick={() => onApplySkills(formatSkills(suggestions.skills))} className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 text-sm font-medium">Use These</button>
              </div>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {suggestions.skills.map((s: string, i: number) => (
                  <div key={i} className="flex items-center text-sm text-gray-700"><span className="w-1.5 h-1.5 bg-green-500 rounded-full mr-2"/>{s}</div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AIJobAssistant;
