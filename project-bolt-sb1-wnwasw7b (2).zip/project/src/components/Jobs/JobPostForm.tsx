import React, { useState } from 'react';
import { useJobs } from '../../hooks/useJobs';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { pricingTiers } from '../../data/mockData';
import { useSubscriptions } from '../../hooks/useSubscriptions';
import PaymentForm from '../Payments/PaymentForm';
import JobPreviewPanel from './JobPreviewPanel';
import AIJobAssistant from './AIJobAssistant';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { X, Briefcase, MapPin, DollarSign, Users, Eye, EyeOff, CheckCircle } from 'lucide-react';
import type { Job } from '../../types';

interface JobPostFormProps {
  onClose: () => void;
}

const JobPostForm: React.FC<JobPostFormProps> = ({ onClose }) => {
  const { createJob, updateJob } = useJobs();
  const { user } = useAuth();
  const { currentSubscription, checkUsageLimit, trackUsage, plans } = useSubscriptions();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [currentStep, setCurrentStep] = useState(0); // 0: details, 1: location & pricing
  const [formData, setFormData] = useState({
    company: '',
    companyDescription: '',
    companyLogo: null as File | null,
    industries: [''] as string[],
    title: '',
    description: '',
    location: '',
    employmentType: 'full-time',
    workplace: 'onsite' as 'onsite' | 'remote' | 'hybrid',
    salaryMin: '',
    salaryMax: '',
    desiredSkills: '',
    skills: '',
    experienceLevel: '',
    experience: '',
    industry: [] as string[],
    benefits: '' as string,
    visibility: 'closed',
    adTier: 'basic',
    country: 'New Zealand',
    postalCode: '',
  });

  const [selectedTier, setSelectedTier] = useState(pricingTiers[0]);
  const [showPreview, setShowPreview] = useState(false);
  const [draftJobId, setDraftJobId] = useState<string | null>(null);
  const [paymentRequested, setPaymentRequested] = useState(false);
  const [lastSavedAt, setLastSavedAt] = useState<Date | null>(null);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [pendingUpdate, setPendingUpdate] = useState<Partial<Job> | null>(null);

  const industries = ['Information Technology and Services','Healthcare and Social Assistance','Professional Services','Education and Training','Manufacturing','Construction','Retail Trade','Transport and Logistics','Finance and Insurance','Government and Public Administration','Media and Communications','Real Estate','Hospitality','Agriculture','Energy','Other'];
  const experienceLevels = ['Entry level','Mid-Senior level','Senior level','Executive level','Internship','Associate level','Director level'];

  // Ensure payment modal never opens just by stepping through the wizard
  React.useEffect(() => {
    if (showPaymentForm) setShowPaymentForm(false);
    if (paymentRequested) setPaymentRequested(false);
  }, [currentStep]);

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) { alert('File size must be less than 2MB'); return; }
    const allowed = ['image/jpeg','image/png','image/gif'];
    if (!allowed.includes(file.type)) { alert('Please upload a JPEG, PNG, or GIF image'); return; }
    setFormData(prev => ({ ...prev, companyLogo: file }));
  };

  const addIndustry = () => setFormData(prev => ({ ...prev, industries: [...prev.industries, ''] }));
  const removeIndustry = (index: number) => setFormData(prev => ({ ...prev, industries: prev.industries.filter((_, i) => i !== index) }));
  const updateIndustry = (index: number, value: string) => setFormData(prev => ({ ...prev, industries: prev.industries.map((v, i) => i === index ? value : v) }));

  // Auto-tie company name and profile to employer's organization (read-only when available)
  React.useEffect(() => {
    let isMounted = true;
    const loadOrgProfile = async () => {
      try {
        if (!user?.organizationId) return;
        const { data, error } = await supabase
          .from('organizations')
          .select('name, about, website, logo_path, city, country')
          .eq('id', user.organizationId)
          .maybeSingle();
        if (!error && data && isMounted) {
          setFormData(prev => ({
            ...prev,
            company: data.name || prev.company,
            companyDescription: (data as any)?.about || prev.companyDescription,
          }));
        }
      } catch {}
    };
    loadOrgProfile();
    return () => { isMounted = false; };
  }, [user?.organizationId]);

  // Determine subscription features
  const hasActiveSubscription = !!currentSubscription;
  const currentPlan = plans.find(p => p.name.toLowerCase().includes(currentSubscription?.planName.toLowerCase() || ''));
  const subscriptionAllowsRecruiterBids = currentPlan ? (currentPlan.limits.recruiter_bids_per_job === -1 || currentPlan.limits.recruiter_bids_per_job > 0) : false;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      // Compose location with workplace hint for search (remote/hybrid)
      let locationValue = formData.location;
      const lower = locationValue.toLowerCase();
      if (formData.workplace === 'remote' && !lower.includes('remote')) {
        locationValue = `${locationValue}${locationValue ? ' ' : ''}Remote`;
      } else if (formData.workplace === 'hybrid' && !lower.includes('hybrid')) {
        locationValue = `${locationValue}${locationValue ? ' ' : ''}Hybrid`;
      }
      const jobData: Partial<Job> = {
        title: formData.title,
        description: formData.description,
        location: locationValue,
        employmentType: formData.employmentType as any,
        salaryRange: formData.salaryMin && formData.salaryMax ? {
          min: parseInt(formData.salaryMin),
          max: parseInt(formData.salaryMax)
        } : undefined,
        skills: (formData.desiredSkills
          ? formData.desiredSkills.split('\n').map(s => s.replace(/^•\s*/,'').trim())
          : formData.skills.split(',')
        ).map(s => s.trim()).filter(Boolean),
        experienceLevel: (formData.experience || formData.experienceLevel) as any,
        industry: formData.industries.map(i => i.trim()).filter(Boolean),
        benefits: formData.benefits ? formData.benefits.split('\n').map(b => b.trim()).filter(Boolean) : undefined,
        visibility: formData.visibility as any,
        // For subscription users, use 'standard' tier by default; for pay-per-use, use selected tier
        adTier: hasActiveSubscription ? 'standard' : (formData.adTier as any),
        // Set bidLimit based on subscription or selected tier
        bidLimit: hasActiveSubscription
          ? (currentPlan?.limits.recruiter_bids_per_job === -1 ? undefined : currentPlan?.limits.recruiter_bids_per_job)
          : selectedTier.bidLimit,
        status: 'open',
      };

      // Handle payment based on subscription status and tier
      if (currentSubscription) {
        console.log('User has subscription, checking limits and tier...');

        // Check if user has reached job posting limit
        const canPost = await checkUsageLimit('job_posts_per_month', 1);

        if (!canPost) {
          setError('You have reached your monthly job posting limit. Please upgrade your plan or wait for the next billing cycle.');
          setIsSubmitting(false);
          return;
        }

        // Calculate tier difference payment for Standard/Premium
        const selectedTierPrice = pricingTiers.find(t => t.name === formData.adTier)?.price || 0;
        const basicTierPrice = pricingTiers.find(t => t.name === 'basic')?.price || 0;
        const tierDifference = Math.max(0, selectedTierPrice - basicTierPrice);

        if (tierDifference > 0 && (formData.adTier === 'standard' || formData.adTier === 'premium')) {
          // Require payment for tier upgrade
          console.log(`Tier upgrade required: ${formData.adTier}. Difference: $${tierDifference}`);
          setPaymentAmount(tierDifference * 100); // Convert to cents
          setPendingUpdate(jobData);
          setPaymentRequested(true);
          setShowPaymentForm(true);
          setIsSubmitting(false);
          return;
        }

        // Basic tier or within subscription - post without payment
        if (draftJobId) {
          await updateJob(draftJobId, jobData);
          try {
            await trackUsage({
              usageType: 'job_posts_per_month',
              quantity: 1,
              unitPrice: 0,
              metadata: {
                job_id: draftJobId,
                job_title: jobData.title,
                ad_tier: jobData.adTier,
              },
            });
          } catch (usageError) { console.error('Usage tracking failed:', usageError); }
        } else {
          await createJob(jobData); // Includes usage tracking
        }
        onClose();
      } else {
        // No subscription - require full payment
        console.log('No subscription found, requiring full payment...');
        setPaymentRequested(true);
        setShowPaymentForm(true);
        setIsSubmitting(false);
        return;
      }

    } catch (err) {
      console.error('Error creating job:', err);
      setError(err instanceof Error ? err.message : 'Failed to create job');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePaymentSuccess = async (paymentIntent: any) => {
    try {
      console.log('Payment successful, creating/updating job...');

      // Use pending update if available (tier upgrade case), otherwise build job data
      const jobData = pendingUpdate || (() => {
        let locationValue = formData.location;
        const lower = locationValue.toLowerCase();
        if (formData.workplace === 'remote' && !lower.includes('remote')) {
          locationValue = `${locationValue}${locationValue ? ' ' : ''}Remote`;
        } else if (formData.workplace === 'hybrid' && !lower.includes('hybrid')) {
          locationValue = `${locationValue}${locationValue ? ' ' : ''}Hybrid`;
        }
        return {
          title: formData.title,
          description: formData.description,
          location: locationValue,
          employmentType: formData.employmentType as any,
          salaryRange: formData.salaryMin && formData.salaryMax ? {
            min: parseInt(formData.salaryMin),
            max: parseInt(formData.salaryMax)
          } : undefined,
          skills: (formData.desiredSkills
            ? formData.desiredSkills.split('\n').map(s => s.replace(/^•\s*/,'').trim())
            : formData.skills.split(',')
          ).map(s => s.trim()).filter(Boolean),
          experienceLevel: (formData.experience || formData.experienceLevel) as any,
          industry: formData.industries.map(i => i.trim()).filter(Boolean),
          benefits: formData.benefits ? formData.benefits.split('\n').map(b => b.trim()).filter(Boolean) : undefined,
          visibility: formData.visibility as any,
          adTier: formData.adTier as any,
          bidLimit: selectedTier.bidLimit,
          status: 'open',
        } as Partial<Job>;
      })();

      if (draftJobId) {
        await updateJob(draftJobId, jobData);
      } else {
        await createJob(jobData);
      }

      // Track the usage
      try {
        const usageType = currentSubscription ? 'job_tier_upgrade' : 'one_time_job_posts';
        await trackUsage({
          usageType: currentSubscription ? 'job_posts_per_month' : usageType,
          quantity: 1,
          unitPrice: paymentAmount,
          metadata: {
            job_id: draftJobId || undefined,
            job_title: jobData.title,
            ad_tier: jobData.adTier,
            payment_intent_id: paymentIntent.id,
            payment_type: currentSubscription ? 'tier_upgrade' : 'one_time',
          },
        });
      } catch (usageError) {
        console.error('Error tracking usage:', usageError);
      }

      setShowPaymentForm(false);
      setPendingUpdate(null);
      onClose();
    } catch (err) {
      console.error('Error creating job after payment:', err);
      setError('Payment successful but failed to create job. Please contact support.');
    }
  };

  const handleTierChange = (tierName: string) => {
    const tier = pricingTiers.find(t => t.name === tierName);
    if (tier) {
      setSelectedTier(tier);
      setFormData(prev => ({ ...prev, adTier: tierName }));
      
      // If selecting basic tier, force visibility to closed
      if (tierName === 'basic') {
        setFormData(prev => ({ ...prev, visibility: 'closed' }));
      }
    }
  };

  const saveAsDraft = async () => {
    try {
      setIsSubmitting(true);
      setError(null);
      let locationValue = formData.location;
      const lower = locationValue.toLowerCase();
      if (formData.workplace === 'remote' && !lower.includes('remote')) {
        locationValue = `${locationValue}${locationValue ? ' ' : ''}Remote`;
      } else if (formData.workplace === 'hybrid' && !lower.includes('hybrid')) {
        locationValue = `${locationValue}${locationValue ? ' ' : ''}Hybrid`;
      }
      const jobData: Partial<Job> = {
        title: formData.title || 'Untitled Job',
        description: formData.description || 'Job description to be added',
        location: (locationValue || 'Location TBD'),
        employmentType: formData.employmentType as any,
        salaryRange: formData.salaryMin && formData.salaryMax ? {
          min: parseInt(formData.salaryMin),
          max: parseInt(formData.salaryMax)
        } : undefined,
        skills: (formData.desiredSkills
          ? formData.desiredSkills.split('\n').map(s => s.replace(/^•\s*/,'').trim())
          : formData.skills.split(',')
        ).map(s => s.trim()).filter(Boolean),
        experienceLevel: (formData.experience || formData.experienceLevel) as any,
        industry: formData.industries.map(i => i.trim()).filter(Boolean),
        benefits: formData.benefits ? formData.benefits.split('\n').map(b => b.trim()).filter(Boolean) : undefined,
        visibility: formData.visibility as any,
        adTier: formData.adTier as any,
        bidLimit: selectedTier.bidLimit,
        status: 'draft',
      };
      if (!draftJobId) {
        // Insert draft directly without consuming usage or requiring subscription
        if (!user?.organizationId) throw new Error('Organization required to save draft');
        const { data, error } = await supabase
          .from('jobs')
          .insert({
            organization_id: user.organizationId,
            title: jobData.title!,
            description: jobData.description!,
            location: jobData.location!,
            salary_min: jobData.salaryRange?.min,
            salary_max: jobData.salaryRange?.max,
            employment_type: jobData.employmentType!,
            skills: jobData.skills || [],
            experience_level: jobData.experienceLevel,
            industry: jobData.industry || [],
            benefits: jobData.benefits || [],
            visibility: jobData.visibility || 'closed',
            ad_tier: jobData.adTier || 'basic',
            bid_limit: jobData.bidLimit,
            blocked_recruiter_ids: [],
            status: 'draft',
          })
          .select()
          .single();
        if (error) {
          // Fallback when DB enum doesn't include 'draft' yet
          const { data: data2, error: error2 } = await supabase
            .from('jobs')
            .insert({
              organization_id: user.organizationId,
              title: jobData.title!,
              description: jobData.description!,
              location: jobData.location!,
              salary_min: jobData.salaryRange?.min,
              salary_max: jobData.salaryRange?.max,
              employment_type: jobData.employmentType!,
              skills: jobData.skills || [],
              experience_level: jobData.experienceLevel,
              industry: jobData.industry || [],
              benefits: jobData.benefits || [],
              visibility: jobData.visibility || 'closed',
              ad_tier: jobData.adTier || 'basic',
              bid_limit: jobData.bidLimit,
              blocked_recruiter_ids: [],
              status: 'on_hold',
            })
            .select()
            .single();
          if (error2) throw error2;
          setDraftJobId(data2.id);
        } else {
          setDraftJobId(data.id);
        }
      } else {
        // Update existing draft
        await updateJob(draftJobId, jobData);
      }
      setLastSavedAt(new Date());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save draft');
    } finally {
      setIsSubmitting(false);
    }
  };

  const employmentTypes = [
    { value: 'full-time', label: 'Full-time' },
    { value: 'part-time', label: 'Part-time' },
    { value: 'contract', label: 'Contract' },
    { value: 'temporary', label: 'Temporary' },
  ];

  const stepTitles = ['Job Details & Description', 'Location & Pricing'];

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4 overflow-y-auto">
        <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden my-8" onClick={(e) => e.stopPropagation()}>
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <div className="flex items-center gap-2">
              <Briefcase className="w-6 h-6" />
              <div>
                <h3 className="text-xl font-semibold">Build Your Job Posting</h3>
                <p className="text-blue-100 text-sm">Step {currentStep + 1} of {stepTitles.length}: {stepTitles[currentStep]}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 text-white/80 hover:text-white" aria-label="Close">
              <X className="w-6 h-6" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="overflow-y-auto max-h-[calc(90vh-180px)]">
            {/* Progress Indicator */}
            <div className="px-6 pt-6 pb-4">
              <div className="flex items-center justify-center gap-3">
                {stepTitles.map((_, i) => (
                  <div key={i} className="flex items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      i <= currentStep ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
                    }`}>
                      {i < currentStep ? <CheckCircle className="w-4 h-4" /> : i + 1}
                    </div>
                    {i < stepTitles.length - 1 && (
                      <div className={`w-12 h-1 mx-2 ${i < currentStep ? 'bg-blue-600' : 'bg-gray-200'}`} />
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="px-6 pb-6 space-y-8">
            {currentStep === 0 && (
              <div className="space-y-8">
                {/* Job Title first */}
                <div>
                  <div className="flex items-center mb-3">
                    <div className="w-8 h-8 bg-gray-600 rounded flex items-center justify-center mr-3">
                      <Briefcase className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900">Job Title</h3>
                  </div>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter job title"
                  />
                </div>

                {/* AI Assistant */}
                <AIJobAssistant
                  jobTitle={formData.title}
                  company={formData.company}
                  industry={formData.industries[0] || ''}
                  currentDescription={formData.description}
                  currentSkills={formData.desiredSkills}
                  companyDescription={formData.companyDescription}
                  onApplyDescription={(d) => setFormData(prev => ({ ...prev, description: d }))}
                  onApplySkills={(s) => setFormData(prev => ({ ...prev, desiredSkills: s }))}
                  onApplyBoth={(d, s) => setFormData(prev => ({ ...prev, description: d, desiredSkills: s }))}
                />

                {/* Work Environment */}
                <div>
                  <div className="flex items-center mb-6">
                    <div className="w-8 h-8 bg-gray-600 rounded flex items-center justify-center mr-3">
                      <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20"><path d="M4 4a2 2 0 00-2 2v8a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2H4zm2 6a2 2 0 114 0 2 2 0 01-4 0zm8-1a1 1 0 100 2 1 1 0 000-2z"/></svg>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900">Work Environment</h3>
                  </div>
                  <div className="space-y-6">
                    {/* Company + logo */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Company</label>
                      <div className="flex items-center gap-4 mt-2">
                        <input type="text" value={formData.company} onChange={(e) => setFormData(prev => ({ ...prev, company: e.target.value }))} className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100" placeholder="Enter company name" disabled={!!user?.organizationId} />
                        <div className="flex-shrink-0">
                          <input type="file" id="company-logo" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                          <label htmlFor="company-logo" className="w-16 h-16 bg-yellow-400 rounded flex items-center justify-center cursor-pointer hover:bg-yellow-500">
                            {formData.companyLogo ? (
                              <img src={URL.createObjectURL(formData.companyLogo)} alt="Company logo" className="w-full h-full object-cover rounded" />
                            ) : (
                              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1M12 12v8m0-8l-3 3m3-3l3 3m0-6a4 4 0 10-8 0 4 4 0 008 0z"/></svg>
                            )}
                          </label>
                        </div>
                      </div>
                      {user?.organizationId && (
                        <p className="text-xs text-gray-500 mt-1">Company linked to your organization.</p>
                      )}
                    </div>
                    {/* Company Description */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Company Description</label>
                      <div className="bg-white border border-gray-300 rounded-lg">
                        <ReactQuill
                          theme="snow"
                          value={formData.companyDescription}
                          onChange={(value) => setFormData(prev => ({ ...prev, companyDescription: value }))}
                          placeholder="Describe the company culture, mission and environment"
                          modules={{
                            toolbar: [
                              [{ 'header': [1, 2, 3, false] }],
                              ['bold', 'italic', 'underline', 'strike'],
                              [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                              ['link'],
                              ['clean']
                            ]
                          }}
                          className="bg-white"
                        />
                      </div>
                    </div>
                    {/* Industries (dynamic) */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Industries</label>
                      <div className="space-y-2">
                        {formData.industries.map((val, idx) => (
                          <div key={idx} className="flex items-center gap-2">
                            <input type="text" value={val} onChange={(e) => updateIndustry(idx, e.target.value)} className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="e.g., Information Technology and Services" />
                            {formData.industries.length > 1 && (
                              <button type="button" onClick={() => removeIndustry(idx)} className="p-2 text-gray-400 hover:text-red-600">✕</button>
                            )}
                          </div>
                        ))}
                        <button type="button" onClick={addIndustry} className="text-blue-600 hover:text-blue-700 text-sm font-medium">+ Add another</button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Position */}
                <div>
                  <div className="flex items-center mb-6">
                    <div className="w-8 h-8 bg-gray-600 rounded flex items-center justify-center mr-3">
                      <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900">Position</h3>
                  </div>
                  <div className="space-y-6">
                    {/* Title moved to the top */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Experience</label>
                      <select value={formData.experience} onChange={(e) => setFormData(prev => ({ ...prev, experience: e.target.value }))} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">Select experience level...</option>
                        {experienceLevels.map(level => (<option key={level} value={level}>{level}</option>))}
                      </select>
                    </div>
                    {/* Job Description with simple toolbar */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Job Description</label>
                      <div className="border border-gray-300 rounded-lg">
                        <div className="border-b border-gray-300 px-3 py-2 bg-gray-50 flex items-center gap-2 text-sm text-gray-700">
                          <button type="button" className="p-1 hover:bg-gray-200 rounded font-bold">B</button>
                          <button type="button" className="p-1 hover:bg-gray-200 rounded italic">I</button>
                          <button type="button" className="p-1 hover:bg-gray-200 rounded underline">U</button>
                        </div>
                        <textarea rows={8} value={formData.description} onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))} className="w-full px-4 py-3 border-0 rounded-b-lg focus:ring-2 focus:ring-blue-500 resize-none" placeholder="Describe the role, responsibilities, and what makes this position exciting..." />
                      </div>
                    </div>
                    {/* Desired Skills */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Desired Skills</label>
                      <div className="border border-gray-300 rounded-lg">
                        <div className="border-b border-gray-300 px-3 py-2 bg-gray-50 flex items-center gap-2 text-sm text-gray-700">
                          <button type="button" className="p-1 hover:bg-gray-200 rounded font-bold">B</button>
                          <button type="button" className="p-1 hover:bg-gray-200 rounded italic">I</button>
                          <button type="button" className="p-1 hover:bg-gray-200 rounded underline">U</button>
                        </div>
                        <textarea rows={6} value={formData.desiredSkills} onChange={(e) => setFormData(prev => ({ ...prev, desiredSkills: e.target.value }))} className="w-full px-4 py-3 border-0 rounded-b-lg focus:ring-2 focus:ring-blue-500 resize-none" placeholder="List the skills, qualifications, and experience required for this role..." />
                      </div>
                    </div>
                    {/* Location & Salary & Employment */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2"><MapPin className="w-4 h-4 inline mr-1"/> Location</label>
                    <input type="text" required value={formData.location} onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="e.g., Auckland or Remote" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Employment Type</label>
                    <select value={formData.employmentType} onChange={(e) => setFormData(prev => ({ ...prev, employmentType: e.target.value }))} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                      {employmentTypes.map(type => (<option key={type.value} value={type.value}>{type.label}</option>))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Workplace</label>
                    <select value={formData.workplace} onChange={(e) => setFormData(prev => ({ ...prev, workplace: e.target.value as any }))} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                      <option value="onsite">On-site</option>
                      <option value="remote">Work from home</option>
                      <option value="hybrid">Flexible / hybrid</option>
                    </select>
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2"><DollarSign className="w-4 h-4 inline mr-1"/> Salary Range (Optional)</label>
                    <div className="grid grid-cols-2 gap-4">
                          <input type="number" value={formData.salaryMin} onChange={(e) => setFormData(prev => ({ ...prev, salaryMin: e.target.value }))} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="Minimum salary" />
                          <input type="number" value={formData.salaryMax} onChange={(e) => setFormData(prev => ({ ...prev, salaryMax: e.target.value }))} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="Maximum salary" />
                        </div>
                      </div>
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">Benefits (optional)</label>
                      <textarea rows={4} value={formData.benefits} onChange={(e) => setFormData(prev => ({ ...prev, benefits: e.target.value }))} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder={"List one benefit per line (e.g.\nHealth insurance\nFlexible hours)"} />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentStep === 1 && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900">Location & Pricing</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Country</label>
                    <select value={formData.country} onChange={(e) => setFormData(prev => ({ ...prev, country: e.target.value }))} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                      {['New Zealand','Australia','United States','United Kingdom','Canada'].map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Postal Code</label>
                    <input type="text" value={formData.postalCode} onChange={(e) => setFormData(prev => ({ ...prev, postalCode: e.target.value }))} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="0600" />
                  </div>
                </div>

                <div className="text-lg font-semibold text-gray-900">{formData.location ? `${formData.location}, ${formData.country}` : formData.country}</div>

                {/* Show tier selection only for users without subscription (pay-per-use) */}
                {!hasActiveSubscription && (
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Choose Ad Tier</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {pricingTiers.map(tier => (
                        <label key={tier.name} className={`relative p-4 border-2 rounded-lg cursor-pointer transition-all ${selectedTier.name === tier.name ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}`}>
                          <input type="radio" name="tier" className="sr-only" value={tier.name} checked={selectedTier.name === tier.name} onChange={() => handleTierChange(tier.name)} />
                          <div className="text-center">
                            <h5 className="font-semibold text-gray-900 capitalize">{tier.name}</h5>
                            <div className="text-2xl font-bold text-blue-600 my-2">${tier.price}</div>
                            <p className="text-sm text-gray-600 mb-3">{tier.description}</p>
                            <ul className="text-xs text-gray-500 space-y-1">
                              {tier.features.map((feature, index) => (<li key={index}>• {feature}</li>))}
                            </ul>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                {/* Show subscription info for subscribed users */}
                {hasActiveSubscription && currentPlan && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="w-5 h-5 text-blue-600" />
                      <h4 className="text-lg font-semibold text-gray-900">Active Subscription: {currentPlan.name}</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">This job post is included in your subscription plan.</p>
                    <ul className="text-xs text-gray-500 space-y-1">
                      {currentPlan.features.map((feature, index) => (<li key={index}>• {feature}</li>))}
                    </ul>
                  </div>
                )}

                {/* Show visibility options if subscription allows recruiter bids OR if pay-per-use tier is not basic */}
                {((hasActiveSubscription && subscriptionAllowsRecruiterBids) || (!hasActiveSubscription && selectedTier.name !== 'basic')) && (
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Job Visibility</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <label className="cursor-pointer">
                        <input type="radio" name="visibility" value="closed" checked={formData.visibility === 'closed'} onChange={(e) => setFormData(prev => ({ ...prev, visibility: e.target.value }))} className="sr-only" />
                        <div className={`p-4 border-2 rounded-lg ${formData.visibility === 'closed' ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}`}>
                          <div className="flex items-center mb-2"><EyeOff className="w-5 h-5 mr-2 text-gray-600" /><span className="font-medium">Closed to Recruiters</span></div>
                          <p className="text-sm text-gray-600">Only direct candidate applications</p>
                        </div>
                      </label>
                      <label className="cursor-pointer">
                        <input type="radio" name="visibility" value="open" checked={formData.visibility === 'open'} onChange={(e) => setFormData(prev => ({ ...prev, visibility: e.target.value }))} className="sr-only" />
                        <div className={`p-4 border-2 rounded-lg ${formData.visibility === 'open' ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}`}>
                          <div className="flex items-center mb-2"><Eye className="w-5 h-5 mr-2 text-green-600" /><span className="font-medium">Open to Recruiters</span></div>
                          <p className="text-sm text-gray-600">
                            Direct applications + recruiter bids
                            {hasActiveSubscription && currentPlan?.limits.recruiter_bids_per_job !== -1 && currentPlan?.limits.recruiter_bids_per_job
                              ? ` (up to ${currentPlan.limits.recruiter_bids_per_job} bids)`
                              : !hasActiveSubscription && selectedTier.bidLimit
                              ? ` (up to ${selectedTier.bidLimit} bids)`
                              : ''}
                          </p>
                        </div>
                      </label>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-6 py-4 border-t bg-gray-50 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={saveAsDraft}
                disabled={isSubmitting}
                className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100 font-medium transition-colors disabled:opacity-50"
              >
                Save Draft
              </button>
              {lastSavedAt && (
                <span className="text-sm text-gray-500">Saved {lastSavedAt.toLocaleTimeString()}</span>
              )}
              <button
                type="button"
                onClick={() => setShowPreview(true)}
                className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100 font-medium transition-colors flex items-center gap-2"
              >
                <Eye className="w-4 h-4" />
                Preview
              </button>
            </div>

            <div className="flex items-center gap-3">
              {currentStep > 0 && (
                <button
                  type="button"
                  onClick={() => setCurrentStep(s => Math.max(0, s - 1))}
                  className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100 font-medium transition-colors"
                >
                  Back
                </button>
              )}
              {currentStep === 0 ? (
                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setShowPaymentForm(false);
                    setCurrentStep(1);
                  }}
                  disabled={!formData.title || !formData.location}
                  className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Next
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  <CheckCircle className="w-4 h-4" />
                  {isSubmitting ? 'Creating Job...' : hasActiveSubscription ? 'Post Job' : `Post Job & Pay $${selectedTier.price}`}
                </button>
              )}
            </div>
          </div>
        </form>

        {error && (
          <div className="px-6 pb-4 text-red-700">{error}</div>
        )}

        {/* Payment Form Modal */}
        {showPaymentForm && paymentRequested && (
          <PaymentForm
            amount={paymentAmount || (selectedTier.price * 100)}
            description={paymentAmount > 0 && currentSubscription
              ? `Job Tier Upgrade: ${formData.title} (${selectedTier.name} tier - difference only)`
              : `Job Posting: ${formData.title} (${selectedTier.name} tier)`}
            onSuccess={handlePaymentSuccess}
            onError={(error) => { setError(error); setPaymentRequested(false); setShowPaymentForm(false); setPendingUpdate(null); }}
            onClose={() => { setPaymentRequested(false); setShowPaymentForm(false); setPendingUpdate(null); }}
          />
        )}

        {/* Preview Modal: use the same preview as homepage */}
        {showPreview && (
          <div className="fixed inset-0 z-50">
            <div className="absolute inset-0 bg-black/40" onClick={() => setShowPreview(false)} />
            <div className="absolute inset-0 flex items-center justify-center p-4">
              <div className="relative bg-white w-full max-w-3xl max-h-[90vh] rounded-xl shadow-2xl flex flex-col overflow-hidden">
                <button onClick={() => setShowPreview(false)} className="absolute top-3 right-3 z-20 p-2 text-gray-500 hover:text-gray-700 bg-white rounded-full shadow-md hover:shadow-lg">✕</button>
                <div className="flex-1 flex flex-col overflow-hidden">
                  {(() => {
                    const skills = (formData.desiredSkills
                      ? formData.desiredSkills.split('\n').map(s => s.replace(/^•\s*/,'').trim())
                      : formData.skills.split(',')
                    ).map(s => s.trim()).filter(Boolean);
                    const previewJob: Job = {
                      id: 'preview-job',
                      organizationId: user?.organizationId || 'org-preview',
                      organizationName: formData.company || 'Your company',
                      title: formData.title || 'Job Title',
                      description: formData.description || 'Describe the role...\n• Responsibilities\n• Requirements',
                      location: formData.location || 'Location',
                      salaryRange: (formData.salaryMin || formData.salaryMax) ? { min: parseInt(formData.salaryMin||'0')||0, max: parseInt(formData.salaryMax||'0')||0 } : undefined,
                      employmentType: (formData.employmentType as any) || 'full-time',
                      experienceLevel: (formData.experience || formData.experienceLevel) as any,
                      skills,
                      industry: formData.industries.map(i => i.trim()).filter(Boolean),
                      benefits: formData.benefits ? formData.benefits.split('\n').map(b => b.trim()).filter(Boolean) : undefined,
                      visibility: (formData.visibility as any) || 'closed',
                      adTier: (formData.adTier as any) || selectedTier.name,
                      bidLimit: selectedTier.bidLimit,
                      blockedRecruiterIds: [],
                      status: 'open',
                      createdAt: new Date(),
                    };
                    return (
                      <JobPreviewPanel job={previewJob} onClose={() => setShowPreview(false)} />
                    );
                  })()}
                </div>
              </div>
            </div>
          </div>
        )}
        </div>
      </div>
    </div>
  );
};

export default JobPostForm;
