import React, { useState, useMemo } from 'react';
import { Search, Filter, SortAsc, SortDesc, BookmarkPlus, Loader2 } from 'lucide-react';
import JobCard from './JobCard';
import BidForm from '../Bids/BidForm';
import JobFilters, { JobFilters as JobFiltersType } from './JobFilters';
import { useSavedSearches } from '../../hooks/useSavedSearches';
import { useAuth } from '../../context/AuthContext';
import type { Job } from '../../types';

interface JobSearchProps {
  jobs: Job[];
  showActions?: boolean;
  showApplyButton?: boolean;
  onJobEdit?: (job: Job) => void;
  onJobToggleVisibility?: (job: Job) => void;
  onJobApply?: (job: Job) => void;
}

type SortOption = 'newest' | 'oldest' | 'salary-high' | 'salary-low' | 'title-asc' | 'title-desc';

const JobSearch: React.FC<JobSearchProps> = ({
  jobs,
  showActions = false,
  showApplyButton = false,
  onJobEdit,
  onJobToggleVisibility,
  onJobApply
}) => {
  const { user } = useAuth();
  const { createSavedSearch } = useSavedSearches();
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('newest');
  const [showFilters, setShowFilters] = useState(false);
  const [showSaveSearch, setShowSaveSearch] = useState(false);
  const [searchName, setSearchName] = useState('');
  const [savingSearch, setSavingSearch] = useState(false);
  const [filters, setFilters] = useState<JobFiltersType>({
    location: '',
    employmentType: [],
    salaryMin: '',
    salaryMax: '',
    skills: [],
    adTier: [],
    visibility: [],
    status: [],
  });

  const sortOptions = [
    { value: 'newest', label: 'Newest First' },
    { value: 'oldest', label: 'Oldest First' },
    { value: 'salary-high', label: 'Salary: High to Low' },
    { value: 'salary-low', label: 'Salary: Low to High' },
    { value: 'title-asc', label: 'Title: A to Z' },
    { value: 'title-desc', label: 'Title: Z to A' },
  ];

  const filteredAndSortedJobs = useMemo(() => {
    let filtered = jobs.filter(job => {
      // Search query filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesSearch = 
          job.title.toLowerCase().includes(query) ||
          job.description.toLowerCase().includes(query) ||
          job.organizationName.toLowerCase().includes(query) ||
          job.location.toLowerCase().includes(query) ||
          job.skills.some(skill => skill.toLowerCase().includes(query));
        
        if (!matchesSearch) return false;
      }

      // Location filter
      if (filters.location && !job.location.toLowerCase().includes(filters.location.toLowerCase())) {
        return false;
      }

      // Employment type filter
      if (filters.employmentType.length > 0 && !filters.employmentType.includes(job.employmentType)) {
        return false;
      }

      // Salary filter
      if (filters.salaryMin && job.salaryRange && job.salaryRange.min < parseInt(filters.salaryMin)) {
        return false;
      }
      if (filters.salaryMax && job.salaryRange && job.salaryRange.max > parseInt(filters.salaryMax)) {
        return false;
      }

      // Skills filter
      if (filters.skills.length > 0) {
        const hasMatchingSkill = filters.skills.some(filterSkill =>
          job.skills.some(jobSkill => 
            jobSkill.toLowerCase().includes(filterSkill.toLowerCase())
          )
        );
        if (!hasMatchingSkill) return false;
      }

      // Ad tier filter
      if (filters.adTier.length > 0 && !filters.adTier.includes(job.adTier)) {
        return false;
      }

      // Visibility filter
      if (filters.visibility.length > 0 && !filters.visibility.includes(job.visibility)) {
        return false;
      }

      // Status filter
      if (filters.status.length > 0 && !filters.status.includes(job.status)) {
        return false;
      }

      return true;
    });

    // Sort the filtered results
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        case 'oldest':
          return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
        case 'salary-high':
          const aSalaryMax = a.salaryRange?.max || 0;
          const bSalaryMax = b.salaryRange?.max || 0;
          return bSalaryMax - aSalaryMax;
        case 'salary-low':
          const aSalaryMin = a.salaryRange?.min || 0;
          const bSalaryMin = b.salaryRange?.min || 0;
          return aSalaryMin - bSalaryMin;
        case 'title-asc':
          return a.title.localeCompare(b.title);
        case 'title-desc':
          return b.title.localeCompare(a.title);
        default:
          return 0;
      }
    });

    return filtered;
  }, [jobs, searchQuery, sortBy, filters]);

  const getActiveFilterCount = () => {
    let count = 0;
    if (filters.location) count++;
    if (filters.employmentType.length) count++;
    if (filters.salaryMin || filters.salaryMax) count++;
    if (filters.skills.length) count++;
    if (filters.adTier.length) count++;
    if (filters.visibility.length) count++;
    if (filters.status.length) count++;
    return count;
  };

  const hasActiveSearch = () => {
    return searchQuery || getActiveFilterCount() > 0;
  };

  const handleSaveSearch = async () => {
    if (!searchName.trim()) {
      alert('Please enter a name for this search');
      return;
    }

    setSavingSearch(true);
    try {
      await createSavedSearch({
        name: searchName.trim(),
        searchCriteria: {
          query: searchQuery || undefined,
          location: filters.location || undefined,
          employmentType: filters.employmentType.length > 0 ? filters.employmentType : undefined,
          salaryMin: filters.salaryMin ? parseInt(filters.salaryMin) : undefined,
          salaryMax: filters.salaryMax ? parseInt(filters.salaryMax) : undefined,
          skills: filters.skills.length > 0 ? filters.skills : undefined,
          adTier: filters.adTier.length > 0 ? filters.adTier : undefined,
          visibility: filters.visibility.length > 0 ? filters.visibility : undefined,
          status: filters.status.length > 0 ? filters.status : undefined,
        },
        emailAlerts: true,
        alertFrequency: 'daily',
      });

      setShowSaveSearch(false);
      setSearchName('');

      const notification = document.createElement('div');
      notification.className = 'fixed top-4 right-4 bg-green-100 border border-green-200 text-green-800 px-4 py-3 rounded-lg shadow-lg z-50';
      notification.innerHTML = `
        <div class="flex items-center">
          <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
          </svg>
          Search saved successfully! You'll receive email alerts for new matching jobs.
        </div>
      `;
      document.body.appendChild(notification);
      setTimeout(() => {
        if (notification.parentNode) {
          document.body.removeChild(notification);
        }
      }, 4000);
    } catch (error) {
      console.error('Error saving search:', error);
      alert('Failed to save search. Please try again.');
    } finally {
      setSavingSearch(false);
    }
  };

  const [bidJob, setBidJob] = React.useState<any>(null);
  return (
    <div className="space-y-6">
      {/* Search and Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search jobs by title, company, location, or skills..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        
        <div className="flex gap-3">
          {user && user.role === 'candidate' && hasActiveSearch() && (
            <button
              onClick={() => setShowSaveSearch(true)}
              className="flex items-center px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              title="Save this search"
            >
              <BookmarkPlus className="w-4 h-4 mr-2" />
              Save Search
            </button>
          )}

          <button
            onClick={() => setShowFilters(true)}
            className="flex items-center px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Filter className="w-4 h-4 mr-2" />
            Filters
            {getActiveFilterCount() > 0 && (
              <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                {getActiveFilterCount()}
              </span>
            )}
          </button>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as SortOption)}
            className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
          >
            {sortOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Active Filters Display */}
      {getActiveFilterCount() > 0 && (
        <div className="flex flex-wrap gap-2">
          {filters.location && (
            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-800">
              Location: {filters.location}
            </span>
          )}
          {filters.employmentType.map(type => (
            <span key={type} className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-green-100 text-green-800">
              {type}
            </span>
          ))}
          {(filters.salaryMin || filters.salaryMax) && (
            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-purple-100 text-purple-800">
              Salary: {filters.salaryMin && `$${parseInt(filters.salaryMin).toLocaleString()}+`}
              {filters.salaryMin && filters.salaryMax && ' - '}
              {filters.salaryMax && `$${parseInt(filters.salaryMax).toLocaleString()}`}
            </span>
          )}
          {filters.skills.map(skill => (
            <span key={skill} className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-orange-100 text-orange-800">
              {skill}
            </span>
          ))}
        </div>
      )}

      {/* Results Count */}
      <div className="flex justify-between items-center">
        <p className="text-gray-600">
          {filteredAndSortedJobs.length} job{filteredAndSortedJobs.length !== 1 ? 's' : ''} found
          {searchQuery && ` for "${searchQuery}"`}
        </p>
        
        <div className="flex items-center text-sm text-gray-500">
          {sortBy.includes('asc') ? <SortAsc className="w-4 h-4 mr-1" /> : <SortDesc className="w-4 h-4 mr-1" />}
          Sorted by {sortOptions.find(opt => opt.value === sortBy)?.label}
        </div>
      </div>

      {/* Job Results */}
      {filteredAndSortedJobs.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAndSortedJobs.map((job) => (
            <JobCard 
              key={job.id} 
              job={job} 
              showActions={showActions}
              showApplyButton={showApplyButton}
              showBidForRecruiter
              onBid={() => { console.log('[BidModal] open from JobSearch', { jobId: job.id, title: job.title }); setBidJob(job); }}
              onEdit={() => onJobEdit?.(job)}
              onToggleVisibility={() => onJobToggleVisibility?.(job)}
              onApply={() => onJobApply?.(job)}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No jobs found</h3>
          <p className="text-gray-600">
            {searchQuery || getActiveFilterCount() > 0
              ? 'Try adjusting your search criteria or filters'
              : 'No jobs available at the moment'
            }
          </p>
        </div>
      )}

      {bidJob && (
        <BidForm job={bidJob} onClose={() => { console.log('[BidModal] close'); setBidJob(null); }} />
      )}

      {/* Filters Modal */}
      <JobFilters
        isOpen={showFilters}
        onClose={() => setShowFilters(false)}
        onFiltersChange={setFilters}
      />

      {/* Save Search Modal */}
      {showSaveSearch && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Save This Search</h3>

            <p className="text-gray-600 mb-4">
              Get notified when new jobs match your search criteria
            </p>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Search Name
                </label>
                <input
                  type="text"
                  value={searchName}
                  onChange={(e) => setSearchName(e.target.value)}
                  placeholder="e.g., Remote React Jobs"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  autoFocus
                />
              </div>

              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Search Criteria:</h4>
                <div className="text-sm text-gray-600 space-y-1">
                  {searchQuery && <p>Query: "{searchQuery}"</p>}
                  {filters.location && <p>Location: {filters.location}</p>}
                  {filters.employmentType.length > 0 && (
                    <p>Type: {filters.employmentType.join(', ')}</p>
                  )}
                  {(filters.salaryMin || filters.salaryMax) && (
                    <p>
                      Salary: {filters.salaryMin && `$${parseInt(filters.salaryMin).toLocaleString()}+`}
                      {filters.salaryMin && filters.salaryMax && ' - '}
                      {filters.salaryMax && `$${parseInt(filters.salaryMax).toLocaleString()}`}
                    </p>
                  )}
                  {filters.skills.length > 0 && (
                    <p>Skills: {filters.skills.join(', ')}</p>
                  )}
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowSaveSearch(false);
                    setSearchName('');
                  }}
                  disabled={savingSearch}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveSearch}
                  disabled={savingSearch || !searchName.trim()}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center"
                >
                  {savingSearch ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    'Save Search'
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default JobSearch;
