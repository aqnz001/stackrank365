import React from 'react';
import { useState } from 'react';
import ImageOptimizer from '../Performance/ImageOptimizer';
import SwipeGestures from '../Mobile/SwipeGestures';
import { Job } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useBidEligibility } from '../../hooks/useBidEligibility';
import { 
  MapPin, 
  Clock, 
  DollarSign, 
  Users, 
  Eye, 
  EyeOff,
  Calendar,
  Briefcase,
  Send
} from 'lucide-react';
import CompanyProfileView from '../Organizations/CompanyProfileView';
import { getJobLifecycle } from '../../utils/jobs';

interface JobCardProps {
  job: Job;
  showActions?: boolean;
  showApplyButton?: boolean;
  showBidForRecruiter?: boolean;
  onEdit?: () => void;
  onToggleVisibility?: () => void;
  onDelete?: () => void;
  onApply?: () => void;
  onViewDetails?: () => void;
  onBid?: () => void;
}

const JobCard: React.FC<JobCardProps> = ({ 
  job, 
  showActions = false, 
  showApplyButton = false,
  onEdit, 
  onToggleVisibility, 
  onDelete,
  onApply,
  onViewDetails,
  showBidForRecruiter = false,
  onBid,
}) => {
  const [showFullDescription, setShowFullDescription] = useState(false);
  const [showCompany, setShowCompany] = useState(false);
  const { user } = useAuth();
  const { canBid, reason, slotsLeft, loading } = useBidEligibility(job);
  
  const getVisibilityInfo = () => {
    return job.visibility === 'open' 
      ? { icon: <Eye className="w-4 h-4" />, text: 'Open to recruiters', color: 'green' }
      : { icon: <EyeOff className="w-4 h-4" />, text: 'Direct only', color: 'gray' };
  };

  const getTierInfo = () => {
    const tiers = {
      basic: { name: 'Basic', badgeClass: 'bg-blue-100 text-blue-800', price: '$200' },
      standard: { name: 'Standard', badgeClass: 'bg-purple-100 text-purple-800', price: '$300' },
      premium: { name: 'Premium', badgeClass: 'bg-orange-100 text-orange-800', price: '$500' },
    } as const;
    const key = (job.adTier ?? 'basic') as keyof typeof tiers;
    return tiers[key] ?? tiers.basic;
  };

  const visibility = getVisibilityInfo();
  const tier = getTierInfo();
  const life = getJobLifecycle(job);

  const handleSwipeLeft = () => {
    if (showActions && onDelete) {
      onDelete();
    }
  };

  const handleSwipeRight = () => {
    if (showApplyButton && onApply) {
      onApply();
    } else if (showActions && onEdit) {
      onEdit();
    }
  };

  return (
    <SwipeGestures
      onSwipeLeft={handleSwipeLeft}
      onSwipeRight={handleSwipeRight}
      className="bg-white rounded-xl shadow-sm border border-gray-200 hover:shadow-lg hover:border-gray-300 transition-all duration-200 group"
    >
      <div className="p-5 sm:p-6">
      <div className="flex justify-between items-start mb-4">
        <div className="flex-1">
          <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors">{job.title}</h3>
          <div className="text-gray-600 mb-2 text-sm sm:text-base">
            {job.organizationId ? (
              <button
                type="button"
                onClick={()=>setShowCompany(true)}
                className="text-blue-600 hover:text-blue-700 hover:underline"
              >
                {job.organizationName || 'Unknown Company'}
              </button>
            ) : (
              <span>{job.organizationName || 'Unknown Company'}</span>
            )}
          </div>
          
          <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4 space-y-1 sm:space-y-0 text-xs sm:text-sm text-gray-500">
            <div className="flex items-center">
              <MapPin className="w-4 h-4 mr-1" />
              {job.location}
            </div>
            <div className="flex items-center">
              <Briefcase className="w-4 h-4 mr-1" />
              {job.employmentType}
            </div>
            <div className="flex items-center">
              <Calendar className="w-4 h-4 mr-1" />
              {new Date(job.createdAt as any).toLocaleDateString()}
            </div>
          </div>
        </div>

        <div className="flex flex-col items-end space-y-2 ml-4">
          <span className={`px-3 py-1.5 rounded-lg text-xs font-semibold shadow-sm ${tier.badgeClass}`}>
            <span className="hidden sm:inline">{tier.name} • </span>{tier.price}
          </span>

          {life.closingSoon && (
            <span className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-orange-100 text-orange-700 shadow-sm">Closing soon</span>
          )}
        </div>
      </div>

      {job.salaryRange && (
        <div className="flex items-center text-sm sm:text-base font-semibold text-gray-700 mb-4 bg-green-50 px-4 py-2.5 rounded-lg border border-green-200">
          <DollarSign className="w-5 h-5 mr-2 text-green-600" />
          ${job.salaryRange.min.toLocaleString()} - ${job.salaryRange.max.toLocaleString()}
        </div>
      )}

      <div className="mb-5">
        <div className="flex flex-wrap gap-2">
          {job.employmentType && (
            <span className="inline-flex items-center px-3 py-1.5 bg-blue-50 text-blue-700 text-xs font-medium rounded-lg border border-blue-200 capitalize">
              <Briefcase className="w-3.5 h-3.5 mr-1.5" />
              {job.employmentType.replace('-', ' ')}
            </span>
          )}
          {(job.skills || []).slice(0, 3).map((skill, index) => (
            <span key={index} className="px-3 py-1.5 bg-gray-100 text-gray-700 text-xs font-medium rounded-lg hover:bg-gray-200 transition-colors">
              {skill}
            </span>
          ))}
          {(job.skills || []).length > 3 && (
            <span className="px-3 py-1.5 bg-gray-100 text-gray-600 text-xs font-medium rounded-lg">
              +{(job.skills || []).length - 3} more
            </span>
          )}
        </div>
      </div>

      <div className="mb-5">
        <p className={`text-gray-600 text-sm leading-relaxed ${showFullDescription ? '' : 'line-clamp-3'}`}>
          {job.description}
        </p>
        {job.description.length > 150 && (
          <button
            onClick={() => setShowFullDescription(!showFullDescription)}
            className="text-blue-600 hover:text-blue-700 font-medium text-sm mt-2 inline-flex items-center"
          >
            {showFullDescription ? 'Show less' : 'Read more'}
          </button>
        )}
      </div>

      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-4 sm:space-y-0 pt-4 border-t border-gray-100">
        <div className="flex items-center space-x-4 sm:space-x-5 text-xs sm:text-sm text-gray-600">
          <div className="flex items-center">
            <Users className="w-4 h-4 mr-1" />
            {job.applications?.length || 0} applications
          </div>
          {job.visibility === 'open' && (
            <>
              <div className="flex items-center">
                <Clock className="w-4 h-4 mr-1" />
                {job.recruiterBids?.length || 0} bids
              </div>
              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                loading ? 'bg-gray-100 text-gray-700' : (
                  Number.isFinite(slotsLeft) ? (slotsLeft > 0 ? 'bg-blue-100 text-blue-800' : 'bg-red-100 text-red-800') : 'bg-green-100 text-green-800'
                )
              }`}>
                {loading ? 'Checking…' : (Number.isFinite(slotsLeft) ? (slotsLeft > 0 ? `Slots: ${slotsLeft}` : 'Full') : 'Open')}
              </span>
            </>
          )}
        </div>

        {showActions && (
          <div className="flex flex-wrap gap-2">
            <button
              onClick={onEdit}
              className="px-2 sm:px-3 py-1 text-xs sm:text-sm bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors"
            >
              Edit
            </button>
            <button
              onClick={onToggleVisibility}
              className="px-2 sm:px-3 py-1 text-xs sm:text-sm bg-blue-100 text-blue-700 rounded hover:bg-blue-200 transition-colors"
            >
              {job.visibility === 'open' ? 'Close' : 'Open'}
            </button>
            {onDelete && (
              <button
                onClick={onDelete}
                className="px-2 sm:px-3 py-1 text-xs sm:text-sm bg-red-100 text-red-700 rounded hover:bg-red-200 transition-colors"
              >
                Delete
              </button>
            )}
          </div>
        )}

        <div className="flex items-center gap-3 w-full sm:w-auto">
          {onViewDetails && (
            <button
              onClick={onViewDetails}
              className="flex-1 sm:flex-none text-blue-600 hover:text-blue-700 text-sm"
            >
              View Details
            </button>
          )}
          {showApplyButton && (
            <button
              onClick={onApply}
              className="flex-1 sm:flex-none inline-flex items-center justify-center px-5 sm:px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 active:bg-blue-800 transition-all font-semibold text-sm shadow-sm hover:shadow-md transform hover:-translate-y-0.5"
            >
              <Send className="w-4 h-4 mr-2" />
              Apply Now
            </button>
          )}
          {showBidForRecruiter && user?.role === 'recruiter' && job.visibility === 'open' && (
            reason === 'Bid capacity reached' ? null : (
              <button
                onClick={() => { console.log('[BidCTA] JobCard click', { jobId: job.id, title: job.title }); onBid?.(); }}
                title={!canBid && !loading ? reason : ''}
                className={`flex-1 sm:flex-none inline-flex items-center justify-center px-3 sm:px-4 py-2 rounded-lg transition-colors text-sm disabled:opacity-50 ${
                  loading ? 'bg-gray-100 text-gray-700' : (canBid ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100')
                }`}
                disabled={loading || !canBid}
              >
                Bid for this Job{Number.isFinite(slotsLeft) ? ` • ${slotsLeft}` : ''}
              </button>
            )
          )}
        </div>
      </div>

      {showCompany && job.organizationId && (
        <CompanyProfileView
          orgId={job.organizationId}
          isOpen={showCompany}
          onClose={()=>setShowCompany(false)}
          onViewAllJobs={() => {
            setShowCompany(false);
            window.location.href = `/#/?employer=${encodeURIComponent(job.organizationName || '')}&employerId=${job.organizationId}`;
          }}
          onJobClick={(jobId) => {
            if (onViewDetails) {
              const jobToView = { ...job, id: jobId };
              onViewDetails();
            }
          }}
        />
      )}

      <div className="mt-3 sm:mt-4 pt-3 sm:pt-4 border-t border-gray-100">
        <div className="flex justify-end items-center">
          {job.bidLimit && (
            <div className="text-xs text-gray-500">
              <span className="hidden sm:inline">Bid limit: </span>{job.bidLimit}
            </div>
          )}
        </div>
      </div>
      </div>
    </SwipeGestures>
  );
};

export default JobCard;
