import React, { useState, useMemo } from 'react';
import { Job, Application, RecruiterBid } from '../../types';
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Eye, 
  Calendar,
  DollarSign,
  Clock,
  Target,
  Filter
} from 'lucide-react';

interface JobAnalyticsProps {
  jobs: Job[];
  applications: Application[];
  recruiterBids: RecruiterBid[];
}

const JobAnalytics: React.FC<JobAnalyticsProps> = ({ jobs, applications, recruiterBids }) => {
  const [selectedTimeframe, setSelectedTimeframe] = useState('30');
  const [selectedJobId, setSelectedJobId] = useState<string>('all');

  const timeframes = [
    { value: '7', label: 'Last 7 days' },
    { value: '30', label: 'Last 30 days' },
    { value: '90', label: 'Last 90 days' },
    { value: 'all', label: 'All time' },
  ];

  const filteredData = useMemo(() => {
    const now = new Date();
    const timeframeDays = selectedTimeframe === 'all' ? Infinity : parseInt(selectedTimeframe);
    const cutoffDate = new Date(now.getTime() - timeframeDays * 24 * 60 * 60 * 1000);

    const filteredJobs = jobs.filter(job => 
      (selectedJobId === 'all' || job.id === selectedJobId) &&
      (selectedTimeframe === 'all' || job.createdAt >= cutoffDate)
    );

    const filteredApplications = applications.filter(app =>
      (selectedJobId === 'all' || app.jobId === selectedJobId) &&
      (selectedTimeframe === 'all' || app.createdAt >= cutoffDate)
    );

    const filteredBids = recruiterBids.filter(bid =>
      (selectedJobId === 'all' || bid.jobId === selectedJobId) &&
      (selectedTimeframe === 'all' || bid.createdAt >= cutoffDate)
    );

    return { jobs: filteredJobs, applications: filteredApplications, bids: filteredBids };
  }, [jobs, applications, recruiterBids, selectedTimeframe, selectedJobId]);

  const analytics = useMemo(() => {
    const { jobs: filteredJobs, applications: filteredApplications, bids: filteredBids } = filteredData;

    // Basic metrics
    const totalJobs = filteredJobs.length;
    const totalApplications = filteredApplications.length;
    const totalBids = filteredBids.length;
    const avgApplicationsPerJob = totalJobs > 0 ? (totalApplications / totalJobs).toFixed(1) : '0';

    // Application status breakdown
    const applicationsByStatus = filteredApplications.reduce((acc, app) => {
      acc[app.status] = (acc[app.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Bid status breakdown
    const bidsByStatus = filteredBids.reduce((acc, bid) => {
      acc[bid.status] = (acc[bid.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Job performance
    const jobPerformance = filteredJobs.map(job => {
      const jobApplications = filteredApplications.filter(app => app.jobId === job.id);
      const jobBids = filteredBids.filter(bid => bid.jobId === job.id);
      
      return {
        id: job.id,
        title: job.title,
        applications: jobApplications.length,
        bids: jobBids.length,
        views: Math.floor(Math.random() * 500) + 50, // Mock data
        conversionRate: jobApplications.length > 0 ? ((jobApplications.length / (Math.floor(Math.random() * 500) + 50)) * 100).toFixed(1) : '0',
        adTier: job.adTier,
        status: job.status,
        createdAt: job.createdAt,
      };
    });

    // Time series data (mock for now)
    const timeSeriesData = Array.from({ length: 30 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (29 - i));
      return {
        date: date.toISOString().split('T')[0],
        applications: Math.floor(Math.random() * 10),
        views: Math.floor(Math.random() * 50) + 10,
        bids: Math.floor(Math.random() * 5),
      };
    });

    return {
      totalJobs,
      totalApplications,
      totalBids,
      avgApplicationsPerJob,
      applicationsByStatus,
      bidsByStatus,
      jobPerformance,
      timeSeriesData,
    };
  }, [filteredData]);

  const getStatusColor = (status: string) => {
    const colors = {
      submitted: 'bg-blue-100 text-blue-800',
      shortlisted: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
      hired: 'bg-purple-100 text-purple-800',
      accepted: 'bg-green-100 text-green-800',
      withdrawn: 'bg-gray-100 text-gray-800',
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Filter className="w-4 h-4 inline mr-1" />
              Job
            </label>
            <select
              value={selectedJobId}
              onChange={(e) => setSelectedJobId(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="all">All Jobs</option>
              {jobs.map(job => (
                <option key={job.id} value={job.id}>{job.title}</option>
              ))}
            </select>
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Calendar className="w-4 h-4 inline mr-1" />
              Timeframe
            </label>
            <select
              value={selectedTimeframe}
              onChange={(e) => setSelectedTimeframe(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            >
              {timeframes.map(timeframe => (
                <option key={timeframe.value} value={timeframe.value}>{timeframe.label}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-lg bg-blue-100">
              <BarChart3 className="w-6 h-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-2xl font-bold text-gray-900">{analytics.totalJobs}</h3>
              <p className="text-gray-600 text-sm">Active Jobs</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-lg bg-green-100">
              <Users className="w-6 h-6 text-green-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-2xl font-bold text-gray-900">{analytics.totalApplications}</h3>
              <p className="text-gray-600 text-sm">Total Applications</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-lg bg-purple-100">
              <Target className="w-6 h-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-2xl font-bold text-gray-900">{analytics.totalBids}</h3>
              <p className="text-gray-600 text-sm">Recruiter Bids</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-lg bg-orange-100">
              <TrendingUp className="w-6 h-6 text-orange-600" />
            </div>
            <div className="ml-4">
              <h3 className="text-2xl font-bold text-gray-900">{analytics.avgApplicationsPerJob}</h3>
              <p className="text-gray-600 text-sm">Avg Apps/Job</p>
            </div>
          </div>
        </div>
      </div>

      {/* Application Status Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Application Status</h3>
          <div className="space-y-3">
            {Object.entries(analytics.applicationsByStatus).map(([status, count]) => (
              <div key={status} className="flex justify-between items-center">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(status)}`}>
                  {status.charAt(0).toUpperCase() + status.slice(1)}
                </span>
                <span className="font-semibold text-gray-900">{count}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recruiter Bid Status</h3>
          <div className="space-y-3">
            {Object.entries(analytics.bidsByStatus).map(([status, count]) => (
              <div key={status} className="flex justify-between items-center">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(status)}`}>
                  {status.charAt(0).toUpperCase() + status.slice(1)}
                </span>
                <span className="font-semibold text-gray-900">{count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Job Performance Table */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Job Performance</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Job Title
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Applications
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Bids
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Views
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Conversion
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ad Tier
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {analytics.jobPerformance.map((job) => (
                <tr key={job.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{job.title}</div>
                    <div className="text-sm text-gray-500">
                      {job.createdAt.toLocaleDateString()}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Users className="w-4 h-4 text-gray-400 mr-1" />
                      <span className="text-sm text-gray-900">{job.applications}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Target className="w-4 h-4 text-gray-400 mr-1" />
                      <span className="text-sm text-gray-900">{job.bids}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Eye className="w-4 h-4 text-gray-400 mr-1" />
                      <span className="text-sm text-gray-900">{job.views}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-900">{job.conversionRate}%</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      job.adTier === 'premium' ? 'bg-orange-100 text-orange-800' :
                      job.adTier === 'standard' ? 'bg-purple-100 text-purple-800' :
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {job.adTier}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(job.status)}`}>
                      {job.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Performance Chart Placeholder */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Trends</h3>
        <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
          <div className="text-center">
            <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-500">Chart visualization would go here</p>
            <p className="text-sm text-gray-400">Integration with charting library needed</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobAnalytics;