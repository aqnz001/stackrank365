import React, { useState } from 'react';
import { Job } from '../../types';
import { MapPin, Clock, DollarSign, Star, StarOff, Building2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useSavedJobs } from '../../hooks/useSavedJobs';
import { useAppliedJobs } from '../../hooks/useAppliedJobs';
import { useBidEligibility } from '../../hooks/useBidEligibility';
import { getJobLifecycle } from '../../utils/jobs';
import CompanyProfileView from '../Organizations/CompanyProfileView';

interface JobListItemProps {
  job: Job;
  selected?: boolean;
  onSelect?: () => void;
  onApply?: () => void;
  compact?: boolean;
  onBid?: () => void;
}

const JobListItem: React.FC<JobListItemProps> = ({ job, selected, onSelect, onApply, compact = false, onBid }) => {
  const { user } = useAuth();
  const { canSave, isSaved, toggle } = useSavedJobs();
  const { isApplied } = useAppliedJobs();
  const { canBid, loading: bidLoading, reason, slotsLeft } = useBidEligibility(job as any) as any;
  const [showCompany, setShowCompany] = useState(false);

  const snippet = job.description?.slice(0, compact ? 120 : 180) + (job.description?.length > (compact ? 120 : 180) ? '…' : '');
  const salary = job.salaryRange ? `$${job.salaryRange.min.toLocaleString()} – $${job.salaryRange.max.toLocaleString()}` : undefined;
  const daysAgo = (() => {
    const now = Date.now();
    const then = +new Date(job.createdAt as any);
    const diff = Math.max(0, now - then);
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    if (days <= 0) return 'Today';
    if (days === 1) return '1d ago';
    if (days < 30) return `${days}d ago`;
    const months = Math.floor(days / 30);
    return months <= 1 ? '1mo ago' : `${months}mo ago`;
  })();
  const isNew = (() => {
    const days = Math.floor((Date.now() - +new Date(job.createdAt as any)) / (1000 * 60 * 60 * 24));
    return days <= 7;
  })();
  // Promoted badge removed per spec (we only show open jobs)
  const isPromoted = false;
  const life = getJobLifecycle(job);

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={onSelect}
      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onSelect?.(); } }}
      // Hover preview disabled; preview opens on click via onSelect
      aria-selected={selected}
      className={`w-full text-left bg-white border rounded-lg ${compact ? 'px-3 py-3' : 'px-4 py-4'} transition-shadow hover:shadow 
      ${selected ? 'border-gray-200 ring-2 ring-primary-500/20' : 'border-gray-200'}
      ${selected ? 'pl-3 lg:pl-4 border-l-4 border-l-primary-600' : 'pl-3 lg:pl-4 border-l-4 border-l-transparent'}`}
    >
      <div className="flex items-start justify-between">
        <div className={`min-w-0 pr-3`}>
          <div className="flex items-center gap-2 mb-1">
            {/* Promoted badge removed */}
            {isNew && (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 uppercase tracking-wide">New</span>
            )}
            {life.closingSoon && (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-orange-100 text-orange-700 uppercase tracking-wide">Closing soon</span>
            )}
          </div>
          <h3 className={`${compact ? 'text-sm md:text-base' : 'text-base md:text-lg'} font-semibold text-gray-900 ${compact ? 'line-clamp-1' : 'line-clamp-2'}`}>{job.title}</h3>
          <div className={`mt-0.5 flex flex-wrap items-center gap-x-1.5 gap-y-0.5 ${compact ? 'text-xs' : 'text-sm'} text-gray-600`}
          >
            <span className="inline-flex items-center">
              <Building2 className="w-4 h-4 mr-1" />
              {job.organizationId ? (
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); setShowCompany(true); }}
                  className="text-blue-600 hover:text-blue-700 hover:underline"
                >
                  {job.organizationName || 'Unknown Company'}
                </button>
              ) : (
                <span>{job.organizationName || 'Unknown Company'}</span>
              )}
            </span>
            <span className="opacity-50">•</span>
            <span className="inline-flex items-center"><MapPin className="w-4 h-4 mr-1" />{job.location}</span>
            {salary && (
              <>
                <span className="opacity-50">•</span>
                <span className="inline-flex items-center"><DollarSign className="w-4 h-4 mr-1" />{salary}</span>
              </>
            )}
            <span className="opacity-50">•</span>
            <span className="inline-flex items-center"><Clock className="w-4 h-4 mr-1" />{daysAgo}</span>
          </div>
          <p className={`mt-1 ${compact ? 'text-xs' : 'text-sm'} text-gray-700 ${compact ? 'line-clamp-1' : 'line-clamp-2'}`}>{snippet}</p>
          {(job.skills?.length || 0) > 0 && (
            <div className={`${compact ? 'mt-2' : 'mt-3'} flex flex-wrap gap-1.5`}>
              {[...(job.skills || [])].slice(0, compact ? 3 : 4).map((s, i) => (
                <span key={i} className={`px-2 py-0.5 rounded-full ${compact ? 'text-[11px]' : 'text-xs'} bg-gray-100 text-gray-700`}>{s}</span>
              ))}
            </div>
          )}
        </div>
        <div className="flex flex-col items-end gap-2 ml-3">
          {canSave && (
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); toggle(job); }}
              className="p-2 text-gray-500 hover:text-gray-700"
              aria-label={isSaved(job.id) ? 'Unsave job' : 'Save job'}
            >
              {isSaved(job.id) ? <Star className="w-5 h-5 text-yellow-500" /> : <StarOff className="w-5 h-5" />}
            </button>
          )}
          {/* Visibility pill removed (we already filter open jobs) */}
        </div>
      </div>

      <div className={`${compact ? 'mt-2' : 'mt-3'} flex items-center gap-2.5`}>
        <span className={`capitalize inline-flex items-center ${compact ? 'text-[11px]' : 'text-xs'} px-2 py-1 rounded-full bg-gray-100 text-gray-700`}>{(job.employmentType || '').replace('-', ' ')}</span>
        {((!user) || (user?.role === 'candidate' && !isApplied(job.id))) && onApply && (
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); onApply(); }}
            className={`ml-auto inline-flex items-center ${compact ? 'text-xs px-2.5 py-1.5' : 'text-sm px-3 py-1.5'} rounded-md bg-blue-600 text-white hover:bg-blue-700`}
          >
            Apply
          </button>
        )}
        {user?.role === 'candidate' && isApplied(job.id) && (
          <span className={`ml-auto inline-flex items-center ${compact ? 'text-[11px] px-2 py-1' : 'text-xs px-2.5 py-1.5'} rounded-md bg-green-100 text-green-700`}>Applied</span>
        )}
        {user?.role === 'recruiter' && job.visibility === 'open' && (
          reason === 'Bid capacity reached' ? (
            <span className={`ml-auto inline-flex items-center ${compact ? 'text-[11px] px-2 py-1' : 'text-xs px-2.5 py-1.5'} rounded-md bg-red-100 text-red-700`}>Full</span>
          ) : (
            <div className="ml-auto flex items-center gap-2">
              <span className={`px-2 py-0.5 rounded-full ${compact ? 'text-[11px]' : 'text-xs'} ${
                bidLoading ? 'bg-gray-100 text-gray-700' : (
                  Number.isFinite(slotsLeft) ? (slotsLeft > 0 ? 'bg-blue-100 text-blue-800' : 'bg-red-100 text-red-800') : 'bg-green-100 text-green-800'
                )
              }`}>
                {bidLoading ? 'Checking…' : (Number.isFinite(slotsLeft) ? (slotsLeft > 0 ? `Slots: ${slotsLeft}` : 'Full') : 'Open')}
              </span>
              <button
                type="button"
                title={!canBid && !bidLoading ? reason : ''}
                onClick={(e) => { e.stopPropagation(); console.log('[BidCTA] JobListItem click', { jobId: job.id, title: job.title }); onBid?.(); }}
                className={`inline-flex items-center ${compact ? 'text-xs px-2.5 py-1.5' : 'text-sm px-3 py-1.5'} rounded-md disabled:opacity-50 ${
                  bidLoading ? 'bg-gray-100 text-gray-700' : (canBid ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100')
                }`}
                disabled={bidLoading || !canBid}
              >
                Bid for this Job
              </button>
            </div>
          )
        )}
      </div>

      {showCompany && job.organizationId && (
        <CompanyProfileView
          orgId={job.organizationId}
          isOpen={showCompany}
          onClose={() => setShowCompany(false)}
          onViewAllJobs={() => {
            setShowCompany(false);
            window.location.href = `/#/?employer=${encodeURIComponent(job.organizationName || '')}&employerId=${job.organizationId}`;
          }}
          onJobClick={(jobId) => {
            setShowCompany(false);
            if (onSelect) {
              onSelect();
            }
          }}
        />
      )}
    </div>
  );
};

export default JobListItem;
