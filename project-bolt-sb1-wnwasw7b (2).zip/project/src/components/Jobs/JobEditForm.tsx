import React, { useState } from 'react';
import { useJobs } from '../../hooks/useJobs';
import { useSubscriptions } from '../../hooks/useSubscriptions';
import { pricingTiers } from '../../data/mockData';
import { supabase } from '../../lib/supabase';
import { X, Briefcase, MapPin, DollarSign, Eye, EyeOff } from 'lucide-react';
import PaymentForm from '../Payments/PaymentForm';
import AIJobAssistant from './AIJobAssistant';
import type { Job } from '../../types';

interface JobEditFormProps {
  job: Job;
  onClose: () => void;
  onSave: () => void;
}

const JobEditForm: React.FC<JobEditFormProps> = ({ job, onClose, onSave }) => {
  const { updateJob } = useJobs();
  const { currentSubscription, trackUsage } = useSubscriptions();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState<number>(0); // 0: details, 1: pricing & visibility
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [paymentRequested, setPaymentRequested] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [pendingUpdate, setPendingUpdate] = useState<Partial<Job> | null>(null);
  const [companyDescription, setCompanyDescription] = useState<string>('');

  // Keep step navigation passive — never auto-open payment when changing steps
  React.useEffect(() => {
    if (showPaymentForm) setShowPaymentForm(false);
    if (pendingUpdate) setPendingUpdate(null);
    if (paymentRequested) setPaymentRequested(false);
    // reset any staged payment when switching steps to avoid accidental popups
  }, [currentStep]);

  // Load company description from organization profile
  React.useEffect(() => {
    const loadOrgProfile = async () => {
      try {
        if (!job.organizationId) return;
        const { data } = await supabase
          .from('organizations')
          .select('about')
          .eq('id', job.organizationId)
          .maybeSingle();
        if (data && (data as any)?.about) {
          setCompanyDescription((data as any).about);
        }
      } catch {}
    };
    loadOrgProfile();
  }, [job.organizationId]);
  const deriveWorkplace = () => {
    const loc = (job.location || '').toLowerCase();
    if (loc.includes('remote')) return 'remote';
    if (loc.includes('hybrid')) return 'hybrid';
    return 'onsite';
  };
  const [formData, setFormData] = useState({
    title: job.title,
    description: job.description,
    location: job.location,
    employmentType: job.employmentType,
    workplace: deriveWorkplace() as 'onsite' | 'remote' | 'hybrid',
    salaryMin: job.salaryRange?.min?.toString() || '',
    salaryMax: job.salaryRange?.max?.toString() || '',
    desiredSkills: job.skills.length ? job.skills.map(s => `• ${s}`).join('\n') : '',
    skills: job.skills.join(', '),
    benefits: (job.benefits || []).join('\n'),
    experienceLevel: job.experienceLevel || '',
    industry: job.industry || [],
    visibility: job.visibility,
    adTier: job.adTier,
    status: job.status,
  });

  const [selectedTier, setSelectedTier] = useState(
    pricingTiers.find(t => t.name === job.adTier) || pricingTiers[0]
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      // Compose location with workplace hint for search
      let locationValue = formData.location;
      const lower = locationValue.toLowerCase();
      if (formData.workplace === 'remote' && !lower.includes('remote')) {
        locationValue = `${locationValue}${locationValue ? ' ' : ''}Remote`;
      } else if (formData.workplace === 'hybrid' && !lower.includes('hybrid')) {
        locationValue = `${locationValue}${locationValue ? ' ' : ''}Hybrid`;
      }
      const jobData: Partial<Job> = {
        title: formData.title,
        description: formData.description,
        location: locationValue,
        employmentType: formData.employmentType as any,
        salaryRange: formData.salaryMin && formData.salaryMax ? {
          min: parseInt(formData.salaryMin),
          max: parseInt(formData.salaryMax)
        } : undefined,
        skills: (formData.desiredSkills
          ? formData.desiredSkills.split('\n').map(s => s.replace(/^•\s*/,'').trim())
          : formData.skills.split(',')
        ).map(s => s.trim()).filter(Boolean),
        experienceLevel: formData.experienceLevel as any,
        industry: (formData.industry || []).map(i => i.trim()).filter(Boolean),
        benefits: formData.benefits ? formData.benefits.split('\n').map(b => b.trim()).filter(Boolean) : undefined,
        visibility: formData.visibility as any,
        adTier: formData.adTier as any,
        status: formData.status as any,
        bidLimit: selectedTier.bidLimit,
      };

      // Determine pricing logic
      const oldTier = pricingTiers.find(t => t.name === job.adTier)!;
      const newTier = pricingTiers.find(t => t.name === (jobData.adTier || job.adTier))!;
      const diff = Math.max(0, (newTier?.price || 0) - (oldTier?.price || 0));

      if (job.status === 'on_hold' || job.status === 'draft') {
        // Draft: require full payment if no subscription
        if (currentSubscription) {
          await updateJob(job.id, { ...jobData, status: 'open' });
          onSave();
          onClose();
        } else {
          setPaymentAmount((newTier?.price || 0) * 100);
          setPendingUpdate({ ...jobData, status: 'open' });
          setPaymentRequested(true);
          setShowPaymentForm(true);
        }
      } else {
        // Published: upgrades require paying the difference
        if (diff > 0) {
          setPaymentAmount(diff * 100);
          setPendingUpdate(jobData);
          setPaymentRequested(true);
          setShowPaymentForm(true);
        } else {
          await updateJob(job.id, jobData);
          onSave();
          onClose();
        }
      }
    } catch (err) {
      console.error('Error updating job:', err);
      setError(err instanceof Error ? err.message : 'Failed to update job');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleTierChange = (tierName: string) => {
    const tier = pricingTiers.find(t => t.name === tierName);
    if (tier) {
      setSelectedTier(tier);
      setFormData(prev => ({ ...prev, adTier: tierName }));
      
      // If selecting basic tier, force visibility to closed
      if (tierName === 'basic') {
        setFormData(prev => ({ ...prev, visibility: 'closed' }));
      }
    }
  };

  const employmentTypes = [
    { value: 'full-time', label: 'Full-time' },
    { value: 'part-time', label: 'Part-time' },
    { value: 'contract', label: 'Contract' },
    { value: 'temporary', label: 'Temporary' },
  ];
  const industriesList = ['Information Technology and Services','Healthcare and Social Assistance','Professional Services','Education and Training','Manufacturing','Construction','Retail Trade','Transport and Logistics','Finance and Insurance','Government and Public Administration','Media and Communications','Real Estate','Hospitality','Agriculture','Energy','Other'];
  const expOptions = [
    { value: '', label: 'Any' },
    { value: 'entry', label: 'Entry' },
    { value: 'mid', label: 'Mid' },
    { value: 'senior', label: 'Senior' },
    { value: 'lead', label: 'Lead' },
  ];

  const statusOptions = [
    { value: 'open', label: 'Open' },
    { value: 'closed', label: 'Closed' },
    { value: 'on_hold', label: 'On Hold' },
    { value: 'filled', label: 'Filled' },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gray-700 text-white px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold">Edit Job Posting</h2>
          <button onClick={onClose} className="text-white hover:text-gray-300 transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="overflow-y-auto max-h-[calc(90vh-80px)] text-gray-900">
          <div className="p-6 space-y-8">
            {/* Step indicator */}
            <div className="flex items-center justify-center gap-4">
              <div className={`flex items-center ${currentStep === 0 ? 'text-blue-600' : 'text-gray-400'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep === 0 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>
                  1
                </div>
                <span className="ml-2 font-medium">Job Details</span>
              </div>
              <div className="w-16 h-0.5 bg-gray-300"></div>
              <div className={`flex items-center ${currentStep === 1 ? 'text-blue-600' : 'text-gray-400'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep === 1 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>
                  2
                </div>
                <span className="ml-2 font-medium">Pricing & Visibility</span>
              </div>
            </div>
          {/* AI Assistant: only on Details (step 1) */}
          {currentStep === 0 && (
            <AIJobAssistant
              jobTitle={formData.title}
              company={job.organizationName}
              industry={(formData.industry[0] as string) || ''}
              currentDescription={formData.description}
              currentSkills={formData.desiredSkills}
              companyDescription={companyDescription}
              onApplyDescription={(d) => setFormData(prev => ({ ...prev, description: d }))}
              onApplySkills={(s) => setFormData(prev => ({ ...prev, desiredSkills: s }))}
              onApplyBoth={(d, s) => setFormData(prev => ({ ...prev, description: d, desiredSkills: s }))}
            />
          )}

          {currentStep === 0 && (
          <div className="space-y-8">
            {/* Job Title */}
            <div>
              <div className="flex items-center mb-3">
                <div className="w-8 h-8 bg-gray-600 rounded flex items-center justify-center mr-3">
                  <Briefcase className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Job Title</h3>
              </div>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="e.g., Senior Frontend Developer"
              />
            </div>

            {/* Work Environment */}
            <div>
              <div className="flex items-center mb-6">
                <div className="w-8 h-8 bg-gray-600 rounded flex items-center justify-center mr-3">
                  <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20"><path d="M4 4a2 2 0 00-2 2v8a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2H4zm2 6a2 2 0 114 0 2 2 0 01-4 0zm8-1a1 1 0 100 2 1 1 0 000-2z"/></svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Work Environment</h3>
              </div>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Company</label>
                  <input type="text" value={job.organizationName} disabled className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-100" />
                  <p className="text-xs text-gray-500 mt-1">Company is linked to the job's organization.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Experience Level</label>
                    <select
                      value={formData.experienceLevel}
                      onChange={(e) => setFormData(prev => ({ ...prev, experienceLevel: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      {expOptions.map(o => (<option key={o.value} value={o.value}>{o.label}</option>))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <MapPin className="w-4 h-4 inline mr-1" />
                      Location
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.location}
                      onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="e.g., San Francisco, CA or Remote"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Employment Type
                    </label>
                    <select
                      value={formData.employmentType}
                      onChange={(e) => setFormData(prev => ({ ...prev, employmentType: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      {employmentTypes.map(type => (
                        <option key={type.value} value={type.value}>{type.label}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Workplace</label>
                    <select
                      value={formData.workplace}
                      onChange={(e) => setFormData(prev => ({ ...prev, workplace: e.target.value as any }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="onsite">On-site</option>
                      <option value="remote">Work from home</option>
                      <option value="hybrid">Flexible / hybrid</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Job Status
                    </label>
                    <select
                      value={formData.status}
                      onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      {statusOptions.map(status => (
                        <option key={status.value} value={status.value}>{status.label}</option>
                      ))}
                    </select>
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <DollarSign className="w-4 h-4 inline mr-1" />
                      Salary Range (Optional)
                    </label>
                    <div className="grid grid-cols-2 gap-4">
                      <input
                        type="number"
                        value={formData.salaryMin}
                        onChange={(e) => setFormData(prev => ({ ...prev, salaryMin: e.target.value }))}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Minimum salary"
                      />
                      <input
                        type="number"
                        value={formData.salaryMax}
                        onChange={(e) => setFormData(prev => ({ ...prev, salaryMax: e.target.value }))}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Maximum salary"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Job Description Section */}
            <div>
              <div className="flex items-center mb-3">
                <div className="w-8 h-8 bg-gray-600 rounded flex items-center justify-center mr-3">
                  <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z" clipRule="evenodd" /></svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Job Description</h3>
              </div>
              <textarea
                rows={6}
                required
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Describe the role, responsibilities, and requirements..."
              />
            </div>

            {/* Skills Section */}
            <div>
              <div className="flex items-center mb-3">
                <div className="w-8 h-8 bg-gray-600 rounded flex items-center justify-center mr-3">
                  <Users className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Desired Skills</h3>
              </div>
              <textarea
                rows={4}
                value={formData.desiredSkills}
                onChange={(e) => setFormData(prev => ({ ...prev, desiredSkills: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="One per line, or paste bullets (•)"
              />
            </div>

            {/* Industry multi-select tokens */}
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Industry</label>
              <div className="flex flex-wrap gap-2">
                {industriesList.map(ind => (
                  <button
                    key={ind}
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, industry: prev.industry.includes(ind) ? prev.industry.filter(i => i !== ind) : [...prev.industry, ind] }))}
                    className={`px-3 py-1 rounded-full text-sm border ${formData.industry.includes(ind) ? 'bg-blue-600 text-white border-blue-600' : 'text-gray-700 hover:bg-gray-50'}`}
                  >
                    {ind}
                  </button>
                ))}
              </div>
            </div>

            {/* Benefits multiline */}
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Benefits</label>
              <textarea
                rows={3}
                value={formData.benefits}
                onChange={(e) => setFormData(prev => ({ ...prev, benefits: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder={"One per line"}
              />
            </div>
          </div>
          )}

          {currentStep === 1 && (
            <>
              <div>
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Ad Tier</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {pricingTiers.map(tier => (
                    <div
                      key={tier.name}
                      className={`relative p-4 border-2 rounded-lg cursor-pointer transition-all ${
                        selectedTier.name === tier.name
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => handleTierChange(tier.name)}
                    >
                      <div className="text-center">
                        <h5 className="font-semibold text-gray-900 capitalize">{tier.name}</h5>
                        <div className="text-2xl font-bold text-blue-600 my-2">${tier.price}</div>
                        <p className="text-sm text-gray-600 mb-3">{tier.description}</p>
                        <ul className="text-xs text-gray-500 space-y-1">
                          {tier.features.map((feature, index) => (
                            <li key={index}>• {feature}</li>
                          ))}
                        </ul>
                      </div>
                      {selectedTier.name === tier.name && (
                        <div className="absolute top-2 right-2 w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                          <div className="w-2 h-2 bg-white rounded-full"></div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {selectedTier.name !== 'basic' && (
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Job Visibility</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <label className="cursor-pointer">
                  <input
                    type="radio"
                    name="visibility"
                    value="closed"
                    checked={formData.visibility === 'closed'}
                    onChange={(e) => setFormData(prev => ({ ...prev, visibility: e.target.value }))}
                    className="sr-only"
                  />
                  <div className={`p-4 border-2 rounded-lg ${
                    formData.visibility === 'closed'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}>
                    <div className="flex items-center mb-2">
                      <EyeOff className="w-5 h-5 mr-2 text-gray-600" />
                      <span className="font-medium">Closed to Recruiters</span>
                    </div>
                    <p className="text-sm text-gray-600">Only direct candidate applications</p>
                  </div>
                </label>

                <label className="cursor-pointer">
                  <input
                    type="radio"
                    name="visibility"
                    value="open"
                    checked={formData.visibility === 'open'}
                    onChange={(e) => setFormData(prev => ({ ...prev, visibility: e.target.value }))}
                    className="sr-only"
                  />
                  <div className={`p-4 border-2 rounded-lg ${
                    formData.visibility === 'open'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}>
                    <div className="flex items-center mb-2">
                      <Eye className="w-5 h-5 mr-2 text-green-600" />
                      <span className="font-medium">Open to Recruiters</span>
                    </div>
                    <p className="text-sm text-gray-600">
                      Direct applications + recruiter bids
                      {selectedTier.bidLimit && ` (up to ${selectedTier.bidLimit} bids)`}
                    </p>
                  </div>
                </label>
              </div>
                </div>
              )}
            </>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-800">{error}</p>
            </div>
          )}

          </div>

          {/* Footer */}
          <div className="bg-gray-50 px-6 py-4 border-t border-gray-200 flex justify-between items-center sticky bottom-0">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2.5 border-2 border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 font-medium transition-colors"
            >
              Cancel
            </button>
            <div className="flex items-center gap-3">
              {currentStep > 0 && (
                <button
                  type="button"
                  onClick={()=> setCurrentStep(s=>Math.max(0,s-1))}
                  className="px-6 py-2.5 text-gray-700 bg-white border-2 border-gray-300 rounded-lg hover:bg-gray-50 font-medium transition-colors"
                >
                  Previous
                </button>
              )}
              {currentStep === 0 ? (
                <button
                  type="button"
                  onClick={()=> setCurrentStep(1)}
                  disabled={!formData.title || !formData.location}
                  className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium transition-colors"
                >
                  Continue
                </button>
              ) : (
                (()=>{
                  const oldTier = pricingTiers.find(t=>t.name===job.adTier)!;
                  const newTier = pricingTiers.find(t=>t.name===selectedTier.name)!;
                  const diff = Math.max(0, newTier.price - oldTier.price);
                  const isDraft = job.status === 'on_hold' || job.status === 'draft';
                  const label = isDraft ? (currentSubscription ? 'Post Job' : `Post Job & Pay $${newTier.price}`) : (diff>0 ? `Upgrade & Pay $${diff}` : 'Save Changes');
                  return (
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed font-medium transition-colors"
                    >
                      {isSubmitting ? 'Saving...' : label}
                    </button>
                  );
                })()
              )}
            </div>
          </div>
        </form>
        {showPaymentForm && paymentRequested && pendingUpdate && (
          <PaymentForm
            amount={paymentAmount}
            description={(job.status==='on_hold' || job.status==='draft') ? `Publish job: ${formData.title} (${selectedTier.name} tier)` : `Upgrade job: ${formData.title} to ${selectedTier.name}`}
            onSuccess={async (pi:any) => {
              try {
                await updateJob(job.id, pendingUpdate);
                try {
                  await trackUsage({
                    usageType: (job.status==='on_hold' || job.status==='draft') ? 'one_time_job_posts' : 'one_time_job_upgrade',
                    quantity: 1,
                    unitPrice: paymentAmount,
                    metadata: { job_id: job.id, job_title: formData.title, new_tier: selectedTier.name, payment_intent_id: pi.id },
                  });
                } catch (uerr) { console.error('Usage tracking failed:', uerr); }
                setShowPaymentForm(false);
                onSave();
                onClose();
              } catch (err) {
                console.error('Update after payment failed:', err);
                setError('Payment successful but failed to update job. Please contact support.');
                setShowPaymentForm(false);
              }
            }}
            onError={(msg:string)=>{ setError(msg); setShowPaymentForm(false); }}
            onClose={()=> setShowPaymentForm(false)}
          />
        )}
      </div>
    </div>
  );
};

export default JobEditForm;
