import React from 'react';
import { Job } from '../../types';
import { X, MapPin, DollarSign, Briefcase, Calendar, Building } from 'lucide-react';

interface JobDetailsProps {
  job: Job;
  onClose: () => void;
  onApply?: () => void;
}

const JobDetails: React.FC<JobDetailsProps> = ({ job, onClose, onApply }) => {
  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="relative w-full max-w-3xl bg-white rounded-xl shadow-2xl overflow-hidden">
          <button
            onClick={onClose}
            className="absolute top-3 right-3 p-2 text-gray-500 hover:text-gray-700"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="max-h-[85vh] overflow-y-auto">
            <div className="p-6 border-b">
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-2xl font-semibold text-gray-900">{job.title}</h2>
                  <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-gray-600">
                    <span className="inline-flex items-center"><Building className="w-4 h-4 mr-1" />{job.organizationName}</span>
                    <span className="inline-flex items-center"><MapPin className="w-4 h-4 mr-1" />{job.location}</span>
                    {job.employmentType && (
                      <span className="inline-flex items-center"><Briefcase className="w-4 h-4 mr-1" />{job.employmentType}</span>
                    )}
                    <span className="inline-flex items-center"><Calendar className="w-4 h-4 mr-1" />{new Date(job.createdAt as any).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
              {job.salaryRange && (
                <div className="mt-3 inline-flex items-center px-3 py-1 rounded-full text-sm bg-gray-100 text-gray-700">
                  <DollarSign className="w-4 h-4 mr-1" />
                  {job.salaryRange.min.toLocaleString()} - {job.salaryRange.max.toLocaleString()}
                </div>
              )}
            </div>

            <div className="p-6 space-y-6">
              <section>
                <h3 className="text-sm font-semibold text-gray-900 mb-2">Job Description</h3>
                <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">{job.description}</p>
              </section>

              {job.skills?.length ? (
                <section>
                  <h3 className="text-sm font-semibold text-gray-900 mb-2">Key Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {job.skills.map((s, i) => (
                      <span key={i} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">{s}</span>
                    ))}
                  </div>
                </section>
              ) : null}

              {job.benefits?.length ? (
                <section>
                  <h3 className="text-sm font-semibold text-gray-900 mb-2">Benefits</h3>
                  <ul className="list-disc list-inside text-gray-700 space-y-1">
                    {job.benefits.map((b, i) => (<li key={i}>{b}</li>))}
                  </ul>
                </section>
              ) : null}
            </div>

            <div className="p-6 border-t bg-gray-50 flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
              <div className="text-xs text-gray-500">Ad tier: {job.adTier} • Visibility: {job.visibility}</div>
              {onApply && (
                <button
                  onClick={onApply}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Apply Now
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobDetails;

