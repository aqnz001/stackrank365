import React, { useState } from 'react';
import { Filter, X, MapPin, Briefcase, DollarSign, Clock } from 'lucide-react';

interface JobFiltersProps {
  onFiltersChange: (filters: JobFilters) => void;
  isOpen: boolean;
  onClose: () => void;
}

export interface JobFilters {
  location: string;
  employmentType: string[];
  salaryMin: string;
  salaryMax: string;
  skills: string[];
  adTier: string[];
  visibility: string[];
  status: string[];
}

const JobFilters: React.FC<JobFiltersProps> = ({ onFiltersChange, isOpen, onClose }) => {
  const [filters, setFilters] = useState<JobFilters>({
    location: '',
    employmentType: [],
    salaryMin: '',
    salaryMax: '',
    skills: [],
    adTier: [],
    visibility: [],
    status: [],
  });

  const [skillInput, setSkillInput] = useState('');

  const employmentTypes = [
    { value: 'full-time', label: 'Full-time' },
    { value: 'part-time', label: 'Part-time' },
    { value: 'contract', label: 'Contract' },
    { value: 'temporary', label: 'Temporary' },
  ];

  const adTiers = [
    { value: 'basic', label: 'Basic' },
    { value: 'standard', label: 'Standard' },
    { value: 'premium', label: 'Premium' },
  ];

  const visibilityOptions = [
    { value: 'open', label: 'Open to Recruiters' },
    { value: 'closed', label: 'Direct Only' },
  ];

  const statusOptions = [
    { value: 'open', label: 'Open' },
    { value: 'draft', label: 'Draft' },
    { value: 'on_hold', label: 'On Hold' },
    { value: 'filled', label: 'Filled' },
    { value: 'closed', label: 'Closed' },
  ];

  const handleCheckboxChange = (category: keyof JobFilters, value: string) => {
    setFilters(prev => {
      const currentArray = prev[category] as string[];
      const newArray = currentArray.includes(value)
        ? currentArray.filter(item => item !== value)
        : [...currentArray, value];
      
      const newFilters = { ...prev, [category]: newArray };
      onFiltersChange(newFilters);
      return newFilters;
    });
  };

  const handleInputChange = (field: keyof JobFilters, value: string) => {
    setFilters(prev => {
      const newFilters = { ...prev, [field]: value };
      onFiltersChange(newFilters);
      return newFilters;
    });
  };

  const addSkill = () => {
    if (skillInput.trim() && !filters.skills.includes(skillInput.trim())) {
      const newSkills = [...filters.skills, skillInput.trim()];
      setFilters(prev => ({ ...prev, skills: newSkills }));
      onFiltersChange({ ...filters, skills: newSkills });
      setSkillInput('');
    }
  };

  const removeSkill = (skill: string) => {
    const newSkills = filters.skills.filter(s => s !== skill);
    setFilters(prev => ({ ...prev, skills: newSkills }));
    onFiltersChange({ ...filters, skills: newSkills });
  };

  const clearAllFilters = () => {
    const emptyFilters: JobFilters = {
      location: '',
      employmentType: [],
      salaryMin: '',
      salaryMax: '',
      skills: [],
      adTier: [],
      visibility: [],
      status: [],
    };
    setFilters(emptyFilters);
    setSkillInput('');
    onFiltersChange(emptyFilters);
  };

  const getActiveFilterCount = () => {
    let count = 0;
    if (filters.location) count++;
    if (filters.employmentType.length) count++;
    if (filters.salaryMin || filters.salaryMax) count++;
    if (filters.skills.length) count++;
    if (filters.adTier.length) count++;
    if (filters.visibility.length) count++;
    if (filters.status.length) count++;
    return count;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center">
            <Filter className="w-6 h-6 text-gray-600 mr-2" />
            <h3 className="text-2xl font-bold text-gray-900">Filter Jobs</h3>
            {getActiveFilterCount() > 0 && (
              <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-800 text-sm rounded-full">
                {getActiveFilterCount()} active
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 p-2"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="space-y-6">
          {/* Location */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <MapPin className="w-4 h-4 inline mr-1" />
              Location
            </label>
            <input
              type="text"
              value={filters.location}
              onChange={(e) => handleInputChange('location', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              placeholder="e.g., San Francisco, Remote"
            />
          </div>

          {/* Employment Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              <Briefcase className="w-4 h-4 inline mr-1" />
              Employment Type
            </label>
            <div className="grid grid-cols-2 gap-2">
              {employmentTypes.map(type => (
                <label key={type.value} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.employmentType.includes(type.value)}
                    onChange={() => handleCheckboxChange('employmentType', type.value)}
                    className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                  />
                  <span className="ml-2 text-sm text-gray-700">{type.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Salary Range */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <DollarSign className="w-4 h-4 inline mr-1" />
              Salary Range
            </label>
            <div className="grid grid-cols-2 gap-4">
              <input
                type="number"
                value={filters.salaryMin}
                onChange={(e) => handleInputChange('salaryMin', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="Min salary"
              />
              <input
                type="number"
                value={filters.salaryMax}
                onChange={(e) => handleInputChange('salaryMax', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="Max salary"
              />
            </div>
          </div>

          {/* Skills */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Skills
            </label>
            <div className="flex space-x-2 mb-2">
              <input
                type="text"
                value={skillInput}
                onChange={(e) => setSkillInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="Add a skill..."
              />
              <button
                type="button"
                onClick={addSkill}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                Add
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {filters.skills.map(skill => (
                <span
                  key={skill}
                  className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-800"
                >
                  {skill}
                  <button
                    type="button"
                    onClick={() => removeSkill(skill)}
                    className="ml-2 text-blue-600 hover:text-blue-800"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* Ad Tier */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Ad Tier
            </label>
            <div className="grid grid-cols-3 gap-2">
              {adTiers.map(tier => (
                <label key={tier.value} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.adTier.includes(tier.value)}
                    onChange={() => handleCheckboxChange('adTier', tier.value)}
                    className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                  />
                  <span className="ml-2 text-sm text-gray-700">{tier.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Visibility */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Visibility
            </label>
            <div className="grid grid-cols-2 gap-2">
              {visibilityOptions.map(option => (
                <label key={option.value} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.visibility.includes(option.value)}
                    onChange={() => handleCheckboxChange('visibility', option.value)}
                    className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                  />
                  <span className="ml-2 text-sm text-gray-700">{option.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Status */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              <Clock className="w-4 h-4 inline mr-1" />
              Status
            </label>
            <div className="grid grid-cols-2 gap-2">
              {statusOptions.map(status => (
                <label key={status.value} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.status.includes(status.value)}
                    onChange={() => handleCheckboxChange('status', status.value)}
                    className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                  />
                  <span className="ml-2 text-sm text-gray-700">{status.label}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        <div className="flex justify-between items-center pt-6 border-t mt-6">
          <button
            type="button"
            onClick={clearAllFilters}
            className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            Clear All Filters
          </button>
          <div className="flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              Apply Filters
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobFilters;

export { JobFilters }
