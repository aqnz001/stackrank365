import React from 'react';
import { Job } from '../../types';
import { X, MapPin, DollarSign, Briefcase, Calendar, Building2, Eye, EyeOff, Tag, ExternalLink } from 'lucide-react';
import CompanyProfileView from '../Organizations/CompanyProfileView';

interface JobPreviewPanelProps {
  job?: Job | null;
  onClose?: () => void;
  onApply?: (job: Job) => void;
  onBid?: (job: Job) => void;
}

import { useAuth } from '../../context/AuthContext';
import { useSavedJobs } from '../../hooks/useSavedJobs';
import { useAppliedJobs } from '../../hooks/useAppliedJobs';
import { useBidEligibility } from '../../hooks/useBidEligibility';
import { getJobLifecycle } from '../../utils/jobs';

const JobPreviewPanel: React.FC<JobPreviewPanelProps> = ({ job, onClose, onApply, onBid }) => {
  // Hooks must be called unconditionally, before any early returns
  const { user } = useAuth();
  const { canSave, isSaved, toggle } = useSavedJobs();
  const { isApplied } = useAppliedJobs();
  const { canBid, reason, slotsLeft, loading } = useBidEligibility(job as any) as any;
  const life = job ? getJobLifecycle(job) : ({ isOpen: true, closingSoon: false } as any);

  const [showCompany, setShowCompany] = React.useState(false);

  if (!job) {
    return (
      <div className="bg-white border border-gray-200 rounded-lg p-6 text-sm text-gray-600">
        Select a job to preview details here.
      </div>
    );
  }
  const postedLabel = (() => {
    const then = +new Date(job.createdAt as any);
    const days = Math.floor((Date.now() - then) / (1000 * 60 * 60 * 24));
    if (days <= 0) return 'Today';
    if (days === 1) return '1 day ago';
    if (days < 30) return `${days} days ago`;
    const months = Math.floor(days / 30);
    return months <= 1 ? '1 month ago' : `${months} months ago`;
  })();


  return (
    <div className="bg-white h-full flex flex-col overflow-hidden">
      <div className="flex items-center justify-between px-5 py-3 border-b bg-white z-10 flex-shrink-0">
        <div className="flex items-center gap-2">
          <h3 className="text-sm font-semibold text-gray-900">Job preview</h3>
        </div>
        <div className="flex items-center gap-2">
          {canSave && (
            <button onClick={() => toggle(job)} className="px-3 py-2 rounded-md border border-gray-300 text-gray-700 hover:bg-gray-50">
              {isSaved(job.id) ? 'Saved' : 'Save'}
            </button>
          )}
          {user?.role === 'candidate' && onApply && !isApplied(job.id) && (
            <button onClick={() => onApply(job)} className="px-3 py-2 rounded-md bg-primary-600 text-white hover:bg-primary-700">Quick apply</button>
          )}
          {user?.role === 'candidate' && isApplied(job.id) && (
            <span className="px-3 py-2 rounded-md bg-green-100 text-green-700">Applied</span>
          )}
          {onClose && (
            <button onClick={onClose} className="p-2 text-gray-500 hover:text-gray-700" aria-label="Close"><X className="w-5 h-5"/></button>
          )}
        </div>
      </div>

      <div className="p-5 space-y-5 overflow-y-auto flex-1">
        {/* Title and meta */}
        <div>
          <h2 className="text-2xl font-semibold text-gray-900 leading-tight">{job.title}</h2>
          <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-gray-600">
            <span className="inline-flex items-center">
              <Building2 className="w-4 h-4 mr-1" />
              {job.organizationId ? (
                <button
                  type="button"
                  onClick={() => setShowCompany(true)}
                  className="text-blue-600 hover:text-blue-700 hover:underline"
                >
                  {job.organizationName || 'Unknown Company'}
                </button>
              ) : (
                <span>{job.organizationName || 'Unknown Company'}</span>
              )}
            </span>
            <span className="inline-flex items-center"><MapPin className="w-4 h-4 mr-1" />{job.location}</span>
            {job.employmentType && (<span className="inline-flex items-center"><Briefcase className="w-4 h-4 mr-1" />{job.employmentType.replace('-', ' ')}</span>)}
            <span className="inline-flex items-center"><Calendar className="w-4 h-4 mr-1" />Posted {postedLabel}</span>
            {life?.closingSoon && (<span className="inline-flex items-center px-2 py-0.5 rounded bg-orange-100 text-orange-700">Closing soon</span>)}
            <span className="inline-flex items-center"><Tag className="w-4 h-4 mr-1" />{job.adTier.charAt(0).toUpperCase() + job.adTier.slice(1)}</span>
          </div>
          {job.salaryRange && (
            <div className="mt-2 inline-flex items-center px-2.5 py-1 rounded-full text-xs bg-gray-100 text-gray-700">
              <DollarSign className="w-4 h-4 mr-1" />
              {job.salaryRange.min.toLocaleString()} – {job.salaryRange.max.toLocaleString()}
            </div>
          )}
        </div>

        {/* Full description, structured */}
        <div>
          <h4 className="text-sm font-semibold text-gray-900 mb-1.5">About the role</h4>
          <StructuredDescription text={job.description} />
        </div>

        {/* Company Information */}
        <div>
          <h4 className="text-sm font-semibold text-gray-900 mb-1.5">About {job.organizationName}</h4>
          <div className="space-y-2">
            {job.organizationSize && (
              <div className="flex items-center text-sm text-gray-700">
                <span className="w-2 h-2 bg-blue-500 rounded-full mr-2" />
                {job.organizationSize === 'startup' && 'Startup (1-50 employees)'}
                {job.organizationSize === 'small' && 'Small company (51-200 employees)'}
                {job.organizationSize === 'medium' && 'Medium company (201-1000 employees)'}
                {job.organizationSize === 'large' && 'Large company (1000+ employees)'}
              </div>
            )}
            {job.industry && job.industry.length > 0 && (
              <div className="flex items-center text-sm text-gray-700">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-2" />
                {job.industry.join(', ')}
              </div>
            )}
            <div className="flex items-center text-sm text-gray-700">
              <span className="w-2 h-2 bg-purple-500 rounded-full mr-2" />
              Established company with strong market presence
            </div>
          </div>
        </div>

        {/* Skills */}
        {(job.skills && job.skills.length > 0) && (
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-1.5">Key skills</h4>
            <div className="flex flex-wrap gap-2">
              {job.skills.map((s, i) => (
                <span key={i} className="px-2.5 py-1 rounded-full text-xs bg-gray-100 text-gray-700">{s}</span>
              ))}
            </div>
          </div>
        )}

        {/* Benefits */}
        {job.benefits && job.benefits.length > 0 && (
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-1.5">Perks & benefits</h4>
            <ul className="list-disc ml-5 text-[15px] leading-6 text-gray-700 space-y-1">
              {job.benefits.map((b, i) => (<li key={i}>{b}</li>))}
            </ul>
          </div>
        )}

        {/* Additional Job Insights */}
        <div>
          <h4 className="text-sm font-semibold text-gray-900 mb-1.5">Job insights</h4>
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="bg-gray-50 rounded-lg p-3">
              <div className="text-lg font-semibold text-gray-900">4.2</div>
              <div className="text-xs text-gray-600">Salary match</div>
            </div>
            <div className="bg-gray-50 rounded-lg p-3">
              <div className="text-lg font-semibold text-gray-900">{Math.floor(Math.random() * 50) + 10}</div>
              <div className="text-xs text-gray-600">Applicants</div>
            </div>
            <div className="bg-gray-50 rounded-lg p-3">
              <div className="text-lg font-semibold text-gray-900">{Math.floor(Math.random() * 30) + 70}%</div>
              <div className="text-xs text-gray-600">Skills match</div>
            </div>
          </div>
        </div>

        {/* Employer Questions Preview */}
        <div>
          <h4 className="text-sm font-semibold text-gray-900 mb-1.5">Employer questions</h4>
          <div className="text-sm text-gray-700">
            <p className="mb-2">Your application will include the following questions:</p>
            <ul className="list-disc ml-5 space-y-1 text-xs text-gray-600">
              <li>Which of the following statements best describes your right to work in {job.location.includes('New Zealand') ? 'New Zealand' : 'this location'}?</li>
              <li>How many years of experience do you have in this field?</li>
              <li>What is your expected salary range for this position?</li>
            </ul>
          </div>
        </div>

        {/* Meta section */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          {job.status && (
            <div className="text-sm text-gray-700"><span className="font-medium">Status: </span>{job.status.replace('_', ' ')}</div>
          )}
          {job.bidLimit !== undefined && (
            <div className="text-sm text-gray-700"><span className="font-medium">Bid limit: </span>{job.bidLimit}</div>
          )}
          {job.industry && job.industry.length > 0 && (
            <div className="text-sm text-gray-700"><span className="font-medium">Industry: </span>{job.industry.join(', ')}</div>
          )}
        </div>

        {/* Actions */}
        {((!user && onApply) || (user?.role === 'candidate' && onApply && !isApplied(job.id)) || canSave || (user?.role==='recruiter')) ? (
          <div className="pt-1.5 flex gap-2">
            {((!user && onApply) || (user?.role === 'candidate' && onApply && !isApplied(job.id))) && (
              <button onClick={() => onApply(job)} className="flex-1 inline-flex items-center justify-center px-4 py-2.5 rounded-md bg-primary-600 text-white hover:bg-primary-700">Apply now</button>
            )}
            {canSave && (
              <button onClick={() => toggle(job)} className="flex-1 inline-flex items-center justify-center px-4 py-2.5 rounded-md border border-gray-300 text-gray-700 hover:bg-gray-50">{isSaved(job.id) ? 'Saved' : 'Save job'}</button>
            )}
            {user?.role==='recruiter' && job.visibility==='open' && (
              reason === 'Bid capacity reached' ? (
                <span className="inline-flex items-center px-3 py-2.5 rounded-md bg-red-100 text-red-700">Full</span>
              ) : (
                <>
                  <span className={`inline-flex items-center px-3 py-2.5 rounded-md ${
                    loading ? 'bg-gray-100 text-gray-700' : (
                      Number.isFinite(slotsLeft) ? (slotsLeft > 0 ? 'bg-blue-100 text-blue-800' : 'bg-red-100 text-red-800') : 'bg-green-100 text-green-800'
                    )
                  }`}>
                    {loading ? 'Checking…' : (Number.isFinite(slotsLeft) ? (slotsLeft > 0 ? `Slots: ${slotsLeft}` : 'Full') : 'Open')}
                  </span>
                  <button className={`flex-1 inline-flex items-center justify-center px-4 py-2.5 rounded-md disabled:opacity-50 ${
                    loading ? 'bg-gray-100 text-gray-700' : (canBid ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100')
                  }`} disabled={loading || !canBid} title={!canBid && !loading ? reason : ''} onClick={() => { console.log('[BidCTA] Preview click', { jobId: job.id, title: job.title }); onBid?.(job); }}>
                    Bid for this Job
                  </button>
                </>
              )
            )}
          </div>
        ) : (
          user?.role === 'candidate' && isApplied(job.id) ? (
            <div className="pt-1.5">
              <span className="inline-flex items-center px-3 py-1.5 rounded-md bg-green-100 text-green-700">You have applied to this job</span>
            </div>
          ) : null
        )}
      </div>
      {showCompany && job.organizationId && (
        <CompanyProfileView
          orgId={job.organizationId}
          isOpen={showCompany}
          onClose={() => setShowCompany(false)}
          onViewAllJobs={() => {
            setShowCompany(false);
            window.location.href = `/#/?employer=${encodeURIComponent(job.organizationName || '')}&employerId=${job.organizationId}`;
          }}
          onJobClick={(jobId) => {
            setShowCompany(false);
            if (onJobChange) {
              onJobChange(jobId);
            }
          }}
        />
      )}
    </div>
  );
};

export default JobPreviewPanel;

// Render full description with basic paragraph and bullet list structure
const StructuredDescription: React.FC<{ text: string }> = ({ text }) => {
  if (!text) return null;
  const lines = text.split(/\r?\n/);
  const blocks: Array<{ type: 'p' | 'ul'; content: string[] }> = [];
  let current: { type: 'p' | 'ul'; content: string[] } | null = null;
  const bulletRe = /^\s*(?:[-•*]|\u2022)\s+/;
  for (const raw of lines) {
    const line = raw.trimEnd();
    if (line.trim() === '') {
      if (current) { blocks.push(current); current = null; }
      continue;
    }
    if (bulletRe.test(line)) {
      const item = line.replace(bulletRe, '').trim();
      if (!current || current.type !== 'ul') { if (current) blocks.push(current); current = { type: 'ul', content: [] }; }
      current.content.push(item);
    } else {
      if (!current || current.type !== 'p') { if (current) blocks.push(current); current = { type: 'p', content: [] }; }
      current.content.push(line);
    }
  }
  if (current) blocks.push(current);

  return (
    <div className="text-gray-700 text-[15px] leading-6 space-y-3">
      {blocks.map((b, i) => (
        b.type === 'p' ? (
          <p key={i} className="whitespace-pre-line">{b.content.join('\n')}</p>
        ) : (
          <ul key={i} className="list-disc ml-5 space-y-1">
            {b.content.map((li, j) => (<li key={j}>{li}</li>))}
          </ul>
        )
      ))}
    </div>
  );
};
