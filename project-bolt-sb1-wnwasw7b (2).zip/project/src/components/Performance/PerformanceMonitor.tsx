import React, { useState, useEffect } from 'react';
import { usePerformance } from '../../hooks/usePerformance';
import { Activity, Zap, Wifi, HardDrive, X } from 'lucide-react';

interface PerformanceMonitorProps {
  isVisible: boolean;
  onClose: () => void;
}

const PerformanceMonitor: React.FC<PerformanceMonitorProps> = ({ isVisible, onClose }) => {
  const { metrics, measureNetworkLatency } = usePerformance();
  const [coreVitals, setCoreVitals] = useState<any>(null);

  useEffect(() => {
    if (isVisible) {
      // Measure network latency
      measureNetworkLatency();

      // Get Core Web Vitals
      import('../../utils/performance').then(({ PerformanceMonitor }) => {
        PerformanceMonitor.getInstance().getCoreWebVitals().then(setCoreVitals);
      });
    }
  }, [isVisible, measureNetworkLatency]);

  if (!isVisible) return null;

  const getPerformanceColor = (value: number, thresholds: [number, number]) => {
    if (value <= thresholds[0]) return 'text-green-600';
    if (value <= thresholds[1]) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="fixed bottom-4 right-4 w-80 bg-white rounded-lg shadow-xl border border-gray-200 z-50">
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        <div className="flex items-center space-x-2">
          <Activity className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold text-gray-900">Performance Monitor</h3>
        </div>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-600"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-4">
        {/* Memory Usage */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <HardDrive className="w-4 h-4 text-gray-500" />
            <span className="text-sm text-gray-700">Memory</span>
          </div>
          <div className="text-right">
            <div className={`text-sm font-medium ${getPerformanceColor(metrics.memoryUsage.percentage, [50, 80])}`}>
              {metrics.memoryUsage.percentage}%
            </div>
            <div className="text-xs text-gray-500">
              {metrics.memoryUsage.used}MB / {metrics.memoryUsage.total}MB
            </div>
          </div>
        </div>

        {/* Network Latency */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Wifi className="w-4 h-4 text-gray-500" />
            <span className="text-sm text-gray-700">Network</span>
          </div>
          <div className="text-right">
            <div className={`text-sm font-medium ${getPerformanceColor(metrics.networkLatency, [100, 300])}`}>
              {metrics.networkLatency.toFixed(0)}ms
            </div>
            <div className="text-xs text-gray-500">Latency</div>
          </div>
        </div>

        {/* Render Performance */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-gray-500" />
            <span className="text-sm text-gray-700">Render</span>
          </div>
          <div className="text-right">
            <div className={`text-sm font-medium ${getPerformanceColor(metrics.renderTime, [16, 50])}`}>
              {metrics.renderTime.toFixed(1)}ms
            </div>
            <div className="text-xs text-gray-500">Last render</div>
          </div>
        </div>

        {/* Core Web Vitals */}
        {coreVitals && (
          <div className="pt-4 border-t border-gray-200">
            <h4 className="text-sm font-medium text-gray-900 mb-3">Core Web Vitals</h4>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">FCP</span>
                <span className={getPerformanceColor(coreVitals.fcp, [1800, 3000])}>
                  {coreVitals.fcp.toFixed(0)}ms
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">LCP</span>
                <span className={getPerformanceColor(coreVitals.lcp, [2500, 4000])}>
                  {coreVitals.lcp.toFixed(0)}ms
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">FID</span>
                <span className={getPerformanceColor(coreVitals.fid, [100, 300])}>
                  {coreVitals.fid.toFixed(0)}ms
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">CLS</span>
                <span className={getPerformanceColor(coreVitals.cls * 1000, [100, 250])}>
                  {coreVitals.cls.toFixed(3)}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PerformanceMonitor;