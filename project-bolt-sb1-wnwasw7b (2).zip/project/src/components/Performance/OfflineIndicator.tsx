import React from 'react';
import { useOfflineSync } from '../../hooks/useOfflineSync';
import { WifiOff, Wifi, FolderSync as Sync, AlertCircle } from 'lucide-react';

const OfflineIndicator: React.FC = () => {
  const { isOnline, offlineActions, syncing } = useOfflineSync();

  if (isOnline && offlineActions.length === 0) {
    return null;
  }

  return (
    <div className="fixed top-4 right-4 z-50">
      <div className={`flex items-center space-x-2 px-4 py-2 rounded-lg shadow-lg border ${
        isOnline 
          ? 'bg-green-50 border-green-200 text-green-800'
          : 'bg-red-50 border-red-200 text-red-800'
      }`}>
        {syncing ? (
          <Sync className="w-4 h-4 animate-spin" />
        ) : isOnline ? (
          <Wifi className="w-4 h-4" />
        ) : (
          <WifiOff className="w-4 h-4" />
        )}
        
        <span className="text-sm font-medium">
          {syncing ? (
            'Syncing...'
          ) : isOnline ? (
            offlineActions.length > 0 
              ? `Syncing ${offlineActions.length} actions`
              : 'Online'
          ) : (
            'Offline Mode'
          )}
        </span>

        {offlineActions.length > 0 && (
          <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
            {offlineActions.length}
          </span>
        )}
      </div>

      {!isOnline && (
        <div className="mt-2 bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-2 rounded-lg shadow-lg">
          <div className="flex items-center space-x-2">
            <AlertCircle className="w-4 h-4" />
            <span className="text-sm">
              Changes will sync when connection is restored
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

export default OfflineIndicator;