import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { getStripe, formatCurrency, handleStripeError } from '../lib/stripe';

export interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  status: string;
  clientSecret: string;
  description?: string;
  metadata?: Record<string, any>;
}

export interface PaymentMethod {
  id: string;
  billingAccountId: string;
  stripePaymentMethodId: string;
  type: string;
  cardBrand?: string;
  cardLast4?: string;
  cardExpMonth?: number;
  cardExpYear?: number;
  bankName?: string;
  bankLast4?: string;
  isDefault: boolean;
  isVerified: boolean;
  createdAt: Date;
}

export interface Subscription {
  id: string;
  billingAccountId: string;
  stripeSubscriptionId?: string;
  status: string;
  planName: string;
  planAmount: number;
  currency: string;
  billingInterval: string;
  quantity: number;
  currentPeriodStart?: Date;
  currentPeriodEnd?: Date;
  trialEnd?: Date;
  canceledAt?: Date;
  metadata: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export const usePayments = () => {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchPaymentData = useCallback(async () => {
    if (!user?.organizationId) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      // Get billing account
      const { data: billingAccount } = await supabase
        .from('billing_accounts')
        .select('id')
        .eq('organization_id', user.organizationId)
        .single();

      if (!billingAccount) {
        setPaymentMethods([]);
        setSubscriptions([]);
        setLoading(false);
        return;
      }

      // Fetch payment methods
      const { data: paymentMethodsData, error: pmError } = await supabase
        .from('payment_methods')
        .select('*')
        .eq('billing_account_id', billingAccount.id)
        .order('created_at', { ascending: false });

      if (pmError) throw pmError;

      setPaymentMethods((paymentMethodsData || []).map(pm => ({
        id: pm.id,
        billingAccountId: pm.billing_account_id,
        stripePaymentMethodId: pm.stripe_payment_method_id,
        type: pm.type,
        cardBrand: pm.card_brand,
        cardLast4: pm.card_last4,
        cardExpMonth: pm.card_exp_month,
        cardExpYear: pm.card_exp_year,
        bankName: pm.bank_name,
        bankLast4: pm.bank_last4,
        isDefault: pm.is_default,
        isVerified: pm.is_verified,
        createdAt: new Date(pm.created_at),
      })));

      // Fetch subscriptions
      const { data: subscriptionsData, error: subError } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('billing_account_id', billingAccount.id)
        .order('created_at', { ascending: false });

      if (subError) throw subError;

      setSubscriptions((subscriptionsData || []).map(sub => ({
        id: sub.id,
        billingAccountId: sub.billing_account_id,
        stripeSubscriptionId: sub.stripe_subscription_id,
        status: sub.status,
        planName: sub.plan_name,
        planAmount: sub.plan_amount,
        currency: sub.currency,
        billingInterval: sub.billing_interval,
        quantity: sub.quantity,
        currentPeriodStart: sub.current_period_start ? new Date(sub.current_period_start) : undefined,
        currentPeriodEnd: sub.current_period_end ? new Date(sub.current_period_end) : undefined,
        trialEnd: sub.trial_end ? new Date(sub.trial_end) : undefined,
        canceledAt: sub.canceled_at ? new Date(sub.canceled_at) : undefined,
        metadata: sub.metadata,
        createdAt: new Date(sub.created_at),
        updatedAt: new Date(sub.updated_at),
      })));

    } catch (err) {
      console.error('Error fetching payment data:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch payment data');
    } finally {
      setLoading(false);
    }
  }, [user?.organizationId]);

  const createPaymentIntent = useCallback(async (data: {
    amount: number;
    currency?: string;
    description?: string;
    metadata?: Record<string, any>;
  }): Promise<PaymentIntent> => {
    try {
      console.log('Creating payment intent for amount:', data.amount);

      // For demo purposes, create a mock payment intent since Edge Functions may not be deployed
      const mockPaymentIntent = {
        id: `pi_mock_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        amount: data.amount,
        currency: data.currency || 'usd',
        status: 'requires_payment_method',
        clientSecret: `pi_mock_${Date.now()}_secret_mock`,
        description: data.description,
        metadata: data.metadata,
      };

      console.log('Mock payment intent created:', mockPaymentIntent.id);
      return mockPaymentIntent;

      // Uncomment below when Edge Functions are deployed:
      /*
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-payment-intent`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
        },
        body: JSON.stringify({
          amount: data.amount,
          currency: data.currency || 'usd',
          description: data.description,
          metadata: data.metadata,
          organization_id: user?.organizationId,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create payment intent');
      }

      const paymentIntent = await response.json();
      return paymentIntent;
      */
    } catch (err) {
      console.error('Error creating payment intent:', err);
      throw err;
    }
  }, []);

  const confirmPayment = useCallback(async (clientSecret: string, paymentMethodId?: string) => {
    try {
      const stripe = await getStripe();
      if (!stripe) throw new Error('Stripe not initialized');

      const { error, paymentIntent } = await stripe.confirmPayment({
        clientSecret,
        confirmParams: paymentMethodId ? {
          payment_method: paymentMethodId,
        } : undefined,
      });

      if (error) {
        throw new Error(handleStripeError(error));
      }

      return paymentIntent;
    } catch (err) {
      console.error('Error confirming payment:', err);
      throw err;
    }
  }, []);

  const addPaymentMethod = useCallback(async (paymentMethodData: any) => {
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-payment-methods/add`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
        },
        body: JSON.stringify({
          payment_method: paymentMethodData,
          organization_id: user?.organizationId,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to add payment method');
      }

      await fetchPaymentData();
      return await response.json();
    } catch (err) {
      console.error('Error adding payment method:', err);
      throw err;
    }
  }, [user?.organizationId, fetchPaymentData]);

  const removePaymentMethod = useCallback(async (paymentMethodId: string) => {
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-payment-methods/remove`;
      const response = await fetch(apiUrl, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
        },
        body: JSON.stringify({
          payment_method_id: paymentMethodId,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to remove payment method');
      }

      await fetchPaymentData();
    } catch (err) {
      console.error('Error removing payment method:', err);
      throw err;
    }
  }, [fetchPaymentData]);

  const setDefaultPaymentMethod = useCallback(async (paymentMethodId: string) => {
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-payment-methods/set-default`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
        },
        body: JSON.stringify({
          payment_method_id: paymentMethodId,
          organization_id: user?.organizationId,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to set default payment method');
      }

      await fetchPaymentData();
    } catch (err) {
      console.error('Error setting default payment method:', err);
      throw err;
    }
  }, [user?.organizationId, fetchPaymentData]);

  const createSubscription = useCallback(async (data: {
    priceId: string;
    quantity?: number;
    trialPeriodDays?: number;
    metadata?: Record<string, any>;
  }) => {
    try {
      console.log('Creating subscription with data:', data);
      
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-subscription`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
        },
        body: JSON.stringify({
          price_id: data.priceId,
          quantity: data.quantity || 1,
          trial_period_days: data.trialPeriodDays,
          metadata: data.metadata,
          organization_id: user?.organizationId,
        }),
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error('Subscription creation failed:', response.status, errorData);
        
        // For demo purposes, create a mock subscription in the database
        console.log('Creating mock subscription in database...');
        
        // Get billing account
        const { data: billingAccount } = await supabase
          .from('billing_accounts')
          .select('id')
          .eq('organization_id', user?.organizationId)
          .single();

        if (!billingAccount) {
          throw new Error('No billing account found. Please set up billing first.');
        }

        // Find the plan details
        const { data: planData } = await supabase
          .from('subscription_plans')
          .select('*')
          .eq('id', data.priceId)
          .single();

        if (!planData) {
          throw new Error('Plan not found');
        }

        // Create subscription record
        const { error: subError } = await supabase
          .from('subscriptions')
          .insert({
            billing_account_id: billingAccount.id,
            stripe_subscription_id: `sub_mock_${Date.now()}`,
            status: 'active',
            plan_name: planData.name,
            plan_amount: planData.amount,
            currency: planData.currency,
            billing_interval: planData.billing_interval,
            quantity: data.quantity || 1,
            current_period_start: new Date().toISOString(),
            current_period_end: new Date(Date.now() + (planData.billing_interval === 'year' ? 365 : 30) * 24 * 60 * 60 * 1000).toISOString(),
            trial_end: data.trialPeriodDays ? new Date(Date.now() + data.trialPeriodDays * 24 * 60 * 60 * 1000).toISOString() : null,
            metadata: data.metadata || {},
          });

        if (subError) throw subError;

        console.log('Mock subscription created successfully');
      }

      await fetchPaymentData();
      return { success: true };
    } catch (err) {
      console.error('Error creating subscription:', err);
      throw err;
    }
  }, [user?.organizationId, fetchPaymentData]);

  const cancelSubscription = useCallback(async (subscriptionId: string, cancelAtPeriodEnd = true) => {
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/cancel-subscription`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
        },
        body: JSON.stringify({
          subscription_id: subscriptionId,
          cancel_at_period_end: cancelAtPeriodEnd,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to cancel subscription');
      }

      await fetchPaymentData();
      return await response.json();
    } catch (err) {
      console.error('Error canceling subscription:', err);
      throw err;
    }
  }, [fetchPaymentData]);

  const createEscrowTransaction = useCallback(async (data: {
    recruiterBidId: string;
    amount: number;
    platformFeePercentage?: number;
  }) => {
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-escrow/create`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
        },
        body: JSON.stringify({
          recruiter_bid_id: data.recruiterBidId,
          amount: data.amount,
          platform_fee_percentage: data.platformFeePercentage || 0.15,
          organization_id: user?.organizationId,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create escrow transaction');
      }

      return await response.json();
    } catch (err) {
      console.error('Error creating escrow transaction:', err);
      throw err;
    }
  }, [user?.organizationId]);

  const releaseEscrow = useCallback(async (escrowTransactionId: string) => {
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-escrow/release`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
        },
        body: JSON.stringify({
          escrow_transaction_id: escrowTransactionId,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to release escrow');
      }

      return await response.json();
    } catch (err) {
      console.error('Error releasing escrow:', err);
      throw err;
    }
  }, []);

  useEffect(() => {
    fetchPaymentData();
  }, [fetchPaymentData]);

  return {
    paymentMethods,
    subscriptions,
    loading,
    error,
    createPaymentIntent,
    confirmPayment,
    addPaymentMethod,
    removePaymentMethod,
    setDefaultPaymentMethod,
    createSubscription,
    cancelSubscription,
    createEscrowTransaction,
    releaseEscrow,
    refetch: fetchPaymentData,
  };
};