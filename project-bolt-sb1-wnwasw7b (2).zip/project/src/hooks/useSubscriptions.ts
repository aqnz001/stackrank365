import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import type { Database } from '../lib/supabase';

export interface SubscriptionPlan {
  id: string;
  stripePriceId: string | null;
  name: string;
  description?: string;
  amount: number;
  currency: string;
  billingInterval: Database['public']['Enums']['billing_interval'];
  trialPeriodDays: number;
  features: string[];
  limits: Record<string, number>;
  audience: 'employer' | 'recruiter';
  availableFrom?: Date | null;
  availableTo?: Date | null;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface SubscriptionUsage {
  id: string;
  subscriptionId: string | null;
  billingAccountId: string | null;
  usageType: string;
  quantity: number;
  unitPrice: number;
  periodStart: Date;
  periodEnd: Date;
  metadata: Record<string, any>;
  createdAt: Date;
}

export interface CurrentSubscription {
  id: string;
  billingAccountId: string;
  stripeSubscriptionId?: string;
  status: Database['public']['Enums']['subscription_status'];
  planName: string;
  planAmount: number;
  currency: string;
  billingInterval: string;
  currentPeriodStart?: Date;
  currentPeriodEnd?: Date;
  trialEnd?: Date;
  canceledAt?: Date;
  metadata: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}
export const useSubscriptions = () => {
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [currentSubscription, setCurrentSubscription] = useState<CurrentSubscription | null>(null);
  const [usage, setUsage] = useState<SubscriptionUsage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchSubscriptionPlans = async () => {
    try {
      const { data, error: fetchError } = await supabase
        .from('subscription_plans')
        .select('*')
        .eq('is_active', true)
        .order('amount', { ascending: true });

      if (fetchError) throw fetchError;
      const transformedPlans: SubscriptionPlan[] = (data || []).map(plan => ({
        id: plan.id,
        stripePriceId: plan.stripe_price_id,
        name: plan.name,
        description: plan.description,
        amount: plan.amount,
        currency: plan.currency,
        billingInterval: plan.billing_interval,
        trialPeriodDays: plan.trial_period_days,
        features: Array.isArray(plan.features) ? plan.features : [],
        limits: typeof plan.limits === 'object' && plan.limits ? plan.limits : {},
        audience: (plan as any).audience || 'employer',
        availableFrom: (plan as any).available_from ? new Date((plan as any).available_from) : null,
        availableTo: (plan as any).available_to ? new Date((plan as any).available_to) : null,
        isActive: plan.is_active,
        createdAt: new Date(plan.created_at),
        updatedAt: new Date(plan.updated_at),
      }));

      setPlans(transformedPlans);
    } catch (err) {
      console.error('Error fetching subscription plans:', err);
      throw err;
    }
  };

  const fetchCurrentSubscription = async () => {
    if (!user?.organizationId) return;

    try {
      
      // Get billing account
      const { data: billingAccount } = await supabase
        .from('billing_accounts')
        .select('id')
        .eq('organization_id', user.organizationId)
        .single();

      if (!billingAccount) {
        return;
      }

      // Get current subscription
      const { data: subscription, error: subError } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('billing_account_id', billingAccount.id)
        .in('status', ['active', 'trialing', 'past_due'])
        .order('created_at', { ascending: false })
        .limit(1);

      if (subError) throw subError;

      console.log('[Subscription Debug] Found subscriptions:', subscription);

      if (subscription && subscription.length > 0) {
        const sub = subscription[0];
        console.log('[Subscription Debug] Using subscription:', {
          id: sub.id,
          plan_name: sub.plan_name,
          status: sub.status,
          created_at: sub.created_at
        });
        
        setCurrentSubscription({
          id: sub.id,
          billingAccountId: sub.billing_account_id,
          stripeSubscriptionId: sub.stripe_subscription_id,
          status: sub.status,
          planName: sub.plan_name,
          planAmount: sub.plan_amount,
          currency: sub.currency,
          billingInterval: sub.billing_interval,
          currentPeriodStart: sub.current_period_start ? new Date(sub.current_period_start) : undefined,
          currentPeriodEnd: sub.current_period_end ? new Date(sub.current_period_end) : undefined,
          trialEnd: sub.trial_end ? new Date(sub.trial_end) : undefined,
          canceledAt: sub.canceled_at ? new Date(sub.canceled_at) : undefined,
          metadata: sub.metadata || {},
          createdAt: new Date(sub.created_at),
          updatedAt: new Date(sub.updated_at),
        });
      } else {
        setCurrentSubscription(null);
      }
    } catch (err) {
      console.error('Error fetching current subscription:', err);
      throw err;
    }
  };

  const fetchUsageData = async () => {
    if (!user?.organizationId) return;

    try {
      
      // Get billing account
      const { data: billingAccount } = await supabase
        .from('billing_accounts')
        .select('id')
        .eq('organization_id', user.organizationId)
        .single();

      if (!billingAccount) return;

      // Get current period usage
      const currentPeriodStart = new Date();
      currentPeriodStart.setDate(1); // First day of current month

      const { data: usageData, error: usageError } = await supabase
        .from('subscription_usage')
        .select('*')
        .eq('billing_account_id', billingAccount.id)
        .gte('period_start', currentPeriodStart.toISOString())
        .order('created_at', { ascending: false });

      if (usageError) throw usageError;
      const transformedUsage: SubscriptionUsage[] = (usageData || []).map(usage => ({
        id: usage.id,
        subscriptionId: usage.subscription_id,
        billingAccountId: usage.billing_account_id,
        usageType: usage.usage_type,
        quantity: usage.quantity,
        unitPrice: usage.unit_price,
        periodStart: new Date(usage.period_start),
        periodEnd: new Date(usage.period_end),
        metadata: usage.metadata || {},
        createdAt: new Date(usage.created_at),
      }));

      setUsage(transformedUsage);
    } catch (err) {
      console.error('Error fetching usage data:', err);
      throw err;
    }
  };

  const trackUsage = async (data: {
    usageType: string;
    quantity: number;
    unitPrice?: number;
    metadata?: Record<string, any>;
  }) => {
    if (!user?.organizationId) {
      console.warn('Cannot track usage: no organization ID');
      return;
    }

    try {
      console.log('Tracking usage:', data.usageType, 'quantity:', data.quantity);
      
      // Get billing account
      const { data: billingAccount } = await supabase
        .from('billing_accounts')
        .select('id')
        .eq('organization_id', user.organizationId)
        .single();

      if (!billingAccount) {
        console.warn('Cannot track usage: no billing account found');
        return;
      }

      const currentPeriodStart = new Date();
      currentPeriodStart.setDate(1);
      
      const currentPeriodEnd = new Date(currentPeriodStart);
      currentPeriodEnd.setMonth(currentPeriodEnd.getMonth() + 1);
      currentPeriodEnd.setDate(0); // Last day of current month

      const { error } = await supabase
        .from('subscription_usage')
        .insert({
          subscription_id: currentSubscription?.id || null,
          billing_account_id: billingAccount.id,
          usage_type: data.usageType,
          quantity: data.quantity,
          unit_price: data.unitPrice || 0,
          period_start: currentPeriodStart.toISOString(),
          period_end: currentPeriodEnd.toISOString(),
          metadata: data.metadata || {},
        });

      if (error) throw error;

      console.log('Usage tracked successfully');
      await fetchUsageData();
    } catch (err) {
      console.error('Error tracking usage:', err);
      throw err;
    }
  };

  const getUsageSummary = () => {
    const summary: Record<string, number> = {};

    usage.forEach(item => {
      summary[item.usageType] = (summary[item.usageType] || 0) + item.quantity;
    });

    return summary;
  };

  const getTeamMemberCount = async (): Promise<number> => {
    if (!user?.organizationId) return 0;

    try {
      const { count, error } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .eq('organization_id', user.organizationId);

      if (error) throw error;
      return count || 0;
    } catch (err) {
      console.error('Error counting team members:', err);
      return 0;
    }
  };

  const getJobPostsThisMonth = async (): Promise<number> => {
    if (!user?.organizationId) return 0;

    try {
      const currentPeriodStart = new Date();
      currentPeriodStart.setDate(1);
      currentPeriodStart.setHours(0, 0, 0, 0);

      const { count, error } = await supabase
        .from('jobs')
        .select('*', { count: 'exact', head: true })
        .eq('organization_id', user.organizationId)
        .gte('created_at', currentPeriodStart.toISOString());

      if (error) throw error;
      return count || 0;
    } catch (err) {
      console.error('Error counting job posts:', err);
      return 0;
    }
  };

  const checkUsageLimit = async (usageType: string, requestedQuantity = 1): Promise<boolean> => {
    if (!currentSubscription) {
      console.log('No subscription found, allowing usage (pay-per-use)');
      return true; // Allow usage for pay-per-use customers
    }

    const currentPlan = plans.find(p => p.name.toLowerCase().includes(currentSubscription.planName.toLowerCase()));
    if (!currentPlan) {
      console.warn('Current plan not found in available plans');
      return false;
    }

    const limit = currentPlan.limits[usageType];
    if (limit === -1 || limit === undefined) {
      console.log('Unlimited usage for', usageType);
      return true; // Unlimited
    }

    // For job_posts_per_month, get actual count from jobs table
    let currentUsage = 0;
    if (usageType === 'job_posts_per_month') {
      currentUsage = await getJobPostsThisMonth();
    } else {
      currentUsage = getUsageSummary()[usageType] || 0;
    }

    const canUse = (currentUsage + requestedQuantity) <= limit;

    console.log(`Usage check for ${usageType}: ${currentUsage + requestedQuantity}/${limit} = ${canUse ? 'ALLOWED' : 'BLOCKED'}`);
    return canUse;
  };

  const createDefaultPlans = async () => {
    try {
      console.log('Creating default subscription plans...');
      
      // Check if plans already exist to avoid RLS issues
      const { data: existingPlans } = await supabase
        .from('subscription_plans')
        .select('id')
        .eq('is_active', true)
        .limit(1);

      if (existingPlans && existingPlans.length > 0) {
        console.log('Subscription plans already exist, skipping creation');
        return;
      }

      const defaultPlans = [
        {
          name: 'Basic Plan',
          description: 'Perfect for small businesses',
          amount: 29900, // $299 in cents
          currency: 'usd',
          billing_interval: 'month' as const,
          trial_period_days: 14,
          features: [
            'Up to 5 job posts per month',
            'Up to 3 team members',
            'Direct applications only',
            'Basic analytics',
            'Email support'
          ],
          limits: {
            job_posts_per_month: 5,
            applications_per_job: -1, // Unlimited
            recruiter_bids_per_job: 0, // No recruiter bids for basic
            team_members: 3
          },
          is_active: true
        },
        {
          name: 'Standard Plan',
          description: 'Great for growing companies',
          amount: 59900, // $599 in cents
          currency: 'usd',
          billing_interval: 'month' as const,
          trial_period_days: 14,
          features: [
            'Up to 20 job posts per month',
            'Up to 10 team members',
            'Recruiter marketplace access',
            'Up to 10 bids per job',
            'Advanced analytics',
            'Priority support',
            'Custom workflows'
          ],
          limits: {
            job_posts_per_month: 20,
            recruiter_bids_per_job: 10,
            applications_per_job: -1,
            team_members: 10
          },
          is_active: true
        },
        {
          name: 'Premium Plan',
          description: 'For enterprise organizations',
          amount: 99900, // $999 in cents
          currency: 'usd',
          billing_interval: 'month' as const,
          trial_period_days: 14,
          features: [
            'Unlimited job posts',
            'Unlimited team members',
            'Full recruiter marketplace',
            'Unlimited bids per job',
            'Premium analytics',
            'Dedicated support',
            'White-label options',
            'API access'
          ],
          limits: {
            job_posts_per_month: -1,
            recruiter_bids_per_job: -1,
            applications_per_job: -1,
            team_members: -1
          },
          is_active: true
        }
      ];

      const { error } = await supabase
        .from('subscription_plans')
        .insert(defaultPlans);

      if (error) throw error;

      console.log('Default subscription plans created successfully');
      await fetchSubscriptionPlans();
    } catch (err) {
      console.error('Error creating default plans:', err);
      throw err;
    }
  };
  const fetchAllData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Always fetch plans so the UI can render even without an organization
      await fetchSubscriptionPlans();

      if (user?.organizationId) {
        await Promise.all([
          fetchCurrentSubscription(),
          fetchUsageData(),
        ]);
      } else {
        // No organization context yet; clear org-scoped state so UI doesn't hang
        setCurrentSubscription(null);
        setUsage([]);
      }
    } catch (err) {
      console.error('Error fetching subscription data:', err);
      // Don't set error for RLS policy violations during plan creation
      if (err instanceof Error && !err.message.includes('row-level security policy')) {
        setError(err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Fetch plans immediately; enrich with org-scoped data when org becomes available
    fetchAllData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.organizationId]);

  return {
    plans,
    currentSubscription,
    usage,
    loading,
    error,
    trackUsage,
    getUsageSummary,
    getTeamMemberCount,
    getJobPostsThisMonth,
    checkUsageLimit,
    createDefaultPlans,
    refetch: fetchAllData,
  };
};
