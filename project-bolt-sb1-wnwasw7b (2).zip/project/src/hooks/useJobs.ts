import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useSubscriptions } from './useSubscriptions';
import type { Job } from '../types';

export const useJobs = () => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();
  const { trackUsage, checkUsageLimit } = useSubscriptions();

  const fetchJobs = async () => {
    try {
      setLoading(true);
      setError(null);
      
      console.log('Fetching jobs for user role:', user?.role);

      let query = supabase
        .from('jobs')
        .select(`
          *,
          organizations (
            id,
            name,
            type,
            size
          )
        `);

      // Filter based on user role
      if (user?.role === 'employer') {
        console.log('Filtering jobs for employer organization:', user.organizationId);
        
        // Check if organizationId is valid
        if (!user.organizationId || user.organizationId === 'null' || user.organizationId === null) {
          console.log('Employer has no valid organization ID, returning empty jobs list');
          setJobs([]);
          setLoading(false);
          return;
        }
        
        query = query.eq('organization_id', user.organizationId);
      } else if (user?.role === 'recruiter') {
        console.log('Filtering jobs for recruiter (open visibility only)');
        query = query.eq('visibility', 'open');
      } else if (!user) {
        // Public homepage: show only open + active jobs
        console.log('No authenticated user; fetching publicly visible open jobs');
        query = query.eq('visibility', 'open').eq('status', 'open');
      }

      const { data, error: fetchError } = await query.order('created_at', { ascending: false });

      if (fetchError) {
        console.error('Error fetching jobs:', fetchError.message, fetchError.details);
        throw fetchError;
      }

      console.log('Jobs fetched successfully:', data?.length || 0, 'jobs');

      const transformedJobs: Job[] = (data || []).map(job => ({
        id: job.id,
        organizationId: job.organization_id,
        organizationName: job.organizations?.name || 'Unknown Organization',
        organizationSize: job.organizations?.size || undefined,
        title: job.title,
        description: job.description,
        location: job.location,
        salaryRange: job.salary_min && job.salary_max ? {
          min: job.salary_min,
          max: job.salary_max
        } : undefined,
        employmentType: job.employment_type,
        experienceLevel: job.experience_level || undefined,
        skills: job.skills || [],
        industry: job.industry || [],
        benefits: job.benefits || [],
        visibility: job.visibility,
        adTier: job.ad_tier,
        bidLimit: job.bid_limit,
        blockedRecruiterIds: job.blocked_recruiter_ids || [],
        status: (job.status === 'on_hold' ? 'draft' : job.status) as any,
        createdAt: new Date(job.created_at),
        applications: [], // TODO: Fetch applications
        recruiterBids: [], // TODO: Fetch recruiter bids
      }));

      setJobs(transformedJobs);
    } catch (err) {
      console.error('Error fetching jobs:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch jobs');
    } finally {
      setLoading(false);
    }
  };

  const createJob = async (jobData: Partial<Job>) => {
    if (!user?.organizationId) {
      console.error('Cannot create job: user not associated with organization');
      throw new Error('You must be associated with an organization to create jobs. Please contact support.');
    }

    // Check usage limits before creating job
    if (!checkUsageLimit('job_posts_per_month', 1)) {
      throw new Error('You have reached your monthly job posting limit. Please upgrade your plan or wait until next month.');
    }
    try {
      console.log('Creating job:', jobData.title);
      
      const { data, error } = await supabase
        .from('jobs')
        .insert({
          organization_id: user.organizationId,
          title: jobData.title!,
          description: jobData.description!,
          location: jobData.location!,
          salary_min: jobData.salaryRange?.min,
          salary_max: jobData.salaryRange?.max,
          employment_type: jobData.employmentType!,
          skills: jobData.skills || [],
          experience_level: jobData.experienceLevel,
          industry: jobData.industry || [],
          benefits: jobData.benefits || [],
          visibility: jobData.visibility || 'closed',
          ad_tier: jobData.adTier || 'basic',
          bid_limit: jobData.bidLimit,
          blocked_recruiter_ids: jobData.blockedRecruiterIds || [],
          status: jobData.status || 'open',
        })
        .select()
        .single();

      if (error) {
        console.error('Error creating job:', error.message, error.details);
        throw error;
      }

      console.log('Job created successfully:', data.id);

      // Track usage after successful job creation
      try {
        await trackUsage({
          usageType: 'job_posts_per_month',
          quantity: 1,
          unitPrice: 0, // Free within subscription limits
          metadata: {
            job_id: data.id,
            job_title: jobData.title,
            ad_tier: jobData.adTier,
          },
        });
      } catch (usageError) {
        console.error('Error tracking job posting usage:', usageError);
        // Don't fail the job creation if usage tracking fails
      }

      // Check saved searches for matching users
      try {
        const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
        const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

        await fetch(`${supabaseUrl}/functions/v1/check-saved-searches`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${supabaseAnonKey}`,
          },
          body: JSON.stringify({ job: data }),
        });
      } catch (notifError) {
        console.error('Error checking saved searches:', notifError);
        // Don't fail the job creation if notification check fails
      }

      // Refresh jobs list
      await fetchJobs();
      return data;
    } catch (err) {
      console.error('Error creating job:', err);
      throw err;
    }
  };

  const updateJob = async (jobId: string, updates: Partial<Job>) => {
    try {
      const { error } = await supabase
        .from('jobs')
        .update({
          title: updates.title,
          description: updates.description,
          location: updates.location,
          salary_min: updates.salaryRange?.min,
          salary_max: updates.salaryRange?.max,
          employment_type: updates.employmentType,
          skills: updates.skills,
          experience_level: updates.experienceLevel,
          industry: updates.industry,
          benefits: updates.benefits,
          visibility: updates.visibility,
          ad_tier: updates.adTier,
          bid_limit: updates.bidLimit,
          blocked_recruiter_ids: updates.blockedRecruiterIds,
          status: updates.status === 'draft' ? 'on_hold' : updates.status,
        })
        .eq('id', jobId);

      if (error) {
        throw error;
      }

      // Refresh jobs list
      await fetchJobs();
    } catch (err) {
      console.error('Error updating job:', err);
      throw err;
    }
  };

  const deleteJob = async (jobId: string) => {
    try {
      const { error } = await supabase
        .from('jobs')
        .delete()
        .eq('id', jobId);

      if (error) {
        throw error;
      }

      // Refresh jobs list
      await fetchJobs();
    } catch (err) {
      console.error('Error deleting job:', err);
      throw err;
    }
  };
  useEffect(() => {
    // Fetch jobs on mount and when auth state changes. When no user, fetch public jobs.
    fetchJobs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  return {
    jobs,
    loading,
    error,
    refetch: fetchJobs,
    createJob,
    updateJob,

    deleteJob,
  };
};
