import { useState, useEffect, useCallback } from 'react';
import { PerformanceMonitor, getMemoryUsage } from '../utils/performance';

interface PerformanceMetrics {
  memoryUsage: {
    used: number;
    total: number;
    percentage: number;
  };
  renderTime: number;
  networkLatency: number;
  cacheHitRate: number;
}

export const usePerformance = (componentName?: string) => {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    memoryUsage: { used: 0, total: 0, percentage: 0 },
    renderTime: 0,
    networkLatency: 0,
    cacheHitRate: 0,
  });
  const [isMonitoring, setIsMonitoring] = useState(false);

  const monitor = PerformanceMonitor.getInstance();

  // Start performance monitoring
  const startMonitoring = useCallback(() => {
    setIsMonitoring(true);
    if (componentName) {
      monitor.startTiming(`component-${componentName}`);
    }
  }, [componentName, monitor]);

  // Stop performance monitoring
  const stopMonitoring = useCallback(() => {
    setIsMonitoring(false);
    if (componentName) {
      const renderTime = monitor.endTiming(`component-${componentName}`);
      setMetrics(prev => ({ ...prev, renderTime }));
    }
  }, [componentName, monitor]);

  // Measure network latency
  const measureNetworkLatency = useCallback(async (url: string = '/api/health') => {
    const start = performance.now();
    try {
      await fetch(url, { method: 'HEAD' });
      const latency = performance.now() - start;
      setMetrics(prev => ({ ...prev, networkLatency: latency }));
      return latency;
    } catch (error) {
      console.error('Network latency measurement failed:', error);
      return -1;
    }
  }, []);

  // Update memory usage
  const updateMemoryUsage = useCallback(() => {
    const memoryUsage = getMemoryUsage();
    setMetrics(prev => ({ ...prev, memoryUsage }));
  }, []);

  // Performance monitoring interval
  useEffect(() => {
    if (!isMonitoring) return;

    const interval = setInterval(() => {
      updateMemoryUsage();
    }, 5000); // Update every 5 seconds

    return () => clearInterval(interval);
  }, [isMonitoring, updateMemoryUsage]);

  // Component mount/unmount timing
  useEffect(() => {
    startMonitoring();
    return stopMonitoring;
  }, [startMonitoring, stopMonitoring]);

  return {
    metrics,
    isMonitoring,
    startMonitoring,
    stopMonitoring,
    measureNetworkLatency,
    updateMemoryUsage,
  };
};