import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useWorkflows } from './useWorkflows';

export interface Interview {
  id: string;
  applicationId?: string;
  recruiterBidId?: string;
  interviewerId: string;
  candidateId: string;
  interviewType: 'phone' | 'video' | 'in_person' | 'technical' | 'panel';
  status: 'scheduled' | 'confirmed' | 'rescheduled' | 'completed' | 'cancelled' | 'no_show';
  scheduledAt: Date;
  durationMinutes: number;
  location?: string;
  meetingLink?: string;
  meetingId?: string;
  notes?: string;
  feedback: any;
  reminderSent: boolean;
  calendarEventId?: string;
  createdAt: Date;
  updatedAt: Date;
  // Populated fields
  candidateName?: string;
  interviewerName?: string;
  jobTitle?: string;
}

export const useInterviews = () => {
  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();
  const { triggerWorkflow } = useWorkflows();

  const fetchInterviews = async () => {
    try {
      setLoading(true);
      setError(null);

      console.log('Fetching interviews for user role:', user?.role);

      let query = supabase
        .from('interview_schedules')
        .select(`
          *,
          candidate:profiles!interview_schedules_candidate_id_fkey (
            id,
            name,
            email
          ),
          interviewer:profiles!interview_schedules_interviewer_id_fkey (
            id,
            name,
            email
          ),
          applications!interview_schedules_application_id_fkey (
            id,
            jobs!applications_job_id_fkey (
              title
            )
          ),
          recruiter_bids!interview_schedules_recruiter_bid_id_fkey (
            id,
            jobs!recruiter_bids_job_id_fkey (
              title
            )
          )
        `);

      // Filter based on user role
      if (user?.role === 'candidate') {
        query = query.eq('candidate_id', user.id);
      } else if (user?.role === 'employer' || user?.role === 'recruiter') {
        query = query.eq('interviewer_id', user.id);
      }

      const { data, error: fetchError } = await query.order('scheduled_at', { ascending: true });

      if (fetchError) throw fetchError;

      console.log('Interviews fetched successfully:', data?.length || 0);

      const transformedInterviews: Interview[] = (data || []).map(interview => ({
        id: interview.id,
        applicationId: interview.application_id,
        recruiterBidId: interview.recruiter_bid_id,
        interviewerId: interview.interviewer_id,
        candidateId: interview.candidate_id,
        interviewType: interview.interview_type,
        status: interview.status,
        scheduledAt: new Date(interview.scheduled_at),
        durationMinutes: interview.duration_minutes,
        location: interview.location,
        meetingLink: interview.meeting_link,
        meetingId: interview.meeting_id,
        notes: interview.notes,
        feedback: interview.feedback,
        reminderSent: interview.reminder_sent,
        calendarEventId: interview.calendar_event_id,
        createdAt: new Date(interview.created_at),
        updatedAt: new Date(interview.updated_at),
        candidateName: interview.candidate?.name,
        interviewerName: interview.interviewer?.name,
        jobTitle: interview.applications?.jobs?.title || interview.recruiter_bids?.jobs?.title,
      }));

      setInterviews(transformedInterviews);
    } catch (err) {
      console.error('Error fetching interviews:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch interviews');
    } finally {
      setLoading(false);
    }
  };

  const scheduleInterview = async (interviewData: {
    applicationId?: string;
    recruiterBidId?: string;
    candidateId: string;
    interviewType: Interview['interviewType'];
    scheduledAt: Date;
    durationMinutes: number;
    location?: string;
    meetingLink?: string;
    notes?: string;
  }) => {
    if (!user) throw new Error('User not authenticated');

    try {
      console.log('Scheduling interview for candidate:', interviewData.candidateId);

      const { data, error } = await supabase
        .from('interview_schedules')
        .insert({
          application_id: interviewData.applicationId,
          recruiter_bid_id: interviewData.recruiterBidId,
          interviewer_id: user.id,
          candidate_id: interviewData.candidateId,
          interview_type: interviewData.interviewType,
          scheduled_at: interviewData.scheduledAt.toISOString(),
          duration_minutes: interviewData.durationMinutes,
          location: interviewData.location,
          meeting_link: interviewData.meetingLink,
          notes: interviewData.notes,
        })
        .select()
        .single();

      if (error) throw error;

      console.log('Interview scheduled successfully:', data.id);

      // Create notification for candidate
      try {
        const { error: notifError } = await supabase
          .from('notifications')
          .insert({
            user_id: interviewData.candidateId,
            type: 'interview_scheduled',
            title: 'Interview Scheduled',
            message: `You have an interview scheduled for ${interviewData.scheduledAt.toLocaleDateString()} at ${interviewData.scheduledAt.toLocaleTimeString()}`,
            data: {
              interview_id: data.id,
              interview_type: interviewData.interviewType,
              scheduled_at: interviewData.scheduledAt.toISOString(),
              meeting_link: interviewData.meetingLink,
              location: interviewData.location,
            },
            read: false,
          });

        if (notifError) {
          console.error('Error creating notification:', notifError);
        }
      } catch (notifError) {
        console.error('Error creating notification:', notifError);
      }

      // Trigger workflow automation for scheduled interview
      try {
        await triggerWorkflow(
          'interview_scheduled',
          'interview',
          data.id,
          {
            interview_id: data.id,
            candidate_id: interviewData.candidateId,
            interviewer_id: user.id,
            interview_type: interviewData.interviewType,
            scheduled_at: interviewData.scheduledAt.toISOString(),
          }
        );
        console.log('Interview scheduling workflow triggered successfully');
      } catch (workflowError) {
        console.error('Error triggering interview workflow:', workflowError);
      }

      // Trigger payment milestone if this is from a recruiter bid
      if (interviewData.recruiterBidId) {
        try {
          const { data: milestoneData, error: milestoneError } = await supabase.functions.invoke(
            'trigger-payment-milestones',
            {
              body: {
                trigger: 'interview_scheduled',
                recruiterBidId: interviewData.recruiterBidId,
                applicationId: interviewData.applicationId,
                interviewId: data.id,
                notes: 'Interview scheduled successfully',
              },
            }
          );

          if (milestoneError) {
            console.error('Error triggering payment milestone:', milestoneError);
          } else {
            console.log('Payment milestone triggered:', milestoneData);
          }
        } catch (milestoneError) {
          console.error('Error triggering payment milestone:', milestoneError);
        }
      }

      await fetchInterviews();
      return data;
    } catch (err) {
      console.error('Error scheduling interview:', err);
      throw err;
    }
  };

  const updateInterviewStatus = async (interviewId: string, status: Interview['status'], notes?: string) => {
    try {
      console.log('Updating interview status:', interviewId, 'to', status);

      const updateData: any = {
        status,
        updated_at: new Date().toISOString()
      };

      if (notes) updateData.notes = notes;
      if (status === 'completed') updateData.completed_at = new Date().toISOString();

      const { data: interview, error } = await supabase
        .from('interview_schedules')
        .update(updateData)
        .eq('id', interviewId)
        .select('candidate_id, interviewer_id')
        .single();

      if (error) throw error;

      // Create notification for status changes
      if (interview && status === 'confirmed') {
        try {
          await supabase.from('notifications').insert({
            user_id: interview.interviewer_id,
            type: 'interview_confirmed',
            title: 'Interview Confirmed',
            message: 'A candidate has confirmed their interview',
            data: { interview_id: interviewId },
            read: false,
          });
        } catch (notifError) {
          console.error('Error creating notification:', notifError);
        }
      } else if (interview && status === 'cancelled') {
        try {
          await supabase.from('notifications').insert({
            user_id: user?.role === 'candidate' ? interview.interviewer_id : interview.candidate_id,
            type: 'interview_cancelled',
            title: 'Interview Cancelled',
            message: 'An interview has been cancelled',
            data: { interview_id: interviewId, notes },
            read: false,
          });
        } catch (notifError) {
          console.error('Error creating notification:', notifError);
        }
      }

      await fetchInterviews();
    } catch (err) {
      console.error('Error updating interview status:', err);
      throw err;
    }
  };

  const rescheduleInterview = async (interviewId: string, newDateTime: Date, reason?: string) => {
    try {
      console.log('Rescheduling interview:', interviewId, 'to', newDateTime);

      const { data: interview, error } = await supabase
        .from('interview_schedules')
        .update({
          scheduled_at: newDateTime.toISOString(),
          status: 'rescheduled',
          notes: reason,
          updated_at: new Date().toISOString(),
        })
        .eq('id', interviewId)
        .select('candidate_id, interviewer_id')
        .single();

      if (error) throw error;

      // Notify the other party about reschedule
      if (interview) {
        try {
          const recipientId = user?.role === 'candidate' ? interview.interviewer_id : interview.candidate_id;
          await supabase.from('notifications').insert({
            user_id: recipientId,
            type: 'interview_rescheduled',
            title: 'Interview Rescheduled',
            message: `An interview has been rescheduled to ${newDateTime.toLocaleDateString()} at ${newDateTime.toLocaleTimeString()}`,
            data: { interview_id: interviewId, new_time: newDateTime.toISOString(), reason },
            read: false,
          });
        } catch (notifError) {
          console.error('Error creating notification:', notifError);
        }
      }

      await fetchInterviews();
    } catch (err) {
      console.error('Error rescheduling interview:', err);
      throw err;
    }
  };

  const addInterviewFeedback = async (interviewId: string, feedback: any) => {
    try {
      console.log('Adding interview feedback for:', interviewId);

      const { error } = await supabase
        .from('interview_schedules')
        .update({
          feedback,
          status: 'completed',
          updated_at: new Date().toISOString(),
        })
        .eq('id', interviewId);

      if (error) throw error;

      await fetchInterviews();
    } catch (err) {
      console.error('Error adding interview feedback:', err);
      throw err;
    }
  };

  useEffect(() => {
    if (user) {
      fetchInterviews();
    }
  }, [user]);

  return {
    interviews,
    loading,
    error,
    scheduleInterview,
    updateInterviewStatus,
    rescheduleInterview,
    addInterviewFeedback,
    refetch: fetchInterviews,
  };
};