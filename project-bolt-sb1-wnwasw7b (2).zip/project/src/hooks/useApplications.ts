import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useWorkflows } from './useWorkflows';
import type { Application } from '../types';

export const useApplications = () => {
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();
  const { triggerWorkflow } = useWorkflows();

  const fetchApplications = async () => {
    try {
      setLoading(true);
      setError(null);
      
      console.log('Fetching applications for user role:', user?.role);

      let query = supabase
        .from('applications')
        .select(`
          *,
          jobs!applications_job_id_fkey (
            id,
            title,
            organization_id,
            organizations!jobs_organization_id_fkey (
              name
            )
          )
        `);

      // Filter based on user role
      if (user?.role === 'candidate') {
        query = query.eq('candidate_id', user.id);
      } else if (user?.role === 'employer') {
        // Get applications for jobs belonging to user's organization
        if (!user.organizationId) {
          setApplications([]);
          setLoading(false);
          return;
        }
        
        // First get job IDs for this organization
        const { data: jobIds, error: jobError } = await supabase
          .from('jobs')
          .select('id')
          .eq('organization_id', user.organizationId);

        if (jobError) throw jobError;

        if (jobIds && jobIds.length > 0) {
          query = query.in('job_id', jobIds.map(job => job.id));
        } else {
          setApplications([]);
          setLoading(false);
          return;
        }
      }

      const { data, error: fetchError } = await query.order('created_at', { ascending: false });

      if (fetchError) {
        console.error('Error fetching applications:', fetchError);
        throw fetchError;
      }

      console.log('Applications fetched successfully:', data?.length || 0);

      const transformedApplications: Application[] = (data || []).map(app => ({
        id: app.id,
        jobId: app.job_id,
        candidateId: app.candidate_id,
        candidateName: app.candidate_name,
        candidateEmail: app.candidate_email,
        source: app.source,
        status: app.status,
        recruiterBidId: app.recruiter_bid_id,
        resumeUrl: app.resume_url,
        resumeFileName: app.resume_file_name,
        coverLetter: app.cover_letter,
        phone: app.phone,
        location: app.location,
        salaryExpectation: app.salary_expectation,
        availabilityDate: app.availability_date ? new Date(app.availability_date) : undefined,
        workAuthorization: app.work_authorization,
        willingToRelocate: app.willing_to_relocate,
        additionalInfo: app.additional_info,
        interviewDecision: app.interview_decision,
        decisionNotes: app.decision_notes,
        decisionMadeAt: app.decision_made_at ? new Date(app.decision_made_at) : undefined,
        decisionMadeBy: app.decision_made_by,
        shortlist_notes: app.shortlist_notes,
        shortlisted_at: app.shortlisted_at ? new Date(app.shortlisted_at) : undefined,
        shortlisted_by: app.shortlisted_by,
        createdAt: new Date(app.created_at),
        // Non-typed convenience fields for UI (from joined jobs table)
        ...(app.jobs ? {
          jobTitle: app.jobs.title,
          organizationName: app.jobs.organizations?.name,
          jobLocation: (app.jobs as any).location,
        } : {}),
      } as any));

      setApplications(transformedApplications);
    } catch (err) {
      console.error('Error fetching applications:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch applications');
    } finally {
      setLoading(false);
    }
  };

  const createApplication = async (applicationData: any) => {
    try {
      console.log('Creating application for job:', applicationData.jobId);
      
      // TODO: Handle file upload for resume
      let resumeUrl = null;
      if (applicationData.resume) {
        // For now, we'll skip file upload and just store the filename
        resumeUrl = applicationData.resume.name;
      }

      const { data, error } = await supabase
        .from('applications')
        .insert({
          job_id: applicationData.jobId,
          candidate_id: applicationData.candidateId,
          candidate_name: applicationData.candidateName,
          candidate_email: applicationData.candidateEmail,
          source: applicationData.source,
          status: applicationData.status,
          recruiter_bid_id: applicationData.recruiterBidId || null,
          cover_letter: applicationData.coverLetter,
          phone: applicationData.phone,
          location: applicationData.location,
          salary_expectation: applicationData.salaryExpectation,
          availability_date: applicationData.availabilityDate,
          work_authorization: applicationData.workAuthorization,
          willing_to_relocate: applicationData.willingToRelocate,
          additional_info: applicationData.additionalInfo,
          resume_url: applicationData.resumeUrl,
        })
        .select()
        .single();

      if (error) {
        console.error('Error creating application:', error);
        throw error;
      }

      console.log('Application created successfully:', data.id);
      
      // Trigger workflow automation for new application
      try {
        await triggerWorkflow(
          'application_received',
          'application',
          data.id,
          {
            job_id: applicationData.jobId,
            candidate_id: applicationData.candidateId,
            job_title: 'Job Application', // Would get from job data
          }
        );
        console.log('Application workflow triggered successfully');
      } catch (workflowError) {
        console.error('Error triggering application workflow:', workflowError);
        // Don't fail the application creation if workflow fails
      }
      
      // Refresh applications list
      await fetchApplications();
      return data;
    } catch (err) {
      console.error('Error creating application:', err);
      throw err;
    }
  };

  const updateApplicationStatus = async (
    applicationId: string,
    status: string,
    options?: {
      shortlistNotes?: string;
      decisionNotes?: string;
      notifyCandidate?: boolean;
    }
  ) => {
    if (!user) throw new Error('User not authenticated');

    try {
      const updateData: any = { status };

      if (status === 'shortlisted' && options?.shortlistNotes) {
        updateData.shortlist_notes = options.shortlistNotes;
        updateData.shortlisted_at = new Date().toISOString();
        updateData.shortlisted_by = user.id;
      }

      if (status === 'rejected' && options?.decisionNotes) {
        updateData.decision_notes = options.decisionNotes;
        updateData.decision_made_at = new Date().toISOString();
        updateData.decision_made_by = user.id;
      }

      const { data: application, error } = await supabase
        .from('applications')
        .update(updateData)
        .eq('id', applicationId)
        .select('candidate_id, job_id')
        .single();

      if (error) {
        throw error;
      }

      if (options?.notifyCandidate && application) {
        try {
          const notificationMap: Record<string, { title: string; message: string; type: string }> = {
            shortlisted: {
              title: 'Application Shortlisted',
              message: 'Good news! Your application has been shortlisted. The employer will be in touch soon.',
              type: 'application_shortlisted',
            },
            rejected: {
              title: 'Application Update',
              message: 'Thank you for your interest. After careful consideration, we have decided to move forward with other candidates.',
              type: 'application_rejected',
            },
          };

          const notif = notificationMap[status];
          if (notif) {
            await supabase.from('notifications').insert({
              user_id: application.candidate_id,
              type: notif.type,
              title: notif.title,
              message: notif.message,
              data: {
                application_id: applicationId,
                job_id: application.job_id,
                status,
              },
              read: false,
            });
          }
        } catch (notifError) {
          console.error('Error sending notification:', notifError);
        }
      }

      await fetchApplications();
    } catch (err) {
      console.error('Error updating application status:', err);
      throw err;
    }
  };

  const updateApplicationWithDecision = async (
    applicationId: string,
    decision: 'accepted' | 'rejected' | 'offer_extended',
    decisionNotes: string
  ) => {
    if (!user) throw new Error('User not authenticated');

    try {
      console.log('Recording interview decision for application:', applicationId);

      const statusMap = {
        accepted: 'shortlisted',
        rejected: 'rejected',
        offer_extended: 'hired',
      };

      const { data: application, error: updateError } = await supabase
        .from('applications')
        .update({
          interview_decision: decision,
          decision_notes: decisionNotes,
          decision_made_at: new Date().toISOString(),
          decision_made_by: user.id,
          status: statusMap[decision],
          onboarding_status: decision === 'offer_extended' ? 'offer_extended' : undefined,
        })
        .eq('id', applicationId)
        .select('candidate_id, job_id, candidate_name, candidate_email, recruiter_bid_id')
        .single();

      if (updateError) throw updateError;

      console.log('Application decision recorded successfully');

      if (decision === 'offer_extended') {
        try {
          const { data: existingSelection } = await supabase
            .from('candidate_selections')
            .select('id')
            .eq('job_id', application.job_id)
            .maybeSingle();

          if (!existingSelection) {
            const { error: selectionError } = await supabase
              .from('candidate_selections')
              .insert({
                job_id: application.job_id,
                application_id: applicationId,
                recruiter_bid_id: application.recruiter_bid_id,
                selected_by: user.id,
                offer_extended_date: new Date().toISOString(),
                onboarding_status: 'offer_extended',
              });

            if (selectionError) {
              console.error('Error creating candidate selection:', selectionError);
            } else {
              console.log('Candidate selection record created successfully');
            }

            await supabase
              .from('jobs')
              .update({ status: 'filled' })
              .eq('id', application.job_id);

            console.log('Job status updated to filled');
          }
        } catch (selectionError) {
          console.error('Error handling candidate selection:', selectionError);
        }
      }

      try {
        const notificationMessages = {
          accepted: 'Your application has been accepted! The employer will be in touch with next steps.',
          rejected: 'Thank you for your interest. After careful consideration, we have decided to move forward with other candidates.',
          offer_extended: 'Congratulations! We are pleased to extend you a job offer. Please check your email for details.',
        };

        const notificationTitles = {
          accepted: 'Application Accepted',
          rejected: 'Application Update',
          offer_extended: 'Job Offer Extended',
        };

        await supabase.from('notifications').insert({
          user_id: application.candidate_id,
          type: decision === 'rejected' ? 'application_rejected' : 'application_accepted',
          title: notificationTitles[decision],
          message: notificationMessages[decision],
          data: {
            application_id: applicationId,
            job_id: application.job_id,
            decision,
          },
          read: false,
        });

        console.log('Decision notification sent to candidate');
      } catch (notifError) {
        console.error('Error creating notification:', notifError);
      }

      try {
        await triggerWorkflow(
          decision === 'rejected' ? 'application_rejected' : 'application_accepted',
          'application',
          applicationId,
          {
            application_id: applicationId,
            candidate_id: application.candidate_id,
            job_id: application.job_id,
            decision,
            decision_notes: decisionNotes,
          }
        );
        console.log('Decision workflow triggered successfully');
      } catch (workflowError) {
        console.error('Error triggering decision workflow:', workflowError);
      }

      if (decision === 'offer_extended') {
        const appData = await supabase
          .from('applications')
          .select('recruiter_bid_id')
          .eq('id', applicationId)
          .single();

        if (appData.data?.recruiter_bid_id) {
          try {
            const { data: milestoneData, error: milestoneError } = await supabase.functions.invoke(
              'trigger-payment-milestones',
              {
                body: {
                  trigger: 'candidate_hired',
                  recruiterBidId: appData.data.recruiter_bid_id,
                  applicationId: applicationId,
                  notes: 'Candidate hired - offer extended',
                },
              }
            );

            if (milestoneError) {
              console.error('Error triggering payment milestone:', milestoneError);
            } else {
              console.log('Payment milestone triggered for hire:', milestoneData);
            }
          } catch (milestoneError) {
            console.error('Error triggering payment milestone:', milestoneError);
          }
        }
      }

      await fetchApplications();
      return application;
    } catch (err) {
      console.error('Error recording application decision:', err);
      throw err;
    }
  };

  useEffect(() => {
    if (user) {
      fetchApplications();
    }
  }, [user]);

  return {
    applications,
    loading,
    error,
    refetch: fetchApplications,
    createApplication,
    updateApplicationStatus,
    updateApplicationWithDecision,
  };
};
