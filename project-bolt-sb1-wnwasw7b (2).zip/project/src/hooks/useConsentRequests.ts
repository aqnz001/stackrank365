import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import type { Consent } from '../types';

export const useConsentRequests = () => {
  const [consents, setConsents] = useState<Consent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchConsents = async () => {
    try {
      setLoading(true);
      setError(null);
      
      console.log('Fetching consent requests for user role:', user?.role);

      let query = supabase
        .from('consent_requests')
        .select(`
          *,
          jobs!consent_requests_job_id_fkey (
            id,
            title
          ),
          candidate:profiles!consent_requests_candidate_id_fkey (
            id,
            name,
            email
          ),
          recruiter:profiles!consent_requests_recruiter_id_fkey (
            id,
            name,
            organizations!profiles_organization_id_fkey (
              name
            )
          )
        `);

      // Filter based on user role
      if (user?.role === 'candidate') {
        query = query.eq('candidate_id', user.id);
      } else if (user?.role === 'recruiter') {
        query = query.eq('recruiter_id', user.id);
      }

      const { data, error: fetchError } = await query.order('created_at', { ascending: false });

      if (fetchError) {
        console.error('Error fetching consent requests:', fetchError);
        throw fetchError;
      }

      console.log('Consent requests fetched successfully:', data?.length || 0);

      const transformedConsents: Consent[] = (data || []).map(consent => ({
        id: consent.id,
        candidateId: consent.candidate_id,
        candidateName: consent.candidate_name || consent.candidate?.name || undefined,
        candidateEmail: consent.candidate_email || consent.candidate?.email || undefined,
        recruiterId: consent.recruiter_id,
        jobId: consent.job_id,
        jobTitle: consent.jobs?.title || 'Unknown Job',
        recruiterName: consent.recruiter?.name || 'Unknown Recruiter',
        recruiterCompany: consent.recruiter?.organizations?.name || 'Unknown Company',
        status: consent.status,
        message: consent.message,
        requestedAt: new Date(consent.requested_at),
        respondedAt: consent.responded_at ? new Date(consent.responded_at) : undefined,
      }));

      setConsents(transformedConsents);
    } catch (err) {
      console.error('Error fetching consent requests:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch consent requests');
    } finally {
      setLoading(false);
    }
  };

  const createConsentRequest = async (consentData: {
    candidateId: string;
    candidateName?: string;
    candidateEmail?: string;
    jobId: string;
    message?: string;
  }) => {
    if (!user?.id) {
      throw new Error('User not authenticated');
    }

    try {
      console.log('Creating consent request for candidate:', consentData.candidateId);

      const { data, error } = await supabase
        .from('consent_requests')
        .insert({
          candidate_id: consentData.candidateId,
          candidate_name: consentData.candidateName || null,
          candidate_email: consentData.candidateEmail || null,
          recruiter_id: user.id,
          job_id: consentData.jobId,
          message: consentData.message,
          status: 'requested',
        })
        .select()
        .single();

      if (error) {
        console.error('Error creating consent request:', error);
        throw error;
      }

      console.log('Consent request created successfully:', data.id);
      
      // Refresh consents list
      await fetchConsents();
      return data;
    } catch (err) {
      console.error('Error creating consent request:', err);
      throw err;
    }
  };

  const updateConsentStatus = async (consentId: string, status: 'approved' | 'declined' | 'revoked') => {
    try {
      const { error } = await supabase
        .from('consent_requests')
        .update({ 
          status,
          responded_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .eq('id', consentId);

      if (error) {
        throw error;
      }

      // Refresh consents list
      await fetchConsents();
    } catch (err) {
      console.error('Error updating consent status:', err);
      throw err;
    }
  };

  const approveConsent = async (consentId: string) => {
    try {
      await updateConsentStatus(consentId, 'approved');
    } catch (err) {
      console.error('Error approving consent:', err);
      throw err;
    }
  };

  const declineConsent = async (consentId: string) => {
    try {
      await updateConsentStatus(consentId, 'declined');
    } catch (err) {
      console.error('Error declining consent:', err);
      throw err;
    }
  };

  const blockRecruiter = async (consentId: string) => {
    try {
      await updateConsentStatus(consentId, 'blocked' as any);
    } catch (err) {
      console.error('Error blocking recruiter:', err);
      throw err;
    }
  };

  const inviteCandidate = async (invite: { email: string; jobId: string; message?: string }) => {
    if (!user?.id) throw new Error('User not authenticated');
    // Best-effort insert to 'candidate_invites' if table exists; otherwise log
    try {
      const { error } = await supabase.from('candidate_invites').insert({
        recruiter_id: user.id,
        email: invite.email,
        job_id: invite.jobId,
        message: invite.message,
        status: 'sent',
      });
      if (error) throw error;
      return true;
    } catch (e) {
      console.warn('Invite table missing, falling back to console log:', e);
      console.log('Invite candidate', invite.email, 'for job', invite.jobId, 'message', invite.message);
      return true;
    }
  };

  const revokeConsent = async (consentId: string) => {
    try {
      await updateConsentStatus(consentId, 'revoked');
    } catch (err) {
      console.error('Error revoking consent:', err);
      throw err;
    }
  };

  useEffect(() => {
    if (user) {
      fetchConsents();
    }
  }, [user]);

  return {
    consents,
    loading,
    error,
    refetch: fetchConsents,
    createConsentRequest,
    approveConsent,
    declineConsent,
    revokeConsent,
    blockRecruiter,
    inviteCandidate,
  };
};
