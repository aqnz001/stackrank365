import { useEffect, useMemo, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';

export interface RecruiterProfile {
  companyName: string;
  website?: string;
  registrationNumber?: string;
  about?: string;
  logoPath?: string;
  logoUrl?: string;
  publishProfile?: boolean;
  addressLine1?: string;
  city?: string;
  country?: string;
  postalCode?: string;
  contactName?: string;
  contactEmail?: string;
  contactPhone?: string;
  publishEmail?: boolean;
  documents?: Array<{ id: string; name: string; path?: string; url?: string; type?: string }>;
  acceptedTerms?: boolean;
  acceptedAt?: string;
  bankStatus?: 'pending' | 'verified' | 'missing';
  // Banking details (required for submission)
  bankName?: string;
  bankAccountNumber?: string;
  bankAccountHolderName?: string;
  bankAddressLine1?: string;
  bankAddressLine2?: string;
  bankAccountHolderAddressLine1?: string;
  bankAccountHolderAddressLine2?: string;
  bankAccountHolderAddressLine3?: string;
  branchName?: string;
  bankAccountCountry?: string;
  currency?: string;
  clearingCode?: string;
  iban?: string;
  swiftCode?: string;
}

const keyFor = (userId: string) => `recruiter_profile:${userId}`;

let serverSupportedFlag: boolean | null = null;

export const useRecruiterProfile = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<RecruiterProfile | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Default to using server storage unless explicitly disabled via env
  const useServer = (import.meta as any).env?.VITE_USE_SUPABASE_PROFILES !== 'false';

  const fetch = async () => {
    if (!user) return;
    setLoading(true);
    setError(null);
    try {
      // Try server-side profile if supported
      if (useServer && serverSupportedFlag !== false) {
        const { data, error } = await supabase
          .from('recruiter_profiles')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();
        if (!error && data) {
          setProfile(data.profile_json as RecruiterProfile);
          setLoading(false);
          return;
        } else if (error && (error as any).code === 'PGRST205') {
          // Table not found
          serverSupportedFlag = false;
        } else if (error && (error as any).code && (error as any).code !== 'PGRST116') {
          // Unexpected error other than no rows
          throw error;
        }
      }

      // Fallback to localStorage for existing data
      const raw = localStorage.getItem(keyFor(user.id));
      if (raw) {
        const localProfile = JSON.parse(raw);
        setProfile(localProfile);
        
        // Attempt migration to database if supported
        if (useServer && serverSupportedFlag !== false) {
          try {
            await supabase
              .from('recruiter_profiles')
              .insert({ user_id: user.id, profile_json: localProfile });
            // Remove from localStorage after successful migration
            localStorage.removeItem(keyFor(user.id));
          } catch (migrationError: any) {
            if (migrationError?.code === 'PGRST205') serverSupportedFlag = false;
          }
        }
      } else {
        setProfile(null);
      }
    } catch (fetchError) {
      console.error('Error fetching recruiter profile:', fetchError);
      setError(fetchError instanceof Error ? fetchError.message : 'Failed to fetch profile');
      setProfile(null);
    } finally {
      setLoading(false);
    }
  };

  const save = async (p: RecruiterProfile) => {
    if (!user) return;
    console.log('Saving recruiter profile:', p);
    setProfile(p);
    
    try {
      if (useServer && serverSupportedFlag !== false) {
        const { error } = await supabase
          .from('recruiter_profiles')
          .upsert({ user_id: user.id, profile_json: p }, { onConflict: 'user_id' });
        if (error) {
          if ((error as any).code === 'PGRST205') serverSupportedFlag = false;
          throw error;
        }
        // Remove local copy if DB save succeeds
        localStorage.removeItem(keyFor(user.id));
      } else {
        localStorage.setItem(keyFor(user.id), JSON.stringify(p));
      }
    } catch {
      // Fallback to localStorage if database save fails
      localStorage.setItem(keyFor(user.id), JSON.stringify(p));
    }
  };

  const isComplete = useMemo(() => {
    const p = profile;
    if (!p) return false;
    
    // Required fields for completion
    const hasCompanyName = !!p.companyName?.trim();
    const hasContactEmail = !!p.contactEmail?.trim();
    const hasContactName = !!p.contactName?.trim();
    const hasAddress = !!(p.addressLine1?.trim() && p.city?.trim() && p.country?.trim());
    const hasAcceptedTerms = !!(p.acceptedTerms && p.acceptedAt);
    const hasDocuments = !!(p.documents && p.documents.length > 0);
    const hasBanking = !!(
      p.bankName?.trim() &&
      p.bankAccountNumber?.trim() &&
      p.bankAccountHolderName?.trim() &&
      p.branchName?.trim()
    );
    
    console.log('Profile completion check:', {
      hasCompanyName,
      hasContactEmail,
      hasContactName,
      hasAddress,
      hasAcceptedTerms,
      hasDocuments,
      hasBanking
    });
    
    return hasCompanyName && hasContactEmail && hasContactName && hasAddress && hasDocuments && hasBanking && hasAcceptedTerms;
  }, [profile]);

  useEffect(() => { fetch(); }, [user?.id]);

  return { profile, save, isComplete, loading, error, refetch: fetch } as const;
};
