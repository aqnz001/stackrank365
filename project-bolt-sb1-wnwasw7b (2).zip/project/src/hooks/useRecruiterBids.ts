import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useWorkflows } from './useWorkflows';
import type { RecruiterBid } from '../types';

export const useRecruiterBids = () => {
  const [bids, setBids] = useState<RecruiterBid[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();
  const { triggerWorkflow } = useWorkflows();

  const fetchBids = async () => {
    try {
      setLoading(true);
      setError(null);
      
      console.log('Fetching recruiter bids for user role:', user?.role);

      let query = supabase
        .from('recruiter_bids')
        .select(`
          *,
          jobs!recruiter_bids_job_id_fkey (
            id,
            title,
            organization_id,
            organizations!jobs_organization_id_fkey (
              name
            )
          ),
          profiles!recruiter_bids_recruiter_id_fkey (
            id,
            name,
            organizations!profiles_organization_id_fkey (
              name
            )
          )
        `);

      // Filter based on user role
      if (user?.role === 'recruiter') {
        query = query.eq('recruiter_id', user.id);
      } else if (user?.role === 'employer') {
        // Get bids for jobs belonging to user's organization
        if (!user.organizationId) {
          setBids([]);
          setLoading(false);
          return;
        }
        
        // First get job IDs for this organization
        const { data: jobIds, error: jobError } = await supabase
          .from('jobs')
          .select('id')
          .eq('organization_id', user.organizationId);

        if (jobError) throw jobError;

        if (jobIds && jobIds.length > 0) {
          query = query.in('job_id', jobIds.map(job => job.id));
        } else {
          setBids([]);
          setLoading(false);
          return;
        }
      }

      const { data, error: fetchError } = await query.order('created_at', { ascending: false });

      if (fetchError) {
        console.error('Error fetching recruiter bids:', fetchError);
        throw fetchError;
      }

      console.log('Recruiter bids fetched successfully:', data?.length || 0);

      const transformedBids: RecruiterBid[] = (data || []).map(bid => ({
        id: bid.id,
        jobId: bid.job_id,
        recruiterId: bid.recruiter_id,
        recruiterName: bid.profiles?.name || 'Unknown Recruiter',
        recruiterCompany: bid.profiles?.organizations?.name || 'Unknown Company',
        candidateStub: bid.candidate_stub,
        feeType: bid.fee_type,
        feeValue: parseFloat(bid.fee_value),
        guaranteeDays: bid.guarantee_days,
        status: bid.status,
        revealedCandidate: bid.revealed_candidate,
        acceptedAt: bid.accepted_at ? new Date(bid.accepted_at) : undefined,
        createdAt: new Date(bid.created_at),
      }));

      setBids(transformedBids);
    } catch (err) {
      console.error('Error fetching recruiter bids:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch recruiter bids');
    } finally {
      setLoading(false);
    }
  };

  const createBid = async (bidData: {
    jobId: string;
    candidateStub: any;
    feeType: 'flat' | 'percent';
    feeValue: number;
    guaranteeDays: number;
  }) => {
    if (!user?.id) {
      throw new Error('User not authenticated');
    }

    try {
      console.log('Creating recruiter bid for job:', bidData.jobId);
      
      const { data, error } = await supabase
        .from('recruiter_bids')
        .insert({
          job_id: bidData.jobId,
          recruiter_id: user.id,
          candidate_stub: bidData.candidateStub,
          fee_type: bidData.feeType,
          fee_value: bidData.feeValue,
          guarantee_days: bidData.guaranteeDays,
          status: 'submitted',
        })
        .select()
        .single();

      if (error) {
        console.error('Error creating recruiter bid:', error);
        throw error;
      }

      console.log('Recruiter bid created successfully:', data.id);
      
      // Trigger workflow automation for new bid
      try {
        await triggerWorkflow(
          'bid_submitted',
          'recruiter_bid',
          data.id,
          {
            job_id: bidData.jobId,
            recruiter_id: user.id,
            fee_type: bidData.feeType,
            fee_value: bidData.feeValue,
          }
        );
        console.log('Bid workflow triggered successfully');
      } catch (workflowError) {
        console.error('Error triggering bid workflow:', workflowError);
        // Don't fail the bid creation if workflow fails
      }
      
      // Refresh bids list
      await fetchBids();
      return data;
    } catch (err) {
      console.error('Error creating recruiter bid:', err);
      throw err;
    }
  };

  const updateBidStatus = async (bidId: string, status: string, revealedCandidate?: any) => {
    try {
      const updateData: any = { 
        status,
        updated_at: new Date().toISOString()
      };
      
      if (status === 'accepted') {
        updateData.accepted_at = new Date().toISOString();
        if (revealedCandidate) {
          updateData.revealed_candidate = revealedCandidate;
        }
        
        // Trigger workflow automation for accepted bid
        try {
          await triggerWorkflow(
            'bid_accepted',
            'recruiter_bid',
            bidId,
            {
              bid_id: bidId,
              recruiter_id: user?.id,
              revealed_candidate: revealedCandidate,
            }
          );
          console.log('Bid acceptance workflow triggered successfully');
        } catch (workflowError) {
          console.error('Error triggering bid acceptance workflow:', workflowError);
          // Don't fail the status update if workflow fails
        }
      }

      const { error } = await supabase
        .from('recruiter_bids')
        .update(updateData)
        .eq('id', bidId);

      if (error) {
        throw error;
      }

      // Refresh bids list
      await fetchBids();
    } catch (err) {
      console.error('Error updating bid status:', err);
      throw err;
    }
  };

  const withdrawBid = async (bidId: string) => {
    try {
      await updateBidStatus(bidId, 'withdrawn');
    } catch (err) {
      console.error('Error withdrawing bid:', err);
      throw err;
    }
  };

  useEffect(() => {
    if (user) {
      fetchBids();
    }
  }, [user]);

  return {
    bids,
    loading,
    error,
    refetch: fetchBids,
    createBid,
    updateBidStatus,
    withdrawBid,
  };
};