import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export interface DraftApplicationData {
  step: number;
  useSaved: boolean;
  selectedResumeId: string;
  uploadedResumeData?: {
    id: string;
    name: string;
    url: string;
    path: string;
  } | null;
  formData: {
    coverLetter: string;
    phone: string;
    location: string;
    salaryExpectation: string;
    availabilityDate: string;
    workAuthorization: string;
    willingToRelocate: string;
    additionalInfo: string;
  };
}

export interface DraftApplication {
  id: string;
  candidateId: string;
  jobId: string;
  draftData: DraftApplicationData;
  lastSavedStep: number;
  createdAt: string;
  updatedAt: string;
}

export function useDraftApplications(candidateId?: string) {
  const [drafts, setDrafts] = useState<DraftApplication[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (candidateId) {
      fetchDrafts(candidateId);
    } else {
      setDrafts([]);
    }
  }, [candidateId]);

  const fetchDrafts = async (candId: string) => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('draft_applications')
        .select('*')
        .eq('candidate_id', candId)
        .order('updated_at', { ascending: false });

      if (fetchError) {
        throw fetchError;
      }

      const mappedDrafts: DraftApplication[] = (data || []).map((item) => ({
        id: item.id,
        candidateId: item.candidate_id,
        jobId: item.job_id,
        draftData: item.draft_data,
        lastSavedStep: item.last_saved_step,
        createdAt: item.created_at,
        updatedAt: item.updated_at,
      }));

      setDrafts(mappedDrafts);
    } catch (err: any) {
      console.error('Error fetching draft applications:', err);
      setError(err.message || 'Failed to fetch draft applications');
      setDrafts([]);
    } finally {
      setLoading(false);
    }
  };

  const getDraftForJob = async (jobId: string, candId: string): Promise<DraftApplication | null> => {
    try {
      const { data, error: fetchError } = await supabase
        .from('draft_applications')
        .select('*')
        .eq('candidate_id', candId)
        .eq('job_id', jobId)
        .maybeSingle();

      if (fetchError) {
        throw fetchError;
      }

      if (!data) return null;

      return {
        id: data.id,
        candidateId: data.candidate_id,
        jobId: data.job_id,
        draftData: data.draft_data,
        lastSavedStep: data.last_saved_step,
        createdAt: data.created_at,
        updatedAt: data.updated_at,
      };
    } catch (err: any) {
      console.error('Error fetching draft for job:', err);
      return null;
    }
  };

  const saveDraft = async (
    jobId: string,
    candId: string,
    draftData: DraftApplicationData,
    currentStep: number
  ): Promise<DraftApplication | null> => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: upsertError } = await supabase
        .from('draft_applications')
        .upsert(
          {
            candidate_id: candId,
            job_id: jobId,
            draft_data: draftData,
            last_saved_step: currentStep,
          },
          {
            onConflict: 'candidate_id,job_id',
          }
        )
        .select()
        .single();

      if (upsertError) {
        throw upsertError;
      }

      const savedDraft: DraftApplication = {
        id: data.id,
        candidateId: data.candidate_id,
        jobId: data.job_id,
        draftData: data.draft_data,
        lastSavedStep: data.last_saved_step,
        createdAt: data.created_at,
        updatedAt: data.updated_at,
      };

      setDrafts((prev) => {
        const existing = prev.findIndex((d) => d.jobId === jobId);
        if (existing >= 0) {
          const updated = [...prev];
          updated[existing] = savedDraft;
          return updated;
        }
        return [savedDraft, ...prev];
      });

      return savedDraft;
    } catch (err: any) {
      console.error('Error saving draft application:', err);
      setError(err.message || 'Failed to save draft application');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const deleteDraft = async (draftId: string): Promise<boolean> => {
    try {
      setLoading(true);
      setError(null);

      const { error: deleteError } = await supabase
        .from('draft_applications')
        .delete()
        .eq('id', draftId);

      if (deleteError) {
        throw deleteError;
      }

      setDrafts((prev) => prev.filter((d) => d.id !== draftId));
      return true;
    } catch (err: any) {
      console.error('Error deleting draft application:', err);
      setError(err.message || 'Failed to delete draft application');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const deleteDraftForJob = async (jobId: string, candId: string): Promise<boolean> => {
    try {
      const { error: deleteError } = await supabase
        .from('draft_applications')
        .delete()
        .eq('candidate_id', candId)
        .eq('job_id', jobId);

      if (deleteError) {
        throw deleteError;
      }

      setDrafts((prev) => prev.filter((d) => d.jobId !== jobId));
      return true;
    } catch (err: any) {
      console.error('Error deleting draft for job:', err);
      return false;
    }
  };

  const refetch = async () => {
    if (candidateId) {
      await fetchDrafts(candidateId);
    }
  };

  return {
    drafts,
    loading,
    error,
    getDraftForJob,
    saveDraft,
    deleteDraft,
    deleteDraftForJob,
    refetch,
  };
}
