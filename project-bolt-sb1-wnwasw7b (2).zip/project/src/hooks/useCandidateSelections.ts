import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

export interface CandidateSelection {
  id: string;
  jobId: string;
  applicationId: string;
  recruiterBidId?: string;
  selectedBy: string;
  offerExtendedDate?: Date;
  startDate?: Date;
  onboardingStatus: 'offer_extended' | 'offer_accepted' | 'onboarding' | 'active' | 'completed';
  onboardingNotes?: string;
  createdAt: Date;
  updatedAt: Date;
  candidateName?: string;
  jobTitle?: string;
}

export const useCandidateSelections = (jobId?: string) => {
  const [selections, setSelections] = useState<CandidateSelection[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchSelections = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      let query = supabase
        .from('candidate_selections')
        .select(`
          *,
          applications!candidate_selections_application_id_fkey (
            candidate_name,
            jobs!applications_job_id_fkey (
              title
            )
          )
        `)
        .order('created_at', { ascending: false });

      if (jobId) {
        query = query.eq('job_id', jobId);
      }

      const { data, error: fetchError } = await query;

      if (fetchError) throw fetchError;

      const transformedSelections: CandidateSelection[] = (data || []).map(selection => ({
        id: selection.id,
        jobId: selection.job_id,
        applicationId: selection.application_id,
        recruiterBidId: selection.recruiter_bid_id,
        selectedBy: selection.selected_by,
        offerExtendedDate: selection.offer_extended_date ? new Date(selection.offer_extended_date) : undefined,
        startDate: selection.start_date ? new Date(selection.start_date) : undefined,
        onboardingStatus: selection.onboarding_status,
        onboardingNotes: selection.onboarding_notes,
        createdAt: new Date(selection.created_at),
        updatedAt: new Date(selection.updated_at),
        candidateName: selection.applications?.candidate_name,
        jobTitle: selection.applications?.jobs?.title,
      }));

      setSelections(transformedSelections);
    } catch (err) {
      console.error('Error fetching candidate selections:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch candidate selections');
    } finally {
      setLoading(false);
    }
  }, [jobId]);

  const selectCandidate = async (selectionData: {
    jobId: string;
    applicationId: string;
    recruiterBidId?: string;
    offerExtendedDate?: Date;
  }) => {
    if (!user) throw new Error('User not authenticated');

    try {
      const { data: existingSelection } = await supabase
        .from('candidate_selections')
        .select('id')
        .eq('job_id', selectionData.jobId)
        .maybeSingle();

      if (existingSelection) {
        throw new Error('A candidate has already been selected for this job');
      }

      const { data, error } = await supabase
        .from('candidate_selections')
        .insert({
          job_id: selectionData.jobId,
          application_id: selectionData.applicationId,
          recruiter_bid_id: selectionData.recruiterBidId,
          selected_by: user.id,
          offer_extended_date: selectionData.offerExtendedDate?.toISOString(),
          onboarding_status: 'offer_extended',
        })
        .select()
        .single();

      if (error) throw error;

      await supabase
        .from('applications')
        .update({
          status: 'hired',
          onboarding_status: 'offer_extended',
        })
        .eq('id', selectionData.applicationId);

      await supabase
        .from('jobs')
        .update({ status: 'filled' })
        .eq('id', selectionData.jobId);

      const { data: application } = await supabase
        .from('applications')
        .select('candidate_id')
        .eq('id', selectionData.applicationId)
        .single();

      if (application) {
        await supabase.from('notifications').insert({
          user_id: application.candidate_id,
          type: 'offer_extended',
          title: 'Job Offer Extended',
          message: 'Congratulations! An employer has extended a job offer to you.',
          data: {
            job_id: selectionData.jobId,
            application_id: selectionData.applicationId,
          },
          read: false,
        });
      }

      if (selectionData.recruiterBidId) {
        try {
          const { data: milestoneData, error: milestoneError } = await supabase.functions.invoke(
            'trigger-payment-milestones',
            {
              body: {
                trigger: 'candidate_hired',
                recruiterBidId: selectionData.recruiterBidId,
                applicationId: selectionData.applicationId,
                notes: 'Candidate has been hired',
              },
            }
          );

          if (milestoneError) {
            console.error('Error triggering payment milestone:', milestoneError);
          } else {
            console.log('Candidate hired milestone triggered:', milestoneData);
          }
        } catch (milestoneError) {
          console.error('Error triggering payment milestone:', milestoneError);
        }
      }

      await fetchSelections();
      return data;
    } catch (err) {
      console.error('Error selecting candidate:', err);
      throw err;
    }
  };

  const updateOnboardingStatus = async (
    selectionId: string,
    status: CandidateSelection['onboardingStatus'],
    notes?: string,
    startDate?: Date
  ) => {
    try {
      const updateData: any = {
        onboarding_status: status,
        updated_at: new Date().toISOString(),
      };

      if (notes) updateData.onboarding_notes = notes;
      if (startDate) updateData.start_date = startDate.toISOString();

      const { error } = await supabase
        .from('candidate_selections')
        .update(updateData)
        .eq('id', selectionId);

      if (error) throw error;

      await fetchSelections();
    } catch (err) {
      console.error('Error updating onboarding status:', err);
      throw err;
    }
  };

  useEffect(() => {
    if (user) {
      fetchSelections();
    }
  }, [user, fetchSelections]);

  return {
    selections,
    loading,
    error,
    refetch: fetchSelections,
    selectCandidate,
    updateOnboardingStatus,
  };
};
