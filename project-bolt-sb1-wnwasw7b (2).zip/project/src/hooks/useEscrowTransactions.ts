import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

export type EscrowStatus = 'initiated' | 'authorized' | 'captured' | 'released' | 'refunded' | 'disputed';

export interface EscrowTxnRecord {
  id: string;
  recruiterBidId: string;
  jobId?: string | null;
  employerOrgId?: string | null;
  employerOrganizationName?: string | null;
  recruiterId?: string | null;
  recruiterCompany?: string | null;
  feeType: 'flat' | 'percent';
  feeValue: number;
  amount?: number | null; // may be null for percent until salary known
  currency?: string | null;
  status: EscrowStatus;
  createdAt: string; // ISO
  updatedAt: string; // ISO
}

const KEY = 'escrow_transactions_v1';

const readAll = (): EscrowTxnRecord[] => {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed as EscrowTxnRecord[];
  } catch {
    return [];
  }
};

const writeAll = (items: EscrowTxnRecord[]) => {
  localStorage.setItem(KEY, JSON.stringify(items));
};

export const useEscrowTransactions = () => {
  const { user } = useAuth();
  const [items, setItems] = useState<EscrowTxnRecord[]>(() => readAll());
  const [remoteReady, setRemoteReady] = useState(false);

  const loadRemote = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('escrow_transactions')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      const mapped: EscrowTxnRecord[] = (data || []).map((r: any) => ({
        id: r.id,
        recruiterBidId: r.recruiter_bid_id,
        jobId: r.job_id,
        employerOrgId: r.employer_org_id,
        employerOrganizationName: r.employer_org_name || null,
        recruiterId: r.recruiter_id || null,
        recruiterCompany: r.recruiter_company || null,
        feeType: r.fee_type,
        feeValue: Number(r.fee_value),
        amount: r.amount !== null ? Number(r.amount) : null,
        currency: r.currency || 'USD',
        status: r.status,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
      }));
      setItems(mapped);
      setRemoteReady(true);
    } catch (e) {
      console.warn('[escrow] remote load failed, using local', e);
      setRemoteReady(false);
      setItems(readAll());
    }
  }, []);

  useEffect(() => {
    if (user) loadRemote();
  }, [user, loadRemote]);

  const persist = useCallback((next: EscrowTxnRecord[]) => {
    setItems(next);
    writeAll(next);
  }, []);

  const createForBid = useCallback(async (input: Omit<EscrowTxnRecord, 'id'|'createdAt'|'updatedAt'|'status'> & { status?: EscrowStatus }) => {
    const now = new Date().toISOString();
    const rec: EscrowTxnRecord = {
      id: crypto.randomUUID(),
      recruiterBidId: input.recruiterBidId,
      jobId: input.jobId || null,
      employerOrgId: input.employerOrgId || null,
      employerOrganizationName: input.employerOrganizationName || null,
      recruiterId: input.recruiterId || null,
      recruiterCompany: input.recruiterCompany || null,
      feeType: input.feeType,
      feeValue: input.feeValue,
      amount: typeof input.amount === 'number' ? input.amount : null,
      currency: input.currency || 'USD',
      status: input.status || 'initiated',
      createdAt: now,
      updatedAt: now,
    };
    // Try remote insert first
    try {
      const { data, error } = await supabase
        .from('escrow_transactions')
        .insert({
          recruiter_bid_id: rec.recruiterBidId,
          job_id: rec.jobId,
          employer_org_id: rec.employerOrgId,
          employer_org_name: rec.employerOrganizationName,
          recruiter_id: rec.recruiterId,
          recruiter_company: rec.recruiterCompany,
          fee_type: rec.feeType,
          fee_value: rec.feeValue,
          amount: rec.amount,
          currency: rec.currency || 'USD',
          status: rec.status,
        })
        .select('*')
        .single();
      if (error) throw error;
      await loadRemote();
      return {
        ...rec,
        id: data.id,
        createdAt: data.created_at,
        updatedAt: data.updated_at,
      } as EscrowTxnRecord;
    } catch (e) {
      console.warn('[escrow] remote insert failed, storing local', e);
      const next = [rec, ...items];
      persist(next);
      return rec;
    }
  }, [items, persist]);

  const updateStatus = useCallback(async (id: string, status: EscrowStatus) => {
    const now = new Date().toISOString();
    try {
      const { error } = await supabase
        .from('escrow_transactions')
        .update({ status, updated_at: now })
        .eq('id', id);
      if (error) throw error;
      await loadRemote();
    } catch (e) {
      console.warn('[escrow] remote update failed, updating local', e);
      const next = items.map(it => it.id === id ? { ...it, status, updatedAt: now } : it);
      persist(next);
    }
  }, [items, persist, loadRemote]);

  return { items, createForBid, updateStatus };
};
