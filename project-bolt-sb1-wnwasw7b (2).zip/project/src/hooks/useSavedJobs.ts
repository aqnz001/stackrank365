import { useCallback, useEffect, useMemo, useState } from 'react';
import { Job } from '../types';
import { useAuth } from '../context/AuthContext';

// Lightweight saved-jobs manager backed by localStorage per-user.
// If a backend table is added later, this can be swapped to Supabase easily.

const storageKeyFor = (userId: string) => `saved_jobs:${userId}`;

export const useSavedJobs = () => {
  const { user } = useAuth();
  const [savedIds, setSavedIds] = useState<string[]>([]);

  // Load on mount or when user changes
  useEffect(() => {
    if (!user) { setSavedIds([]); return; }
    try {
      const raw = localStorage.getItem(storageKeyFor(user.id));
      if (raw) setSavedIds(JSON.parse(raw));
      else setSavedIds([]);
    } catch {
      setSavedIds([]);
    }
  }, [user?.id]);

  const persist = useCallback((ids: string[]) => {
    if (!user) return;
    setSavedIds(ids);
    try {
      localStorage.setItem(storageKeyFor(user.id), JSON.stringify(ids));
    } catch {
      // ignore
    }
  }, [user?.id]);

  const isSaved = useCallback((jobId?: string) => {
    if (!user || !jobId) return false;
    return savedIds.includes(jobId);
  }, [user?.id, savedIds]);

  const save = useCallback((job: Job) => {
    if (!user) return;
    if (!savedIds.includes(job.id)) persist([...savedIds, job.id]);
  }, [user?.id, savedIds, persist]);

  const unsave = useCallback((job: Job) => {
    if (!user) return;
    if (savedIds.includes(job.id)) persist(savedIds.filter(id => id !== job.id));
  }, [user?.id, savedIds, persist]);

  const toggle = useCallback((job: Job) => {
    if (!user) return;
    isSaved(job.id) ? unsave(job) : save(job);
  }, [user?.id, isSaved, save, unsave]);

  return {
    canSave: !!user && user.role === 'candidate',
    ids: savedIds,
    isSaved,
    save,
    unsave,
    toggle,
  } as const;
};

