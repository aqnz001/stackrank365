import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

export interface SavedSearch {
  id: string;
  userId: string;
  name: string;
  searchCriteria: {
    query?: string;
    location?: string;
    employmentType?: string[];
    salaryMin?: number;
    salaryMax?: number;
    skills?: string[];
    adTier?: string[];
    visibility?: string[];
    status?: string[];
  };
  emailAlerts: boolean;
  alertFrequency: 'immediate' | 'daily' | 'weekly';
  lastAlertSent?: Date;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export const useSavedSearches = () => {
  const [savedSearches, setSavedSearches] = useState<SavedSearch[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchSavedSearches = async () => {
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      console.log('Fetching saved searches for user:', user.id);
      
      const { data, error: fetchError } = await supabase
        .from('saved_searches')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;

      console.log('Saved searches fetched:', data?.length || 0);
      
      const transformedSearches: SavedSearch[] = (data || []).map(search => ({
        id: search.id,
        userId: search.user_id,
        name: search.name,
        searchCriteria: search.search_criteria,
        emailAlerts: search.email_alerts,
        alertFrequency: search.alert_frequency,
        lastAlertSent: search.last_alert_sent ? new Date(search.last_alert_sent) : undefined,
        isActive: search.is_active,
        createdAt: new Date(search.created_at),
        updatedAt: new Date(search.updated_at),
      }));

      setSavedSearches(transformedSearches);
    } catch (err) {
      console.error('Error fetching saved searches:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch saved searches');
    } finally {
      setLoading(false);
    }
  };

  const createSavedSearch = async (searchData: {
    name: string;
    searchCriteria: SavedSearch['searchCriteria'];
    emailAlerts?: boolean;
    alertFrequency?: SavedSearch['alertFrequency'];
  }) => {
    if (!user) throw new Error('User not authenticated');

    try {
      console.log('Creating saved search:', searchData.name);
      
      const { data, error } = await supabase
        .from('saved_searches')
        .insert({
          user_id: user.id,
          name: searchData.name,
          search_criteria: searchData.searchCriteria,
          email_alerts: searchData.emailAlerts || false,
          alert_frequency: searchData.alertFrequency || 'daily',
        })
        .select()
        .single();

      if (error) throw error;

      console.log('Saved search created successfully:', data.id);
      await fetchSavedSearches();
      return data;
    } catch (err) {
      console.error('Error creating saved search:', err);
      throw err;
    }
  };

  const updateSavedSearch = async (searchId: string, updates: Partial<SavedSearch>) => {
    try {
      const { error } = await supabase
        .from('saved_searches')
        .update({
          name: updates.name,
          search_criteria: updates.searchCriteria,
          email_alerts: updates.emailAlerts,
          alert_frequency: updates.alertFrequency,
          is_active: updates.isActive,
          updated_at: new Date().toISOString(),
        })
        .eq('id', searchId);

      if (error) throw error;

      await fetchSavedSearches();
    } catch (err) {
      console.error('Error updating saved search:', err);
      throw err;
    }
  };

  const deleteSavedSearch = async (searchId: string) => {
    try {
      const { error } = await supabase
        .from('saved_searches')
        .delete()
        .eq('id', searchId);

      if (error) throw error;

      await fetchSavedSearches();
    } catch (err) {
      console.error('Error deleting saved search:', err);
      throw err;
    }
  };

  const toggleSearchAlerts = async (searchId: string, enabled: boolean) => {
    try {
      await updateSavedSearch(searchId, { emailAlerts: enabled });
    } catch (err) {
      console.error('Error toggling search alerts:', err);
      throw err;
    }
  };

  useEffect(() => {
    fetchSavedSearches();
  }, [user]);

  return {
    savedSearches,
    loading,
    error,
    createSavedSearch,
    updateSavedSearch,
    deleteSavedSearch,
    toggleSearchAlerts,
    refetch: fetchSavedSearches,
  };
};