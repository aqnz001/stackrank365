import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

export interface WorkflowTemplate {
  id: string;
  name: string;
  description?: string;
  category: 'hiring' | 'onboarding' | 'recruitment' | 'compliance';
  triggerEvent: 'application_received' | 'bid_accepted' | 'interview_scheduled' | 'offer_made';
  steps: WorkflowStepTemplate[];
  isActive: boolean;
  organizationId: string;
  createdBy?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface WorkflowStepTemplate {
  stepNumber: number;
  name: string;
  type: 'email' | 'notification' | 'task' | 'delay' | 'condition' | 'approval';
  config: any;
  assignedRole?: string;
  delayDays?: number;
  conditions?: any;
}

export interface WorkflowInstance {
  id: string;
  templateId: string;
  entityType: 'application' | 'recruiter_bid' | 'interview';
  entityId: string;
  status: 'active' | 'completed' | 'paused' | 'cancelled';
  currentStep: number;
  contextData: any;
  startedAt: Date;
  completedAt?: Date;
  createdAt: Date;
  template?: WorkflowTemplate;
  steps?: WorkflowStep[];
}

export interface WorkflowStep {
  id: string;
  workflowInstanceId: string;
  stepNumber: number;
  stepName: string;
  stepType: 'email' | 'notification' | 'task' | 'delay' | 'condition' | 'approval';
  status: 'pending' | 'in_progress' | 'completed' | 'skipped' | 'failed';
  assignedTo?: string;
  dueDate?: Date;
  completedAt?: Date;
  stepData: any;
  resultData: any;
  createdAt: Date;
  assignedToName?: string;
}

export const useWorkflows = () => {
  const [templates, setTemplates] = useState<WorkflowTemplate[]>([]);
  const [instances, setInstances] = useState<WorkflowInstance[]>([]);
  const [steps, setSteps] = useState<WorkflowStep[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchWorkflowTemplates = async () => {
    if (!user?.organizationId) return;

    try {
      console.log('Fetching workflow templates for organization:', user.organizationId);
      
      const { data, error: fetchError } = await supabase
        .from('workflow_templates')
        .select('*')
        .eq('organization_id', user.organizationId)
        .order('name', { ascending: true });

      if (fetchError) throw fetchError;

      console.log('Workflow templates fetched:', data?.length || 0);

      const transformedTemplates: WorkflowTemplate[] = (data || []).map(template => ({
        id: template.id,
        name: template.name,
        description: template.description,
        category: template.category,
        triggerEvent: template.trigger_event,
        steps: template.steps || [],
        isActive: template.is_active,
        organizationId: template.organization_id,
        createdBy: template.created_by,
        createdAt: new Date(template.created_at),
        updatedAt: new Date(template.updated_at),
      }));

      setTemplates(transformedTemplates);
    } catch (err) {
      console.error('Error fetching workflow templates:', err);
      throw err;
    }
  };

  const fetchWorkflowInstances = async () => {
    if (!user?.organizationId) return;

    try {
      console.log('Fetching workflow instances for organization:', user.organizationId);
      
      const { data, error: fetchError } = await supabase
        .from('workflow_instances')
        .select(`
          *,
          workflow_templates!workflow_instances_template_id_fkey (
            name,
            category
          ),
          workflow_steps!workflow_steps_workflow_instance_id_fkey (
            *,
            profiles!workflow_steps_assigned_to_fkey (
              name
            )
          )
        `)
        .order('started_at', { ascending: false });

      if (fetchError) throw fetchError;

      console.log('Workflow instances fetched:', data?.length || 0);

      const transformedInstances: WorkflowInstance[] = (data || []).map(instance => ({
        id: instance.id,
        templateId: instance.template_id,
        entityType: instance.entity_type,
        entityId: instance.entity_id,
        status: instance.status,
        currentStep: instance.current_step,
        contextData: instance.context_data,
        startedAt: new Date(instance.started_at),
        completedAt: instance.completed_at ? new Date(instance.completed_at) : undefined,
        createdAt: new Date(instance.created_at),
        template: instance.workflow_templates ? {
          id: instance.workflow_templates.id,
          name: instance.workflow_templates.name,
          category: instance.workflow_templates.category,
        } as any : undefined,
        steps: (instance.workflow_steps || []).map((step: any) => ({
          id: step.id,
          workflowInstanceId: step.workflow_instance_id,
          stepNumber: step.step_number,
          stepName: step.step_name,
          stepType: step.step_type,
          status: step.status,
          assignedTo: step.assigned_to,
          dueDate: step.due_date ? new Date(step.due_date) : undefined,
          completedAt: step.completed_at ? new Date(step.completed_at) : undefined,
          stepData: step.step_data,
          resultData: step.result_data,
          createdAt: new Date(step.created_at),
          assignedToName: step.profiles?.name,
        })),
      }));

      setInstances(transformedInstances);
    } catch (err) {
      console.error('Error fetching workflow instances:', err);
      throw err;
    }
  };

  const createWorkflowTemplate = async (templateData: {
    name: string;
    description?: string;
    category: WorkflowTemplate['category'];
    triggerEvent: WorkflowTemplate['triggerEvent'];
    steps: WorkflowStepTemplate[];
  }) => {
    if (!user?.organizationId) throw new Error('Organization required');

    try {
      console.log('Creating workflow template:', templateData.name);
      
      const { data, error } = await supabase
        .from('workflow_templates')
        .insert({
          name: templateData.name,
          description: templateData.description,
          category: templateData.category,
          trigger_event: templateData.triggerEvent,
          steps: templateData.steps,
          organization_id: user.organizationId,
          created_by: user.id,
        })
        .select()
        .single();

      if (error) throw error;

      console.log('Workflow template created successfully:', data.id);
      await fetchWorkflowTemplates();
      return data;
    } catch (err) {
      console.error('Error creating workflow template:', err);
      throw err;
    }
  };

  const updateWorkflowStep = async (stepId: string, updates: {
    status?: WorkflowStep['status'];
    resultData?: any;
    notes?: string;
  }) => {
    try {
      console.log('Updating workflow step:', stepId, 'with status:', updates.status);
      
      const updateData: any = {
      };

      if (updates.status) {
        updateData.status = updates.status;
        if (updates.status === 'completed') {
          updateData.completed_at = new Date().toISOString();
        }
      }

      if (updates.resultData) {
        updateData.result_data = updates.resultData;
      }

      const { error } = await supabase
        .from('workflow_steps')
        .update(updateData)
        .eq('id', stepId);

      if (error) throw error;

      console.log('Workflow step updated successfully');
      await fetchWorkflowInstances();
    } catch (err) {
      console.error('Error updating workflow step:', err);
      throw err;
    }
  };

  const pauseWorkflow = async (instanceId: string) => {
    try {
      console.log('Pausing workflow instance:', instanceId);
      
      const { error } = await supabase
        .from('workflow_instances')
        .update({ status: 'paused' })
        .eq('id', instanceId);

      if (error) throw error;

      console.log('Workflow paused successfully');
      await fetchWorkflowInstances();
    } catch (err) {
      console.error('Error pausing workflow:', err);
      throw err;
    }
  };

  const resumeWorkflow = async (instanceId: string) => {
    try {
      console.log('Resuming workflow instance:', instanceId);
      
      const { error } = await supabase
        .from('workflow_instances')
        .update({ status: 'active' })
        .eq('id', instanceId);

      if (error) throw error;

      console.log('Workflow resumed successfully');
      await fetchWorkflowInstances();
    } catch (err) {
      console.error('Error resuming workflow:', err);
      throw err;
    }
  };

  const triggerWorkflow = async (
    triggerEvent: WorkflowTemplate['triggerEvent'],
    entityType: WorkflowInstance['entityType'],
    entityId: string,
    contextData: any = {}
  ) => {
    if (!user?.organizationId) return;

    try {
      console.log('Triggering workflows for event:', triggerEvent, 'entity:', entityType, entityId);
      
      // Find active templates for this trigger event
      const { data: templates, error: templatesError } = await supabase
        .from('workflow_templates')
        .select('*')
        .eq('organization_id', user.organizationId)
        .eq('trigger_event', triggerEvent)
        .eq('is_active', true);

      if (templatesError) throw templatesError;

      console.log('Found', templates?.length || 0, 'matching workflow templates');

      // Create workflow instances for each matching template
      for (const template of templates || []) {
        console.log('Creating workflow instance for template:', template.name);
        
        const { data: instance, error: instanceError } = await supabase
          .from('workflow_instances')
          .insert({
            template_id: template.id,
            entity_type: entityType,
            entity_id: entityId,
            context_data: contextData,
          })
          .select()
          .single();

        if (instanceError) {
          console.error('Error creating workflow instance:', instanceError);
          continue;
        }

        // Create workflow steps from template
        const steps = (template.steps as WorkflowStepTemplate[]).map(step => ({
          workflow_instance_id: instance.id,
          step_number: step.stepNumber,
          step_name: step.name,
          step_type: step.type,
          step_data: step.config,
          assigned_to: step.assignedRole ? null : null, // Would need to resolve role to user ID
          due_date: step.delayDays ? new Date(Date.now() + step.delayDays * 24 * 60 * 60 * 1000).toISOString() : null,
        }));

        if (steps.length > 0) {
          const { error: stepsError } = await supabase
            .from('workflow_steps')
            .insert(steps);

          if (stepsError) {
            console.error('Error creating workflow steps:', stepsError);
          } else {
            console.log('Created', steps.length, 'workflow steps for instance:', instance.id);
          }
        }
      }

      await fetchWorkflowInstances();
    } catch (err) {
      console.error('Error triggering workflows:', err);
      throw err;
    }
  };

  useEffect(() => {
    if (user?.organizationId) {
      fetchWorkflowTemplates();
      fetchWorkflowInstances();
    }
  }, [user?.organizationId]);

  return {
    templates,
    instances,
    steps,
    loading,
    error,
    createWorkflowTemplate,
    updateWorkflowStep,
    pauseWorkflow,
    resumeWorkflow,
    triggerWorkflow,
    refetch: () => {
      fetchWorkflowTemplates();
      fetchWorkflowInstances();
    },
  };
};