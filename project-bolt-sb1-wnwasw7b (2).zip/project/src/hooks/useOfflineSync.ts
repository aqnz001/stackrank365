import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

interface OfflineAction {
  id: string;
  type: 'create_application' | 'update_job' | 'send_message' | 'mark_notification_read';
  data: any;
  timestamp: Date;
  retryCount: number;
}

export const useOfflineSync = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [offlineActions, setOfflineActions] = useState<OfflineAction[]>([]);
  const [syncing, setSyncing] = useState(false);
  const { user } = useAuth();

  // Monitor online/offline status
  useEffect(() => {
    const handleOnline = () => {
      console.log('Connection restored');
      setIsOnline(true);
      syncOfflineActions();
    };

    const handleOffline = () => {
      console.log('Connection lost');
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Load offline actions from localStorage
  useEffect(() => {
    const stored = localStorage.getItem('offlineActions');
    if (stored) {
      try {
        const actions = JSON.parse(stored).map((action: any) => ({
          ...action,
          timestamp: new Date(action.timestamp),
        }));
        setOfflineActions(actions);
      } catch (error) {
        console.error('Error loading offline actions:', error);
        localStorage.removeItem('offlineActions');
      }
    }
  }, []);

  // Save offline actions to localStorage
  const saveOfflineActions = (actions: OfflineAction[]) => {
    localStorage.setItem('offlineActions', JSON.stringify(actions));
    setOfflineActions(actions);
  };

  // Add action to offline queue
  const queueOfflineAction = (type: OfflineAction['type'], data: any) => {
    const action: OfflineAction = {
      id: `offline_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type,
      data,
      timestamp: new Date(),
      retryCount: 0,
    };

    const newActions = [...offlineActions, action];
    saveOfflineActions(newActions);
    
    console.log('Queued offline action:', action.type);
    return action.id;
  };

  // Sync offline actions when connection is restored
  const syncOfflineActions = async () => {
    if (!isOnline || offlineActions.length === 0 || syncing) {
      return;
    }

    setSyncing(true);
    console.log('Syncing offline actions:', offlineActions.length);

    const successfulActions: string[] = [];
    const failedActions: OfflineAction[] = [];

    for (const action of offlineActions) {
      try {
        await syncAction(action);
        successfulActions.push(action.id);
        console.log('Synced action:', action.type);
      } catch (error) {
        console.error('Failed to sync action:', action.type, error);
        
        // Retry logic
        if (action.retryCount < 3) {
          failedActions.push({
            ...action,
            retryCount: action.retryCount + 1,
          });
        } else {
          console.error('Max retries reached for action:', action.id);
        }
      }
    }

    // Update offline actions list
    saveOfflineActions(failedActions);
    setSyncing(false);

    if (successfulActions.length > 0) {
      console.log(`Successfully synced ${successfulActions.length} actions`);
      
      // Show success notification
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('Data Synced', {
          body: `${successfulActions.length} offline actions synced successfully`,
          icon: '/icons/icon-192x192.png',
        });
      }
    }
  };

  // Sync individual action
  const syncAction = async (action: OfflineAction) => {
    const { supabase } = await import('../lib/supabase');
    
    switch (action.type) {
      case 'create_application':
        const { error: appError } = await supabase
          .from('applications')
          .insert(action.data);
        if (appError) throw appError;
        break;

      case 'update_job':
        const { error: jobError } = await supabase
          .from('jobs')
          .update(action.data.updates)
          .eq('id', action.data.jobId);
        if (jobError) throw jobError;
        break;

      case 'send_message':
        const { error: msgError } = await supabase
          .from('messages')
          .insert(action.data);
        if (msgError) throw msgError;
        break;

      case 'mark_notification_read':
        const { error: notifError } = await supabase
          .from('notifications')
          .update({ read: true })
          .eq('id', action.data.notificationId);
        if (notifError) throw notifError;
        break;

      default:
        throw new Error(`Unknown action type: ${action.type}`);
    }
  };

  // Clear all offline actions
  const clearOfflineActions = () => {
    localStorage.removeItem('offlineActions');
    setOfflineActions([]);
  };

  // Register service worker
  useEffect(() => {
    // Check if we're in StackBlitz or other unsupported environment
    const isStackBlitz = window.location.hostname.includes('stackblitz') || 
                        window.location.hostname.includes('webcontainer') ||
                        window.location.hostname.includes('bolt.new');
    
    if ('serviceWorker' in navigator && !isStackBlitz) {
      navigator.serviceWorker.register('/sw.js')
        .then(registration => {
          console.log('Service Worker registered:', registration);
        })
        .catch(error => {
          console.log('Service Worker registration failed (this is normal in development):', error.message);
        });
    } else {
      console.log('Service Worker not available in this environment');
    }
  }, []);

  return {
    isOnline,
    offlineActions,
    syncing,
    queueOfflineAction,
    syncOfflineActions,
    clearOfflineActions,
  };
};