import { useAuth } from '../context/AuthContext';
import { useCallback, useMemo, useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export type ConsentPolicyType = 'terms' | 'privacy';

export interface ConsentPolicyTemplate {
  id: string;
  recruiterId: string;
  type: ConsentPolicyType;
  title: string;
  content: string;
  isDefault?: boolean;
  createdAt: string; // ISO
  updatedAt: string; // ISO
}

const storageKey = (recruiterId: string) => `consent_policies_${recruiterId}`;

const readAll = (recruiterId: string): ConsentPolicyTemplate[] => {
  try {
    const raw = localStorage.getItem(storageKey(recruiterId));
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed as ConsentPolicyTemplate[];
  } catch {
    return [];
  }
};

const writeAll = (recruiterId: string, items: ConsentPolicyTemplate[]) => {
  localStorage.setItem(storageKey(recruiterId), JSON.stringify(items));
};

export const useConsentPolicies = (opts?: { scopeRecruiterId?: string }) => {
  const { user } = useAuth();
  const recruiterId = opts?.scopeRecruiterId || user?.id || 'anonymous';
  const [items, setItems] = useState<ConsentPolicyTemplate[]>(() => readAll(recruiterId));

  const persist = useCallback((next: ConsentPolicyTemplate[]) => {
    setItems(next);
    writeAll(recruiterId, next);
  }, [recruiterId]);

  const loadRemote = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('consent_policies')
        .select('*')
        .eq('recruiter_id', recruiterId)
        .order('updated_at', { ascending: false });
      if (error) throw error;
      const mapped: ConsentPolicyTemplate[] = (data || []).map((r: any) => ({
        id: r.id,
        recruiterId: r.recruiter_id,
        type: r.type,
        title: r.title,
        content: r.content,
        isDefault: r.is_default,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
      }));
      setItems(mapped);
    } catch (e) {
      console.warn('[consent-policies] remote load failed, using local', e);
      setItems(readAll(recruiterId));
    }
  }, [recruiterId]);

  useEffect(() => { if (recruiterId) loadRemote(); }, [recruiterId, loadRemote]);

  const create = useCallback((input: { type: ConsentPolicyType; title: string; content: string; setAsDefault?: boolean; }): ConsentPolicyTemplate => {
    const now = new Date().toISOString();
    const newItem: ConsentPolicyTemplate = {
      id: crypto.randomUUID(),
      recruiterId,
      type: input.type,
      title: input.title.trim() || (input.type === 'terms' ? 'Terms & Conditions' : 'Data & Privacy'),
      content: input.content,
      isDefault: Boolean(input.setAsDefault),
      createdAt: now,
      updatedAt: now,
    };
    // Try remote insert first
    (async () => {
      try {
        const { data, error } = await supabase
          .from('consent_policies')
          .insert({
            recruiter_id: recruiterId,
            type: newItem.type,
            title: newItem.title,
            content: newItem.content,
            is_default: newItem.isDefault,
          })
          .select('*')
          .single();
        if (error) throw error;
        if (newItem.isDefault) {
          await supabase
            .from('consent_policies')
            .update({ is_default: false })
            .eq('recruiter_id', recruiterId)
            .eq('type', newItem.type)
            .neq('id', data.id);
        }
        await loadRemote();
      } catch (e) {
        console.warn('[consent-policies] remote insert failed, storing local', e);
        let next = [...items, newItem];
        if (newItem.isDefault) {
          next = next.map(it => it.type === newItem.type ? { ...it, isDefault: it.id === newItem.id } : it);
        }
        persist(next);
      }
    })();
    return newItem;
  }, [items, recruiterId, persist]);

  const update = useCallback((id: string, patch: Partial<Pick<ConsentPolicyTemplate, 'title' | 'content' | 'isDefault'>>) => {
    const now = new Date().toISOString();
    (async () => {
      try {
        const { error } = await supabase
          .from('consent_policies')
          .update({
            title: patch.title,
            content: patch.content,
            is_default: patch.isDefault,
            updated_at: now,
          })
          .eq('id', id);
        if (error) throw error;
        if (patch.isDefault) {
          // Unset others of same type
          const edited = items.find(it => it.id === id);
          if (edited) {
            await supabase
              .from('consent_policies')
              .update({ is_default: false })
              .eq('recruiter_id', edited.recruiterId)
              .eq('type', edited.type)
              .neq('id', id);
          }
        }
        await loadRemote();
      } catch (e) {
        console.warn('[consent-policies] remote update failed, updating local', e);
        let next = items.map(it => it.id === id ? { ...it, ...patch, updatedAt: now } : it);
        const edited = items.find(it => it.id === id);
        if (patch.isDefault && edited) {
          next = next.map(it => it.type === edited.type ? { ...it, isDefault: it.id === id } : it);
        }
        persist(next);
      }
    })();
  }, [items, persist, loadRemote]);

  const remove = useCallback((id: string) => {
    (async () => {
      try {
        const { error } = await supabase.from('consent_policies').delete().eq('id', id);
        if (error) throw error;
        await loadRemote();
      } catch (e) {
        console.warn('[consent-policies] remote delete failed, removing local', e);
        const next = items.filter(it => it.id !== id);
        persist(next);
      }
    })();
  }, [items, persist, loadRemote]);

  const listByType = useCallback((type: ConsentPolicyType) => items.filter(it => it.type === type), [items]);
  const getDefault = useCallback((type: ConsentPolicyType) => items.find(it => it.type === type && it.isDefault) || null, [items]);
  const getById = useCallback((id: string) => items.find(it => it.id === id) || null, [items]);

  const api = useMemo(() => ({
    items,
    create,
    update,
    remove,
    listByType,
    getDefault,
    getById,
  }), [items, create, update, remove, listByType, getDefault, getById]);

  return api;
};

// Utilities to embed policies into a text payload (e.g., consent message)
export interface EmbeddedPoliciesPayload {
  terms?: { title: string; content: string };
  privacy?: { title: string; content: string };
}

const MARKER_PREFIX = '[[CONSENT_POLICIES_JSON:';
const MARKER_SUFFIX = ']]';

export const embedPoliciesInMessage = (message: string | undefined, payload: EmbeddedPoliciesPayload): string => {
  try {
    const json = JSON.stringify(payload);
    if (typeof btoa === 'undefined') return message || '';
    const b64 = btoa(unescape(encodeURIComponent(json)));
    const marker = `${MARKER_PREFIX}${b64}${MARKER_SUFFIX}`;
    const trimmed = (message || '').trim();
    return trimmed ? `${trimmed}\n\n${marker}` : marker;
  } catch {
    return message || '';
  }
};

export const extractPoliciesFromMessage = (message: string | undefined): EmbeddedPoliciesPayload | null => {
  if (!message) return null;
  const start = message.indexOf(MARKER_PREFIX);
  const end = message.indexOf(MARKER_SUFFIX, start + MARKER_PREFIX.length);
  if (start === -1 || end === -1) return null;
  const b64 = message.slice(start + MARKER_PREFIX.length, end);
  try {
    if (typeof atob === 'undefined') return null;
    const json = decodeURIComponent(escape(atob(b64)));
    const parsed = JSON.parse(json);
    if (parsed && (parsed.terms || parsed.privacy)) return parsed as EmbeddedPoliciesPayload;
    return null;
  } catch {
    return null;
  }
};

export const stripPoliciesMarker = (message: string | undefined): string => {
  if (!message) return '';
  const start = message.indexOf(MARKER_PREFIX);
  if (start === -1) return message;
  const end = message.indexOf(MARKER_SUFFIX, start + MARKER_PREFIX.length);
  if (end === -1) return message;
  const before = message.slice(0, start).trim();
  return before;
};
