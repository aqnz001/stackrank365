import { useCallback, useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

export interface PendingRecruiterSummary {
  id: string;
  name: string | null;
  email: string | null;
  kycStatus: string | null;
  submittedAt: string | null;
}

export const usePendingRecruiters = (status: 'pending' | 'verified' | 'rejected' = 'pending') => {
  const [items, setItems] = useState<PendingRecruiterSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refetch = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, name, email, kyc_status, updated_at')
        .eq('role', 'recruiter')
        .eq('kyc_status', status)
        .order('updated_at', { ascending: false });
      if (error) throw error as any;
      const rows = (data || []).map((r: any) => ({
        id: r.id,
        name: r.name ?? null,
        email: r.email ?? null,
        kycStatus: r.kyc_status ?? null,
        submittedAt: r.updated_at ?? null,
      }));
      setItems(rows);
    } catch (e: any) {
      setError(e?.message || 'Failed to load pending recruiters');
      setItems([]);
    } finally {
      setLoading(false);
    }
  }, [status]);

  useEffect(() => { refetch(); }, [refetch]);

  return { items, loading, error, refetch } as const;
};
