import { useCallback, useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

export type KycStatus = 'pending' | 'verified' | 'rejected';

export const useRecruiterKycCounts = () => {
  const [counts, setCounts] = useState<Record<KycStatus, number>>({ pending: 0, verified: 0, rejected: 0 });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchCount = async (status: KycStatus) => {
    const { count, error } = await supabase
      .from('profiles')
      .select('*', { head: true, count: 'exact' })
      .eq('role', 'recruiter')
      .eq('kyc_status', status);
    if (error) throw error as any;
    return count || 0;
  };

  const refetch = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [pending, verified, rejected] = await Promise.all([
        fetchCount('pending'),
        fetchCount('verified'),
        fetchCount('rejected'),
      ]);
      setCounts({ pending, verified, rejected });
    } catch (e: any) {
      setError(e?.message || 'Failed to load recruiter KYC counts');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { refetch(); }, [refetch]);

  return { counts, loading, error, refetch } as const;
};

