import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import type { Job } from '../types';

export interface JobRecommendation {
  id: string;
  candidateId: string;
  jobId: string;
  job?: Job;
  matchScore: number;
  matchReasons: {
    skillMatch?: string[];
    locationMatch?: string;
    salaryMatch?: string;
    experienceMatch?: string;
    industryMatch?: string;
  };
  skillMatchScore: number;
  locationMatchScore: number;
  salaryMatchScore: number;
  experienceMatchScore: number;
  isViewed: boolean;
  isDismissed: boolean;
  createdAt: Date;
}

export interface CandidateRecommendation {
  id: string;
  jobId: string;
  candidateId: string;
  candidateName?: string;
  candidateEmail?: string;
  matchScore: number;
  matchReasons: {
    skillMatch?: string[];
    locationMatch?: string;
    salaryMatch?: string;
    experienceMatch?: string;
  };
  skillMatchScore: number;
  locationMatchScore: number;
  salaryMatchScore: number;
  experienceMatchScore: number;
  isViewed: boolean;
  isContacted: boolean;
  createdAt: Date;
}

export const useJobRecommendations = () => {
  const [jobRecommendations, setJobRecommendations] = useState<JobRecommendation[]>([]);
  const [candidateRecommendations, setCandidateRecommendations] = useState<CandidateRecommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchJobRecommendations = async () => {
    if (!user || user.role !== 'candidate') return;

    try {
      setLoading(true);
      setError(null);

      console.log('Fetching job recommendations for candidate:', user.id);
      
      const { data, error: fetchError } = await supabase
        .from('job_recommendations')
        .select(`
          *,
          jobs!job_recommendations_job_id_fkey (
            *,
            organizations!jobs_organization_id_fkey (
              name
            )
          )
        `)
        .eq('candidate_id', user.id)
        .eq('is_dismissed', false)
        .order('match_score', { ascending: false })
        .limit(20);

      if (fetchError) throw fetchError;

      console.log('Job recommendations fetched:', data?.length || 0);
      
      const transformedRecommendations: JobRecommendation[] = (data || []).map(rec => ({
        id: rec.id,
        candidateId: rec.candidate_id,
        jobId: rec.job_id,
        job: rec.jobs ? {
          id: rec.jobs.id,
          organizationId: rec.jobs.organization_id,
          organizationName: rec.jobs.organizations?.name || 'Unknown',
          title: rec.jobs.title,
          description: rec.jobs.description,
          location: rec.jobs.location,
          salaryRange: rec.jobs.salary_min && rec.jobs.salary_max ? {
            min: rec.jobs.salary_min,
            max: rec.jobs.salary_max
          } : undefined,
          employmentType: rec.jobs.employment_type,
          skills: rec.jobs.skills || [],
          visibility: rec.jobs.visibility,
          adTier: rec.jobs.ad_tier,
          bidLimit: rec.jobs.bid_limit,
          blockedRecruiterIds: rec.jobs.blocked_recruiter_ids || [],
          status: rec.jobs.status,
          createdAt: new Date(rec.jobs.created_at),
        } : undefined,
        matchScore: rec.match_score,
        matchReasons: rec.match_reasons,
        skillMatchScore: rec.skill_match_score,
        locationMatchScore: rec.location_match_score,
        salaryMatchScore: rec.salary_match_score,
        experienceMatchScore: rec.experience_match_score,
        isViewed: rec.is_viewed,
        isDismissed: rec.is_dismissed,
        createdAt: new Date(rec.created_at),
      }));

      setJobRecommendations(transformedRecommendations);
    } catch (err) {
      console.error('Error fetching job recommendations:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch recommendations');
    } finally {
      setLoading(false);
    }
  };

  const fetchCandidateRecommendations = async (jobId?: string) => {
    if (!user || user.role !== 'employer') return;

    try {
      setLoading(true);
      setError(null);

      let query = supabase
        .from('candidate_recommendations')
        .select(`
          *,
          profiles!candidate_recommendations_candidate_id_fkey (
            id,
            name,
            email
          )
        `);

      if (jobId) {
        query = query.eq('job_id', jobId);
      } else {
        // Get recommendations for all jobs in user's organization
        const { data: jobIds } = await supabase
          .from('jobs')
          .select('id')
          .eq('organization_id', user.organizationId);

        if (jobIds && jobIds.length > 0) {
          query = query.in('job_id', jobIds.map(job => job.id));
        } else {
          setCandidateRecommendations([]);
          setLoading(false);
          return;
        }
      }

      const { data, error: fetchError } = await query
        .order('match_score', { ascending: false })
        .limit(50);

      if (fetchError) throw fetchError;

      const transformedRecommendations: CandidateRecommendation[] = (data || []).map(rec => ({
        id: rec.id,
        jobId: rec.job_id,
        candidateId: rec.candidate_id,
        candidateName: rec.profiles?.name,
        candidateEmail: rec.profiles?.email,
        matchScore: rec.match_score,
        matchReasons: rec.match_reasons,
        skillMatchScore: rec.skill_match_score,
        locationMatchScore: rec.location_match_score,
        salaryMatchScore: rec.salary_match_score,
        experienceMatchScore: rec.experience_match_score,
        isViewed: rec.is_viewed,
        isContacted: rec.is_contacted,
        createdAt: new Date(rec.created_at),
      }));

      setCandidateRecommendations(transformedRecommendations);
    } catch (err) {
      console.error('Error fetching candidate recommendations:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch candidate recommendations');
    } finally {
      setLoading(false);
    }
  };

  const markRecommendationViewed = async (recommendationId: string, type: 'job' | 'candidate') => {
    try {
      const table = type === 'job' ? 'job_recommendations' : 'candidate_recommendations';
      const { error } = await supabase
        .from(table)
        .update({ is_viewed: true })
        .eq('id', recommendationId);

      if (error) throw error;

      // Update local state
      if (type === 'job') {
        setJobRecommendations(prev => 
          prev.map(rec => 
            rec.id === recommendationId ? { ...rec, isViewed: true } : rec
          )
        );
      } else {
        setCandidateRecommendations(prev => 
          prev.map(rec => 
            rec.id === recommendationId ? { ...rec, isViewed: true } : rec
          )
        );
      }
    } catch (err) {
      console.error('Error marking recommendation as viewed:', err);
      throw err;
    }
  };

  const dismissJobRecommendation = async (recommendationId: string) => {
    try {
      const { error } = await supabase
        .from('job_recommendations')
        .update({ is_dismissed: true })
        .eq('id', recommendationId);

      if (error) throw error;

      // Remove from local state
      setJobRecommendations(prev => 
        prev.filter(rec => rec.id !== recommendationId)
      );
    } catch (err) {
      console.error('Error dismissing recommendation:', err);
      throw err;
    }
  };

  const markCandidateContacted = async (recommendationId: string) => {
    try {
      const { error } = await supabase
        .from('candidate_recommendations')
        .update({ is_contacted: true })
        .eq('id', recommendationId);

      if (error) throw error;

      // Update local state
      setCandidateRecommendations(prev => 
        prev.map(rec => 
          rec.id === recommendationId ? { ...rec, isContacted: true } : rec
        )
      );
    } catch (err) {
      console.error('Error marking candidate as contacted:', err);
      throw err;
    }
  };

  // Generate recommendations (mock implementation - would use AI in production)
  const generateJobRecommendations = async () => {
    if (!user || user.role !== 'candidate') return;

    try {
      console.log('Generating job recommendations for candidate:', user.id);
      
      const { data: jobs } = await supabase
        .from('jobs')
        .select('*')
        .eq('status', 'open')
        .eq('visibility', 'open')
        .limit(10);

      if (!jobs) return;

      // Simple matching algorithm based on job skills and title keywords
      const recommendations = jobs.map(job => ({
        candidate_id: user.id,
        job_id: job.id,
        match_score: calculateSimpleMatchScore(job),
        match_reasons: {
          skillMatch: job.skills?.slice(0, 3) || [],
          locationMatch: job.location.includes('Remote') ? 'Remote work available' : 'Location match',
          salaryMatch: job.salary_min ? 'Salary range available' : 'Salary negotiable',
          experienceMatch: 'Experience level match',
        },
        skill_match_score: Math.random() * 30 + 70,
        location_match_score: job.location.includes('Remote') ? 95 : Math.random() * 30 + 60,
        salary_match_score: job.salary_min ? Math.random() * 20 + 75 : 60,
        experience_match_score: Math.random() * 25 + 70,
      }));

      const { error } = await supabase
        .from('job_recommendations')
        .upsert(recommendations, { onConflict: 'candidate_id,job_id' });

      if (error) throw error;

      console.log('Job recommendations generated:', recommendations.length);
      await fetchJobRecommendations();
    } catch (err) {
      console.error('Error generating job recommendations:', err);
      throw err;
    }
  };
  
  // Simple match score calculation
  const calculateSimpleMatchScore = (job: any): number => {
    let score = 60; // Base score
    
    // Boost for remote work
    if (job.location?.toLowerCase().includes('remote')) score += 15;
    
    // Boost for common skills
    const commonSkills = ['React', 'TypeScript', 'JavaScript', 'Node.js', 'Python'];
    const matchingSkills = job.skills?.filter((skill: string) => 
      commonSkills.some(common => skill.toLowerCase().includes(common.toLowerCase()))
    ) || [];
    score += matchingSkills.length * 5;
    
    // Boost for salary range
    if (job.salary_min && job.salary_max) score += 10;
    
    // Add some randomness
    score += Math.random() * 15;
    
    return Math.min(Math.round(score), 100);
  };

  useEffect(() => {
    if (user?.role === 'candidate') {
      fetchJobRecommendations();
    } else if (user?.role === 'employer') {
      fetchCandidateRecommendations();
    }
  }, [user]);

  return {
    jobRecommendations,
    candidateRecommendations,
    loading,
    error,
    markRecommendationViewed,
    dismissJobRecommendation,
    markCandidateContacted,
    generateJobRecommendations,
    refetch: user?.role === 'candidate' ? fetchJobRecommendations : fetchCandidateRecommendations,
  };
};