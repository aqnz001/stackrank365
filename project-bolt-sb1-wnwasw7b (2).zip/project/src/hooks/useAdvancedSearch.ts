import { useState, useEffect, useMemo } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { debounce } from '../utils/performance';
import type { Job } from '../types';

export interface SearchFilters {
  query: string;
  location: string;
  radius: number;
  employmentType: string[];
  salaryMin: string;
  salaryMax: string;
  skills: string[];
  experienceLevel: string;
  adTier: string[];
  visibility: string[];
  status: string[];
  postedWithin: string;
  companySize: string[];
  industry: string[];
  remoteWork: boolean;
  benefits: string[];
}

export interface SearchResult {
  jobs: Job[];
  totalCount: number;
  facets: {
    locations: Array<{ value: string; count: number }>;
    skills: Array<{ value: string; count: number }>;
    companies: Array<{ value: string; count: number }>;
    salaryRanges: Array<{ range: string; count: number }>;
  };
  searchTime: number;
  suggestions: string[];
}

export const useAdvancedSearch = () => {
  const [searchResults, setSearchResults] = useState<SearchResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const { user } = useAuth();

  // Debounced search function
  const debouncedSearch = useMemo(
    () => debounce(async (filters: SearchFilters) => {
      await performSearch(filters);
    }, 300),
    []
  );

  const performSearch = async (filters: SearchFilters) => {
    try {
      setLoading(true);
      setError(null);
      const startTime = performance.now();

      console.log('Performing search with filters:', filters);
      
      // Build the query
      let query = supabase
        .from('jobs')
        .select(`
          *,
          organizations!jobs_organization_id_fkey (
            id,
            name,
            type,
            size
          )
        `, { count: 'exact' });

      console.log('Base query created');

      // Apply filters
      if (filters.query) {
        console.log('Applying text search filter:', filters.query);
        // Full-text search across multiple fields
        const searchTerms = filters.query.toLowerCase().split(' ').filter(Boolean);
        
        // For now, use simple ILIKE queries (in production, use full-text search)
        const searchConditions = searchTerms.map(term => 
          `title.ilike.%${term}%,description.ilike.%${term}%,location.ilike.%${term}%`
        ).join(',');
        query = query.or(searchConditions);
      }

      if (filters.location) {
        console.log('Applying location filter:', filters.location);
        query = query.ilike('location', `%${filters.location}%`);
      }
      
      if (filters.remoteWork) {
        console.log('Applying remote/hybrid work filter');
        // Match both remote and hybrid
        query = (query as any).or('location.ilike.%remote%,location.ilike.%hybrid%');
      }

      if (filters.employmentType.length > 0) {
        console.log('Applying employment type filter:', filters.employmentType);
        query = query.in('employment_type', filters.employmentType);
      }

      if (filters.experienceLevel) {
        console.log('Applying experience level filter:', filters.experienceLevel);
        query = query.eq('experience_level', filters.experienceLevel);
      }

      if (filters.salaryMin) {
        console.log('Applying salary min filter:', filters.salaryMin);
        query = query.gte('salary_min', parseInt(filters.salaryMin));
      }

      if (filters.salaryMax) {
        console.log('Applying salary max filter:', filters.salaryMax);
        query = query.lte('salary_max', parseInt(filters.salaryMax));
      }

      if (filters.skills.length > 0) {
        console.log('Applying skills filter:', filters.skills);
        // Check if any of the job skills match the search skills
        query = query.overlaps('skills', filters.skills);
      }

      if (filters.industry && filters.industry.length > 0) {
        console.log('Applying industry filter:', filters.industry);
        query = query.overlaps('industry', filters.industry);
      }

      if (filters.benefits && filters.benefits.length > 0) {
        console.log('Applying benefits filter:', filters.benefits);
        query = query.overlaps('benefits', filters.benefits);
      }

      if (filters.adTier.length > 0) {
        console.log('Applying ad tier filter:', filters.adTier);
        query = query.in('ad_tier', filters.adTier);
      }

      if (filters.companySize && filters.companySize.length > 0) {
        console.log('Applying company size filter:', filters.companySize);
        // Filter on joined organizations.size
        query = (query as any).in('organizations.size', filters.companySize);
      }

      if (filters.visibility.length > 0) {
        console.log('Applying visibility filter:', filters.visibility);
        query = query.in('visibility', filters.visibility);
      }

      if (filters.status.length > 0) {
        console.log('Applying status filter:', filters.status);
        query = query.in('status', filters.status);
      }

      if (filters.postedWithin) {
        console.log('Applying posted within filter:', filters.postedWithin);
        const days = parseInt(filters.postedWithin);
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - days);
        query = query.gte('created_at', cutoffDate.toISOString());
      }

      // Apply user role-based filtering
      if (user?.role === 'recruiter') {
        console.log('Applying recruiter role filter (open visibility only)');
        // Recruiters should not see jobs closed to recruiters
        query = query.eq('visibility', 'open');
      }

      console.log('Executing search query...');
      const { data, error: searchError, count } = await query
        .order('created_at', { ascending: false })
        .limit(50);

      console.log('Search query results:', { 
        dataLength: data?.length || 0, 
        count, 
        error: searchError,
        sampleData: data?.slice(0, 2) 
      });

      if (searchError) throw searchError;

      const searchTime = performance.now() - startTime;
      console.log('Search completed in', searchTime, 'ms with', count, 'results');

      // Transform results
      const jobs: Job[] = (data || []).map(job => ({
        id: job.id,
        organizationId: job.organization_id,
        organizationName: job.organizations?.name || 'Unknown',
        organizationSize: job.organizations?.size || undefined,
        title: job.title,
        description: job.description,
        location: job.location,
        salaryRange: job.salary_min && job.salary_max ? {
          min: job.salary_min,
          max: job.salary_max
        } : undefined,
        employmentType: job.employment_type,
        experienceLevel: job.experience_level || undefined,
        skills: job.skills || [],
        industry: job.industry || [],
        benefits: job.benefits || [],
        visibility: job.visibility,
        adTier: job.ad_tier,
        bidLimit: job.bid_limit,
        blockedRecruiterIds: job.blocked_recruiter_ids || [],
        status: job.status,
        createdAt: new Date(job.created_at),
      }));

      // Generate facets for filtering
      const facets = generateFacets(jobs);

      // Generate search suggestions
      const suggestions = generateSuggestions(filters.query, jobs);

      setSearchResults({
        jobs,
        totalCount: count || 0,
        facets,
        searchTime,
        suggestions,
      });

      // Track search analytics
      await trackSearch(filters, count || 0, searchTime);

      // Update search history
      if (filters.query && !searchHistory.includes(filters.query)) {
        setSearchHistory(prev => [filters.query, ...prev.slice(0, 9)]);
      }

    } catch (err) {
      console.error('Error performing search:', err);
      setError(err instanceof Error ? err.message : 'Search failed');
    } finally {
      setLoading(false);
    }
  };

  const generateFacets = (jobs: Job[]) => {
    const locations = new Map<string, number>();
    const skills = new Map<string, number>();
    const companies = new Map<string, number>();
    const salaryRanges = new Map<string, number>();

    jobs.forEach(job => {
      // Location facets
      const location = job.location.split(',')[0].trim();
      locations.set(location, (locations.get(location) || 0) + 1);

      // Skill facets
      job.skills.forEach(skill => {
        skills.set(skill, (skills.get(skill) || 0) + 1);
      });

      // Company facets
      companies.set(job.organizationName, (companies.get(job.organizationName) || 0) + 1);

      // Salary range facets
      if (job.salaryRange) {
        const range = getSalaryRangeCategory(job.salaryRange.min);
        salaryRanges.set(range, (salaryRanges.get(range) || 0) + 1);
      }
    });

    return {
      locations: Array.from(locations.entries())
        .map(([value, count]) => ({ value, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10),
      skills: Array.from(skills.entries())
        .map(([value, count]) => ({ value, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 15),
      companies: Array.from(companies.entries())
        .map(([value, count]) => ({ value, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10),
      salaryRanges: Array.from(salaryRanges.entries())
        .map(([range, count]) => ({ range, count }))
        .sort((a, b) => b.count - a.count),
    };
  };

  const generateSuggestions = (query: string, jobs: Job[]): string[] => {
    if (!query || query.length < 2) return [];

    const suggestions = new Set<string>();
    const queryLower = query.toLowerCase();

    jobs.forEach(job => {
      // Title suggestions
      if (job.title.toLowerCase().includes(queryLower)) {
        suggestions.add(job.title);
      }

      // Skill suggestions
      job.skills.forEach(skill => {
        if (skill.toLowerCase().includes(queryLower)) {
          suggestions.add(skill);
        }
      });

      // Company suggestions
      if (job.organizationName.toLowerCase().includes(queryLower)) {
        suggestions.add(job.organizationName);
      }
    });

    return Array.from(suggestions).slice(0, 5);
  };

  const getSalaryRangeCategory = (salary: number): string => {
    if (salary < 50000) return '$0 - $50k';
    if (salary < 75000) return '$50k - $75k';
    if (salary < 100000) return '$75k - $100k';
    if (salary < 150000) return '$100k - $150k';
    if (salary < 200000) return '$150k - $200k';
    return '$200k+';
  };

  const trackSearch = async (filters: SearchFilters, resultCount: number, duration: number) => {
    if (!user) return;

    try {
      console.log('Tracking search:', { query: filters.query, resultCount, duration });
      
      await supabase
        .from('search_analytics')
        .insert({
          user_id: user.id,
          search_query: filters.query || '',
          search_filters: filters,
          results_count: resultCount,
          search_duration_ms: Math.round(duration),
          session_id: `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        });
      
      console.log('Search tracked successfully');
    } catch (err) {
      console.error('Error tracking search:', err);
      // Don't throw - search tracking shouldn't break the search
    }
  };

  const clearSearchResults = () => {
    setSearchResults(null);
    setError(null);
  };

  const getPopularSearches = async () => {
    try {
      const { data } = await supabase
        .from('search_analytics')
        .select('search_query')
        .not('search_query', 'is', null)
        .gte('created_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString())
        .limit(100);

      if (!data) return [];

      // Count query frequency
      const queryCount = new Map<string, number>();
      data.forEach(({ search_query }) => {
        if (search_query) {
          queryCount.set(search_query, (queryCount.get(search_query) || 0) + 1);
        }
      });

      return Array.from(queryCount.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map(([query]) => query);
    } catch (err) {
      console.error('Error fetching popular searches:', err);
      return [];
    }
  };

  return {
    searchResults,
    loading,
    error,
    searchHistory,
    performSearch: debouncedSearch,
    clearSearchResults,
    getPopularSearches,
    trackSearch,
  };
};
