import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

export interface DocumentShare {
  id: string;
  ownerId: string;
  sharedWithId: string;
  fileUploadId: string;
  applicationId?: string;
  recruiterBidId?: string;
  accessLevel: 'view' | 'download' | 'edit';
  expiresAt?: Date;
  passwordProtected: boolean;
  accessPassword?: string;
  downloadCount: number;
  lastAccessedAt?: Date;
  isActive: boolean;
  createdAt: Date;
  // Populated fields
  fileName?: string;
  fileSize?: number;
  sharedWithName?: string;
  ownerName?: string;
}

export const useDocumentSharing = () => {
  const [documentShares, setDocumentShares] = useState<DocumentShare[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchDocumentShares = async () => {
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('document_shares')
        .select(`
          *,
          file_uploads!document_shares_file_upload_id_fkey (
            file_name,
            file_size,
            mime_type
          ),
          owner:profiles!document_shares_owner_id_fkey (
            name
          ),
          shared_with:profiles!document_shares_shared_with_id_fkey (
            name
          )
        `)
        .or(`owner_id.eq.${user.id},shared_with_id.eq.${user.id}`)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;

      const transformedShares: DocumentShare[] = (data || []).map(share => ({
        id: share.id,
        ownerId: share.owner_id,
        sharedWithId: share.shared_with_id,
        fileUploadId: share.file_upload_id,
        applicationId: share.application_id,
        recruiterBidId: share.recruiter_bid_id,
        accessLevel: share.access_level,
        expiresAt: share.expires_at ? new Date(share.expires_at) : undefined,
        passwordProtected: share.password_protected,
        accessPassword: share.access_password,
        downloadCount: share.download_count,
        lastAccessedAt: share.last_accessed_at ? new Date(share.last_accessed_at) : undefined,
        isActive: share.is_active,
        createdAt: new Date(share.created_at),
        fileName: share.file_uploads?.file_name,
        fileSize: share.file_uploads?.file_size,
        sharedWithName: share.shared_with?.name,
        ownerName: share.owner?.name,
      }));

      setDocumentShares(transformedShares);
    } catch (err) {
      console.error('Error fetching document shares:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch document shares');
    } finally {
      setLoading(false);
    }
  };

  const shareDocument = async (shareData: {
    fileUploadId: string;
    sharedWithId: string;
    applicationId?: string;
    recruiterBidId?: string;
    accessLevel: DocumentShare['accessLevel'];
    expiresAt?: Date;
    password?: string;
  }) => {
    if (!user) throw new Error('User not authenticated');

    try {
      console.log('Sharing document:', shareData);
      
      const { data, error } = await supabase
        .from('document_shares')
        .insert({
          owner_id: user.id,
          shared_with_id: shareData.sharedWithId,
          file_upload_id: shareData.fileUploadId,
          application_id: shareData.applicationId,
          recruiter_bid_id: shareData.recruiterBidId,
          access_level: shareData.accessLevel,
          expires_at: shareData.expiresAt?.toISOString(),
          password_protected: !!shareData.password,
          access_password: shareData.password,
        })
        .select()
        .single();

      if (error) throw error;

      console.log('Document shared successfully:', data.id);
      await fetchDocumentShares();
      return data;
    } catch (err) {
      console.error('Error sharing document:', err);
      throw err;
    }
  };

  const revokeDocumentShare = async (shareId: string) => {
    try {
      const { error } = await supabase
        .from('document_shares')
        .update({ is_active: false })
        .eq('id', shareId);

      if (error) throw error;

      await fetchDocumentShares();
    } catch (err) {
      console.error('Error revoking document share:', err);
      throw err;
    }
  };

  const trackDocumentAccess = async (shareId: string) => {
    try {
      const { error } = await supabase
        .from('document_shares')
        .update({
          download_count: supabase.sql`download_count + 1`,
          last_accessed_at: new Date().toISOString(),
        })
        .eq('id', shareId);

      if (error) throw error;
    } catch (err) {
      console.error('Error tracking document access:', err);
    }
  };

  const getSharedDocument = async (shareId: string, password?: string) => {
    try {
      const { data: share, error: shareError } = await supabase
        .from('document_shares')
        .select(`
          *,
          file_uploads!document_shares_file_upload_id_fkey (*)
        `)
        .eq('id', shareId)
        .eq('is_active', true)
        .single();

      if (shareError) throw shareError;

      // Check expiration
      if (share.expires_at && new Date(share.expires_at) < new Date()) {
        throw new Error('Document share has expired');
      }

      // Check password
      if (share.password_protected && share.access_password !== password) {
        throw new Error('Invalid password');
      }

      // Track access
      await trackDocumentAccess(shareId);

      return {
        share,
        file: share.file_uploads,
      };
    } catch (err) {
      console.error('Error accessing shared document:', err);
      throw err;
    }
  };

  useEffect(() => {
    fetchDocumentShares();
  }, [user]);

  return {
    documentShares,
    loading,
    error,
    shareDocument,
    revokeDocumentShare,
    getSharedDocument,
    trackDocumentAccess,
    refetch: fetchDocumentShares,
  };
};