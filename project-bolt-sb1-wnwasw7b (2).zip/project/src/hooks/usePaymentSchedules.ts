import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

export interface PaymentMilestone {
  name: string;
  trigger: string;
  percentage: number;
  description: string;
}

export interface PaymentSchedule {
  id: string;
  name: string;
  description?: string;
  milestones: PaymentMilestone[];
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface ScheduledPayment {
  id: string;
  recruiterBidId: string;
  escrowTransactionId?: string;
  installmentName: string;
  monthNumber: number;
  amount: number;
  percentage: number;
  status: 'pending' | 'triggered' | 'released' | 'failed';
  paymentDate?: Date;
  triggerDate?: Date;
  releaseDate?: Date;
  sequenceOrder: number;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

export const usePaymentSchedules = () => {
  const [schedules, setSchedules] = useState<PaymentSchedule[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchSchedules = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('payment_schedules')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (fetchError) throw fetchError;

      const transformedSchedules: PaymentSchedule[] = (data || []).map(schedule => ({
        id: schedule.id,
        name: schedule.name,
        description: schedule.description,
        milestones: schedule.milestones || [],
        isActive: schedule.is_active,
        createdAt: new Date(schedule.created_at),
        updatedAt: new Date(schedule.updated_at),
      }));

      setSchedules(transformedSchedules);
    } catch (err) {
      console.error('Error fetching payment schedules:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch payment schedules');
    } finally {
      setLoading(false);
    }
  }, []);

  const createSchedule = async (scheduleData: {
    name: string;
    description?: string;
    milestones: PaymentMilestone[];
  }) => {
    if (user?.role !== 'admin') {
      throw new Error('Only admins can create payment schedules');
    }

    try {
      const { data, error } = await supabase
        .from('payment_schedules')
        .insert({
          name: scheduleData.name,
          description: scheduleData.description,
          milestones: scheduleData.milestones,
          is_active: true,
        })
        .select()
        .single();

      if (error) throw error;

      await fetchSchedules();
      return data;
    } catch (err) {
      console.error('Error creating payment schedule:', err);
      throw err;
    }
  };

  useEffect(() => {
    if (user) {
      fetchSchedules();
    }
  }, [user, fetchSchedules]);

  return {
    schedules,
    loading,
    error,
    refetch: fetchSchedules,
    createSchedule,
  };
};

export const useScheduledPayments = (recruiterBidId?: string) => {
  const [payments, setPayments] = useState<ScheduledPayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchPayments = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      let query = supabase
        .from('scheduled_payments')
        .select('*')
        .order('sequence_order');

      if (recruiterBidId) {
        query = query.eq('recruiter_bid_id', recruiterBidId);
      } else if (user?.role === 'recruiter') {
        const { data: bidIds } = await supabase
          .from('recruiter_bids')
          .select('id')
          .eq('recruiter_id', user.id);

        if (bidIds && bidIds.length > 0) {
          query = query.in('recruiter_bid_id', bidIds.map(b => b.id));
        }
      } else if (user?.role === 'employer' && user.organizationId) {
        const { data: jobIds } = await supabase
          .from('jobs')
          .select('id')
          .eq('organization_id', user.organizationId);

        if (jobIds && jobIds.length > 0) {
          const { data: bidIds } = await supabase
            .from('recruiter_bids')
            .select('id')
            .in('job_id', jobIds.map(j => j.id));

          if (bidIds && bidIds.length > 0) {
            query = query.in('recruiter_bid_id', bidIds.map(b => b.id));
          }
        }
      }

      const { data, error: fetchError } = await query;

      if (fetchError) throw fetchError;

      const transformedPayments: ScheduledPayment[] = (data || []).map(payment => ({
        id: payment.id,
        recruiterBidId: payment.recruiter_bid_id,
        escrowTransactionId: payment.escrow_transaction_id,
        installmentName: payment.installment_name || payment.milestone_name || 'Payment',
        monthNumber: payment.month_number || payment.sequence_order,
        amount: payment.amount,
        percentage: parseFloat(payment.percentage),
        status: payment.status,
        paymentDate: payment.payment_date ? new Date(payment.payment_date) : undefined,
        triggerDate: payment.trigger_date ? new Date(payment.trigger_date) : undefined,
        releaseDate: payment.release_date ? new Date(payment.release_date) : undefined,
        sequenceOrder: payment.sequence_order,
        notes: payment.notes,
        createdAt: new Date(payment.created_at),
        updatedAt: new Date(payment.updated_at),
      }));

      setPayments(transformedPayments);
    } catch (err) {
      console.error('Error fetching scheduled payments:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch scheduled payments');
    } finally {
      setLoading(false);
    }
  }, [recruiterBidId, user]);

  const createScheduledPayments = async (
    recruiterBidId: string,
    escrowTransactionId: string,
    totalAmount: number,
    milestones: PaymentMilestone[]
  ) => {
    try {
      const paymentsToCreate = milestones.map((milestone, index) => ({
        recruiter_bid_id: recruiterBidId,
        escrow_transaction_id: escrowTransactionId,
        milestone_name: milestone.name,
        milestone_trigger: milestone.trigger,
        amount: Math.round((totalAmount * milestone.percentage) / 100),
        percentage: milestone.percentage,
        status: 'pending' as const,
        sequence_order: index + 1,
      }));

      const { error } = await supabase
        .from('scheduled_payments')
        .insert(paymentsToCreate);

      if (error) throw error;

      await fetchPayments();
    } catch (err) {
      console.error('Error creating scheduled payments:', err);
      throw err;
    }
  };

  const triggerMilestone = async (paymentId: string, notes?: string) => {
    try {
      const { error } = await supabase
        .from('scheduled_payments')
        .update({
          status: 'triggered',
          trigger_date: new Date().toISOString(),
          notes,
        })
        .eq('id', paymentId);

      if (error) throw error;

      await fetchPayments();
    } catch (err) {
      console.error('Error triggering milestone:', err);
      throw err;
    }
  };

  const releasePayment = async (paymentId: string) => {
    try {
      const { error } = await supabase
        .from('scheduled_payments')
        .update({
          status: 'released',
          release_date: new Date().toISOString(),
        })
        .eq('id', paymentId);

      if (error) throw error;

      await fetchPayments();
    } catch (err) {
      console.error('Error releasing payment:', err);
      throw err;
    }
  };

  useEffect(() => {
    if (user) {
      fetchPayments();
    }
  }, [user, fetchPayments]);

  return {
    payments,
    loading,
    error,
    refetch: fetchPayments,
    createScheduledPayments,
    triggerMilestone,
    releasePayment,
  };
};
