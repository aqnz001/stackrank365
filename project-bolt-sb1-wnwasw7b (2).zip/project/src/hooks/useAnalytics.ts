import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

export interface PlatformMetrics {
  totalUsers: number;
  totalJobs: number;
  totalApplications: number;
  totalBids: number;
  totalRevenue: number;
  activeUsers: number;
  conversionRate: number;
  averageTimeToHire: number;
}

export interface UserEngagementMetrics {
  dailyActiveUsers: number;
  weeklyActiveUsers: number;
  monthlyActiveUsers: number;
  averageSessionDuration: number;
  bounceRate: number;
  retentionRate: number;
}

export interface RevenueMetrics {
  monthlyRecurringRevenue: number;
  totalRevenue: number;
  averageRevenuePerUser: number;
  revenueGrowthRate: number;
  churnRate: number;
  lifetimeValue: number;
}

export interface JobMetrics {
  totalJobsPosted: number;
  averageApplicationsPerJob: number;
  averageBidsPerJob: number;
  jobFillRate: number;
  averageTimeToFill: number;
  topPerformingJobs: Array<{
    id: string;
    title: string;
    applications: number;
    bids: number;
    views: number;
  }>;
}

export const useAnalytics = () => {
  const [platformMetrics, setPlatformMetrics] = useState<PlatformMetrics | null>(null);
  const [userEngagement, setUserEngagement] = useState<UserEngagementMetrics | null>(null);
  const [revenueMetrics, setRevenueMetrics] = useState<RevenueMetrics | null>(null);
  const [jobMetrics, setJobMetrics] = useState<JobMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchPlatformMetrics = async () => {
    try {
      // Get basic counts
      const [
        { count: totalUsers },
        { count: totalJobs },
        { count: totalApplications },
        { count: totalBids }
      ] = await Promise.all([
        supabase.from('profiles').select('*', { count: 'exact', head: true }),
        supabase.from('jobs').select('*', { count: 'exact', head: true }),
        supabase.from('applications').select('*', { count: 'exact', head: true }),
        supabase.from('recruiter_bids').select('*', { count: 'exact', head: true })
      ]);

      // Get active users (logged in within last 30 days)
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      const { count: activeUsers } = await supabase
        .from('user_sessions')
        .select('*', { count: 'exact', head: true })
        .gte('session_start', thirtyDaysAgo.toISOString())
        .eq('is_active', true);

      // Calculate revenue (mock for now - would integrate with actual payment data)
      const { data: payments } = await supabase
        .from('payments')
        .select('amount')
        .eq('status', 'succeeded');

      const totalRevenue = payments?.reduce((sum, payment) => sum + payment.amount, 0) || 0;

      // Calculate conversion rate (applications to hires)
      const { count: hiredApplications } = await supabase
        .from('applications')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'hired');

      const conversionRate = totalApplications && hiredApplications 
        ? (hiredApplications / totalApplications) * 100 
        : 0;

      setPlatformMetrics({
        totalUsers: totalUsers || 0,
        totalJobs: totalJobs || 0,
        totalApplications: totalApplications || 0,
        totalBids: totalBids || 0,
        totalRevenue: totalRevenue / 100, // Convert from cents
        activeUsers: activeUsers || 0,
        conversionRate: Math.round(conversionRate * 100) / 100,
        averageTimeToHire: 12.5, // Mock data - would calculate from actual hire dates
      });
    } catch (err) {
      console.error('Error fetching platform metrics:', err);
      throw err;
    }
  };

  const fetchUserEngagementMetrics = async () => {
    try {
      const now = new Date();
      const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      const oneMonthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

      const [
        { count: dailyActiveUsers },
        { count: weeklyActiveUsers },
        { count: monthlyActiveUsers }
      ] = await Promise.all([
        supabase.from('user_sessions').select('user_id', { count: 'exact', head: true }).gte('session_start', oneDayAgo.toISOString()),
        supabase.from('user_sessions').select('user_id', { count: 'exact', head: true }).gte('session_start', oneWeekAgo.toISOString()),
        supabase.from('user_sessions').select('user_id', { count: 'exact', head: true }).gte('session_start', oneMonthAgo.toISOString())
      ]);

      setUserEngagement({
        dailyActiveUsers: dailyActiveUsers || 0,
        weeklyActiveUsers: weeklyActiveUsers || 0,
        monthlyActiveUsers: monthlyActiveUsers || 0,
        averageSessionDuration: 24.5, // Mock data
        bounceRate: 15.2, // Mock data
        retentionRate: 78.5, // Mock data
      });
    } catch (err) {
      console.error('Error fetching user engagement metrics:', err);
      throw err;
    }
  };

  const fetchRevenueMetrics = async () => {
    try {
      // Get revenue data from payments
      const { data: payments } = await supabase
        .from('payments')
        .select('amount, created_at')
        .eq('status', 'succeeded');

      const totalRevenue = payments?.reduce((sum, payment) => sum + payment.amount, 0) || 0;
      
      // Calculate monthly recurring revenue (mock calculation)
      const currentMonth = new Date();
      currentMonth.setDate(1);
      
      const monthlyPayments = payments?.filter(payment => 
        new Date(payment.created_at) >= currentMonth
      ) || [];
      
      const monthlyRevenue = monthlyPayments.reduce((sum, payment) => sum + payment.amount, 0);

      setRevenueMetrics({
        monthlyRecurringRevenue: monthlyRevenue / 100,
        totalRevenue: totalRevenue / 100,
        averageRevenuePerUser: 145.50, // Mock data
        revenueGrowthRate: 23.5, // Mock data
        churnRate: 5.2, // Mock data
        lifetimeValue: 2450.00, // Mock data
      });
    } catch (err) {
      console.error('Error fetching revenue metrics:', err);
      throw err;
    }
  };

  const fetchJobMetrics = async () => {
    try {
      const { count: totalJobsPosted } = await supabase
        .from('jobs')
        .select('*', { count: 'exact', head: true });

      // Get job performance data
      const { data: jobsWithCounts } = await supabase
        .from('jobs')
        .select(`
          id,
          title,
          applications!applications_job_id_fkey(count),
          recruiter_bids!recruiter_bids_job_id_fkey(count)
        `);

      const totalApplications = jobsWithCounts?.reduce((sum, job) => 
        sum + (job.applications?.length || 0), 0) || 0;
      
      const totalBids = jobsWithCounts?.reduce((sum, job) => 
        sum + (job.recruiter_bids?.length || 0), 0) || 0;

      const averageApplicationsPerJob = totalJobsPosted 
        ? Math.round((totalApplications / totalJobsPosted) * 100) / 100
        : 0;

      const averageBidsPerJob = totalJobsPosted 
        ? Math.round((totalBids / totalJobsPosted) * 100) / 100
        : 0;

      // Calculate job fill rate
      const { count: filledJobs } = await supabase
        .from('jobs')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'filled');

      const jobFillRate = totalJobsPosted && filledJobs
        ? Math.round((filledJobs / totalJobsPosted) * 10000) / 100
        : 0;

      setJobMetrics({
        totalJobsPosted: totalJobsPosted || 0,
        averageApplicationsPerJob,
        averageBidsPerJob,
        jobFillRate,
        averageTimeToFill: 18.5, // Mock data
        topPerformingJobs: [], // Would be calculated from actual data
      });
    } catch (err) {
      console.error('Error fetching job metrics:', err);
      throw err;
    }
  };

  const generateReport = async (reportType: string, parameters: any = {}) => {
    try {
      const { data, error } = await supabase
        .from('reports')
        .insert({
          name: `${reportType} Report`,
          description: `Generated ${reportType} report`,
          report_type: reportType,
          parameters,
          generated_by: user?.id,
          status: 'pending',
        })
        .select()
        .single();

      if (error) throw error;

      // In a real implementation, this would trigger a background job
      // to generate the actual report file
      console.log('Report generation initiated:', data.id);
      
      return data;
    } catch (err) {
      console.error('Error generating report:', err);
      throw err;
    }
  };

  const updatePlatformSetting = async (key: string, value: any) => {
    try {
      const { error } = await supabase
        .from('platform_settings')
        .upsert({
          key,
          value: typeof value === 'string' ? `"${value}"` : JSON.stringify(value),
          updated_at: new Date().toISOString(),
        });

      if (error) throw error;
    } catch (err) {
      console.error('Error updating platform setting:', err);
      throw err;
    }
  };

  const toggleFeatureFlag = async (flagName: string, enabled: boolean) => {
    try {
      const { error } = await supabase
        .from('feature_flags')
        .update({ 
          is_enabled: enabled,
          updated_at: new Date().toISOString()
        })
        .eq('name', flagName);

      if (error) throw error;
    } catch (err) {
      console.error('Error toggling feature flag:', err);
      throw err;
    }
  };

  const fetchAllMetrics = async () => {
    try {
      setLoading(true);
      setError(null);

      await Promise.all([
        fetchPlatformMetrics(),
        fetchUserEngagementMetrics(),
        fetchRevenueMetrics(),
        fetchJobMetrics(),
      ]);
    } catch (err) {
      console.error('Error fetching analytics:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch analytics');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.role === 'admin') {
      fetchAllMetrics();
    }
  }, [user]);

  return {
    platformMetrics,
    userEngagement,
    revenueMetrics,
    jobMetrics,
    loading,
    error,
    generateReport,
    updatePlatformSetting,
    toggleFeatureFlag,
    refetch: fetchAllMetrics,
  };
};