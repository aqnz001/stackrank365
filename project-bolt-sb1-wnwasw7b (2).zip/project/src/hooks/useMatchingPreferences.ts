import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

export interface MatchingPreferences {
  id: string;
  userId: string;
  skillWeight: number;
  locationWeight: number;
  salaryWeight: number;
  experienceWeight: number;
  industryWeight: number;
  maxCommuteDistance: number;
  remoteWorkPreference: 'required' | 'preferred' | 'flexible' | 'no';
  salaryFlexibility: number;
  notificationFrequency: 'immediate' | 'daily' | 'weekly' | 'never';
  createdAt: Date;
  updatedAt: Date;
}

export const useMatchingPreferences = () => {
  const [preferences, setPreferences] = useState<MatchingPreferences | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchPreferences = async () => {
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      console.log('Fetching matching preferences for user:', user.id);
      
      const { data, error: fetchError } = await supabase
        .from('matching_preferences')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (fetchError && fetchError.code !== 'PGRST116') {
        throw fetchError;
      }

      if (data) {
        console.log('Matching preferences found');
        setPreferences({
          id: data.id,
          userId: data.user_id,
          skillWeight: data.skill_weight,
          locationWeight: data.location_weight,
          salaryWeight: data.salary_weight,
          experienceWeight: data.experience_weight,
          industryWeight: data.industry_weight,
          maxCommuteDistance: data.max_commute_distance,
          remoteWorkPreference: data.remote_work_preference,
          salaryFlexibility: data.salary_flexibility,
          notificationFrequency: data.notification_frequency,
          createdAt: new Date(data.created_at),
          updatedAt: new Date(data.updated_at),
        });
      } else {
        console.log('No matching preferences found, creating defaults');
        // Create default preferences
        await createDefaultPreferences();
      }
    } catch (err) {
      console.error('Error fetching matching preferences:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch preferences');
    } finally {
      setLoading(false);
    }
  };

  const createDefaultPreferences = async () => {
    if (!user) return;

    try {
      console.log('Creating default matching preferences for user:', user.id);
      
      const { data, error } = await supabase
        .from('matching_preferences')
        .insert({
          user_id: user.id,
          skill_weight: 0.30,
          location_weight: 0.25,
          salary_weight: 0.20,
          experience_weight: 0.15,
          industry_weight: 0.10,
          max_commute_distance: 50,
          remote_work_preference: 'flexible',
          salary_flexibility: 0.15,
          notification_frequency: 'daily',
        })
        .select()
        .single();

      if (error) throw error;

      console.log('Default matching preferences created');
      setPreferences({
        id: data.id,
        userId: data.user_id,
        skillWeight: data.skill_weight,
        locationWeight: data.location_weight,
        salaryWeight: data.salary_weight,
        experienceWeight: data.experience_weight,
        industryWeight: data.industry_weight,
        maxCommuteDistance: data.max_commute_distance,
        remoteWorkPreference: data.remote_work_preference,
        salaryFlexibility: data.salary_flexibility,
        notificationFrequency: data.notification_frequency,
        createdAt: new Date(data.created_at),
        updatedAt: new Date(data.updated_at),
      });
    } catch (err) {
      console.error('Error creating default preferences:', err);
      throw err;
    }
  };

  const updatePreferences = async (updates: Partial<MatchingPreferences>) => {
    if (!preferences) return;

    try {
      const { error } = await supabase
        .from('matching_preferences')
        .update({
          skill_weight: updates.skillWeight,
          location_weight: updates.locationWeight,
          salary_weight: updates.salaryWeight,
          experience_weight: updates.experienceWeight,
          industry_weight: updates.industryWeight,
          max_commute_distance: updates.maxCommuteDistance,
          remote_work_preference: updates.remoteWorkPreference,
          salary_flexibility: updates.salaryFlexibility,
          notification_frequency: updates.notificationFrequency,
          updated_at: new Date().toISOString(),
        })
        .eq('id', preferences.id);

      if (error) throw error;

      setPreferences(prev => prev ? { ...prev, ...updates, updatedAt: new Date() } : null);
    } catch (err) {
      console.error('Error updating preferences:', err);
      throw err;
    }
  };

  const calculateJobMatch = (job: Job, candidateProfile: any): number => {
    if (!preferences) return 0;

    let totalScore = 0;
    let totalWeight = 0;

    // Skill matching
    if (candidateProfile.skills && job.skills.length > 0) {
      const skillMatches = job.skills.filter(jobSkill =>
        candidateProfile.skills.some((candidateSkill: string) =>
          candidateSkill.toLowerCase().includes(jobSkill.toLowerCase()) ||
          jobSkill.toLowerCase().includes(candidateSkill.toLowerCase())
        )
      ).length;
      
      const skillScore = (skillMatches / job.skills.length) * 100;
      totalScore += skillScore * preferences.skillWeight;
      totalWeight += preferences.skillWeight;
    }

    // Location matching
    if (candidateProfile.location && job.location) {
      const locationScore = calculateLocationMatch(candidateProfile.location, job.location);
      totalScore += locationScore * preferences.locationWeight;
      totalWeight += preferences.locationWeight;
    }

    // Salary matching
    if (candidateProfile.salaryExpectation && job.salaryRange) {
      const salaryScore = calculateSalaryMatch(candidateProfile.salaryExpectation, job.salaryRange);
      totalScore += salaryScore * preferences.salaryWeight;
      totalWeight += preferences.salaryWeight;
    }

    // Experience matching
    if (candidateProfile.experienceYears && job.skills.length > 0) {
      const experienceScore = calculateExperienceMatch(candidateProfile.experienceYears, job);
      totalScore += experienceScore * preferences.experienceWeight;
      totalWeight += preferences.experienceWeight;
    }

    return totalWeight > 0 ? Math.round(totalScore / totalWeight) : 0;
  };

  const calculateLocationMatch = (candidateLocation: string, jobLocation: string): number => {
    if (jobLocation.toLowerCase().includes('remote')) return 100;
    if (candidateLocation.toLowerCase() === jobLocation.toLowerCase()) return 100;
    
    // Simple city matching (in production, use geolocation APIs)
    const candidateCity = candidateLocation.split(',')[0].trim().toLowerCase();
    const jobCity = jobLocation.split(',')[0].trim().toLowerCase();
    
    return candidateCity === jobCity ? 80 : 20;
  };

  const calculateSalaryMatch = (expectation: number, range: { min: number; max: number }): number => {
    if (expectation >= range.min && expectation <= range.max) return 100;
    
    const flexibility = preferences?.salaryFlexibility || 0.15;
    const flexibleMin = range.min * (1 - flexibility);
    const flexibleMax = range.max * (1 + flexibility);
    
    if (expectation >= flexibleMin && expectation <= flexibleMax) return 75;
    
    return Math.max(0, 50 - Math.abs(expectation - range.max) / 1000);
  };

  const calculateExperienceMatch = (candidateYears: number, job: Job): number => {
    // Estimate required experience based on job complexity
    const requiredYears = estimateRequiredExperience(job);
    const difference = Math.abs(candidateYears - requiredYears);
    
    if (difference <= 1) return 100;
    if (difference <= 2) return 80;
    if (difference <= 3) return 60;
    return Math.max(20, 60 - (difference * 10));
  };

  const estimateRequiredExperience = (job: Job): number => {
    const title = job.title.toLowerCase();
    
    if (title.includes('senior') || title.includes('lead')) return 5;
    if (title.includes('principal') || title.includes('staff')) return 8;
    if (title.includes('junior') || title.includes('entry')) return 1;
    if (title.includes('mid') || title.includes('intermediate')) return 3;
    
    return 3; // Default
  };

  useEffect(() => {
    fetchPreferences();
  }, [user]);

  return {
    preferences,
    loading,
    error,
    updatePreferences,
    calculateJobMatch,
    refetch: fetchPreferences,
  };
};