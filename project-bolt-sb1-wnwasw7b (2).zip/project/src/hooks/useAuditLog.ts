import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

export interface AuditLogEntry {
  id: string;
  userId: string;
  userName?: string;
  action: string;
  entityType: string;
  entityId?: string;
  oldValues?: any;
  newValues?: any;
  ipAddress?: string;
  userAgent?: string;
  createdAt: Date;
}

export const useAuditLog = () => {
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchAuditLogs = async (limit = 100, offset = 0) => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('audit_logs')
        .select(`
          *,
          profiles!audit_logs_user_id_fkey (
            name
          )
        `)
        .order('created_at', { ascending: false })
        .range(offset, offset + limit - 1);

      if (fetchError) throw fetchError;

      const transformedLogs: AuditLogEntry[] = (data || []).map(log => ({
        id: log.id,
        userId: log.user_id,
        userName: log.profiles?.name,
        action: log.action,
        entityType: log.entity_type,
        entityId: log.entity_id,
        oldValues: log.old_values,
        newValues: log.new_values,
        ipAddress: log.ip_address,
        userAgent: log.user_agent,
        createdAt: new Date(log.created_at),
      }));

      setAuditLogs(transformedLogs);
    } catch (err) {
      console.error('Error fetching audit logs:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch audit logs');
    } finally {
      setLoading(false);
    }
  };

  const logAction = async (data: {
    action: string;
    entityType: string;
    entityId?: string;
    oldValues?: any;
    newValues?: any;
  }) => {
    try {
      const { error } = await supabase
        .from('audit_logs')
        .insert({
          user_id: user?.id,
          action: data.action,
          entity_type: data.entityType,
          entity_id: data.entityId,
          old_values: data.oldValues,
          new_values: data.newValues,
          // IP and user agent would be captured server-side in a real implementation
        });

      if (error) throw error;
    } catch (err) {
      console.error('Error logging action:', err);
      // Don't throw here as audit logging shouldn't break the main flow
    }
  };

  const searchAuditLogs = async (filters: {
    userId?: string;
    action?: string;
    entityType?: string;
    dateFrom?: Date;
    dateTo?: Date;
  }) => {
    try {
      setLoading(true);
      
      let query = supabase
        .from('audit_logs')
        .select(`
          *,
          profiles!audit_logs_user_id_fkey (
            name
          )
        `);

      if (filters.userId) {
        query = query.eq('user_id', filters.userId);
      }
      
      if (filters.action) {
        query = query.eq('action', filters.action);
      }
      
      if (filters.entityType) {
        query = query.eq('entity_type', filters.entityType);
      }
      
      if (filters.dateFrom) {
        query = query.gte('created_at', filters.dateFrom.toISOString());
      }
      
      if (filters.dateTo) {
        query = query.lte('created_at', filters.dateTo.toISOString());
      }

      const { data, error } = await query
        .order('created_at', { ascending: false })
        .limit(500);

      if (error) throw error;

      const transformedLogs: AuditLogEntry[] = (data || []).map(log => ({
        id: log.id,
        userId: log.user_id,
        userName: log.profiles?.name,
        action: log.action,
        entityType: log.entity_type,
        entityId: log.entity_id,
        oldValues: log.old_values,
        newValues: log.new_values,
        ipAddress: log.ip_address,
        userAgent: log.user_agent,
        createdAt: new Date(log.created_at),
      }));

      setAuditLogs(transformedLogs);
    } catch (err) {
      console.error('Error searching audit logs:', err);
      setError(err instanceof Error ? err.message : 'Failed to search audit logs');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.role === 'admin') {
      fetchAuditLogs();
    }
  }, [user]);

  return {
    auditLogs,
    loading,
    error,
    fetchAuditLogs,
    logAction,
    searchAuditLogs,
  };
};