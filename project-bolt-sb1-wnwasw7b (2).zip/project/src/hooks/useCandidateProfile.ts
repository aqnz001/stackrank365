import { useEffect, useMemo, useState } from 'react';
import { useAuth } from '../context/AuthContext';

export interface WorkExperience {
  id: string;
  jobTitle: string;
  company: string;
  industry: string;
  startMonth: string;
  startYear: string;
  endMonth: string;
  endYear: string;
  isCurrentRole: boolean;
  description: string;
}

export interface RoleClassification { id: string; category: string; subcategory: string }
export interface WorkLocation { id: string; city: string; area: string }

export interface ResumeMeta { id: string; name: string; url?: string; path?: string; size?: number; uploadedAt?: string; }

export interface CandidateProfile {
  workExperience: WorkExperience[];
  currentStatus: {
    location: string;
    roleClassifications: RoleClassification[];
    jobSeekingStatus?: string;
    availability?: string;
  };
  qualifications: { highestQualification: string; skills: string[] };
  rolePreferences: {
    workTypes: string[];
    workLocations: WorkLocation[];
    rightToWorkNZ: string;
    salaryType: string; // Annual | Hourly
    minimumSalary: string; // display label
  };
  resumes?: ResumeMeta[];
  primaryResumeId?: string;
}

const keyFor = (userId: string) => `candidate_profile:${userId}`;

export const useCandidateProfile = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<CandidateProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    if (!user) { setProfile(null); return; }
    setLoading(true);
    try {
      const raw = localStorage.getItem(keyFor(user.id));
      setProfile(raw ? JSON.parse(raw) : null);
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  const save = (p: CandidateProfile) => {
    if (!user) return;
    setProfile(p);
    localStorage.setItem(keyFor(user.id), JSON.stringify(p));
  };

  const isComplete = useMemo(() => {
    if (!profile) return false;
    const hasLocation = !!profile.currentStatus.location?.trim();
    const hasExp = profile.workExperience?.length > 0 && !!profile.workExperience[0].jobTitle?.trim();
    const hasSkills = (profile.qualifications.skills || []).length > 0;
    return hasLocation && hasExp && hasSkills;
  }, [profile]);

  return { profile, save, loading, isComplete } as const;
};
