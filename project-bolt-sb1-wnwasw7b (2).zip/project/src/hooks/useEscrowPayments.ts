import { supabase } from '../lib/supabase';

export const useEscrowPayments = () => {
  const createPaymentIntent = async (opts: { amountCents: number; currency?: string; metadata?: Record<string, any> }) => {
    try {
      const { data, error } = await (supabase as any).functions.invoke('create_escrow_payment_intent', {
        body: {
          amount: opts.amountCents,
          currency: opts.currency || 'USD',
          metadata: opts.metadata || {},
        },
      });
      if (error) throw error;
      return { ok: true as const, clientSecret: data?.client_secret || null };
    } catch (e) {
      console.warn('[escrow] createPaymentIntent failed or not configured', e);
      return { ok: false as const, clientSecret: null };
    }
  };

  const capturePayment = async (paymentIntentId: string) => {
    try {
      const { data, error } = await (supabase as any).functions.invoke('capture_escrow_payment', { body: { payment_intent_id: paymentIntentId } });
      if (error) throw error;
      return { ok: true as const };
    } catch (e) {
      console.warn('[escrow] capturePayment failed or not configured', e);
      return { ok: false as const };
    }
  };

  const refundPayment = async (paymentIntentId: string, amountCents?: number) => {
    try {
      const { data, error } = await (supabase as any).functions.invoke('refund_escrow_payment', { body: { payment_intent_id: paymentIntentId, amount: amountCents } });
      if (error) throw error;
      return { ok: true as const };
    } catch (e) {
      console.warn('[escrow] refundPayment failed or not configured', e);
      return { ok: false as const };
    }
  };

  return { createPaymentIntent, capturePayment, refundPayment };
};

