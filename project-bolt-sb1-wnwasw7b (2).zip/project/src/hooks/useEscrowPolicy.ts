import { useState, useCallback, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

export interface EscrowPolicy {
  title: string;
  content: string;
  updatedAt: string; // ISO
}

const KEY = 'platform_escrow_policy_v1';

const read = (): EscrowPolicy | null => {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && parsed.content) return parsed as EscrowPolicy;
    return null;
  } catch {
    return null;
  }
};

const write = (value: EscrowPolicy) => {
  localStorage.setItem(KEY, JSON.stringify(value));
};

export const useEscrowPolicy = () => {
  const { user } = useAuth();
  const [policy, setPolicy] = useState<EscrowPolicy | null>(() => read());

  const loadRemote = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('escrow_policies')
        .select('*')
        .eq('is_active', true)
        .order('updated_at', { ascending: false })
        .limit(1);
      if (error) throw error;
      if (data && data.length > 0) {
        setPolicy({ title: data[0].title, content: data[0].content, updatedAt: data[0].updated_at });
      }
    } catch (e) {
      console.warn('[escrow] failed to load remote policy, using local', e);
      setPolicy(read());
    }
  }, []);

  useEffect(() => { if (user) loadRemote(); }, [user, loadRemote]);

  const save = useCallback(async (input: { title: string; content: string }) => {
    const value: EscrowPolicy = {
      title: input.title.trim() || 'Escrow Terms & Conditions',
      content: input.content,
      updatedAt: new Date().toISOString(),
    };
    try {
      // Deactivate previous active
      await supabase.from('escrow_policies').update({ is_active: false }).eq('is_active', true);
      // Insert new active
      const { error } = await supabase.from('escrow_policies').insert({ title: value.title, content: value.content, is_active: true });
      if (error) throw error;
      await loadRemote();
    } catch (e) {
      console.warn('[escrow] remote save failed, persisting local', e);
      write(value);
      setPolicy(value);
    }
  }, [loadRemote]);

  return { policy, save };
};
