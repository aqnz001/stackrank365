import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { compressImage } from '../utils/performance';

export interface FileUploadOptions {
  bucket: 'resumes' | 'profile-photos' | 'company-logos' | 'documents';
  fileType: 'resume' | 'profile_photo' | 'company_logo' | 'document';
  maxSize?: number; // in bytes
  allowedTypes?: string[];
  organizationId?: string;
}

export interface UploadedFile {
  id: string;
  url: string;
  path: string;
  name: string;
  size: number;
  type: string;
}

export const useFileUpload = () => {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const validateFile = (file: File, options: FileUploadOptions): string | null => {
    // Check file size
    const maxSize = options.maxSize || getDefaultMaxSize(options.bucket);
    if (file.size > maxSize) {
      return `File size must be less than ${formatFileSize(maxSize)}`;
    }

    // Check file type
    const allowedTypes = options.allowedTypes || getDefaultAllowedTypes(options.bucket);
    if (!allowedTypes.includes(file.type)) {
      return `File type ${file.type} is not allowed. Allowed types: ${allowedTypes.join(', ')}`;
    }

    return null;
  };

  const uploadFile = async (file: File, options: FileUploadOptions): Promise<UploadedFile> => {
    if (!user) {
      throw new Error('User must be authenticated to upload files');
    }

    setUploading(true);
    setProgress(0);
    setError(null);

    try {
      // Validate file
      const validationError = validateFile(file, options);
      if (validationError) {
        throw new Error(validationError);
      }

      // Compress images if needed
      let fileToUpload = file;
      if (file.type.startsWith('image/') && file.size > 1024 * 1024) { // Compress if > 1MB
        try {
          const compressedBlob = await compressImage(file, 1200, 0.8);
          fileToUpload = new File([compressedBlob], file.name, { type: 'image/jpeg' });
          console.log('Image compressed:', file.size, '→', fileToUpload.size);
        } catch (compressionError) {
          console.warn('Image compression failed, using original:', compressionError);
        }
      }

      // Generate unique file path
      const fileExt = fileToUpload.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = options.organizationId 
        ? `${options.organizationId}/${fileName}`
        : `${user.id}/${fileName}`;

      // Upload to Supabase Storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from(options.bucket)
        .upload(filePath, fileToUpload, {
          cacheControl: '3600',
          upsert: false,
        });

      if (uploadError) {
        throw uploadError;
      }

      setProgress(50);

      // Save file metadata to database
      const { data: fileRecord, error: dbError } = await supabase
        .from('file_uploads')
        .insert({
          user_id: user.id,
          organization_id: options.organizationId || null,
          bucket_name: options.bucket,
          file_path: uploadData.path,
          file_name: file.name,
          file_size: fileToUpload.size,
          mime_type: fileToUpload.type,
          file_type: options.fileType,
          metadata: {
            original_name: file.name,
            original_size: file.size,
            compressed: fileToUpload.size !== file.size,
            uploaded_at: new Date().toISOString(),
          },
        })
        .select()
        .single();

      if (dbError) {
        // Clean up uploaded file if database insert fails
        await supabase.storage.from(options.bucket).remove([uploadData.path]);
        throw dbError;
      }

      setProgress(100);

      // Get public URL for public buckets
      let publicUrl = '';
      if (options.bucket === 'profile-photos' || options.bucket === 'company-logos') {
        const { data } = supabase.storage.from(options.bucket).getPublicUrl(uploadData.path);
        publicUrl = data.publicUrl;
      } else {
        // For private buckets, create signed URL
        const { data } = await supabase.storage
          .from(options.bucket)
          .createSignedUrl(uploadData.path, 3600); // 1 hour expiry
        publicUrl = data?.signedUrl || '';
      }

      return {
        id: fileRecord.id,
        url: publicUrl,
        path: uploadData.path,
        name: file.name,
        size: file.size,
        type: file.type,
      };
    } catch (err) {
      console.error('File upload error:', err);
      const errorMessage = err instanceof Error ? err.message : 'Failed to upload file';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setUploading(false);
      setProgress(0);
    }
  };

  const deleteFile = async (fileId: string): Promise<void> => {
    if (!user) {
      throw new Error('User must be authenticated to delete files');
    }

    try {
      // Get file record
      const { data: fileRecord, error: fetchError } = await supabase
        .from('file_uploads')
        .select('*')
        .eq('id', fileId)
        .single();

      if (fetchError || !fileRecord) {
        throw new Error('File not found');
      }

      // Delete from storage
      const { error: storageError } = await supabase.storage
        .from(fileRecord.bucket_name)
        .remove([fileRecord.file_path]);

      if (storageError) {
        throw storageError;
      }

      // Delete from database
      const { error: dbError } = await supabase
        .from('file_uploads')
        .delete()
        .eq('id', fileId);

      if (dbError) {
        throw dbError;
      }
    } catch (err) {
      console.error('File deletion error:', err);
      throw err;
    }
  };

  const getSignedUrl = async (filePath: string, bucket: string, expiresIn = 3600): Promise<string> => {
    console.log('getSignedUrl called with:', { filePath, bucket, expiresIn });

    const { data, error } = await supabase.storage
      .from(bucket)
      .createSignedUrl(filePath, expiresIn);

    console.log('getSignedUrl response:', { data, error });

    if (error) {
      throw error;
    }

    if (!data?.signedUrl) {
      throw new Error('No signed URL returned from Supabase');
    }

    return data.signedUrl;
  };

  return {
    uploadFile,
    deleteFile,
    getSignedUrl,
    uploading,
    progress,
    error,
  };
};

// Helper functions
const getDefaultMaxSize = (bucket: string): number => {
  switch (bucket) {
    case 'resumes':
      return 10 * 1024 * 1024; // 10MB
    case 'profile-photos':
      return 5 * 1024 * 1024; // 5MB
    case 'company-logos':
      return 2 * 1024 * 1024; // 2MB
    case 'documents':
      return 20 * 1024 * 1024; // 20MB
    default:
      return 5 * 1024 * 1024; // 5MB default
  }
};

const getDefaultAllowedTypes = (bucket: string): string[] => {
  switch (bucket) {
    case 'resumes':
      return ['application/pdf'];
    case 'profile-photos':
      return ['image/jpeg', 'image/png', 'image/webp'];
    case 'company-logos':
      return ['image/jpeg', 'image/png', 'image/svg+xml', 'image/webp'];
    case 'documents':
      return [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'image/jpeg',
        'image/png'
      ];
    default:
      return ['*/*'];
  }
};

const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};