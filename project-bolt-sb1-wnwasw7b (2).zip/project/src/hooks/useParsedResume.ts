import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export interface ParsedExperience {
  id?: string;
  jobTitle: string;
  company: string;
  industry?: string;
  startMonth?: string;
  startYear?: string;
  endMonth?: string;
  endYear?: string;
  isCurrentRole?: boolean;
  description?: string;
}

export interface ParsedEducation {
  degree?: string;
  institution?: string;
  fieldOfStudy?: string;
  graduationYear?: string;
}

export interface ParsedResumeData {
  id: string;
  fileUploadId: string;
  userId: string;
  parsedText: string | null;
  parsedSkills: string[];
  parsedExperiences: ParsedExperience[];
  parsedEducation: ParsedEducation[];
  parsedMetadata: Record<string, any>;
  parsingStatus: 'pending' | 'completed' | 'failed' | 'stale';
  parsingError: string | null;
  parsedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export function useParsedResume(fileUploadId?: string) {
  const [parsedData, setParsedData] = useState<ParsedResumeData | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!fileUploadId) {
      setParsedData(null);
      return;
    }

    fetchParsedData(fileUploadId);
  }, [fileUploadId]);

  const fetchParsedData = async (fileId: string) => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('resume_parsed_data')
        .select('*')
        .eq('file_upload_id', fileId)
        .maybeSingle();

      if (fetchError) {
        throw fetchError;
      }

      if (data) {
        setParsedData({
          id: data.id,
          fileUploadId: data.file_upload_id,
          userId: data.user_id,
          parsedText: data.parsed_text,
          parsedSkills: data.parsed_skills || [],
          parsedExperiences: data.parsed_experiences || [],
          parsedEducation: data.parsed_education || [],
          parsedMetadata: data.parsed_metadata || {},
          parsingStatus: data.parsing_status,
          parsingError: data.parsing_error,
          parsedAt: data.parsed_at,
          createdAt: data.created_at,
          updatedAt: data.updated_at,
        });
      } else {
        setParsedData(null);
      }
    } catch (err: any) {
      console.error('Error fetching parsed resume data:', err);
      setError(err.message || 'Failed to fetch parsed resume data');
      setParsedData(null);
    } finally {
      setLoading(false);
    }
  };

  const createParsedData = async (
    fileId: string,
    userId: string,
    parsed: {
      text?: string;
      skills?: string[];
      experiences?: ParsedExperience[];
      education?: ParsedEducation[];
      metadata?: Record<string, any>;
    }
  ): Promise<ParsedResumeData | null> => {
    try {
      setLoading(true);
      setError(null);

      const insertData = {
        file_upload_id: fileId,
        user_id: userId,
        parsed_text: parsed.text || null,
        parsed_skills: parsed.skills || [],
        parsed_experiences: parsed.experiences || [],
        parsed_education: parsed.education || [],
        parsed_metadata: parsed.metadata || {},
        parsing_status: 'completed',
        parsed_at: new Date().toISOString(),
      };

      const { data, error: insertError } = await supabase
        .from('resume_parsed_data')
        .insert(insertData)
        .select()
        .single();

      if (insertError) {
        throw insertError;
      }

      const newParsedData: ParsedResumeData = {
        id: data.id,
        fileUploadId: data.file_upload_id,
        userId: data.user_id,
        parsedText: data.parsed_text,
        parsedSkills: data.parsed_skills || [],
        parsedExperiences: data.parsed_experiences || [],
        parsedEducation: data.parsed_education || [],
        parsedMetadata: data.parsed_metadata || {},
        parsingStatus: data.parsing_status,
        parsingError: data.parsing_error,
        parsedAt: data.parsed_at,
        createdAt: data.created_at,
        updatedAt: data.updated_at,
      };

      setParsedData(newParsedData);
      return newParsedData;
    } catch (err: any) {
      console.error('Error creating parsed resume data:', err);
      setError(err.message || 'Failed to create parsed resume data');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const updateParsedData = async (
    fileId: string,
    parsed: {
      text?: string;
      skills?: string[];
      experiences?: ParsedExperience[];
      education?: ParsedEducation[];
      metadata?: Record<string, any>;
      status?: 'pending' | 'completed' | 'failed' | 'stale';
      error?: string | null;
    }
  ): Promise<ParsedResumeData | null> => {
    try {
      setLoading(true);
      setError(null);

      const updateData: any = {};
      if (parsed.text !== undefined) updateData.parsed_text = parsed.text;
      if (parsed.skills !== undefined) updateData.parsed_skills = parsed.skills;
      if (parsed.experiences !== undefined) updateData.parsed_experiences = parsed.experiences;
      if (parsed.education !== undefined) updateData.parsed_education = parsed.education;
      if (parsed.metadata !== undefined) updateData.parsed_metadata = parsed.metadata;
      if (parsed.status !== undefined) updateData.parsing_status = parsed.status;
      if (parsed.error !== undefined) updateData.parsing_error = parsed.error;

      if (parsed.status === 'completed') {
        updateData.parsed_at = new Date().toISOString();
      }

      const { data, error: updateError } = await supabase
        .from('resume_parsed_data')
        .update(updateData)
        .eq('file_upload_id', fileId)
        .select()
        .single();

      if (updateError) {
        throw updateError;
      }

      const updatedParsedData: ParsedResumeData = {
        id: data.id,
        fileUploadId: data.file_upload_id,
        userId: data.user_id,
        parsedText: data.parsed_text,
        parsedSkills: data.parsed_skills || [],
        parsedExperiences: data.parsed_experiences || [],
        parsedEducation: data.parsed_education || [],
        parsedMetadata: data.parsed_metadata || {},
        parsingStatus: data.parsing_status,
        parsingError: data.parsing_error,
        parsedAt: data.parsed_at,
        createdAt: data.created_at,
        updatedAt: data.updated_at,
      };

      setParsedData(updatedParsedData);
      return updatedParsedData;
    } catch (err: any) {
      console.error('Error updating parsed resume data:', err);
      setError(err.message || 'Failed to update parsed resume data');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const markAsFailed = async (fileId: string, errorMsg: string) => {
    return updateParsedData(fileId, {
      status: 'failed',
      error: errorMsg,
    });
  };

  const markAsStale = async (fileId: string) => {
    return updateParsedData(fileId, {
      status: 'stale',
    });
  };

  const refetch = async () => {
    if (fileUploadId) {
      await fetchParsedData(fileUploadId);
    }
  };

  return {
    parsedData,
    loading,
    error,
    createParsedData,
    updateParsedData,
    markAsFailed,
    markAsStale,
    refetch,
  };
}

export function useParsedResumeByUser(userId?: string) {
  const [parsedResumes, setParsedResumes] = useState<ParsedResumeData[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!userId) {
      setParsedResumes([]);
      return;
    }

    fetchUserParsedResumes(userId);
  }, [userId]);

  const fetchUserParsedResumes = async (uid: string) => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('resume_parsed_data')
        .select('*')
        .eq('user_id', uid)
        .order('created_at', { ascending: false });

      if (fetchError) {
        throw fetchError;
      }

      const resumes: ParsedResumeData[] = (data || []).map((item) => ({
        id: item.id,
        fileUploadId: item.file_upload_id,
        userId: item.user_id,
        parsedText: item.parsed_text,
        parsedSkills: item.parsed_skills || [],
        parsedExperiences: item.parsed_experiences || [],
        parsedEducation: item.parsed_education || [],
        parsedMetadata: item.parsed_metadata || {},
        parsingStatus: item.parsing_status,
        parsingError: item.parsing_error,
        parsedAt: item.parsed_at,
        createdAt: item.created_at,
        updatedAt: item.updated_at,
      }));

      setParsedResumes(resumes);
    } catch (err: any) {
      console.error('Error fetching user parsed resumes:', err);
      setError(err.message || 'Failed to fetch parsed resumes');
      setParsedResumes([]);
    } finally {
      setLoading(false);
    }
  };

  const refetch = async () => {
    if (userId) {
      await fetchUserParsedResumes(userId);
    }
  };

  return {
    parsedResumes,
    loading,
    error,
    refetch,
  };
}
