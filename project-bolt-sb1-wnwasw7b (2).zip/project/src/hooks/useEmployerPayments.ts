import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export interface EmployerPayment {
  id: string;
  recruiterBidId: string;
  jobId: string;
  applicationId: string;
  employerOrgId: string;
  amount: number;
  currency: string;
  status: 'pending' | 'paid' | 'refunded' | 'failed';
  paymentDate: Date | null;
  paymentMethod: string | null;
  transactionId: string | null;
  notes: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export const useEmployerPayments = () => {
  const [payments, setPayments] = useState<EmployerPayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchPayments = async () => {
    try {
      setLoading(true);
      const { data, error: fetchError } = await supabase
        .from('employer_payments')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;

      const mapped = (data || []).map((p: any) => ({
        id: p.id,
        recruiterBidId: p.recruiter_bid_id,
        jobId: p.job_id,
        applicationId: p.application_id,
        employerOrgId: p.employer_org_id,
        amount: p.amount,
        currency: p.currency,
        status: p.status,
        paymentDate: p.payment_date ? new Date(p.payment_date) : null,
        paymentMethod: p.payment_method,
        transactionId: p.transaction_id,
        notes: p.notes,
        createdAt: new Date(p.created_at),
        updatedAt: new Date(p.updated_at),
      }));

      setPayments(mapped);
    } catch (err) {
      console.error('Error fetching employer payments:', err);
      setError(err as Error);
    } finally {
      setLoading(false);
    }
  };

  const createPayment = async (payment: Omit<EmployerPayment, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const { data, error: createError } = await supabase
        .from('employer_payments')
        .insert({
          recruiter_bid_id: payment.recruiterBidId,
          job_id: payment.jobId,
          application_id: payment.applicationId,
          employer_org_id: payment.employerOrgId,
          amount: payment.amount,
          currency: payment.currency,
          status: payment.status,
          payment_date: payment.paymentDate,
          payment_method: payment.paymentMethod,
          transaction_id: payment.transactionId,
          notes: payment.notes,
        })
        .select()
        .single();

      if (createError) throw createError;
      await fetchPayments();
      return data;
    } catch (err) {
      console.error('Error creating employer payment:', err);
      throw err;
    }
  };

  const updatePaymentStatus = async (id: string, status: EmployerPayment['status']) => {
    try {
      const { error: updateError } = await supabase
        .from('employer_payments')
        .update({ status, payment_date: status === 'paid' ? new Date().toISOString() : undefined })
        .eq('id', id);

      if (updateError) throw updateError;
      await fetchPayments();
    } catch (err) {
      console.error('Error updating employer payment:', err);
      throw err;
    }
  };

  useEffect(() => {
    fetchPayments();

    const channel = supabase
      .channel('employer_payments_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'employer_payments' }, () => {
        fetchPayments();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return {
    payments,
    loading,
    error,
    createPayment,
    updatePaymentStatus,
    refetch: fetchPayments,
  };
};
