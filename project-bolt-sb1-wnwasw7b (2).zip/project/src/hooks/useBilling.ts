import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

export interface BillingAccount {
  id: string;
  organizationId: string;
  stripeCustomerId?: string;
  billingEmail?: string;
  companyName?: string;
  taxId?: string;
  billingAddress: any;
  paymentMethodId?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface PaymentMethod {
  id: string;
  billingAccountId: string;
  stripePaymentMethodId: string;
  type: string;
  cardBrand?: string;
  cardLast4?: string;
  cardExpMonth?: number;
  cardExpYear?: number;
  isDefault: boolean;
  createdAt: Date;
}

export interface Invoice {
  id: string;
  billingAccountId: string;
  stripeInvoiceId?: string;
  invoiceNumber?: string;
  status: 'draft' | 'open' | 'paid' | 'void' | 'uncollectible';
  amountDue: number;
  amountPaid: number;
  currency: string;
  description?: string;
  dueDate?: Date;
  paidAt?: Date;
  createdAt: Date;
  items: InvoiceItem[];
}

export interface InvoiceItem {
  id: string;
  invoiceId: string;
  description: string;
  quantity: number;
  unitAmount: number;
  totalAmount: number;
  metadata: any;
}

export interface Payment {
  id: string;
  billingAccountId: string;
  invoiceId?: string;
  stripePaymentIntentId?: string;
  amount: number;
  currency: string;
  status: 'pending' | 'processing' | 'succeeded' | 'failed' | 'canceled' | 'refunded';
  paymentMethodId?: string;
  description?: string;
  metadata: any;
  createdAt: Date;
}

export const useBilling = () => {
  const [billingAccount, setBillingAccount] = useState<BillingAccount | null>(null);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchBillingData = async () => {
    console.log('useBilling: fetchBillingData called', { organizationId: user?.organizationId, role: user?.role });

    if (!user?.organizationId && user?.role !== 'admin') {
      console.log('useBilling: No organizationId and not admin, exiting early');
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      console.log('useBilling: Starting to fetch billing data');

      // Admin users fetch all billing data across all organizations
      if (user?.role === 'admin') {
        // Fetch all invoices with items for admin
        const { data: invoicesData, error: invoicesError } = await supabase
          .from('invoices')
          .select(`
            *,
            invoice_items (*)
          `)
          .order('created_at', { ascending: false });

        if (invoicesError) throw invoicesError;

        setInvoices((invoicesData || []).map(invoice => ({
          id: invoice.id,
          billingAccountId: invoice.billing_account_id,
          stripeInvoiceId: invoice.stripe_invoice_id,
          invoiceNumber: invoice.invoice_number,
          status: invoice.status,
          amountDue: invoice.amount_due,
          amountPaid: invoice.amount_paid,
          currency: invoice.currency,
          description: invoice.description,
          dueDate: invoice.due_date ? new Date(invoice.due_date) : undefined,
          paidAt: invoice.paid_at ? new Date(invoice.paid_at) : undefined,
          createdAt: new Date(invoice.created_at),
          items: (invoice.invoice_items || []).map((item: any) => ({
            id: item.id,
            invoiceId: item.invoice_id,
            description: item.description,
            quantity: item.quantity,
            unitAmount: item.unit_amount,
            totalAmount: item.total_amount,
            metadata: item.metadata,
          })),
        })));

        // Fetch all payments for admin
        const { data: paymentsData, error: paymentsError } = await supabase
          .from('payments')
          .select('*')
          .order('created_at', { ascending: false });

        if (paymentsError) throw paymentsError;

        setPayments((paymentsData || []).map(payment => ({
          id: payment.id,
          billingAccountId: payment.billing_account_id,
          invoiceId: payment.invoice_id,
          stripePaymentIntentId: payment.stripe_payment_intent_id,
          amount: payment.amount,
          currency: payment.currency,
          status: payment.status,
          paymentMethodId: payment.payment_method_id,
          description: payment.description,
          metadata: payment.metadata,
          createdAt: new Date(payment.created_at),
        })));

        setLoading(false);
        return;
      }

      // Regular users fetch their organization's billing data
      // Fetch billing account
      const { data: billingData, error: billingError } = await supabase
        .from('billing_accounts')
        .select('*')
        .eq('organization_id', user.organizationId)
        .single();

      if (billingError && billingError.code !== 'PGRST116') {
        throw billingError;
      }

      if (billingData) {
        setBillingAccount({
          id: billingData.id,
          organizationId: billingData.organization_id,
          stripeCustomerId: billingData.stripe_customer_id,
          billingEmail: billingData.billing_email,
          companyName: billingData.company_name,
          taxId: billingData.tax_id,
          billingAddress: billingData.billing_address,
          paymentMethodId: billingData.payment_method_id,
          createdAt: new Date(billingData.created_at),
          updatedAt: new Date(billingData.updated_at),
        });

        // Fetch payment methods
        const { data: paymentMethodsData, error: pmError } = await supabase
          .from('payment_methods')
          .select('*')
          .eq('billing_account_id', billingData.id)
          .order('created_at', { ascending: false });

        if (pmError) throw pmError;

        setPaymentMethods((paymentMethodsData || []).map(pm => ({
          id: pm.id,
          billingAccountId: pm.billing_account_id,
          stripePaymentMethodId: pm.stripe_payment_method_id,
          type: pm.type,
          cardBrand: pm.card_brand,
          cardLast4: pm.card_last4,
          cardExpMonth: pm.card_exp_month,
          cardExpYear: pm.card_exp_year,
          isDefault: pm.is_default,
          createdAt: new Date(pm.created_at),
        })));

        // Fetch invoices with items
        const { data: invoicesData, error: invoicesError } = await supabase
          .from('invoices')
          .select(`
            *,
            invoice_items (*)
          `)
          .eq('billing_account_id', billingData.id)
          .order('created_at', { ascending: false });

        if (invoicesError) throw invoicesError;

        setInvoices((invoicesData || []).map(invoice => ({
          id: invoice.id,
          billingAccountId: invoice.billing_account_id,
          stripeInvoiceId: invoice.stripe_invoice_id,
          invoiceNumber: invoice.invoice_number,
          status: invoice.status,
          amountDue: invoice.amount_due,
          amountPaid: invoice.amount_paid,
          currency: invoice.currency,
          description: invoice.description,
          dueDate: invoice.due_date ? new Date(invoice.due_date) : undefined,
          paidAt: invoice.paid_at ? new Date(invoice.paid_at) : undefined,
          createdAt: new Date(invoice.created_at),
          items: (invoice.invoice_items || []).map((item: any) => ({
            id: item.id,
            invoiceId: item.invoice_id,
            description: item.description,
            quantity: item.quantity,
            unitAmount: item.unit_amount,
            totalAmount: item.total_amount,
            metadata: item.metadata,
          })),
        })));

        // Fetch payments
        const { data: paymentsData, error: paymentsError } = await supabase
          .from('payments')
          .select('*')
          .eq('billing_account_id', billingData.id)
          .order('created_at', { ascending: false });

        if (paymentsError) throw paymentsError;

        setPayments((paymentsData || []).map(payment => ({
          id: payment.id,
          billingAccountId: payment.billing_account_id,
          invoiceId: payment.invoice_id,
          stripePaymentIntentId: payment.stripe_payment_intent_id,
          amount: payment.amount,
          currency: payment.currency,
          status: payment.status,
          paymentMethodId: payment.payment_method_id,
          description: payment.description,
          metadata: payment.metadata,
          createdAt: new Date(payment.created_at),
        })));
      }
      console.log('useBilling: Successfully fetched billing data');
    } catch (err) {
      console.error('useBilling: Error fetching billing data:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch billing data');
    } finally {
      console.log('useBilling: Setting loading to false');
      setLoading(false);
    }
  };

  const createBillingAccount = async (data: {
    billingEmail: string;
    companyName: string;
    taxId?: string;
    billingAddress: any;
  }) => {
    if (!user?.organizationId) {
      throw new Error('Organization ID required');
    }

    try {
      const { data: billingData, error } = await supabase
        .from('billing_accounts')
        .insert({
          organization_id: user.organizationId,
          billing_email: data.billingEmail,
          company_name: data.companyName,
          tax_id: data.taxId,
          billing_address: data.billingAddress,
        })
        .select()
        .single();

      if (error) throw error;

      await fetchBillingData();
      return billingData;
    } catch (err) {
      console.error('Error creating billing account:', err);
      throw err;
    }
  };

  const updateBillingAccount = async (updates: Partial<BillingAccount>) => {
    if (!billingAccount) {
      throw new Error('No billing account found');
    }

    try {
      const { error } = await supabase
        .from('billing_accounts')
        .update({
          billing_email: updates.billingEmail,
          company_name: updates.companyName,
          tax_id: updates.taxId,
          billing_address: updates.billingAddress,
          updated_at: new Date().toISOString(),
        })
        .eq('id', billingAccount.id);

      if (error) throw error;

      await fetchBillingData();
    } catch (err) {
      console.error('Error updating billing account:', err);
      throw err;
    }
  };

  const createInvoice = async (data: {
    description: string;
    items: Array<{
      description: string;
      quantity: number;
      unitAmount: number;
    }>;
    dueDate?: Date;
  }) => {
    if (!billingAccount) {
      throw new Error('No billing account found');
    }

    try {
      const totalAmount = data.items.reduce((sum, item) => sum + (item.quantity * item.unitAmount), 0);

      const { data: invoiceData, error: invoiceError } = await supabase
        .from('invoices')
        .insert({
          billing_account_id: billingAccount.id,
          invoice_number: `INV-${Date.now()}`,
          status: 'open',
          amount_due: totalAmount,
          currency: 'usd',
          description: data.description,
          due_date: data.dueDate?.toISOString(),
        })
        .select()
        .single();

      if (invoiceError) throw invoiceError;

      // Create invoice items
      const invoiceItems = data.items.map(item => ({
        invoice_id: invoiceData.id,
        description: item.description,
        quantity: item.quantity,
        unit_amount: item.unitAmount,
        total_amount: item.quantity * item.unitAmount,
      }));

      const { error: itemsError } = await supabase
        .from('invoice_items')
        .insert(invoiceItems);

      if (itemsError) throw itemsError;

      await fetchBillingData();
      return invoiceData;
    } catch (err) {
      console.error('Error creating invoice:', err);
      throw err;
    }
  };

  useEffect(() => {
    console.log('useBilling: useEffect triggered', { organizationId: user?.organizationId, role: user?.role });
    if (user?.organizationId || user?.role === 'admin') {
      console.log('useBilling: Calling fetchBillingData from useEffect');
      fetchBillingData();
    } else {
      console.log('useBilling: Not fetching - no organizationId and not admin');
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.organizationId, user?.role]);

  const isBillingComplete = (): boolean => {
    if (!billingAccount) return false;

    const hasRequiredFields = !!(
      billingAccount.billingEmail &&
      billingAccount.companyName &&
      billingAccount.taxId
    );

    const hasCompleteAddress = !!(
      billingAccount.billingAddress?.line1 &&
      billingAccount.billingAddress?.city &&
      billingAccount.billingAddress?.postal_code &&
      billingAccount.billingAddress?.country
    );

    return hasRequiredFields && hasCompleteAddress;
  };

  return {
    billingAccount,
    paymentMethods,
    invoices,
    payments,
    loading,
    error,
    refetch: fetchBillingData,
    createBillingAccount,
    updateBillingAccount,
    createInvoice,
    isBillingComplete,
  };
};