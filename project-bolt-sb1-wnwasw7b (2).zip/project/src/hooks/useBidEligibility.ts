import { useEffect, useMemo, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useSubscriptions } from './useSubscriptions';
import { useRecruiterProfile } from './useRecruiterProfile';
import { supabase } from '../lib/supabase';
import type { Job } from '../types';

export const useBidEligibility = (job?: Job | null) => {
  const { user } = useAuth();
  const { currentSubscription } = useSubscriptions();
  const { /* isComplete: profileComplete */ } = useRecruiterProfile();
  const [activeBids, setActiveBids] = useState<number>(0);
  const [hasMyBid, setHasMyBid] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    const fetch = async () => {
      if (!job) return;
      setLoading(true);
      const capacity = typeof job.bidLimit === 'number' && job.bidLimit >= 0 ? job.bidLimit : Infinity;
      // Capacity query (optional if unlimited)
      const capPromise = (async () => {
        if (capacity === Infinity) { setActiveBids(0); return; }
        const { count, error } = await supabase
          .from('recruiter_bids')
          .select('*', { head: true, count: 'exact' })
          .eq('job_id', job.id)
          .not('status', 'in', '(withdrawn,rejected,expired)');
        if (error) {
          console.warn('Capacity count failed, assuming zero:', error.message);
          setActiveBids(0);
        } else {
          setActiveBids(count || 0);
        }
      })();

      // Has-my-bid query
      const minePromise = (async () => {
        if (!user?.id) { setHasMyBid(false); return; }
        const { count, error } = await supabase
          .from('recruiter_bids')
          .select('*', { head: true, count: 'exact' })
          .eq('job_id', job.id)
          .eq('recruiter_id', user.id)
          .not('status', 'in', '(withdrawn,rejected,expired)');
        if (error) {
          console.warn('My-bid check failed, assuming false:', error.message);
          setHasMyBid(false);
        } else {
          setHasMyBid((count || 0) > 0);
        }
      })();

      await Promise.all([capPromise, minePromise]).catch(() => {});
      setLoading(false);
    };
    fetch();
  }, [job?.id, job?.bidLimit, user?.id]);

  const result = useMemo(() => {
    if (!user || user.role !== 'recruiter') return { canBid: false, reason: 'Recruiter account required', slotsLeft: 0, loading } as const;
    if (!job) return { canBid: false, reason: 'No job selected', slotsLeft: 0, loading } as const;
    if (job.visibility !== 'open') return { canBid: false, reason: 'Not open to recruiters', slotsLeft: 0, loading } as const;

    // Capacity
    const capacity = typeof job.bidLimit === 'number' && job.bidLimit >= 0 ? job.bidLimit : Infinity;
    const slotsLeft = Math.max(0, capacity - activeBids);
    if (capacity !== Infinity && slotsLeft <= 0) return { canBid: false, reason: 'Bid capacity reached', slotsLeft: 0, loading } as const;

    // Prevent multiple bids per recruiter per job (new rule)
    if (hasMyBid) return { canBid: false, reason: 'Already bid on this job', slotsLeft, loading } as const;

    // Onboarding completeness not required for bidding (must have KYC only)
    // Identity verification
    if (user.kycStatus && user.kycStatus !== 'verified') return { canBid: false, reason: 'Recruiter verification required', slotsLeft, loading } as const;

    // Banking verification not required to place bids (can be done later)

    // Subscription (temporarily not required for bidding)

    // Blocklist
    if ((job.blockedRecruiterIds || []).includes(user.id)) return { canBid: false, reason: 'You are blocklisted for this job', slotsLeft, loading } as const;

    // Simple daily rate limit via localStorage
    const key = `bid_rate:${user.id}:${new Date().toISOString().slice(0,10)}`;
    let used = 0; try { used = parseInt(localStorage.getItem(key) || '0'); } catch {}
    if (used >= 25) return { canBid: false, reason: 'Daily bid limit reached', slotsLeft, loading } as const;

    return { canBid: true, reason: '', slotsLeft, loading } as const;
  }, [user?.id, user?.kycStatus, user?.role, job?.id, job?.visibility, job?.bidLimit, job?.blockedRecruiterIds, activeBids, currentSubscription, loading, hasMyBid]);

  // Debug log when eligibility changes
  useEffect(() => {
    if (!job) return;
    console.log('[BidEligibility]', {
      jobId: job.id,
      userId: user?.id,
      role: user?.role,
      kycStatus: user?.kycStatus,
      canBid: result.canBid,
      reason: (result as any).reason,
      slotsLeft: (result as any).slotsLeft,
      activeBids,
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [job?.id, user?.id, user?.role, user?.kycStatus, result.canBid, (result as any).reason, (result as any).slotsLeft, activeBids]);

  const recordBid = () => {
    const u = user; if (!u) return;
    const key = `bid_rate:${u.id}:${new Date().toISOString().slice(0,10)}`;
    let used = 0; try { used = parseInt(localStorage.getItem(key) || '0'); } catch {}
    localStorage.setItem(key, String(used + 1));
  };

  return { ...result, activeBids, recordBid } as const;
};
