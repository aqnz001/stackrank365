import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  recipientId: string;
  content: string;
  messageType: 'text' | 'file' | 'system';
  read: boolean;
  createdAt: Date;
  senderName?: string;
  recipientName?: string;
}

export interface Conversation {
  id: string;
  participants: string[];
  jobId?: string;
  lastMessageAt: Date;
  createdAt: Date;
  jobTitle?: string;
  participantNames?: string[];
  lastMessage?: Message;
  unreadCount?: number;
}

export const useMessages = () => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<Record<string, Message[]>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchConversations = async () => {
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('conversations')
        .select(`
          *,
          jobs (title)
        `)
        .contains('participants', [user.id])
        .order('last_message_at', { ascending: false });

      if (fetchError) throw fetchError;

      const transformedConversations: Conversation[] = await Promise.all(
        (data || []).map(async (conv) => {
          // Get participant names
          const { data: participants } = await supabase
            .from('profiles')
            .select('id, name')
            .in('id', conv.participants);

          // Get last message
          const { data: lastMessage } = await supabase
            .from('messages')
            .select('*')
            .eq('conversation_id', conv.id)
            .order('created_at', { ascending: false })
            .limit(1)
            .single();

          // Get unread count
          const { count: unreadCount } = await supabase
            .from('messages')
            .select('*', { count: 'exact', head: true })
            .eq('conversation_id', conv.id)
            .eq('recipient_id', user.id)
            .eq('read', false);

          return {
            id: conv.id,
            participants: conv.participants,
            jobId: conv.job_id,
            lastMessageAt: new Date(conv.last_message_at),
            createdAt: new Date(conv.created_at),
            jobTitle: conv.jobs?.title,
            participantNames: participants?.map(p => p.name) || [],
            lastMessage: lastMessage ? {
              id: lastMessage.id,
              conversationId: lastMessage.conversation_id,
              senderId: lastMessage.sender_id,
              recipientId: lastMessage.recipient_id,
              content: lastMessage.content,
              messageType: lastMessage.message_type,
              read: lastMessage.read,
              createdAt: new Date(lastMessage.created_at),
            } : undefined,
            unreadCount: unreadCount || 0,
          };
        })
      );

      setConversations(transformedConversations);
    } catch (err) {
      console.error('Error fetching conversations:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch conversations');
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async (conversationId: string) => {
    try {
      const { data, error: fetchError } = await supabase
        .from('messages')
        .select(`
          *,
          sender:profiles!messages_sender_id_fkey (name),
          recipient:profiles!messages_recipient_id_fkey (name)
        `)
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: true });

      if (fetchError) throw fetchError;

      const transformedMessages: Message[] = (data || []).map(msg => ({
        id: msg.id,
        conversationId: msg.conversation_id,
        senderId: msg.sender_id,
        recipientId: msg.recipient_id,
        content: msg.content,
        messageType: msg.message_type,
        read: msg.read,
        createdAt: new Date(msg.created_at),
        senderName: msg.sender?.name,
        recipientName: msg.recipient?.name,
      }));

      setMessages(prev => ({ ...prev, [conversationId]: transformedMessages }));
      return transformedMessages;
    } catch (err) {
      console.error('Error fetching messages:', err);
      throw err;
    }
  };

  const createConversation = async (data: {
    participantIds: string[];
    jobId?: string;
    initialMessage?: string;
  }) => {
    if (!user) throw new Error('User not authenticated');

    try {
      const { data: conversation, error: convError } = await supabase
        .from('conversations')
        .insert({
          participants: data.participantIds,
          job_id: data.jobId,
        })
        .select()
        .single();

      if (convError) throw convError;

      // Send initial message if provided
      if (data.initialMessage) {
        const recipientId = data.participantIds.find(id => id !== user.id);
        if (recipientId) {
          await sendMessage(conversation.id, recipientId, data.initialMessage);
        }
      }

      await fetchConversations();
      return conversation;
    } catch (err) {
      console.error('Error creating conversation:', err);
      throw err;
    }
  };

  const sendMessage = async (conversationId: string, recipientId: string, content: string) => {
    if (!user) throw new Error('User not authenticated');

    try {
      const { data, error } = await supabase
        .from('messages')
        .insert({
          conversation_id: conversationId,
          sender_id: user.id,
          recipient_id: recipientId,
          content,
          message_type: 'text',
        })
        .select()
        .single();

      if (error) throw error;

      // Update conversation last message time
      await supabase
        .from('conversations')
        .update({ last_message_at: new Date().toISOString() })
        .eq('id', conversationId);

      return data;
    } catch (err) {
      console.error('Error sending message:', err);
      throw err;
    }
  };

  const markMessagesAsRead = async (conversationId: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('messages')
        .update({ read: true })
        .eq('conversation_id', conversationId)
        .eq('recipient_id', user.id)
        .eq('read', false);

      if (error) throw error;

      // Update local state
      setMessages(prev => ({
        ...prev,
        [conversationId]: prev[conversationId]?.map(msg => 
          msg.recipientId === user.id ? { ...msg, read: true } : msg
        ) || []
      }));

      // Update conversation unread count
      setConversations(prev => 
        prev.map(conv => 
          conv.id === conversationId ? { ...conv, unreadCount: 0 } : conv
        )
      );
    } catch (err) {
      console.error('Error marking messages as read:', err);
    }
  };

  // Set up real-time subscription for messages
  useEffect(() => {
    if (!user) return;

    const subscription = supabase
      .channel('messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `recipient_id=eq.${user.id}`,
        },
        async (payload) => {
          const newMessage: Message = {
            id: payload.new.id,
            conversationId: payload.new.conversation_id,
            senderId: payload.new.sender_id,
            recipientId: payload.new.recipient_id,
            content: payload.new.content,
            messageType: payload.new.message_type,
            read: payload.new.read,
            createdAt: new Date(payload.new.created_at),
          };

          // Add to messages
          setMessages(prev => ({
            ...prev,
            [newMessage.conversationId]: [
              ...(prev[newMessage.conversationId] || []),
              newMessage
            ]
          }));

          // Update conversation
          setConversations(prev => 
            prev.map(conv => 
              conv.id === newMessage.conversationId 
                ? { 
                    ...conv, 
                    lastMessage: newMessage,
                    lastMessageAt: newMessage.createdAt,
                    unreadCount: (conv.unreadCount || 0) + 1
                  }
                : conv
            )
          );
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [user]);

  useEffect(() => {
    fetchConversations();
  }, [user]);

  return {
    conversations,
    messages,
    loading,
    error,
    fetchMessages,
    createConversation,
    sendMessage,
    markMessagesAsRead,
    refetch: fetchConversations,
  };
};