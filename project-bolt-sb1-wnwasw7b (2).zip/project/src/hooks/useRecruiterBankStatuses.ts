import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

export type BankStatus = 'verified' | 'pending' | 'missing';

export const useRecruiterBankStatuses = (userIds: string[]) => {
  const [map, setMap] = useState<Record<string, BankStatus>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchStatuses = async () => {
    console.log('[Banking] Fetch statuses for userIds:', userIds);
    if (!userIds || userIds.length === 0) { setMap({}); return; }
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase
        .from('recruiter_profiles')
        .select('user_id, profile_json')
        .in('user_id', userIds);
      if (error) throw error as any;
      const m: Record<string, BankStatus> = {};
      (data || []).forEach((row: any) => {
        const status = (row?.profile_json?.bankStatus || 'missing') as BankStatus;
        m[row.user_id] = status;
      });
      setMap(m);
      console.log('[Banking] Statuses loaded:', m);
    } catch (e: any) {
      setError(e?.message || 'Failed to load banking statuses');
      console.error('[Banking] Status fetch error:', e);
      setMap({});
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchStatuses(); }, [JSON.stringify(userIds)]);

  return { statuses: map, loading, error, refetch: fetchStatuses } as const;
};
