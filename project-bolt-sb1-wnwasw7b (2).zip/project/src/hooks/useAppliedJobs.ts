import { useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { useApplications } from './useApplications';

export const useAppliedJobs = () => {
  const { user } = useAuth();
  const { applications, loading } = useApplications();

  const ids = useMemo(() => {
    if (!user || user.role !== 'candidate') return new Set<string>();
    return new Set((applications || []).map(a => a.jobId));
  }, [applications, user?.role, user?.id]);

  const isApplied = (jobId?: string | null) => !!jobId && ids.has(jobId);

  return { ids, isApplied, loading } as const;
};

