import type { WorkExperience } from './useCandidateProfile';

export interface ParsedResume {
  skills: string[];
  experiences: WorkExperience[];
}

const uniq = <T,>(arr: T[]) => Array.from(new Set(arr));

export function parseResumeText(text: string): ParsedResume {
  const normalized = (text || '').replace(/\r\n?/g, '\n');

  // Extract Skills section heuristically
  let skillsBlock = '';
  const lower = normalized.toLowerCase();
  const skillsIdx = lower.indexOf('skills');
  if (skillsIdx >= 0) {
    const after = normalized.slice(skillsIdx + 'skills'.length);
    // Take up to next heading-like line or 500 chars
    const chunk = after.slice(0, 600);
    skillsBlock = chunk.split('\n').slice(0, 8).join('\n');
  }

  const rawTokens = skillsBlock
    .split(/[,\n•;\t]/g)
    .map(s => s.trim())
    .filter(Boolean)
    .filter(s => s.length <= 40 && s.length >= 2);
  const skills = uniq(rawTokens).slice(0, 12);

  // Extract simple experience lines "Title at Company" or "Title - Company"
  const experiences: WorkExperience[] = [];
  const lines = normalized.split('\n');
  for (const line of lines) {
    const l = line.trim();
    if (!l) continue;
    const m1 = l.match(/^(?<title>[^•\-\u2013\u2014]{2,60})\s+(?:-|–|—|at)\s+(?<company>[^•\u2013\u2014]{2,80})/i);
    if (m1 && m1.groups) {
      const jobTitle = m1.groups.title.trim();
      const company = m1.groups.company.trim().replace(/[•|·].*$/, '');
      if (jobTitle && company) {
        experiences.push({
          id: String(experiences.length + 1) + '-' + Math.random().toString(36).slice(2, 7),
          jobTitle,
          company,
          industry: '',
          startMonth: '',
          startYear: '',
          endMonth: '',
          endYear: '',
          isCurrentRole: false,
          description: '',
        });
      }
    }
    if (experiences.length >= 5) break;
  }

  return { skills, experiences };
}

