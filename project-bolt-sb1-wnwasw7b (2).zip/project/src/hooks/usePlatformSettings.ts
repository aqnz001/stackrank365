import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';

export interface PlatformSetting {
  id: string;
  key: string;
  value: any;
  description?: string;
  category: string;
  isPublic: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface FeatureFlag {
  id: string;
  name: string;
  description?: string;
  isEnabled: boolean;
  rolloutPercentage: number;
  targetRoles: string[];
  targetOrganizations: string[];
  metadata: any;
  createdAt: Date;
  updatedAt: Date;
}

export const usePlatformSettings = () => {
  const [settings, setSettings] = useState<PlatformSetting[]>([]);
  const [featureFlags, setFeatureFlags] = useState<FeatureFlag[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchSettings = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('platform_settings')
        .select('*')
        .order('category', { ascending: true });

      if (fetchError) throw fetchError;

      const transformedSettings: PlatformSetting[] = (data || []).map(setting => ({
        id: setting.id,
        key: setting.key,
        value: setting.value,
        description: setting.description,
        category: setting.category,
        isPublic: setting.is_public,
        createdAt: new Date(setting.created_at),
        updatedAt: new Date(setting.updated_at),
      }));

      setSettings(transformedSettings);
    } catch (err) {
      console.error('Error fetching platform settings:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch settings');
    } finally {
      setLoading(false);
    }
  };

  const fetchFeatureFlags = async () => {
    try {
      const { data, error: fetchError } = await supabase
        .from('feature_flags')
        .select('*')
        .order('name', { ascending: true });

      if (fetchError) throw fetchError;

      const transformedFlags: FeatureFlag[] = (data || []).map(flag => ({
        id: flag.id,
        name: flag.name,
        description: flag.description,
        isEnabled: flag.is_enabled,
        rolloutPercentage: flag.rollout_percentage,
        targetRoles: flag.target_roles || [],
        targetOrganizations: flag.target_organizations || [],
        metadata: flag.metadata,
        createdAt: new Date(flag.created_at),
        updatedAt: new Date(flag.updated_at),
      }));

      setFeatureFlags(transformedFlags);
    } catch (err) {
      console.error('Error fetching feature flags:', err);
      throw err;
    }
  };

  const updateSetting = async (key: string, value: any) => {
    try {
      const { error } = await supabase
        .from('platform_settings')
        .update({
          value: typeof value === 'string' ? `"${value}"` : JSON.stringify(value),
          updated_at: new Date().toISOString(),
        })
        .eq('key', key);

      if (error) throw error;

      // Update local state
      setSettings(prev => 
        prev.map(setting => 
          setting.key === key 
            ? { ...setting, value, updatedAt: new Date() }
            : setting
        )
      );
    } catch (err) {
      console.error('Error updating setting:', err);
      throw err;
    }
  };

  const toggleFeatureFlag = async (name: string, enabled: boolean) => {
    try {
      const { error } = await supabase
        .from('feature_flags')
        .update({
          is_enabled: enabled,
          updated_at: new Date().toISOString(),
        })
        .eq('name', name);

      if (error) throw error;

      // Update local state
      setFeatureFlags(prev => 
        prev.map(flag => 
          flag.name === name 
            ? { ...flag, isEnabled: enabled, updatedAt: new Date() }
            : flag
        )
      );
    } catch (err) {
      console.error('Error toggling feature flag:', err);
      throw err;
    }
  };

  const createFeatureFlag = async (data: {
    name: string;
    description?: string;
    isEnabled?: boolean;
    rolloutPercentage?: number;
    targetRoles?: string[];
  }) => {
    try {
      const { data: newFlag, error } = await supabase
        .from('feature_flags')
        .insert({
          name: data.name,
          description: data.description,
          is_enabled: data.isEnabled || false,
          rollout_percentage: data.rolloutPercentage || 0,
          target_roles: data.targetRoles || [],
        })
        .select()
        .single();

      if (error) throw error;

      await fetchFeatureFlags();
      return newFlag;
    } catch (err) {
      console.error('Error creating feature flag:', err);
      throw err;
    }
  };

  const getSetting = (key: string, defaultValue?: any) => {
    const setting = settings.find(s => s.key === key);
    return setting ? setting.value : defaultValue;
  };

  const isFeatureEnabled = (flagName: string, userRole?: string) => {
    const flag = featureFlags.find(f => f.name === flagName);
    if (!flag || !flag.isEnabled) return false;
    
    // Check role targeting
    if (flag.targetRoles.length > 0 && userRole) {
      return flag.targetRoles.includes(userRole);
    }
    
    return true;
  };

  useEffect(() => {
    if (user?.role === 'admin') {
      fetchSettings();
      fetchFeatureFlags();
    }
  }, [user]);

  return {
    settings,
    featureFlags,
    loading,
    error,
    updateSetting,
    toggleFeatureFlag,
    createFeatureFlag,
    getSetting,
    isFeatureEnabled,
    refetch: () => {
      fetchSettings();
      fetchFeatureFlags();
    },
  };
};