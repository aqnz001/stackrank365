import { useAuth } from '../context/AuthContext';
import { useState } from 'react';
import { supabase } from '../lib/supabase';

const keyFor = (userId: string) => `consent_codes:${userId}`;

export interface ConsentCode {
  code: string;
  createdAt: string;
  expiresAt: string;
  usedBy?: string; // recruiter id
  usedAt?: string;
}

export const useConsentCodes = () => {
  const { user } = useAuth();
  const [error, setError] = useState<string | null>(null);

  const listLocal = (): ConsentCode[] => {
    if (!user) return [];
    try { const raw = localStorage.getItem(keyFor(user.id)); return raw ? JSON.parse(raw) : []; } catch { return []; }
  };
  const saveLocal = (arr: ConsentCode[]) => { if (user) localStorage.setItem(keyFor(user.id), JSON.stringify(arr)); };

  const generate = async () => {
    if (!user) throw new Error('Not authenticated');
    setError(null);
    const code = Math.random().toString(36).slice(2, 8).toUpperCase();
    const now = new Date();
    const expires = new Date(now.getTime() + 1000 * 60 * 30); // 30 min

    // Try supabase table 'consent_codes' if exists
    try {
      const { error } = await supabase.from('consent_codes').insert({
        candidate_id: user.id,
        code,
        expires_at: expires.toISOString(),
        used_by: null,
      });
      if (error) throw error;
    } catch (e) {
      // fallback to local
      const arr = listLocal();
      arr.unshift({ code, createdAt: now.toISOString(), expiresAt: expires.toISOString() });
      saveLocal(arr);
    }
    return { code, expiresAt: expires };
  };

  const verify = async (code: string): Promise<{ candidateId?: string; ok: boolean; reason?: string }> => {
    // Try supabase
    try {
      const { data, error } = await supabase.from('consent_codes').select('*').eq('code', code).single();
      if (!error && data) {
        if (data.used_by) return { ok: false, reason: 'Code already used' };
        if (new Date(data.expires_at).getTime() < Date.now()) return { ok: false, reason: 'Code expired' };
        return { ok: true, candidateId: data.candidate_id };
      }
    } catch {}
    // Fallback to local
    const allUsersRaw = Object.keys(localStorage).filter(k => k.startsWith('consent_codes:'));
    for (const k of allUsersRaw) {
      try {
        const arr: ConsentCode[] = JSON.parse(localStorage.getItem(k) || '[]');
        const found = arr.find(c => c.code === code);
        if (found) {
          if (new Date(found.expiresAt).getTime() < Date.now()) return { ok: false, reason: 'Code expired' };
          const candidateId = k.split(':')[1];
          return { ok: true, candidateId };
        }
      } catch {}
    }
    return { ok: false, reason: 'Code not found' };
  };

  const markUsed = async (code: string, recruiterId: string) => {
    try {
      const { error } = await supabase.from('consent_codes').update({ used_by: recruiterId, used_at: new Date().toISOString() }).eq('code', code);
      if (error) throw error;
      return;
    } catch {
      // local: no-op
    }
  };

  return { generate, verify, markUsed, error } as const;
};

