import { supabase } from '../lib/supabase';

export type MilestoneTrigger = 'interview_scheduled' | 'candidate_hired' | 'probation_completed';

export interface TriggerMilestoneParams {
  trigger: MilestoneTrigger;
  recruiterBidId: string;
  applicationId?: string;
  interviewId?: string;
  notes?: string;
}

export const triggerPaymentMilestone = async (params: TriggerMilestoneParams) => {
  try {
    const { data, error } = await supabase.functions.invoke('trigger-payment-milestones', {
      body: params,
    });

    if (error) throw error;

    return {
      success: true,
      data,
    };
  } catch (error) {
    console.error('Error triggering payment milestone:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred',
    };
  }
};

export const createScheduledPaymentsForBid = async (
  recruiterBidId: string,
  escrowTransactionId: string,
  totalAmount: number,
  paymentScheduleId: string
) => {
  try {
    const { data: schedule, error: scheduleError } = await supabase
      .from('payment_schedules')
      .select('*')
      .eq('id', paymentScheduleId)
      .single();

    if (scheduleError) throw scheduleError;

    const milestones = schedule.milestones as Array<{
      name: string;
      trigger: string;
      percentage: number;
      description: string;
    }>;

    const paymentsToCreate = milestones.map((milestone, index) => ({
      recruiter_bid_id: recruiterBidId,
      escrow_transaction_id: escrowTransactionId,
      milestone_name: milestone.name,
      milestone_trigger: milestone.trigger,
      amount: Math.round((totalAmount * milestone.percentage) / 100),
      percentage: milestone.percentage,
      status: 'pending',
      sequence_order: index + 1,
    }));

    const { error: insertError } = await supabase
      .from('scheduled_payments')
      .insert(paymentsToCreate);

    if (insertError) throw insertError;

    return {
      success: true,
      count: paymentsToCreate.length,
    };
  } catch (error) {
    console.error('Error creating scheduled payments:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred',
    };
  }
};

export const calculateRecruiterFee = (
  feeType: 'flat' | 'percent',
  feeValue: number,
  salaryAmount?: number
): number => {
  if (feeType === 'flat') {
    return feeValue;
  }

  if (feeType === 'percent' && salaryAmount) {
    return (salaryAmount * feeValue) / 100;
  }

  return 0;
};

export const getMilestoneProgress = (payments: Array<{ status: string }>) => {
  const total = payments.length;
  if (total === 0) return { completed: 0, percentage: 0 };

  const completed = payments.filter(
    (p) => p.status === 'released' || p.status === 'triggered'
  ).length;
  const percentage = Math.round((completed / total) * 100);

  return { completed, total, percentage };
};

export const getNextMilestone = (payments: Array<{
  milestoneName: string;
  status: string;
  sequenceOrder: number;
}>) => {
  const pending = payments
    .filter((p) => p.status === 'pending')
    .sort((a, b) => a.sequenceOrder - b.sequenceOrder);

  return pending.length > 0 ? pending[0] : null;
};

export const canTriggerMilestone = (
  trigger: MilestoneTrigger,
  applicationStatus: string,
  hasInterview: boolean
): boolean => {
  switch (trigger) {
    case 'interview_scheduled':
      return hasInterview;
    case 'candidate_hired':
      return applicationStatus === 'hired';
    case 'probation_completed':
      return applicationStatus === 'hired';
    default:
      return false;
  }
};
