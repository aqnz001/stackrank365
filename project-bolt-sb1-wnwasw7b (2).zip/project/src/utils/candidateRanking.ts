import type { Application, Job } from '../types';

export interface RankingWeights {
  skills_match_weight: number;
  experience_weight: number;
  education_weight: number;
  location_weight: number;
  salary_weight: number;
  availability_weight: number;
}

export interface CandidateScore {
  applicationId: string;
  totalScore: number;
  breakdown: {
    skillsScore: number;
    experienceScore: number;
    educationScore: number;
    locationScore: number;
    salaryScore: number;
    availabilityScore: number;
  };
  rank: number;
}

export interface RankedCandidate extends Application {
  score: CandidateScore;
}

const DEFAULT_WEIGHTS: RankingWeights = {
  skills_match_weight: 30,
  experience_weight: 25,
  education_weight: 15,
  location_weight: 10,
  salary_weight: 15,
  availability_weight: 5,
};

export const calculateSkillsMatch = (
  candidateSkills: string[],
  jobSkills: string[]
): number => {
  if (!jobSkills || jobSkills.length === 0) return 100;
  if (!candidateSkills || candidateSkills.length === 0) return 0;

  const normalizedJobSkills = jobSkills.map(s => s.toLowerCase().trim());
  const normalizedCandidateSkills = candidateSkills.map(s => s.toLowerCase().trim());

  const matchCount = normalizedJobSkills.filter(jobSkill =>
    normalizedCandidateSkills.some(candSkill =>
      candSkill.includes(jobSkill) || jobSkill.includes(candSkill)
    )
  ).length;

  return Math.round((matchCount / normalizedJobSkills.length) * 100);
};

export const calculateExperienceScore = (
  candidateExperience: string | number | undefined,
  jobExperienceLevel?: string
): number => {
  if (!jobExperienceLevel) return 100;

  const expYears = typeof candidateExperience === 'number'
    ? candidateExperience
    : parseInt(String(candidateExperience || '0'));

  const experienceMap: Record<string, { min: number; max: number }> = {
    entry: { min: 0, max: 2 },
    mid: { min: 2, max: 5 },
    senior: { min: 5, max: 10 },
    lead: { min: 8, max: 20 },
  };

  const required = experienceMap[jobExperienceLevel.toLowerCase()] || { min: 0, max: 100 };

  if (expYears >= required.min && expYears <= required.max + 2) {
    return 100;
  } else if (expYears < required.min) {
    const deficit = required.min - expYears;
    return Math.max(0, 100 - (deficit * 20));
  } else {
    const excess = expYears - required.max;
    return Math.max(50, 100 - (excess * 5));
  }
};

export const calculateEducationScore = (
  candidateEducation: string | undefined
): number => {
  if (!candidateEducation) return 50;

  const edu = candidateEducation.toLowerCase();
  const educationLevels: Record<string, number> = {
    'phd': 100,
    'doctorate': 100,
    'masters': 90,
    'master': 90,
    'mba': 90,
    'bachelor': 75,
    'undergraduate': 75,
    'associate': 60,
    'diploma': 50,
    'certificate': 40,
    'high school': 30,
  };

  for (const [level, score] of Object.entries(educationLevels)) {
    if (edu.includes(level)) return score;
  }

  return 50;
};

export const calculateLocationScore = (
  candidateLocation: string | undefined,
  jobLocation: string | undefined,
  willingToRelocate?: boolean
): number => {
  if (!jobLocation) return 100;
  if (!candidateLocation) return willingToRelocate ? 75 : 25;

  const candLoc = candidateLocation.toLowerCase().trim();
  const jobLoc = jobLocation.toLowerCase().trim();

  if (jobLoc.includes('remote') || jobLoc.includes('anywhere')) return 100;
  if (candLoc.includes('remote') || candLoc === jobLoc) return 100;

  const candidateParts = candLoc.split(',').map(p => p.trim());
  const jobParts = jobLoc.split(',').map(p => p.trim());

  const cityMatch = candidateParts.some(cp => jobParts.some(jp => jp.includes(cp) || cp.includes(jp)));
  if (cityMatch) return 100;

  const stateMatch = candidateParts.some(cp =>
    jobParts.some(jp => {
      if (cp.length === 2 && jp.length === 2) return cp === jp;
      return jp.includes(cp) || cp.includes(jp);
    })
  );
  if (stateMatch) return 70;

  return willingToRelocate ? 60 : 20;
};

export const calculateSalaryScore = (
  candidateSalary: number | undefined,
  jobSalaryRange?: { min: number; max: number }
): number => {
  if (!jobSalaryRange) return 100;
  if (!candidateSalary) return 75;

  const { min, max } = jobSalaryRange;
  const midpoint = (min + max) / 2;

  if (candidateSalary >= min && candidateSalary <= max) {
    return 100;
  } else if (candidateSalary < min) {
    const percentBelow = ((min - candidateSalary) / midpoint) * 100;
    return Math.max(50, 100 - percentBelow);
  } else {
    const percentAbove = ((candidateSalary - max) / midpoint) * 100;
    return Math.max(0, 100 - (percentAbove * 2));
  }
};

export const calculateAvailabilityScore = (
  availabilityDate: Date | undefined
): number => {
  if (!availabilityDate) return 100;

  const now = new Date();
  const diffDays = Math.ceil((availabilityDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

  if (diffDays <= 0) return 100;
  if (diffDays <= 14) return 90;
  if (diffDays <= 30) return 80;
  if (diffDays <= 60) return 60;
  if (diffDays <= 90) return 40;

  return 20;
};

export const extractSkillsFromApplication = (application: Application): string[] => {
  const skills: string[] = [];

  if (application.coverLetter) {
    const commonSkills = [
      'javascript', 'typescript', 'react', 'vue', 'angular', 'node', 'python', 'java',
      'sql', 'mongodb', 'aws', 'azure', 'docker', 'kubernetes', 'git', 'agile', 'scrum',
      'leadership', 'management', 'communication', 'problem-solving', 'teamwork'
    ];

    const text = application.coverLetter.toLowerCase();
    commonSkills.forEach(skill => {
      if (text.includes(skill)) skills.push(skill);
    });
  }

  return [...new Set(skills)];
};

export const extractExperienceYears = (application: Application): number => {
  if (!application.additionalInfo && !application.coverLetter) return 0;

  const text = `${application.additionalInfo || ''} ${application.coverLetter || ''}`.toLowerCase();

  const patterns = [
    /(\d+)\+?\s*years?\s+(?:of\s+)?experience/i,
    /experience[:\s]+(\d+)\+?\s*years?/i,
    /(\d+)\+?\s*yrs?\s+(?:of\s+)?experience/i,
  ];

  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) return parseInt(match[1]);
  }

  return 0;
};

export const rankCandidates = (
  applications: Application[],
  job: Job,
  weights: RankingWeights = DEFAULT_WEIGHTS
): RankedCandidate[] => {
  const scoredCandidates = applications.map(app => {
    const candidateSkills = extractSkillsFromApplication(app);
    const experienceYears = extractExperienceYears(app);

    const breakdown = {
      skillsScore: calculateSkillsMatch(candidateSkills, job.skills || []),
      experienceScore: calculateExperienceScore(experienceYears, job.experienceLevel),
      educationScore: calculateEducationScore(app.workAuthorization),
      locationScore: calculateLocationScore(app.location, job.location, app.willingToRelocate),
      salaryScore: calculateSalaryScore(app.salaryExpectation, job.salaryRange),
      availabilityScore: calculateAvailabilityScore(app.availabilityDate),
    };

    const totalWeight = Object.values(weights).reduce((sum, w) => sum + w, 0);

    const totalScore = Math.round(
      (breakdown.skillsScore * weights.skills_match_weight +
        breakdown.experienceScore * weights.experience_weight +
        breakdown.educationScore * weights.education_weight +
        breakdown.locationScore * weights.location_weight +
        breakdown.salaryScore * weights.salary_weight +
        breakdown.availabilityScore * weights.availability_weight) /
        totalWeight
    );

    return {
      ...app,
      score: {
        applicationId: app.id,
        totalScore,
        breakdown,
        rank: 0,
      },
    };
  });

  scoredCandidates.sort((a, b) => b.score.totalScore - a.score.totalScore);

  scoredCandidates.forEach((candidate, index) => {
    candidate.score.rank = index + 1;
  });

  return scoredCandidates;
};

export const getDefaultWeights = (): RankingWeights => ({ ...DEFAULT_WEIGHTS });

export const getPresetWeights = (presetName: string): RankingWeights => {
  const presets: Record<string, RankingWeights> = {
    'Skills-Focused': {
      skills_match_weight: 50,
      experience_weight: 20,
      education_weight: 10,
      location_weight: 5,
      salary_weight: 10,
      availability_weight: 5,
    },
    'Experience-Focused': {
      skills_match_weight: 20,
      experience_weight: 50,
      education_weight: 15,
      location_weight: 5,
      salary_weight: 5,
      availability_weight: 5,
    },
    'Budget-Conscious': {
      skills_match_weight: 25,
      experience_weight: 20,
      education_weight: 10,
      location_weight: 10,
      salary_weight: 30,
      availability_weight: 5,
    },
    'Balanced': {
      ...DEFAULT_WEIGHTS,
    },
  };

  return presets[presetName] || DEFAULT_WEIGHTS;
};
