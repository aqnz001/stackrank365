import type { Job } from '../types';

export interface ResumeParsed {
  skills?: string[];
  experiences?: Array<{ jobTitle?: string; company?: string; description?: string }>;
}

export function composeCoverLetter(job: Job, parsed?: ResumeParsed, resumeText?: string) {
  const company = job.organizationName || 'your company';
  const title = job.title || 'the role';
  const jobSkills = (job.skills || []).slice(0, 6);
  const resumeSkills = (parsed?.skills || []).slice(0, 8);

  // Try to pick 3 overlapping skills first, else top from each
  const overlap = jobSkills.filter(s => resumeSkills.map(x => x.toLowerCase()).includes(s.toLowerCase()));
  const pickedSkills = (overlap.length > 0 ? overlap : (resumeSkills.length ? resumeSkills : jobSkills)).slice(0, 3);

  // Build a simple achievements list from experiences
  const exp = (parsed?.experiences || []).slice(0, 2);
  const achievements = exp.map(e => {
    const role = e.jobTitle || 'my previous role';
    const org = e.company ? ` at ${e.company}` : '';
    return `• In my role as ${role}${org}, I contributed to delivering results through collaboration, problem solving, and ownership.`;
  });
  if (achievements.length === 0) {
    achievements.push('• I deliver results through collaboration, continuous improvement, and customer focus.');
    achievements.push('• I communicate clearly, manage priorities effectively, and take ownership.');
  }

  const intro = `Dear ${company} Hiring Team,`;
  const p1 = `I'm excited to apply for the ${title} position at ${company}. My background and skills align well with the role, and I'm confident I can make an immediate impact.`;
  const p2 = pickedSkills.length
    ? `Key strengths I bring include: ${pickedSkills.join(', ')}.`
    : `I bring strong technical and collaborative skills with a growth mindset.`;
  const p3 = `A few highlights from my experience:`;
  const p4 = `I'm drawn to this opportunity because of ${company}'s reputation for quality and the scope of the role. I value clear communication, pragmatic problem solving, and delivering outcomes that matter.`;
  const closing = `Thank you for your time and consideration. I would welcome the chance to discuss how my experience can support ${company}'s goals.`;
  const sign = `Sincerely,\n${(resumeText || '').match(/\n?([A-Z][a-z]+\s+[A-Z][a-z]+)/)?.[1] || ''}`;

  return [intro, '', p1, p2, p3, ...achievements, '', p4, '', closing, '', sign].join('\n');
}

