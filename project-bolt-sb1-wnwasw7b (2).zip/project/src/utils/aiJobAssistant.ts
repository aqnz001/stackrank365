// AI Job Posting Assistant (ported from old project)
// This utility provides AI-like suggestions for job descriptions and skills

interface JobSuggestion {
  description: string;
  skills: string[];
  responsibilities: string[];
  whatYouBring: string[];
}

interface JobTemplate {
  keywords: string[];
  template: JobSuggestion;
}

const jobTemplates: JobTemplate[] = [
  {
    keywords: ['software engineer', 'developer', 'programmer', 'software developer'],
    template: {
      description: `We are seeking a talented Software Engineer to join our dynamic development team. You will be responsible for designing, developing, and maintaining high-quality software solutions that drive our business forward. This role offers excellent opportunities for growth and the chance to work with cutting-edge technologies in a collaborative environment.

Key responsibilities include developing scalable applications, participating in code reviews, collaborating with cross-functional teams, and contributing to architectural decisions. You'll work in an agile environment where innovation and continuous learning are highly valued.`,
      skills: [
        'JavaScript/TypeScript',
        'React or Vue.js',
        'Node.js',
        'SQL databases',
        'Git version control',
        'RESTful APIs',
        'Agile methodologies',
        'Problem-solving skills'
      ],
      responsibilities: [
        'Design and develop scalable web applications',
        'Write clean, maintainable, and efficient code',
        'Participate in code reviews and technical discussions',
        'Collaborate with product managers and designers',
        'Debug and resolve technical issues',
        'Contribute to system architecture decisions',
        'Mentor junior developers',
        'Stay updated with latest technology trends'
      ],
      whatYouBring: [
        "Bachelor's degree in Computer Science or related field (or equivalent experience)",
        '3+ years of hands-on software development experience',
        'Strong programming skills in modern languages',
        'Experience with web development frameworks',
        'Understanding of software design patterns',
        'Excellent communication and collaboration skills',
        'Ability to thrive in a team environment'
      ]
    }
  },
  {
    keywords: ['product manager', 'product owner', 'pm'],
    template: {
      description: `Join our product team as a Product Manager where you'll drive the strategic direction of our products and work closely with engineering, design, and business stakeholders. You'll be responsible for defining product roadmaps, gathering requirements, and ensuring successful product launches.

This role requires strong analytical skills, customer empathy, and the ability to translate business needs into technical requirements. You'll work in a fast-paced environment where data-driven decisions and user-centric thinking are essential.`,
      skills: [
        'Product strategy',
        'Market research',
        'Data analysis',
        'Agile/Scrum methodologies',
        'User experience design',
        'Stakeholder management',
        'A/B testing',
        'SQL or analytics tools'
      ],
      responsibilities: [
        'Define and execute product strategy and roadmap',
        'Conduct market research and competitive analysis',
        'Gather and prioritize product requirements',
        'Work closely with engineering and design teams',
        'Analyze product metrics and user feedback',
        'Manage product launches and go-to-market strategies',
        'Communicate product vision to stakeholders',
        'Drive product adoption and growth initiatives'
      ],
      whatYouBring: [
        "Bachelor's degree in Business, Engineering, or related field",
        '3+ years of proven product management experience',
        'Strong analytical and problem-solving abilities',
        'Hands-on experience with product management tools',
        'Deep understanding of software development lifecycle',
        'Excellent communication and presentation skills',
        'Customer-focused mindset and approach'
      ]
    }
  },
  {
    keywords: ['data scientist', 'data analyst', 'machine learning engineer'],
    template: {
      description: `We are looking for a Data Scientist to join our analytics team and help drive data-informed decision making across the organization. You'll work with large datasets, build predictive models, and translate complex data insights into actionable business recommendations.

This role offers the opportunity to work on challenging problems using state-of-the-art machine learning techniques and tools. You'll collaborate with product, engineering, and business teams to identify opportunities and implement data-driven solutions.`,
      skills: [
        'Python or R programming',
        'Machine learning algorithms',
        'SQL and database management',
        'Statistical analysis',
        'Data visualization (Tableau, Power BI)',
        'Pandas, NumPy, Scikit-learn',
        'Big data technologies (Spark, Hadoop)',
        'Communication skills'
      ],
      responsibilities: [
        'Build and validate predictive models',
        'Analyze large datasets to extract insights',
        'Design and run experiments',
        'Collaborate with cross-functional teams',
        'Develop data pipelines and tooling',
        'Present findings to stakeholders',
        'Monitor and improve model performance',
        'Contribute to data strategy'
      ],
      whatYouBring: [
        "Bachelor's or Master's degree in a quantitative field",
        'Practical experience with ML frameworks',
        'Strong SQL and database skills',
        'Experience with data visualization tools',
        'Statistical literacy and analytical thinking',
        'Excellent communication and storytelling skills'
      ]
    }
  }
];

const defaultTemplate: JobSuggestion = {
  description: `We are seeking a motivated professional to join our team in this exciting role. The successful candidate will contribute to our organization's success while developing their career in a supportive and dynamic environment.

This position offers opportunities for professional growth, skill development, and the chance to make a meaningful impact. We value collaboration, innovation, and continuous learning.`,
  skills: [
    'Strong communication skills',
    'Problem-solving abilities',
    'Team collaboration',
    'Time management',
    'Attention to detail',
    'Adaptability',
    'Professional attitude',
    'Relevant industry experience'
  ],
  responsibilities: [
    'Execute key responsibilities related to the role',
    'Collaborate with team members and stakeholders',
    'Contribute to project planning and execution',
    'Maintain high standards of work quality',
    'Participate in team meetings and discussions',
    'Support continuous improvement initiatives',
    'Follow company policies and procedures',
    'Assist with additional duties as required'
  ],
  whatYouBring: [
    'Relevant educational background or equivalent experience',
    'Strong work ethic and professional attitude',
    'Excellent communication skills',
    'Ability to work independently and collaboratively',
    'Commitment to continuous learning and growth',
    'Relevant industry experience preferred',
    'Proficiency in relevant tools and technologies'
  ]
};

export const generateJobSuggestions = (jobTitle: string): JobSuggestion => {
  if (!jobTitle.trim()) {
    return defaultTemplate;
  }

  const normalizedTitle = jobTitle.toLowerCase().trim();
  const matchingTemplate = jobTemplates.find(t => t.keywords.some(k => normalizedTitle.includes(k) || k.includes(normalizedTitle)));
  if (matchingTemplate) {
    const customizedDescription = matchingTemplate.template.description
      .replace(/We are seeking a talented \w+/g, `We are seeking a talented ${jobTitle}`)
      .replace(/Join our \w+ team as a \w+/g, `Join our team as a ${jobTitle}`);
    return { ...matchingTemplate.template, description: customizedDescription };
  }
  return { ...defaultTemplate, description: defaultTemplate.description.replace('We are seeking a motivated professional', `We are seeking a motivated ${jobTitle}`) };
};

export const getIndustrySpecificSkills = (industry: string): string[] => {
  const map: Record<string, string[]> = {
    Technology: ['Programming languages','Software development','Database management','Cloud computing','Cybersecurity','DevOps','API development','Git'],
    Healthcare: ['Patient care','Medical terminology','Healthcare regulations','EHR','Clinical procedures','Patient safety','Compliance'],
    Finance: ['Financial analysis','Risk management','Compliance','Modeling','Investment','Accounting','Reporting'],
    Education: ['Curriculum','Classroom management','EdTech','Assessment','Learning theories','Lesson planning'],
    Manufacturing: ['Quality control','Production planning','Lean','Safety','Maintenance','Process optimization'],
    Retail: ['Customer service','Sales','Inventory','POS','Merchandising','Product knowledge'],
  };
  return map[industry] || [];
};

export const enhanceJobDescription = (base: string, jobTitle: string, company: string, industry: string): string => {
  if (!base.trim()) return generateJobSuggestions(jobTitle).description;
  let enhanced = base;
  if (company && !enhanced.includes(company)) {
    enhanced = enhanced.replace(/join our team/gi, `join our team at ${company}`);
  }
  if (industry && !enhanced.includes(industry)) {
    enhanced += `\n\nAs a leader in the ${industry} industry, we offer exciting opportunities for professional growth and development.`;
  }
  return enhanced;
};

export const generateSkillsFromDescription = (description: string, jobTitle: string): string[] => {
  const skillKeywords: Record<string, string[]> = {
    JavaScript: ['javascript','js','react','vue','angular','node'],
    Python: ['python','django','flask','pandas','numpy'],
    Java: ['java','spring','hibernate'],
    'C#': ['c#','.net','asp.net'],
    SQL: ['sql','database','mysql','postgresql','oracle'],
    'Project Management': ['project management','agile','scrum','kanban'],
    Communication: ['communication','presentation','stakeholder'],
    Leadership: ['leadership','team lead','management','mentor'],
    Analytics: ['analytics','data analysis','reporting','metrics'],
    Design: ['design','ui','ux','figma','sketch','photoshop']
  };
  const found: string[] = [];
  const ld = description.toLowerCase();
  const lt = jobTitle.toLowerCase();
  Object.entries(skillKeywords).forEach(([skill, keywords]) => {
    if (keywords.some(k => ld.includes(k) || lt.includes(k))) found.push(skill);
  });
  const base = generateJobSuggestions(jobTitle);
  return [...new Set([...found, ...base.skills])].slice(0, 8);
};

