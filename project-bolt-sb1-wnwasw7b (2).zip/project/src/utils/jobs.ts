import type { Job } from '../types';

export const JOB_LIFESPAN_DAYS = 30;

export function getJobLifecycle(job: Job) {
  const created = job?.createdAt ? new Date(job.createdAt) : new Date();
  const expiresAt = new Date(created.getTime() + JOB_LIFESPAN_DAYS * 24 * 60 * 60 * 1000);
  const now = new Date();
  const msLeft = Math.max(0, expiresAt.getTime() - now.getTime());
  const daysRemaining = Math.ceil(msLeft / (24 * 60 * 60 * 1000));
  const isOpenByAge = now < expiresAt;
  const explicitOpen = job?.status ? job.status === 'open' : true;
  const isOpen = explicitOpen && isOpenByAge;
  const closingSoon = isOpen && daysRemaining <= 7;
  return { expiresAt, daysRemaining, isOpen, closingSoon } as const;
}

