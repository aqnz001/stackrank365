import React from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import ToastProvider from './components/Notifications/ToastProvider';
import LazyWrapper from './components/Performance/LazyWrapper';
import MobileNavigation from './components/Mobile/MobileNavigation';
import OfflineIndicator from './components/Performance/OfflineIndicator';
import PullToRefresh from './components/Mobile/PullToRefresh';
import { useOfflineSync } from './hooks/useOfflineSync';
import { useState, useEffect } from 'react';
import LoginForm from './components/Auth/LoginForm';
import HomePage from './components/Home/HomePage';
import SearchLayoutPage from './components/Home/SearchLayoutPage';
import Navbar from './components/Layout/Navbar';
import EmployerDashboard from './components/Dashboard/EmployerDashboard';
import RecruiterDashboard from './components/Dashboard/RecruiterDashboard';
import CandidateDashboard from './components/Dashboard/CandidateDashboard';
import AdminDashboard from './components/Dashboard/AdminDashboard';
import AcceptInvitation from './components/Invitations/AcceptInvitation';

const DashboardContent: React.FC = () => {
  const { user } = useAuth();
  const { isOnline } = useOfflineSync();
  const [activeTab, setActiveTab] = useState('overview');
  const [isMobile, setIsMobile] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  // Detect mobile device
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const handleRefresh = async () => {
    // Trigger re-render by incrementing refresh key
    // This will cause child components to re-mount and re-fetch their data
    setRefreshKey(prev => prev + 1);
  };

  const renderDashboard = () => {
    switch (user?.role) {
      case 'employer':
        return <EmployerDashboard key={refreshKey} />;
      case 'recruiter':
        return <RecruiterDashboard key={refreshKey} />;
      case 'candidate':
        return <CandidateDashboard key={refreshKey} />;
      case 'admin':
        return <AdminDashboard key={refreshKey} />;
      default:
        return <div>Invalid user role</div>;
    }
  };

  const dashboardContent = (
    <div className="min-h-screen bg-gray-50">
      {/* Desktop Navigation */}
      <div className="hidden lg:block">
        <Navbar />
      </div>
      
      {/* Mobile Navigation */}
      {isMobile && (
        <MobileNavigation 
          activeTab={activeTab}
          onTabChange={setActiveTab}
        />
      )}
      
      {/* Main Content */}
      <div className={`min-h-[calc(100vh-4rem)] ${isMobile ? 'pb-20' : ''}`}>
        {renderDashboard()}
      </div>
      
      {/* Offline Indicator */}
      <OfflineIndicator />
    </div>
  );

  // Wrap with pull-to-refresh on mobile
  return isMobile ? (
    <PullToRefresh onRefresh={handleRefresh}>
      {dashboardContent}
    </PullToRefresh>
  ) : (
    dashboardContent
  );
};

const AppContent: React.FC = () => {
  const { user, isLoading } = useAuth();
  const [hash, setHash] = useState<string>(window.location.hash);
  const [searchParams, setSearchParams] = useState<URLSearchParams>(
    new URLSearchParams(window.location.search)
  );

  useEffect(() => {
    const onHashChange = () => {
      setHash(window.location.hash);
      setSearchParams(new URLSearchParams(window.location.search));
    };
    window.addEventListener('hashchange', onHashChange);
    window.addEventListener('popstate', onHashChange);
    return () => {
      window.removeEventListener('hashchange', onHashChange);
      window.removeEventListener('popstate', onHashChange);
    };
  }, []);

  console.log('AppContent render - user:', user?.email, 'isLoading:', isLoading);
  console.log('Current URL:', window.location.href);
  console.log('Pathname:', window.location.pathname);
  console.log('Hash:', hash);
  console.log('Search params:', window.location.search);

  const invitationId = searchParams.get('id');
  const pathname = window.location.pathname;

  // Check for invitation route in multiple ways
  const isInvitationRoute =
    pathname === '/accept-invitation' ||
    pathname.includes('/accept-invitation') ||
    hash === '#accept-invitation' ||
    hash.includes('#accept-invitation') ||
    window.location.href.includes('/accept-invitation');

  if (isInvitationRoute && invitationId) {
    console.log('Rendering AcceptInvitation component with ID:', invitationId);
    return <AcceptInvitation invitationId={invitationId} />;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading application...</p>
        </div>
      </div>
    );
  }

  // Always keep user on the current page (homepage/search) after sign-in.
  // If user navigates to #dashboard, show dashboard views.
  if (!user) {
    console.log('No user found, showing homepage');
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <SearchLayoutPage />
      </div>
    );
  }

  if (hash.startsWith('#dashboard')) {
    console.log('User authenticated, showing dashboard for role:', user.role);
    return <DashboardContent />;
  }

  console.log('User authenticated, showing homepage with top menu');
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <SearchLayoutPage />
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <AppContent />
      </ToastProvider>
    </AuthProvider>
  );
}

export default App;
