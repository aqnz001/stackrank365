import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import type { User as SupabaseUser } from '@supabase/supabase-js';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, name: string, role?: string) => Promise<void>;
  logout: () => void;
  signOut: () => void;
  refreshUser: () => Promise<void>;
  isLoading: boolean;
  error: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Refs for deduplication
  const initOnceRef = useRef(false);
  const lastHandledUserIdRef = useRef<string | null>(null);
  const inFlightRef = useRef<Promise<any> | null>(null);

  useEffect(() => {
    if (initOnceRef.current) return; // ✅ prevent double-init in StrictMode
    initOnceRef.current = true;

    console.log('Checking initial session...');
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        fetchProfileOnce(session.user);
      } else {
        setIsLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log('Auth state changed:', event, session?.user?.email);
        
        const user = session?.user ?? null;
        // Coalesce noisy transitions: treat both as "signed in"
        if (event === 'SIGNED_IN' || event === 'INITIAL_SESSION') {
          if (user) {
            fetchProfileOnce(user);
          }
        } else if (event === 'SIGNED_OUT') {
          setUser(null);
          setError(null);
          lastHandledUserIdRef.current = null;
          setIsLoading(false);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const fetchProfileOnce = (supabaseUser: SupabaseUser) => {
    if (lastHandledUserIdRef.current === supabaseUser.id && user) {
      // Already loaded for this user
      return;
    }
    lastHandledUserIdRef.current = supabaseUser.id;

    // De-dupe parallel calls
    if (!inFlightRef.current) {
      inFlightRef.current = fetchUserProfileWithRetry(supabaseUser)
        .catch((e) => {
          console.error('Unexpected error in fetchUserProfile:', e);
          setError(e?.message ?? 'Failed to load user profile');
          // Ensure UI is not stuck in loading on error
          setIsLoading(false);
        })
        .finally(() => {
          inFlightRef.current = null;
        });
    }
    return inFlightRef.current;
  };

  const fetchUserProfileWithRetry = async (supabaseUser: SupabaseUser) => {
    console.log('Fetching profile for user:', supabaseUser.email);
    console.log('User ID:', supabaseUser.id);
    
    setIsLoading(true);
    const attempts = 10;
    const delayMs = 300;

    for (let i = 0; i < attempts; i++) {
      console.log(`Querying profiles table... (attempt ${i + 1}/${attempts})`);
      
      const { data: profile, error } = await supabase
        .from('profiles')
        .select('id, email, name, role, organization_id, status, kyc_status, created_at, updated_at')
        .eq('id', supabaseUser.id)
        .single();

      console.log('Profile query result:', { profile, error });

      if (profile) {
        console.log('Profile loaded successfully:', profile.email);
        const user: User = {
          id: profile.id,
          email: profile.email || supabaseUser.email || '',
          name: profile.name || '',
          role: profile.role,
          organizationId: profile.organization_id || null,
          status: profile.status,
          kycStatus: profile.kyc_status,
          createdAt: new Date(profile.created_at),
        };
        setUser(user);
        setError(null);
        setIsLoading(false);

        const pendingInvitationUrl = sessionStorage.getItem('pendingInvitationUrl');
        if (pendingInvitationUrl) {
          sessionStorage.removeItem('pendingInvitationUrl');
          setTimeout(() => {
            window.location.href = pendingInvitationUrl;
          }, 100);
        }

        return;
      }

      // If it's a "no rows" style error, backoff and retry; otherwise surface it
      if (error && error.code && error.code !== 'PGRST116') {
        throw error;
      }
      
      if (i < attempts - 1) {
        console.log(`Profile not found, retrying in ${delayMs}ms...`);
        await new Promise((r) => setTimeout(r, delayMs));
      }
    }

    throw new Error('Profile query timeout after ~3s');
  };

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    setError(null);

    try {
      console.log('Attempting login for:', email);
      
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        console.error('Login error:', error.message);
        setError(error.message);
        setIsLoading(false);
        return;
      }
      
      console.log('Login successful');
      // Don't set loading to false here - let the auth state change handle it
    } catch (err) {
      console.error('Login error:', err);
      setError(err instanceof Error ? err.message : 'Login failed');
      setIsLoading(false);
    }
  };

  const signUp = async (email: string, password: string, name: string, role: string = 'candidate', organizationName?: string) => {
    setIsLoading(true);
    setError(null);

    try {
      console.log('Attempting signup for:', email, 'with role:', role);
      
      // For employers and recruiters, create an organization first
      let organizationId = null;
      if (role === 'employer' || role === 'recruiter') {
        console.log('Creating organization for', role);
        const orgName = organizationName || `${name}'s ${role === 'employer' ? 'Company' : 'Agency'}`;
        const orgType = role === 'employer' ? 'employer' : 'recruiter';
        
        // First create the user account
        const { data: authData, error: authError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              name: name,
              role,
            },
          },
        });

        if (authError) {
          console.error('Auth signup error:', authError);
          setError(authError.message);
          throw authError;
        }

        if (!authData.user) {
          throw new Error('User creation failed');
        }

        console.log('User created, now calling Edge Function to create organization');
        
        // Call Edge Function to create organization and update profile
        try {
          const edgeFunctionUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-organization-and-profile`;
          const response = await fetch(edgeFunctionUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${authData.session?.access_token}`,
            },
            body: JSON.stringify({
              userId: authData.user.id,
              userName: name,
              userEmail: email,
              userRole: role,
              organizationName: orgName,
              organizationType: orgType,
            }),
          });

          if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Failed to create organization');
          }

          const result = await response.json();
          organizationId = result.organizationId;
          console.log('Organization created via Edge Function:', organizationId);
          
          // Add delay to ensure database consistency before fetching profile
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          // Refresh the user profile to include the organization ID
          await fetchUserProfileWithRetry(authData.user);
        } catch (edgeFunctionError) {
          console.error('Error calling Edge Function:', edgeFunctionError);
          setError(`Failed to create organization: ${edgeFunctionError instanceof Error ? edgeFunctionError.message : 'Unknown error'}`);
          throw edgeFunctionError;
        }
      } else {
        // For candidates and admins, just create the user account
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              name: name,
              role,
            },
          },
        });

        if (error) {
          console.error('Signup error details:', error);
          setError(error.message);
          throw error;
        }
      }
      
      console.log('Signup process completed successfully');
    } catch (err) {
      console.error('Sign up error details:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    setIsLoading(true);
    console.log('Logging out user');
    
    const { error } = await supabase.auth.signOut();
    if (error) {
      // Only log errors that aren't related to missing sessions
      if (!error.message?.includes('Auth session missing') && 
          !error.message?.includes('Session from session_id claim in JWT does not exist') &&
          !error.message?.includes('session_not_found')) {
        console.error('Logout error:', error);
      }
    } else {
      console.log('Logout successful');
    }
    setUser(null);
    setError(null);
    lastHandledUserIdRef.current = null;
    setIsLoading(false);
  };

  const refreshUser = async () => {
    const { data: { user: supabaseUser } } = await supabase.auth.getUser();
    if (supabaseUser) {
      lastHandledUserIdRef.current = null;
      await fetchProfileOnce(supabaseUser);
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, signUp, logout, signOut: logout, refreshUser, isLoading, error }}>
      {children}
    </AuthContext.Provider>
  );
};
