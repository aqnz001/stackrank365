## Summary

Describe the changes and the motivation.

## Changes

- Home UI: adopt old hero + exact filter sets (classification, work type, salary range, posted within, remote/hybrid)
- Tailwind: add color palette and utility classes to match old styling
- Job create: update `JobPostForm` to 2-step flow (details, location & pricing), industries, experience level, Save as Draft
- Search: remote/hybrid mapping via `location` ilike on `remote` or `hybrid`

## Screenshots

If applicable, add screenshots or GIFs.

## Testing

- [ ] Guest: search and filter works without auth
- [ ] “View Details” opens modal
- [ ] Apply button gates to auth when logged out
- [ ] Employers: job post flow works with subscription or payment

## Migration/Notes

No DB migrations. Styling tokens added in `tailwind.config.js` and `src/index.css`.

