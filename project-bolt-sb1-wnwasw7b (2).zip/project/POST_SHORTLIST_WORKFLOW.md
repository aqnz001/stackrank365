# Post-Shortlist Workflow & Escrow Payment System

## Overview

This document describes the comprehensive post-shortlist workflow and escrow payment management system that automates the hiring process from candidate shortlisting through onboarding, with integrated payment milestone tracking for recruiter fees.

## Key Features

### 1. Post-Shortlist Interview Scheduling

When a candidate is moved to "shortlisted" status:
- Employers are prompted to schedule an interview
- Interview scheduling component appears with type selection (video, phone, in-person, technical)
- Automatic notifications sent to candidates
- Interview reminders and calendar integration hooks

**Component**: `PostShortlistActions.tsx`

### 2. Payment Schedule Templates

Four pre-configured payment schedule templates:

- **Standard 3-Milestone** (20% / 50% / 30%)
  - Interview Scheduled: 20%
  - Candidate Hired: 50%
  - Probation Completed: 30%

- **Quick 2-Payment** (70% / 30%)
  - Candidate Hired: 70%
  - Probation Completed: 30%

- **Interview Only** (100%)
  - Interview Scheduled: 100%

- **Hire Only** (100%)
  - Candidate Hired: 100%

Admins can create custom templates with any milestone combination.

### 3. Automated Payment Milestone Triggers

Milestones are automatically triggered based on workflow events:

- **Interview Scheduled**: Triggered when employer schedules interview with candidate
- **Candidate Hired**: Triggered when employer selects candidate for hire
- **Probation Completed**: Triggered 90 days after start date (manual or scheduled)

**Edge Function**: `trigger-payment-milestones`

### 4. Candidate Selection & Onboarding

When employer selects a candidate for hire:
- Single-click candidate selection with confirmation workflow
- Automatic job status update to "filled"
- Notifications to selected candidate
- Notifications to other applicants that position is filled
- Onboarding status tracking (offer_extended → offer_accepted → onboarding → active → completed)

**Component**: `CandidateSelectionModal.tsx`

### 5. Recruiter Payment Dashboard

Recruiters have full visibility into their payment schedule:
- Total payment value across all bids
- Pending milestone payments
- Triggered milestone payments
- Released payments
- Payment history with filtering
- Milestone progress tracking

**Component**: `ScheduledPaymentsDashboard.tsx`

### 6. Employer Invoice Generation

When employer accepts a recruiter bid:
- Automatic invoice generation showing full fee breakdown
- Payment schedule with milestone details
- Escrow protection information
- Guarantee period details
- PDF download capability

**Component**: `RecruiterFeeInvoice.tsx`

## Database Schema

### New Tables

#### `payment_schedules`
Stores payment milestone templates
- `id` (uuid)
- `name` (text)
- `description` (text)
- `milestones` (jsonb) - Array of milestone definitions
- `is_active` (boolean)

#### `scheduled_payments`
Tracks individual milestone payments for bids
- `id` (uuid)
- `recruiter_bid_id` (uuid)
- `escrow_transaction_id` (uuid)
- `milestone_name` (text)
- `milestone_trigger` (text)
- `amount` (integer)
- `percentage` (numeric)
- `status` (enum: pending, triggered, released, failed)
- `trigger_date` (timestamptz)
- `release_date` (timestamptz)
- `sequence_order` (integer)

#### `candidate_selections`
Tracks final hiring decisions
- `id` (uuid)
- `job_id` (uuid)
- `application_id` (uuid)
- `recruiter_bid_id` (uuid, nullable)
- `selected_by` (uuid)
- `offer_extended_date` (timestamptz)
- `start_date` (timestamptz)
- `onboarding_status` (enum)
- `onboarding_notes` (text)

### Schema Updates

Added to `recruiter_bids`:
- `milestone_payments` (jsonb)
- `payment_schedule_id` (uuid)
- `next_steps` (jsonb)

Added to `applications`:
- `next_steps` (jsonb)
- `onboarding_status` (text)

Added to `escrow_transactions`:
- `job_id` (uuid)
- `employer_org_id` (uuid)
- `recruiter_id` (uuid)
- `fee_type` (text)
- `fee_value` (numeric)

## Workflow Automation

### Interview Scheduling Flow

1. Candidate status changes to "shortlisted"
2. `PostShortlistActions` component displays prompt to schedule interview
3. Employer fills in interview details
4. Interview created in `interview_schedules` table
5. Candidate receives notification
6. If bid-sourced candidate:
   - Check for "interview_scheduled" milestones
   - Trigger payment release for matching milestones
   - Notify recruiter and employer of payment milestone

### Candidate Selection Flow

1. Employer clicks "Select for Hire" button
2. `CandidateSelectionModal` displays confirmation
3. Shows payment schedule if recruiter-sourced
4. On confirmation:
   - Create `candidate_selections` record
   - Update application status to "hired"
   - Update job status to "filled"
   - Send offer notification to candidate
   - If recruiter-sourced:
     - Trigger "candidate_hired" milestones
     - Generate invoice for employer
     - Create escrow transaction
     - Notify recruiter of payment milestone

### Payment Release Flow

1. Milestone event occurs (interview scheduled, candidate hired, etc.)
2. Edge function `trigger-payment-milestones` invoked
3. Find all pending payments matching trigger type
4. Update payment status to "triggered"
5. Set trigger_date timestamp
6. Create notifications for recruiter and employer
7. Payment held in escrow until manually released by admin or auto-released after guarantee period

## Security & Access Control

### RLS Policies

**payment_schedules**:
- Public read for active templates
- Admin-only write access

**scheduled_payments**:
- Recruiters can view their own payments
- Employers can view payments for their jobs
- Admin can manage all payments

**candidate_selections**:
- Employers can manage selections for their jobs
- Candidates can view their selection status
- Recruiters can view selections for their bids
- Admin can manage all selections

## Usage Examples

### For Employers

1. **Accept a Recruiter Bid**:
   ```typescript
   // Bid is accepted, payment schedule is automatically created
   await updateBidStatus(bidId, 'accepted', revealedCandidate);
   ```

2. **Schedule Interview**:
   ```typescript
   // When shortlisting, use PostShortlistActions component
   <PostShortlistActions
     application={application}
     onComplete={() => refetch()}
   />
   ```

3. **Select Candidate**:
   ```typescript
   // Use CandidateSelectionModal for final hire decision
   <CandidateSelectionModal
     application={application}
     jobId={jobId}
     onClose={() => setShowModal(false)}
     onSuccess={() => refetch()}
   />
   ```

### For Recruiters

1. **View Payment Schedule**:
   ```typescript
   // Use ScheduledPaymentsDashboard in recruiter dashboard
   <ScheduledPaymentsDashboard />
   ```

2. **Track Milestone Progress**:
   ```typescript
   const { payments } = useScheduledPayments(bidId);
   const progress = getMilestoneProgress(payments);
   // progress.completed, progress.total, progress.percentage
   ```

### For Admins

1. **Create Payment Schedule Template**:
   ```typescript
   await createSchedule({
     name: "Custom 4-Milestone",
     description: "Split across four milestones",
     milestones: [
       { name: "Interview", trigger: "interview_scheduled", percentage: 15 },
       { name: "Hire", trigger: "candidate_hired", percentage: 40 },
       { name: "30 Days", trigger: "probation_30", percentage: 25 },
       { name: "90 Days", trigger: "probation_completed", percentage: 20 }
     ]
   });
   ```

2. **Manually Trigger Milestone**:
   ```typescript
   await triggerMilestone(paymentId, "Manual release by admin");
   ```

3. **Release Payment**:
   ```typescript
   await releasePayment(paymentId);
   ```

## Notifications

The system generates automatic notifications for:

- **Candidates**:
  - Interview scheduled
  - Interview confirmed/rescheduled/cancelled
  - Offer extended
  - Onboarding status changes

- **Recruiters**:
  - Payment milestone triggered
  - Payment released
  - Candidate hired (from their bid)

- **Employers**:
  - Payment milestone reached
  - Escrow payment received
  - Invoice generated

## Testing Checklist

- [ ] Shortlist candidate and verify interview scheduling prompt appears
- [ ] Schedule interview and verify milestone payment triggered (if bid-sourced)
- [ ] Select candidate for hire and verify all status updates
- [ ] Verify invoice generated with correct payment breakdown
- [ ] Check recruiter dashboard shows scheduled payments
- [ ] Verify notifications sent to all parties
- [ ] Test payment release workflow
- [ ] Verify escrow balance tracking
- [ ] Test guarantee period refund workflow
- [ ] Verify RLS policies prevent unauthorized access

## Future Enhancements

- Auto-release payments after guarantee period expires
- Stripe integration for actual payment processing
- Dispute resolution workflow
- Candidate replacement workflow for guarantee period
- Probation tracking with automatic milestone triggers at 30/60/90 days
- Performance metrics and analytics for payment schedules
- Bulk payment operations for admins
- Custom milestone creation beyond templates
