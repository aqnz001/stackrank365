import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface InvitationRequest {
  invitationId: string;
  inviteeEmail: string;
  inviterName?: string;
  organizationName: string;
  role: "employer" | "recruiter";
  appUrl?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseServiceKey) {
      throw new Error("Missing Supabase environment variables");
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { persistSession: false },
    });

    const { invitationId, inviteeEmail, inviterName, organizationName, role, appUrl }: InvitationRequest = await req.json();

    if (!invitationId || !inviteeEmail || !organizationName || !role) {
      throw new Error("Missing required fields");
    }

    // Generate invitation link using the app URL or fallback to window.location
    const baseUrl = appUrl || 'https://your-app.com';
    const invitationLink = `${baseUrl}/accept-invitation?id=${invitationId}`;;

    // Send email using Supabase's built-in email service
    // Note: This requires Supabase email templates to be set up in the dashboard
    const emailHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 8px 8px 0 0; }
            .content { background: #f9fafb; padding: 30px; border-radius: 0 0 8px 8px; }
            .button { display: inline-block; background: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 20px 0; }
            .footer { text-align: center; margin-top: 20px; color: #6b7280; font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>You're Invited to Join a Team!</h1>
            </div>
            <div class="content">
              <p>Hi there,</p>
              <p>${inviterName ? `<strong>${inviterName}</strong> has` : 'You have been'} invited you to join <strong>${organizationName}</strong> as a <strong>${role}</strong>.</p>
              <p>Click the button below to accept the invitation and get started:</p>
              <div style="text-align: center;">
                <a href="${invitationLink}" class="button">Accept Invitation</a>
              </div>
              <p style="font-size: 14px; color: #6b7280; margin-top: 30px;">
                Or copy and paste this link into your browser:<br>
                <code style="background: #e5e7eb; padding: 4px 8px; border-radius: 4px; font-size: 12px;">${invitationLink}</code>
              </p>
              <p style="margin-top: 30px;">This invitation will expire in 7 days.</p>
            </div>
            <div class="footer">
              <p>If you didn't expect this invitation, you can safely ignore this email.</p>
            </div>
          </div>
        </body>
      </html>
    `;

    // For now, we'll log the email since Supabase doesn't have built-in SMTP by default
    // In production, you would integrate with a service like SendGrid, Resend, or AWS SES
    console.log('Team invitation email would be sent to:', inviteeEmail);
    console.log('Organization:', organizationName);
    console.log('Role:', role);
    console.log('Invitation link:', invitationLink);

    // Update invitation status to indicate email was sent
    await supabase
      .from('team_invitations')
      .update({ 
        updated_at: new Date().toISOString(),
      })
      .eq('id', invitationId);

    // For development/demo purposes, return the email content
    return new Response(
      JSON.stringify({
        success: true,
        message: 'Invitation email prepared',
        // In development, return the link for testing
        invitationLink,
        note: 'Email sending requires SMTP integration. For now, the invitation is recorded in the database.',
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error: any) {
    console.error('Error in send-team-invitation:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'An error occurred',
      }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});
