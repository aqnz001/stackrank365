import { createClient } from 'npm:@supabase/supabase-js@2.56.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

interface ParsedExperience {
  jobTitle: string;
  company: string;
  industry?: string;
  startMonth?: string;
  startYear?: string;
  endMonth?: string;
  endYear?: string;
  isCurrentRole?: boolean;
  description?: string;
}

function sanitizeTextForDB(text: string): string {
  if (!text) return '';

  // Remove null bytes and other problematic characters
  return text
    .replace(/\0/g, '') // Remove null bytes
    .replace(/\u0000/g, '') // Remove null character
    .replace(/[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F]/g, '') // Remove control characters except \n and \r
    .replace(/\\/g, '\\\\') // Escape backslashes
    .trim();
}

function parseResumeText(text: string): { skills: string[]; experiences: ParsedExperience[] } {
  const normalized = (text || '').replace(/\r\n?/g, '\n');
  const lower = normalized.toLowerCase();
  let skillsBlock = '';
  const skillsIdx = lower.indexOf('skills');
  if (skillsIdx >= 0) {
    const after = normalized.slice(skillsIdx + 'skills'.length);
    const chunk = after.slice(0, 600);
    skillsBlock = chunk.split('\n').slice(0, 8).join('\n');
  }
  const rawTokens = skillsBlock
    .split(/[\n,•;\t]/g)
    .map(s => s.trim())
    .filter(Boolean)
    .filter(s => s.length <= 40 && s.length >= 2);
  const skills = Array.from(new Set(rawTokens)).slice(0, 12);

  const experiences: ParsedExperience[] = [];
  const lines = normalized.split('\n');
  for (const line of lines) {
    const l = line.trim();
    if (!l) continue;
    const m1 = l.match(/^(?<title>[^•\-\u2013\u2014]{2,60})\s+(?:-|–|—|at)\s+(?<company>[^•\u2013\u2014]{2,80})/i);
    const groups = (m1 as any)?.groups;
    if (groups) {
      const jobTitle = String(groups.title || '').trim();
      const company = String(groups.company || '').trim().replace(/[•|·].*$/, '');
      if (jobTitle && company) {
        experiences.push({
          jobTitle,
          company,
          industry: '',
          startMonth: '',
          startYear: '',
          endMonth: '',
          endYear: '',
          isCurrentRole: false,
          description: '',
        });
      }
    }
    if (experiences.length >= 5) break;
  }
  return { skills, experiences };
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    if (req.method !== 'POST') {
      return new Response('Method Not Allowed', {
        status: 405,
        headers: corsHeaders
      });
    }

    const auth = req.headers.get('Authorization') || '';
    if (!auth.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ error: 'unauthorized', detail: 'Missing authorization header' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Verify the user is authenticated
    const supabaseAuth = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: auth },
        },
      }
    );

    const { data: { user }, error: authError } = await supabaseAuth.auth.getUser();
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'unauthorized', detail: 'Invalid authentication' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Use service role key for database operations (bypass RLS)
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const body = await req.json().catch(() => ({} as any));
    const fileUploadId: string | undefined = body.fileUploadId;
    const userId: string | undefined = body.userId;
    const storeToDB: boolean = body.storeToDB !== false;
    const url: string | undefined = body.url;
    const base64: string | undefined = body.base64;

    let text = '';

    // Prefer fileUploadId - fetch file from database
    if (fileUploadId) {
      try {
        const { data: fileUpload, error: fileError } = await supabaseClient
          .from('file_uploads')
          .select('id, user_id, file_path, bucket_name')
          .eq('id', fileUploadId)
          .maybeSingle();

        if (fileError || !fileUpload) {
          return new Response(
            JSON.stringify({ error: 'file_not_found', detail: 'File upload record not found' }),
            { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        // Create signed URL from file path
        const { data: signedUrlData, error: urlError } = await supabaseClient
          .storage
          .from(fileUpload.bucket_name)
          .createSignedUrl(fileUpload.file_path, 3600);

        if (urlError || !signedUrlData?.signedUrl) {
          return new Response(
            JSON.stringify({ error: 'url_error', detail: 'Failed to create signed URL' }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        const fileUrl = signedUrlData.signedUrl;
        const r = await fetch(fileUrl);
        if (!r.ok) {
          return new Response(
            JSON.stringify({ error: 'fetch_failed', detail: 'Failed to fetch file from storage' }),
            { status: 422, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        const ctype = r.headers.get('content-type') || '';
        if (ctype.includes('text')) {
          text = await r.text();
        } else {
          const buf = new Uint8Array(await r.arrayBuffer());
          text = new TextDecoder('utf-8', { fatal: false }).decode(buf);
        }
      } catch (err) {
        console.error('Error fetching file:', err);
        return new Response(
          JSON.stringify({ error: 'fetch_error', detail: String(err) }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    } else if (url) {
      // Fallback to URL if provided
      const r = await fetch(url).catch(() => null);
      if (!r || !r.ok) {
        return new Response(
          JSON.stringify({ error: 'fetch_failed' }),
          { status: 422, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      const ctype = r.headers.get('content-type') || '';
      if (ctype.includes('text')) {
        text = await r.text();
      } else {
        const buf = new Uint8Array(await r.arrayBuffer());
        text = new TextDecoder('utf-8', { fatal: false }).decode(buf);
      }
    } else if (base64) {
      const bytes = Uint8Array.from(atob(base64), c => c.charCodeAt(0));
      text = new TextDecoder('utf-8', { fatal: false }).decode(bytes);
    } else {
      return new Response(
        JSON.stringify({ error: 'no_input', detail: 'No file upload ID, URL, or base64 provided' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const parsed = parseResumeText(text || '');

    if (storeToDB && fileUploadId && userId) {
      try {
        const { data: existing, error: selectError } = await supabaseClient
          .from('resume_parsed_data')
          .select('id')
          .eq('file_upload_id', fileUploadId)
          .maybeSingle();

        if (selectError) {
          console.error('Error checking existing parsed data:', selectError);
          throw selectError;
        }

        const sanitizedText = sanitizeTextForDB(text || '');

        const resumeData = {
          file_upload_id: fileUploadId,
          user_id: userId,
          parsed_text: sanitizedText || null,
          parsed_skills: parsed.skills || [],
          parsed_experiences: parsed.experiences || [],
          parsed_education: [],
          parsed_metadata: {},
          parsing_status: 'completed',
          parsed_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };

        if (existing) {
          const { error: updateError } = await supabaseClient
            .from('resume_parsed_data')
            .update(resumeData)
            .eq('file_upload_id', fileUploadId);

          if (updateError) {
            console.error('Error updating parsed data:', updateError);
            throw updateError;
          }
          console.log(`Updated parsed data for file ${fileUploadId}`);
        } else {
          const { error: insertError } = await supabaseClient
            .from('resume_parsed_data')
            .insert(resumeData);

          if (insertError) {
            console.error('Error inserting parsed data:', insertError);
            throw insertError;
          }
          console.log(`Inserted parsed data for file ${fileUploadId}`);
        }
      } catch (dbError: any) {
        console.error('Error storing parsed data to database:', dbError);
        return new Response(
          JSON.stringify({
            error: 'database_error',
            detail: dbError?.message || String(dbError),
            parsed: parsed
          }),
          {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          }
        );
      }
    }

    return new Response(
      JSON.stringify({ parsed, text }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  } catch (e) {
    console.error('Parse resume error:', e);
    return new Response(
      JSON.stringify({ error: 'internal_error', detail: String(e) }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
