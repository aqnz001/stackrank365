import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.56.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("No authorization header");
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error("Unauthorized");
    }

    const { query, applicationData, parsedResumeData, jobDetails } = await req.json();

    if (!query || !query.trim()) {
      throw new Error("Query is required");
    }

    if (!applicationData) {
      throw new Error("Application data is required");
    }

    const analysis = await analyzeCandidate(
      query,
      applicationData,
      parsedResumeData,
      jobDetails
    );

    return new Response(
      JSON.stringify({ analysis, success: true }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error in analyze-candidate:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error", success: false }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});

async function analyzeCandidate(
  query: string,
  applicationData: any,
  parsedResumeData: any,
  jobDetails: any
): Promise<string> {
  const openaiKey = Deno.env.get("OPENAI_API_KEY");
  
  if (!openaiKey) {
    return generateIntelligentFallback(query, applicationData, parsedResumeData, jobDetails);
  }

  try {
    const systemPrompt = `You are an expert recruitment advisor helping employers evaluate candidates efficiently. Your role is to:

1. Analyze candidate qualifications against job requirements
2. Highlight key strengths and potential concerns
3. Provide actionable insights for decision-making
4. Summarize complex information into clear, concise points
5. Offer strategic recommendations for next steps

Be professional, objective, and focus on helping the employer make informed hiring decisions. Keep responses concise but insightful.`;

    let context = `CANDIDATE: ${applicationData.candidateName}\n`;
    context += `APPLICATION STATUS: ${applicationData.status}\n`;
    context += `APPLIED: ${new Date(applicationData.createdAt).toLocaleDateString()}\n`;
    context += `SOURCE: ${applicationData.source === 'recruiter' ? 'Recruiter Submission' : 'Direct Application'}\n\n`;

    if (parsedResumeData && parsedResumeData.parsing_status === 'completed') {
      const skills = parsedResumeData.parsed_skills || [];
      const experiences = parsedResumeData.parsed_experiences || [];
      const education = parsedResumeData.parsed_education || [];

      if (skills.length > 0) {
        context += `SKILLS: ${skills.join(', ')}\n\n`;
      }

      if (experiences.length > 0) {
        context += `WORK EXPERIENCE:\n`;
        experiences.forEach((exp: any) => {
          context += `- ${exp.jobTitle || 'Position'} at ${exp.company || 'Company'}`;
          if (exp.duration) context += ` (${exp.duration})`;
          if (exp.description) context += `\n  ${exp.description}`;
          context += `\n`;
        });
        context += `\n`;
      }

      if (education.length > 0) {
        context += `EDUCATION:\n`;
        education.forEach((edu: any) => {
          context += `- ${edu.degree || 'Degree'} from ${edu.institution || 'Institution'}`;
          if (edu.year) context += ` (${edu.year})`;
          context += `\n`;
        });
        context += `\n`;
      }
    } else {
      context += `RESUME: Not yet parsed\n\n`;
    }

    if (applicationData.coverLetter) {
      context += `COVER LETTER:\n${applicationData.coverLetter}\n\n`;
    }

    if (applicationData.salaryExpectation) {
      context += `SALARY EXPECTATION: $${applicationData.salaryExpectation.toLocaleString()}\n`;
    }

    if (applicationData.location) {
      context += `LOCATION: ${applicationData.location}\n`;
    }

    if (applicationData.availabilityDate) {
      context += `AVAILABLE FROM: ${new Date(applicationData.availabilityDate).toLocaleDateString()}\n`;
    }

    if (applicationData.willingToRelocate) {
      context += `WILLING TO RELOCATE: Yes\n`;
    }

    if (jobDetails) {
      context += `\nJOB DETAILS:\n`;
      context += `Title: ${jobDetails.title || 'N/A'}\n`;
      context += `Company: ${jobDetails.company || 'N/A'}\n`;
      if (jobDetails.description) {
        context += `Description: ${jobDetails.description.substring(0, 500)}...\n`;
      }
      if (jobDetails.requirements) {
        context += `Requirements: ${jobDetails.requirements.substring(0, 500)}...\n`;
      }
    }

    const userPrompt = `${context}\n\nEMPLOYER QUESTION: ${query}\n\nProvide a concise, insightful analysis that helps the employer make an informed decision. Focus on actionable insights.`;

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.7,
        max_tokens: 800,
      }),
    });

    if (!response.ok) {
      console.error("OpenAI API error:", response.status, await response.text());
      return generateIntelligentFallback(query, applicationData, parsedResumeData, jobDetails);
    }

    const data = await response.json();
    return data.choices[0]?.message?.content || generateIntelligentFallback(query, applicationData, parsedResumeData, jobDetails);
  } catch (error) {
    console.error("Error calling OpenAI:", error);
    return generateIntelligentFallback(query, applicationData, parsedResumeData, jobDetails);
  }
}

function generateIntelligentFallback(
  query: string,
  applicationData: any,
  parsedResumeData: any,
  jobDetails: any
): string {
  const lowerQuery = query.toLowerCase();
  const candidateName = applicationData.candidateName;

  let response = `**${candidateName} - Candidate Analysis**\n\n`;

  if (lowerQuery.includes('summar') || lowerQuery.includes('tell me about') || lowerQuery.includes('who is')) {
    response += `**Overview:**\n`;
    response += `${candidateName} applied on ${new Date(applicationData.createdAt).toLocaleDateString()} `;
    response += `via ${applicationData.source === 'recruiter' ? 'recruiter submission' : 'direct application'}. `;
    response += `Current status: **${applicationData.status}**.\n\n`;

    if (parsedResumeData && parsedResumeData.parsing_status === 'completed') {
      const skills = parsedResumeData.parsed_skills || [];
      const experiences = parsedResumeData.parsed_experiences || [];

      if (skills.length > 0) {
        response += `**Key Skills:** ${skills.slice(0, 5).join(', ')}${skills.length > 5 ? ', and more' : ''}\n\n`;
      }

      if (experiences.length > 0) {
        response += `**Experience Highlights:**\n`;
        const latestRole = experiences[0];
        response += `Most recently worked as ${latestRole.jobTitle || 'a professional'} at ${latestRole.company || 'a company'}. `;
        response += `Total of ${experiences.length} role${experiences.length > 1 ? 's' : ''} documented.\n\n`;
      }
    } else {
      response += `*Note: Resume parsing pending. Full skill and experience analysis will be available once processing completes.*\n\n`;
    }

    if (applicationData.salaryExpectation) {
      response += `**Compensation:** Expects $${applicationData.salaryExpectation.toLocaleString()}/year\n`;
    }

    if (applicationData.coverLetter) {
      const motivation = applicationData.coverLetter.substring(0, 200).trim();
      response += `\n**Motivation:** ${candidateName}'s cover letter expresses genuine interest in the role and highlights relevant experience.\n`;
    }

    response += `\n**Recommendation:** `;
    if (applicationData.status === 'submitted') {
      response += `Review full application details and consider moving to shortlist if qualifications align with requirements.`;
    } else if (applicationData.status === 'shortlisted') {
      response += `Strong candidate worth scheduling an interview to discuss qualifications in detail.`;
    } else {
      response += `Continue evaluation process based on current status.`;
    }

    return response;
  }

  if (lowerQuery.includes('skill')) {
    if (parsedResumeData && parsedResumeData.parsing_status === 'completed') {
      const skills = parsedResumeData.parsed_skills || [];
      if (skills.length > 0) {
        response += `**Skills Assessment:**\n\n`;
        response += `${candidateName} demonstrates ${skills.length} documented skills:\n`;
        response += skills.slice(0, 10).map(s => `• ${s}`).join('\n');
        if (skills.length > 10) response += `\n...and ${skills.length - 10} more`;
        response += `\n\n**Recommendation:** Cross-reference these skills with your job requirements to assess fit.`;
      } else {
        response += `Skills information not available in parsed resume data.`;
      }
    } else {
      response += `Resume parsing is pending. Skills analysis will be available once processing completes.`;
    }
    return response;
  }

  if (lowerQuery.includes('experience')) {
    if (parsedResumeData && parsedResumeData.parsing_status === 'completed') {
      const experiences = parsedResumeData.parsed_experiences || [];
      if (experiences.length > 0) {
        response += `**Experience Overview:**\n\n`;
        response += `${candidateName} has ${experiences.length} documented role${experiences.length > 1 ? 's' : ''}:\n\n`;
        experiences.slice(0, 3).forEach((exp: any) => {
          response += `• **${exp.jobTitle || 'Position'}** at **${exp.company || 'Company'}**\n`;
          if (exp.duration) response += `  Duration: ${exp.duration}\n`;
        });
        response += `\n**Recommendation:** Review work history progression and relevance to your position.`;
      } else {
        response += `Experience information not available in parsed resume data.`;
      }
    } else {
      response += `Resume parsing is pending. Experience analysis will be available once processing completes.`;
    }
    return response;
  }

  response += `I can help you analyze ${candidateName}'s application. Try asking:\n\n`;
  response += `• "Summarize ${candidateName}'s resume"\n`;
  response += `• "What skills does ${candidateName} have?"\n`;
  response += `• "Tell me about ${candidateName}'s experience"\n`;
  response += `• "Is ${candidateName} a good fit for this role?"\n`;

  return response;
}
