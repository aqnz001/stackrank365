import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'npm:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Get the authorization header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('No authorization header')
    }

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    // Verify the user
    const token = authHeader.replace('Bearer ', '')
    const { data: { user }, error: authError } = await supabase.auth.getUser(token)
    
    if (authError || !user) {
      throw new Error('Invalid authentication')
    }

    const url = new URL(req.url)
    const action = url.pathname.split('/').pop()

    if (action === 'create') {
      return await createEscrowTransaction(supabase, req, user)
    } else if (action === 'release') {
      return await releaseEscrowTransaction(supabase, req, user)
    }

    throw new Error('Invalid action')
  } catch (error) {
    console.error('Escrow error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    )
  }
})

async function createEscrowTransaction(supabase: any, req: Request, user: any) {
  const { 
    recruiter_bid_id, 
    amount, 
    platform_fee_percentage = 0.15,
    organization_id 
  } = await req.json()

  if (!recruiter_bid_id || !amount || !organization_id) {
    throw new Error('Missing required parameters')
  }

  // Get billing account
  const { data: billingAccount } = await supabase
    .from('billing_accounts')
    .select('*')
    .eq('organization_id', organization_id)
    .single()

  if (!billingAccount) {
    throw new Error('No billing account found')
  }

  // Calculate fees
  const platformFee = Math.round(amount * platform_fee_percentage)
  const recruiterFee = amount - platformFee

  // Create escrow transaction
  const { data: escrow, error } = await supabase
    .from('escrow_transactions')
    .insert({
      recruiter_bid_id,
      billing_account_id: billingAccount.id,
      stripe_payment_intent_id: `pi_escrow_${Date.now()}`,
      amount,
      platform_fee: platformFee,
      recruiter_fee: recruiterFee,
      currency: 'usd',
      status: 'held',
      held_until: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(), // 90 days
    })
    .select()
    .single()

  if (error) throw error

  console.log('Escrow transaction created:', escrow.id)

  return new Response(
    JSON.stringify(escrow),
    {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    }
  )
}

async function releaseEscrowTransaction(supabase: any, req: Request, user: any) {
  const { escrow_transaction_id } = await req.json()

  if (!escrow_transaction_id) {
    throw new Error('Missing escrow transaction ID')
  }

  // Update escrow status
  const { data: escrow, error } = await supabase
    .from('escrow_transactions')
    .update({
      status: 'released',
      released_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq('id', escrow_transaction_id)
    .select()
    .single()

  if (error) throw error

  console.log('Escrow transaction released:', escrow.id)

  return new Response(
    JSON.stringify(escrow),
    {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    }
  )
}