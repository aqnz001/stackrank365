import { createClient } from 'npm:@supabase/supabase-js@2.56.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

interface CandidateProfile {
  name?: string;
  email?: string;
  bio?: string;
  skills?: string[];
  experience?: string;
  experienceYears?: number;
  education?: string;
  location?: string;
  industry?: string;
}

function anonymizeName(name?: string): string {
  if (!name) return 'Experienced Professional';
  const parts = name.split(' ');
  if (parts.length === 1) return 'Senior Professional';
  return `${parts[0][0]}. ${parts[parts.length - 1][0]}.`;
}

function extractSkills(profile: CandidateProfile, jobSkills: string[]): string[] {
  const candidateSkills = profile.skills || [];
  const normalizedJobSkills = jobSkills.map(s => s.toLowerCase());
  
  const matchedSkills = candidateSkills.filter(skill =>
    normalizedJobSkills.some(jobSkill =>
      skill.toLowerCase().includes(jobSkill) || jobSkill.includes(skill.toLowerCase())
    )
  );

  const additionalRelevantSkills = candidateSkills.filter(skill => {
    const skillLower = skill.toLowerCase();
    return !matchedSkills.includes(skill) && (
      skillLower.includes('leadership') ||
      skillLower.includes('management') ||
      skillLower.includes('senior') ||
      skillLower.includes('architect')
    );
  });

  return [...matchedSkills, ...additionalRelevantSkills].slice(0, 10);
}

function generateSummary(profile: CandidateProfile, jobDescription: string, jobTitle: string): string {
  const yearsExp = profile.experienceYears || 5;
  const industry = profile.industry || 'Technology';
  const location = profile.location ? `based in ${profile.location.split(',')[0]}` : 'available for remote work';
  
  let summary = `<p><strong>Seasoned ${industry} professional</strong> with ${yearsExp}+ years of progressive experience, ${location}.</p>`;

  if (profile.bio) {
    const bioSentences = profile.bio.split('.').filter(s => s.trim().length > 10);
    if (bioSentences.length > 0) {
      summary += `<p>${bioSentences[0].trim()}.</p>`;
    }
  }

  summary += '<p><strong>Key Qualifications:</strong></p><ul>';

  const experienceHighlights = [
    `Proven track record in ${industry.toLowerCase()} sector`,
    'Strong technical foundation with hands-on expertise',
    'Excellent problem-solving and analytical capabilities',
    'Collaborative team player with leadership experience',
  ];

  if (profile.experience) {
    const expKeywords = [
      { keyword: 'led', highlight: 'Demonstrated leadership in managing technical teams and projects' },
      { keyword: 'built', highlight: 'Experience building and scaling production systems' },
      { keyword: 'designed', highlight: 'Architected and designed complex technical solutions' },
      { keyword: 'improved', highlight: 'Track record of process improvement and optimization' },
      { keyword: 'managed', highlight: 'Managed cross-functional teams and stakeholder relationships' },
    ];

    const expLower = profile.experience.toLowerCase();
    expKeywords.forEach(({ keyword, highlight }) => {
      if (expLower.includes(keyword)) {
        experienceHighlights.push(highlight);
      }
    });
  }

  experienceHighlights.slice(0, 4).forEach(highlight => {
    summary += `<li>${highlight}</li>`;
  });

  summary += '</ul>';

  if (profile.education) {
    const eduLines = profile.education.split('\n').filter(l => l.trim());
    if (eduLines.length > 0) {
      summary += `<p><strong>Education:</strong> ${eduLines[0]}</p>`;
    }
  }

  summary += '<p><em>This anonymized profile highlights the candidate\'s relevant qualifications while protecting their identity. Full details will be shared upon bid acceptance.</em></p>';

  return summary;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { candidateProfile, jobDescription, jobTitle, jobSkills } = await req.json();

    if (!candidateProfile) {
      throw new Error('Candidate profile is required');
    }

    console.log('Generating anonymized profile for:', candidateProfile.email);

    const profile: CandidateProfile = candidateProfile;
    const skills = extractSkills(profile, jobSkills || []);
    const summary = generateSummary(profile, jobDescription, jobTitle);

    const anonymizedProfile = {
      skills: skills,
      experienceYears: profile.experienceYears || 5,
      industry: profile.industry || 'Technology',
      location: profile.location?.split(',')[0] || 'Flexible',
      summary: summary,
    };

    console.log('Profile generated successfully');

    return new Response(
      JSON.stringify(anonymizedProfile),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    );
  }
});
