import { createClient } from 'npm:@supabase/supabase-js@2.56.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

interface Job {
  id: string;
  title: string;
  description: string;
  location: string;
  employment_type: string;
  salary_min?: number;
  salary_max?: number;
  skills: string[];
  organization_id: string;
  created_at: string;
}

interface SavedSearch {
  id: string;
  user_id: string;
  name: string;
  search_criteria: {
    query?: string;
    location?: string;
    employmentType?: string[];
    salaryMin?: number;
    salaryMax?: number;
    skills?: string[];
  };
  email_alerts: boolean;
  alert_frequency: string;
  last_alert_sent?: string;
}

function matchesSearch(job: Job, criteria: any): boolean {
  if (criteria.query) {
    const query = criteria.query.toLowerCase();
    const searchText = `${job.title} ${job.description} ${job.location} ${job.skills.join(' ')}`.toLowerCase();
    if (!searchText.includes(query)) return false;
  }

  if (criteria.location && !job.location.toLowerCase().includes(criteria.location.toLowerCase())) {
    return false;
  }

  if (criteria.employmentType?.length > 0 && !criteria.employmentType.includes(job.employment_type)) {
    return false;
  }

  if (criteria.salaryMin && job.salary_min && job.salary_min < criteria.salaryMin) {
    return false;
  }

  if (criteria.salaryMax && job.salary_max && job.salary_max > criteria.salaryMax) {
    return false;
  }

  if (criteria.skills?.length > 0) {
    const hasMatchingSkill = criteria.skills.some((skill: string) =>
      job.skills.some(jobSkill => jobSkill.toLowerCase().includes(skill.toLowerCase()))
    );
    if (!hasMatchingSkill) return false;
  }

  return true;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { job } = await req.json();

    if (!job) {
      throw new Error('Job data is required');
    }

    console.log('Checking saved searches for new job:', job.id);

    const { data: savedSearches, error: searchError } = await supabase
      .from('saved_searches')
      .select('*')
      .eq('email_alerts', true)
      .eq('is_active', true);

    if (searchError) throw searchError;

    console.log(`Found ${savedSearches?.length || 0} active saved searches`);

    const notifications = [];
    const now = new Date();

    for (const search of savedSearches || []) {
      if (matchesSearch(job, search.search_criteria)) {
        const shouldSendAlert = (() => {
          if (!search.last_alert_sent) return true;
          
          const lastSent = new Date(search.last_alert_sent);
          const hoursSinceLastAlert = (now.getTime() - lastSent.getTime()) / (1000 * 60 * 60);

          switch (search.alert_frequency) {
            case 'immediate':
              return true;
            case 'daily':
              return hoursSinceLastAlert >= 24;
            case 'weekly':
              return hoursSinceLastAlert >= 168;
            default:
              return false;
          }
        })();

        if (shouldSendAlert) {
          notifications.push({
            user_id: search.user_id,
            type: 'saved_search_match',
            title: `New job matches "${search.name}"`,
            message: `${job.title} at ${job.location}`,
            link: `/jobs/${job.id}`,
            metadata: {
              job_id: job.id,
              saved_search_id: search.id,
            },
          });

          await supabase
            .from('saved_searches')
            .update({ last_alert_sent: now.toISOString() })
            .eq('id', search.id);

          console.log(`Created notification for user ${search.user_id} and search "${search.name}"`);
        }
      }
    }

    if (notifications.length > 0) {
      const { error: notifError } = await supabase
        .from('notifications')
        .insert(notifications);

      if (notifError) {
        console.error('Error creating notifications:', notifError);
      } else {
        console.log(`Created ${notifications.length} notifications`);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        notificationsCreated: notifications.length,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    );
  }
});
