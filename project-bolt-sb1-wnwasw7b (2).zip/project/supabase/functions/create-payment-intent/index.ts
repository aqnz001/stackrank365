import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'npm:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Get the authorization header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('No authorization header')
    }

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    // Verify the user
    const token = authHeader.replace('Bearer ', '')
    const { data: { user }, error: authError } = await supabase.auth.getUser(token)
    
    if (authError || !user) {
      throw new Error('Invalid authentication')
    }

    const { amount, currency = 'usd', description, metadata, organization_id } = await req.json()

    if (!amount || amount < 50) {
      throw new Error('Amount must be at least $0.50')
    }

    // Get or create billing account
    let { data: billingAccount } = await supabase
      .from('billing_accounts')
      .select('*')
      .eq('organization_id', organization_id)
      .single()

    if (!billingAccount) {
      // Create billing account if it doesn't exist
      const { data: newBillingAccount, error: billingError } = await supabase
        .from('billing_accounts')
        .insert({
          organization_id,
          billing_email: user.email,
        })
        .select()
        .single()

      if (billingError) throw billingError
      billingAccount = newBillingAccount
    }

    // For demo purposes, create a mock payment intent
    const paymentIntentId = `pi_mock_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const clientSecret = `${paymentIntentId}_secret_mock`

    // Create payment record
    const { data: payment, error: paymentError } = await supabase
      .from('payments')
      .insert({
        billing_account_id: billingAccount.id,
        stripe_payment_intent_id: paymentIntentId,
        amount,
        currency,
        status: 'pending',
        description,
        metadata: metadata || {},
      })
      .select()
      .single()

    if (paymentError) throw paymentError

    console.log('Payment intent created:', paymentIntentId)

    return new Response(
      JSON.stringify({
        id: paymentIntentId,
        client_secret: clientSecret,
        amount,
        currency,
        status: 'requires_payment_method',
        description,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )
  } catch (error) {
    console.error('Error creating payment intent:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    )
  }
})