// supabase/functions/create-organization-and-profile/index.ts

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'npm:@supabase/supabase-js';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Initialize Supabase client with the service_role key
    // This bypasses Row Level Security (RLS)
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!supabaseUrl || !supabaseServiceKey) {
      throw new Error('Missing Supabase environment variables for service role.');
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        persistSession: false, // Important for server-side functions
      },
    });

    const { userId, userName, userEmail, userRole, organizationName, organizationType } = await req.json();

    if (!userId || !userName || !userEmail || !userRole || !organizationName || !organizationType) {
      throw new Error('Missing required parameters for organization and profile creation.');
    }

    // 1. Create the organization
    const { data: organization, error: orgError } = await supabase
      .from('organizations')
      .insert({
        name: organizationName,
        type: organizationType,
        status: 'active', // Default status
      })
      .select()
      .single();

    if (orgError) {
      console.error('Error creating organization:', orgError);
      throw new Error(`Failed to create organization: ${orgError.message}`);
    }

    console.log('Organization created successfully:', organization.id);

    // 2. Create billing account for the organization
    const { data: billingAccount, error: billingError } = await supabase
      .from('billing_accounts')
      .insert({
        organization_id: organization.id,
        billing_email: userEmail,
        company_name: organizationName,
      })
      .select()
      .single();

    if (billingError) {
      console.error('Error creating billing account:', billingError);
      // Rollback organization creation if billing account creation fails
      await supabase.from('organizations').delete().eq('id', organization.id);
      throw new Error(`Failed to create billing account: ${billingError.message}`);
    }

    console.log('Billing account created successfully:', billingAccount.id);

    // 3. Update organization with billing account reference
    const { error: orgUpdateError } = await supabase
      .from('organizations')
      .update({ billing_account_id: billingAccount.id })
      .eq('id', organization.id);

    if (orgUpdateError) {
      console.error('Error linking billing account to organization:', orgUpdateError);
      // This is not critical, so we won't rollback, but we'll log it
    }

    // 4. Update the user's profile with the organization_id and role
    // This assumes the profile record already exists from the auth.signUp trigger
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .update({
        organization_id: organization.id,
        role: userRole,
        name: userName,
        email: userEmail,
      })
      .eq('id', userId)
      .select()
      .single();

    if (profileError) {
      console.error('Error updating user profile:', profileError);
      // Consider rolling back organization and billing account creation if profile update fails
      await supabase.from('billing_accounts').delete().eq('id', billingAccount.id);
      await supabase.from('organizations').delete().eq('id', organization.id);
      throw new Error(`Failed to update user profile with organization: ${profileError.message}`);
    }

    console.log('Profile updated successfully with organization:', profile.id);

    console.log(`Organization ${organization.id} created, linked to user ${userId}, and billing account ${billingAccount.id} set up`);

    return new Response(
      JSON.stringify({
        message: 'Organization and profile updated successfully',
        organizationId: organization.id,
        profileId: profile.id,
        billingAccountId: billingAccount.id,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    );
  } catch (error) {
    console.error('Edge Function error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      },
    );
  }
});