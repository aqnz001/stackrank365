import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'npm:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, DELETE, OPTIONS',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Get the authorization header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('No authorization header')
    }

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    // Verify the user
    const token = authHeader.replace('Bearer ', '')
    const { data: { user }, error: authError } = await supabase.auth.getUser(token)
    
    if (authError || !user) {
      throw new Error('Invalid authentication')
    }

    const url = new URL(req.url)
    const action = url.pathname.split('/').pop()

    if (req.method === 'POST' && action === 'add') {
      return await addPaymentMethod(supabase, req, user)
    } else if (req.method === 'DELETE' && action === 'remove') {
      return await removePaymentMethod(supabase, req, user)
    } else if (req.method === 'POST' && action === 'set-default') {
      return await setDefaultPaymentMethod(supabase, req, user)
    }

    throw new Error('Invalid action')
  } catch (error) {
    console.error('Payment method error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    )
  }
})

async function addPaymentMethod(supabase: any, req: Request, user: any) {
  const { payment_method, organization_id, set_as_default } = await req.json()

  // Get billing account
  const { data: billingAccount } = await supabase
    .from('billing_accounts')
    .select('*')
    .eq('organization_id', organization_id)
    .single()

  if (!billingAccount) {
    throw new Error('No billing account found')
  }

  // For demo purposes, create a mock payment method
  const paymentMethodId = `pm_mock_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  
  // Set all other methods as non-default if this is default
  if (set_as_default) {
    await supabase
      .from('payment_methods')
      .update({ is_default: false })
      .eq('billing_account_id', billingAccount.id)
  }

  const { data: newMethod, error } = await supabase
    .from('payment_methods')
    .insert({
      billing_account_id: billingAccount.id,
      stripe_payment_method_id: paymentMethodId,
      type: 'card',
      card_brand: 'visa',
      card_last4: '4242',
      card_exp_month: 12,
      card_exp_year: 2025,
      is_default: set_as_default || false,
    })
    .select()
    .single()

  if (error) throw error

  return new Response(
    JSON.stringify(newMethod),
    {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    }
  )
}

async function removePaymentMethod(supabase: any, req: Request, user: any) {
  const { payment_method_id } = await req.json()

  const { error } = await supabase
    .from('payment_methods')
    .delete()
    .eq('stripe_payment_method_id', payment_method_id)

  if (error) throw error

  return new Response(
    JSON.stringify({ success: true }),
    {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    }
  )
}

async function setDefaultPaymentMethod(supabase: any, req: Request, user: any) {
  const { payment_method_id, organization_id } = await req.json()

  // Get billing account
  const { data: billingAccount } = await supabase
    .from('billing_accounts')
    .select('*')
    .eq('organization_id', organization_id)
    .single()

  if (!billingAccount) {
    throw new Error('No billing account found')
  }

  // Set all methods as non-default
  await supabase
    .from('payment_methods')
    .update({ is_default: false })
    .eq('billing_account_id', billingAccount.id)

  // Set the selected method as default
  const { error } = await supabase
    .from('payment_methods')
    .update({ is_default: true })
    .eq('stripe_payment_method_id', payment_method_id)

  if (error) throw error

  return new Response(
    JSON.stringify({ success: true }),
    {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    }
  )
}