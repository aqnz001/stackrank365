import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface MilestoneTriggerRequest {
  trigger: 'interview_scheduled' | 'candidate_hired' | 'probation_completed';
  recruiterBidId: string;
  applicationId?: string;
  interviewId?: string;
  notes?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { trigger, recruiterBidId, applicationId, interviewId, notes }: MilestoneTriggerRequest =
      await req.json();

    console.log('Processing milestone trigger:', { trigger, recruiterBidId });

    const { data: pendingPayments, error: paymentsError } = await supabase
      .from('scheduled_payments')
      .select('*')
      .eq('recruiter_bid_id', recruiterBidId)
      .eq('milestone_trigger', trigger)
      .eq('status', 'pending');

    if (paymentsError) {
      console.error('Error fetching pending payments:', paymentsError);
      throw paymentsError;
    }

    if (!pendingPayments || pendingPayments.length === 0) {
      console.log('No pending payments found for this trigger');
      return new Response(
        JSON.stringify({
          success: true,
          message: 'No pending payments for this trigger',
          triggered: 0,
        }),
        {
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const updates = pendingPayments.map((payment) => ({
      id: payment.id,
      status: 'triggered',
      trigger_date: new Date().toISOString(),
      notes: notes || `Triggered by ${trigger}`,
    }));

    for (const update of updates) {
      const { error: updateError } = await supabase
        .from('scheduled_payments')
        .update({
          status: update.status,
          trigger_date: update.trigger_date,
          notes: update.notes,
        })
        .eq('id', update.id);

      if (updateError) {
        console.error('Error updating payment:', updateError);
        throw updateError;
      }
    }

    const { data: bidData } = await supabase
      .from('recruiter_bids')
      .select(`
        *,
        profiles!recruiter_bids_recruiter_id_fkey (
          id,
          name
        ),
        jobs!recruiter_bids_job_id_fkey (
          id,
          title,
          organization_id
        )
      `)
      .eq('id', recruiterBidId)
      .single();

    if (bidData) {
      await supabase.from('notifications').insert({
        user_id: bidData.recruiter_id,
        type: 'payment_milestone_triggered',
        title: 'Payment Milestone Triggered',
        message: `A payment milestone has been triggered for your bid on ${bidData.jobs?.title}`,
        data: {
          recruiter_bid_id: recruiterBidId,
          trigger,
          payment_count: updates.length,
          application_id: applicationId,
          interview_id: interviewId,
        },
        read: false,
      });

      if (bidData.jobs?.organization_id) {
        const { data: orgMembers } = await supabase
          .from('profiles')
          .select('id')
          .eq('organization_id', bidData.jobs.organization_id)
          .eq('role', 'employer');

        if (orgMembers && orgMembers.length > 0) {
          const employerNotifications = orgMembers.map((member) => ({
            user_id: member.id,
            type: 'payment_milestone_triggered',
            title: 'Recruiter Payment Milestone Reached',
            message: `A payment milestone has been reached for recruiter ${bidData.profiles?.name} on ${bidData.jobs?.title}`,
            data: {
              recruiter_bid_id: recruiterBidId,
              trigger,
              payment_count: updates.length,
            },
            read: false,
          }));

          await supabase.from('notifications').insert(employerNotifications);
        }
      }
    }

    console.log('Successfully triggered milestones:', updates.length);

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Milestones triggered successfully',
        triggered: updates.length,
        payments: updates,
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Error in trigger-payment-milestones:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});