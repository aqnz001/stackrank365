import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'npm:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Get the authorization header
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('No authorization header')
    }

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    // Verify the user
    const token = authHeader.replace('Bearer ', '')
    const { data: { user }, error: authError } = await supabase.auth.getUser(token)
    
    if (authError || !user) {
      throw new Error('Invalid authentication')
    }

    const { 
      price_id, 
      quantity = 1, 
      trial_period_days, 
      metadata, 
      organization_id 
    } = await req.json()

    if (!price_id || !organization_id) {
      throw new Error('Missing required parameters')
    }

    // Get billing account
    const { data: billingAccount } = await supabase
      .from('billing_accounts')
      .select('*')
      .eq('organization_id', organization_id)
      .single()

    if (!billingAccount) {
      throw new Error('No billing account found. Please set up billing first.')
    }

    // Get plan details
    const { data: plan } = await supabase
      .from('subscription_plans')
      .select('*')
      .eq('id', price_id)
      .single()

    if (!plan) {
      throw new Error('Plan not found')
    }

    // For demo purposes, create a mock subscription
    const subscriptionId = `sub_mock_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    
    const { data: subscription, error: subError } = await supabase
      .from('subscriptions')
      .insert({
        billing_account_id: billingAccount.id,
        stripe_subscription_id: subscriptionId,
        status: trial_period_days ? 'trialing' : 'active',
        plan_name: plan.name,
        plan_amount: plan.amount,
        currency: plan.currency,
        billing_cycle: plan.billing_interval,
        current_period_start: new Date().toISOString(),
        current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        trial_end: trial_period_days ? new Date(Date.now() + trial_period_days * 24 * 60 * 60 * 1000).toISOString() : null,
      })
      .select()
      .single()

    if (subError) throw subError

    console.log('Subscription created:', subscription.id)

    return new Response(
      JSON.stringify({
        id: subscription.id,
        status: subscription.status,
        plan_name: subscription.plan_name,
        current_period_start: subscription.current_period_start,
        current_period_end: subscription.current_period_end,
        trial_end: subscription.trial_end,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )
  } catch (error) {
    console.error('Error creating subscription:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    )
  }
})