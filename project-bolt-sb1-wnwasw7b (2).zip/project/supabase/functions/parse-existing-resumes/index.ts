import { createClient } from 'npm:@supabase/supabase-js@2.56.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

interface ParsedExperience {
  jobTitle: string;
  company: string;
  industry?: string;
  startMonth?: string;
  startYear?: string;
  endMonth?: string;
  endYear?: string;
  isCurrentRole?: boolean;
  description?: string;
}

function parseResumeText(text: string): { skills: string[]; experiences: ParsedExperience[] } {
  const normalized = (text || '').replace(/\r\n?/g, '\n');
  const lower = normalized.toLowerCase();
  let skillsBlock = '';
  const skillsIdx = lower.indexOf('skills');
  if (skillsIdx >= 0) {
    const after = normalized.slice(skillsIdx + 'skills'.length);
    const chunk = after.slice(0, 600);
    skillsBlock = chunk.split('\n').slice(0, 8).join('\n');
  }
  const rawTokens = skillsBlock
    .split(/[\n,•;\t]/g)
    .map(s => s.trim())
    .filter(Boolean)
    .filter(s => s.length <= 40 && s.length >= 2);
  const skills = Array.from(new Set(rawTokens)).slice(0, 12);

  const experiences: ParsedExperience[] = [];
  const lines = normalized.split('\n');
  for (const line of lines) {
    const l = line.trim();
    if (!l) continue;
    const m1 = l.match(/^(?<title>[^•\-\u2013\u2014]{2,60})\s+(?:-|–|—|at)\s+(?<company>[^•\u2013\u2014]{2,80})/i);
    const groups = (m1 as any)?.groups;
    if (groups) {
      const jobTitle = String(groups.title || '').trim();
      const company = String(groups.company || '').trim().replace(/[•|·].*$/, '');
      if (jobTitle && company) {
        experiences.push({
          jobTitle,
          company,
          industry: '',
          startMonth: '',
          startYear: '',
          endMonth: '',
          endYear: '',
          isCurrentRole: false,
          description: '',
        });
      }
    }
    if (experiences.length >= 5) break;
  }
  return { skills, experiences };
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    if (req.method !== 'POST') {
      return new Response('Method Not Allowed', {
        status: 405,
        headers: corsHeaders
      });
    }

    const auth = req.headers.get('Authorization') || '';
    if (!auth.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ error: 'unauthorized', detail: 'Missing authorization header' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Verify the user is authenticated but use service role key for database operations
    const supabaseAuth = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: auth },
        },
      }
    );

    const { data: { user }, error: authError } = await supabaseAuth.auth.getUser();
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'unauthorized', detail: 'Invalid authentication' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Use service role key for database operations (bypass RLS)
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const body = await req.json().catch(() => ({} as any));
    const limit = body.limit || 10;
    const dryRun = body.dryRun === true;

    console.log(`Starting batch parse for existing resumes (limit: ${limit}, dryRun: ${dryRun})`);

    const { data: existingResumes, error: fetchError } = await supabaseClient
      .from('file_uploads')
      .select('id, user_id, file_path, bucket_name')
      .eq('file_type', 'resume')
      .eq('is_active', true)
      .limit(limit);

    if (fetchError) {
      console.error('Error fetching resumes:', fetchError);
      return new Response(
        JSON.stringify({ error: 'fetch_error', detail: fetchError.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!existingResumes || existingResumes.length === 0) {
      return new Response(
        JSON.stringify({ message: 'No resumes found to parse', processed: 0 }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Found ${existingResumes.length} resumes to process`);

    const results = {
      total: existingResumes.length,
      alreadyParsed: 0,
      parsed: 0,
      failed: 0,
      skipped: 0,
      details: [] as any[],
    };

    for (const resume of existingResumes) {
      try {
        const { data: existingParsed } = await supabaseClient
          .from('resume_parsed_data')
          .select('id, parsing_status')
          .eq('file_upload_id', resume.id)
          .maybeSingle();

        if (existingParsed && existingParsed.parsing_status === 'completed') {
          console.log(`Resume ${resume.id} already parsed, skipping`);
          results.alreadyParsed++;
          results.details.push({
            fileId: resume.id,
            status: 'already_parsed',
          });
          continue;
        }

        const { data: signedUrlData, error: urlError } = await supabaseClient
          .storage
          .from(resume.bucket_name)
          .createSignedUrl(resume.file_path, 3600);

        if (urlError || !signedUrlData?.signedUrl) {
          console.error(`Failed to get signed URL for ${resume.id}:`, urlError);
          results.skipped++;
          results.details.push({
            fileId: resume.id,
            status: 'url_error',
            error: urlError?.message,
          });
          continue;
        }

        const url = signedUrlData.signedUrl;
        let text = '';

        try {
          const fileResp = await fetch(url);
          if (!fileResp.ok) {
            console.error(`Failed to fetch resume ${resume.id}`);
            results.skipped++;
            results.details.push({
              fileId: resume.id,
              status: 'fetch_failed',
            });
            continue;
          }

          const ctype = fileResp.headers.get('content-type') || '';
          if (ctype.includes('text')) {
            text = await fileResp.text();
          } else {
            const buf = new Uint8Array(await fileResp.arrayBuffer());
            text = new TextDecoder('utf-8', { fatal: false }).decode(buf);
          }
        } catch (fetchErr) {
          console.error(`Error fetching resume ${resume.id}:`, fetchErr);
          results.skipped++;
          results.details.push({
            fileId: resume.id,
            status: 'fetch_error',
            error: String(fetchErr),
          });
          continue;
        }

        const parsed = parseResumeText(text || '');

        if (dryRun) {
          console.log(`[DRY RUN] Would parse resume ${resume.id}: ${parsed.skills.length} skills, ${parsed.experiences.length} experiences`);
          results.parsed++;
          results.details.push({
            fileId: resume.id,
            status: 'would_parse',
            skills: parsed.skills.length,
            experiences: parsed.experiences.length,
          });
          continue;
        }

        const resumeData = {
          file_upload_id: resume.id,
          user_id: resume.user_id,
          parsed_text: text || null,
          parsed_skills: parsed.skills || [],
          parsed_experiences: parsed.experiences || [],
          parsed_education: [],
          parsed_metadata: {},
          parsing_status: 'completed',
          parsed_at: new Date().toISOString(),
        };

        if (existingParsed) {
          await supabaseClient
            .from('resume_parsed_data')
            .update(resumeData)
            .eq('file_upload_id', resume.id);
        } else {
          await supabaseClient
            .from('resume_parsed_data')
            .insert(resumeData);
        }

        console.log(`Successfully parsed resume ${resume.id}`);
        results.parsed++;
        results.details.push({
          fileId: resume.id,
          status: 'parsed',
          skills: parsed.skills.length,
          experiences: parsed.experiences.length,
        });
      } catch (err) {
        console.error(`Error processing resume ${resume.id}:`, err);
        results.failed++;
        results.details.push({
          fileId: resume.id,
          status: 'error',
          error: String(err),
        });
      }
    }

    console.log('Batch parsing complete:', results);

    return new Response(
      JSON.stringify({
        success: true,
        dryRun,
        results,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  } catch (e) {
    console.error('Batch parse error:', e);
    return new Response(
      JSON.stringify({ error: 'internal_error', detail: String(e) }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
