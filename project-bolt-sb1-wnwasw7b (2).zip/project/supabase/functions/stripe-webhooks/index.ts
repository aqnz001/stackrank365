import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'npm:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, stripe-signature',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const signature = req.headers.get('stripe-signature')
    if (!signature) {
      throw new Error('No Stripe signature found')
    }

    const body = await req.text()
    const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET')
    
    if (!webhookSecret) {
      throw new Error('Stripe webhook secret not configured')
    }

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    // Verify webhook signature (simplified for demo)
    console.log('Processing Stripe webhook:', body.substring(0, 100))

    const event = JSON.parse(body)
    
    // Store webhook event for processing
    await supabase.from('webhook_events').insert({
      stripe_event_id: event.id,
      event_type: event.type,
      data: event.data,
      processed: false,
    })

    // Process different event types
    switch (event.type) {
      case 'payment_intent.succeeded':
        await handlePaymentSuccess(supabase, event.data.object)
        break
      
      case 'payment_intent.payment_failed':
        await handlePaymentFailure(supabase, event.data.object)
        break
      
      case 'customer.subscription.created':
      case 'customer.subscription.updated':
        await handleSubscriptionUpdate(supabase, event.data.object)
        break
      
      case 'customer.subscription.deleted':
        await handleSubscriptionCancellation(supabase, event.data.object)
        break
      
      case 'invoice.payment_succeeded':
        await handleInvoicePayment(supabase, event.data.object)
        break
      
      case 'invoice.payment_failed':
        await handleInvoiceFailure(supabase, event.data.object)
        break
      
      default:
        console.log(`Unhandled event type: ${event.type}`)
    }

    // Mark webhook as processed
    await supabase
      .from('webhook_events')
      .update({ processed: true })
      .eq('stripe_event_id', event.id)

    return new Response(JSON.stringify({ received: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    })
  } catch (error) {
    console.error('Webhook error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    )
  }
})

async function handlePaymentSuccess(supabase: any, paymentIntent: any) {
  console.log('Payment succeeded:', paymentIntent.id)
  
  // Update payment record
  await supabase
    .from('payments')
    .update({ 
      status: 'succeeded',
      updated_at: new Date().toISOString()
    })
    .eq('stripe_payment_intent_id', paymentIntent.id)
}

async function handlePaymentFailure(supabase: any, paymentIntent: any) {
  console.log('Payment failed:', paymentIntent.id)
  
  // Update payment record
  await supabase
    .from('payments')
    .update({ 
      status: 'failed',
      updated_at: new Date().toISOString()
    })
    .eq('stripe_payment_intent_id', paymentIntent.id)
}

async function handleSubscriptionUpdate(supabase: any, subscription: any) {
  console.log('Subscription updated:', subscription.id)
  
  // Update subscription record
  await supabase
    .from('subscriptions')
    .upsert({
      stripe_subscription_id: subscription.id,
      status: subscription.status,
      current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
      current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
      updated_at: new Date().toISOString(),
    })
}

async function handleSubscriptionCancellation(supabase: any, subscription: any) {
  console.log('Subscription cancelled:', subscription.id)
  
  // Update subscription record
  await supabase
    .from('subscriptions')
    .update({
      status: 'canceled',
      canceled_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq('stripe_subscription_id', subscription.id)
}

async function handleInvoicePayment(supabase: any, invoice: any) {
  console.log('Invoice paid:', invoice.id)
  
  // Update invoice record
  await supabase
    .from('invoices')
    .update({
      status: 'paid',
      amount_paid: invoice.amount_paid,
      paid_at: new Date(invoice.status_transitions.paid_at * 1000).toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq('stripe_invoice_id', invoice.id)
}

async function handleInvoiceFailure(supabase: any, invoice: any) {
  console.log('Invoice payment failed:', invoice.id)
  
  // Update invoice record
  await supabase
    .from('invoices')
    .update({
      status: 'open',
      updated_at: new Date().toISOString(),
    })
    .eq('stripe_invoice_id', invoice.id)
}