import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.56.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("No authorization header");
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error("Unauthorized");
    }

    const { question, resumeText, coverLetter, jobDetails, contextType } = await req.json();

    if (!question || !question.trim()) {
      throw new Error("Question is required");
    }

    let context = "";
    
    if (resumeText && (contextType === "resume" || contextType === "both")) {
      context += `\n\nRESUME CONTENT:\n${resumeText}\n`;
    }
    
    if (coverLetter && (contextType === "cover_letter" || contextType === "both")) {
      context += `\n\nCOVER LETTER CONTENT:\n${coverLetter}\n`;
    }

    if (jobDetails) {
      context += `\n\nJOB DETAILS:\nTitle: ${jobDetails.title || 'N/A'}\nCompany: ${jobDetails.company || 'N/A'}\nDescription: ${jobDetails.description || 'N/A'}\n`;
    }

    const systemPrompt = `You are an expert career advisor and document reviewer helping job seekers understand and improve their application materials. You have access to the candidate's resume, cover letter, and job details.

Your role is to:
1. Answer specific questions about the resume and cover letter content
2. Provide constructive feedback and suggestions for improvement
3. Highlight strengths and areas for enhancement
4. Compare the application materials against the job requirements
5. Offer strategic advice for presenting qualifications effectively

Be concise, actionable, and supportive in your responses. Focus on providing value to help the candidate succeed.`;

    const userPrompt = `${context}\n\nQUESTION: ${question}\n\nProvide a helpful, detailed answer based on the content provided above.`;

    const answer = await analyzeWithAI(systemPrompt, userPrompt);

    return new Response(
      JSON.stringify({ answer, success: true }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error in application-assistant:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error", success: false }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});

async function analyzeWithAI(systemPrompt: string, userPrompt: string): Promise<string> {
  const openaiKey = Deno.env.get("OPENAI_API_KEY");

  if (!openaiKey) {
    console.log("OPENAI_API_KEY not found in environment");
    return generateFallbackResponse(userPrompt);
  }

  console.log("OpenAI API key found, attempting to call API...");

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.7,
        max_tokens: 1000,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("OpenAI API error - Status:", response.status);
      console.error("OpenAI API error - Response:", errorText);
      return generateFallbackResponse(userPrompt);
    }

    const data = await response.json();
    console.log("OpenAI API success - received response");
    const answer = data.choices[0]?.message?.content;

    if (!answer) {
      console.error("No answer in OpenAI response:", JSON.stringify(data));
      return generateFallbackResponse(userPrompt);
    }

    return answer;
  } catch (error) {
    console.error("Error calling OpenAI - Exception:", error);
    console.error("Error details:", error.message, error.stack);
    return generateFallbackResponse(userPrompt);
  }
}

function generateFallbackResponse(fullPrompt: string): string {
  console.log("Using fallback response (AI unavailable or error occurred)");

  const lines = fullPrompt.split('\n').filter(l => l.trim());
  const questionLine = lines.find(l => l.startsWith('QUESTION:'));
  const question = questionLine ? questionLine.replace('QUESTION:', '').trim().toLowerCase() : fullPrompt.toLowerCase();

  const hasResume = fullPrompt.includes('RESUME CONTENT:');
  const hasCoverLetter = fullPrompt.includes('COVER LETTER CONTENT:');
  const hasJobDetails = fullPrompt.includes('JOB DETAILS:');

  let response = "**Note:** Unable to connect to AI service at this time. Here's some general guidance:\n\n";

  if (question.includes("skill")) {
    if (hasResume) {
      response += "I can see your resume content. Based on typical best practices:\n\n";
      response += "• Organize skills into clear categories (Technical, Soft Skills, Tools)\n";
      response += "• List the most relevant skills for the target role first\n";
      response += "• Include both hard and soft skills\n";
      response += "• Remove outdated or irrelevant skills\n";
      if (hasJobDetails) {
        response += "• Match your skills to the job description keywords";
      }
    } else {
      response += "Upload your resume to get personalized skill recommendations.";
    }
  } else if (question.includes("strength")) {
    response += "To identify key strengths:\n\n";
    response += "• Review your most recent and impactful achievements\n";
    response += "• Look for recurring themes across your experience\n";
    response += "• Consider what makes you unique for this role\n";
    response += "• Focus on quantifiable accomplishments";
  } else if (question.includes("experience") || question.includes("work history")) {
    response += "For work experience:\n\n";
    response += "• Use the STAR method (Situation, Task, Action, Result)\n";
    response += "• Quantify achievements with metrics and numbers\n";
    response += "• Focus on results and impact, not just duties\n";
    response += "• Tailor descriptions to match the target role";
  } else if (question.includes("cover letter")) {
    if (hasCoverLetter) {
      response += "Cover letter best practices:\n\n";
      response += "• Keep it to 3-4 concise paragraphs\n";
      response += "• Address specific job requirements\n";
      response += "• Show enthusiasm for the role and company\n";
      response += "• Include a clear call to action in closing\n";
      response += "• Proofread carefully for errors";
    } else {
      response += "Write or upload a cover letter to get specific feedback.";
    }
  } else if (question.includes("improve") || question.includes("better") || question.includes("enhance")) {
    response += "General improvement suggestions:\n\n";
    response += "1. **Tailor to the role** - Customize for each application\n";
    response += "2. **Use action verbs** - Start bullets with strong verbs\n";
    response += "3. **Add metrics** - Quantify your achievements\n";
    response += "4. **Check formatting** - Ensure consistency throughout\n";
    response += "5. **Proofread** - Eliminate typos and errors\n";
    response += "6. **Keep it focused** - 1-2 pages for resume, 3-4 paragraphs for cover letter";
  } else if (question.includes("match") || question.includes("fit") || question.includes("suitable")) {
    if (hasJobDetails) {
      response += "To improve job match:\n\n";
      response += "• Mirror keywords from the job description\n";
      response += "• Highlight relevant experience prominently\n";
      response += "• Address required qualifications directly\n";
      response += "• Demonstrate understanding of the role and company";
    } else {
      response += "Add job details to get specific matching advice.";
    }
  } else if (question.includes("gap")) {
    response += "Addressing potential gaps:\n\n";
    response += "• Be honest and brief about employment gaps\n";
    response += "• Highlight any skills developed during gaps\n";
    response += "• Focus on your readiness to contribute now\n";
    response += "• Consider a functional resume format if gaps are significant";
  } else {
    response += "I've noted your question. Here are some general tips:\n\n";
    if (hasResume) {
      response += "• Your resume is loaded - ask specific questions about sections\n";
    }
    if (hasCoverLetter) {
      response += "• Your cover letter is available for review\n";
    }
    if (hasJobDetails) {
      response += "• Job details are available for comparison\n";
    }
    response += "\nTry asking about:\n";
    response += "• Specific skills to emphasize\n";
    response += "• Work experience improvements\n";
    response += "• Cover letter effectiveness\n";
    response += "• How well you match the job requirements";
  }

  response += "\n\n*Check the Edge Function logs for AI service connection details.*";

  return response;
}
