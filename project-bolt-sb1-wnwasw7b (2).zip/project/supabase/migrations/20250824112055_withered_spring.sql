/*
  # Fix RLS policies for organizations and profiles

  1. Organizations Table
    - Add policy to allow authenticated users to insert organizations
    - Add policy to allow users to read organizations they belong to

  2. Profiles Table  
    - Add policy to allow authenticated users to insert their own profile
    - Add policy to allow authenticated users to read their own profile
    - Add policy to allow authenticated users to update their own profile

  3. Security
    - All policies use auth.uid() to ensure users can only access their own data
    - Organization creation is allowed for authenticated users during signup
*/

-- Drop existing conflicting policies if they exist
DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "profiles insert" ON profiles;
DROP POLICY IF EXISTS "profiles select own" ON profiles;
DROP POLICY IF EXISTS "profiles update own" ON profiles;

-- Create comprehensive RLS policies for profiles table
CREATE POLICY "Allow authenticated users to insert own profile"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Allow authenticated users to read own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Allow authenticated users to update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Create RLS policies for organizations table
CREATE POLICY "Allow authenticated users to create organizations"
  ON organizations
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow users to read organizations they belong to"
  ON organizations
  FOR SELECT
  TO authenticated
  USING (
    id IN (
      SELECT organization_id 
      FROM profiles 
      WHERE id = auth.uid() AND organization_id IS NOT NULL
    )
  );

CREATE POLICY "Allow organization members to update organization"
  ON organizations
  FOR UPDATE
  TO authenticated
  USING (
    id IN (
      SELECT organization_id 
      FROM profiles 
      WHERE id = auth.uid() AND organization_id IS NOT NULL
    )
  )
  WITH CHECK (
    id IN (
      SELECT organization_id 
      FROM profiles 
      WHERE id = auth.uid() AND organization_id IS NOT NULL
    )
  );