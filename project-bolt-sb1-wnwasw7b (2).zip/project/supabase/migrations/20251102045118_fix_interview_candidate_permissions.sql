/*
  # Fix Interview Candidate Permissions

  1. Changes
    - Add UPDATE policy for candidates on their own interviews
    - Allows candidates to confirm, reschedule, and cancel interviews
    - Maintains security by restricting to only their own interviews

  2. Security
    - Candidates can only update interviews where they are the candidate
    - Cannot modify interviewer, candidate_id, or application/bid relationships
*/

-- Drop the existing read-only policy for candidates
DROP POLICY IF EXISTS "Candidates can view their own interviews" ON interview_schedules;

-- Create separate SELECT policy for candidates
CREATE POLICY "Candidates can view their own interviews"
  ON interview_schedules
  FOR SELECT
  TO authenticated
  USING (candidate_id = auth.uid());

-- Create UPDATE policy for candidates to manage their interviews
CREATE POLICY "Candidates can update their own interviews"
  ON interview_schedules
  FOR UPDATE
  TO authenticated
  USING (candidate_id = auth.uid())
  WITH CHECK (candidate_id = auth.uid());
