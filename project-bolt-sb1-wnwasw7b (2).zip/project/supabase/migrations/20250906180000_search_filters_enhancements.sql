-- Add industry and benefits to jobs; add size to organizations; create enums when helpful

-- 1) Organization size enum
do $$
begin
  if not exists (select 1 from pg_type typ join pg_namespace nsp on nsp.oid = typ.typnamespace where typ.typname = 'organization_size') then
    create type organization_size as enum ('startup', 'small', 'medium', 'large');
  end if;
end$$;

-- 2) Add columns to organizations
alter table if exists public.organizations
  add column if not exists size organization_size;

-- 3) Add columns to jobs: industry and benefits as text[]
alter table if exists public.jobs
  add column if not exists industry text[] default '{}'::text[],
  add column if not exists benefits text[] default '{}'::text[];

-- Optional: backfill example values (no-op if none)
-- update public.jobs set industry = array['Technology'] where industry = '{}'::text[];

-- 4) Update RLS policies (no changes needed if existing policies allow select on these tables/columns)

-- 5) Comment for documentation
comment on column public.jobs.industry is 'List of industries relevant to the job posting';
comment on column public.jobs.benefits is 'List of benefits offered for the job';
comment on column public.organizations.size is 'Company size category';

