/*
  # Add Interview Decision Fields to Applications

  1. Changes to applications table
    - Add `interview_decision` field (enum: pending, accepted, rejected, offer_extended)
    - Add `decision_notes` field (text) for employer notes on final decision
    - Add `decision_made_at` field (timestamp) to track when decision was made
    - Add `decision_made_by` field (uuid) to track who made the decision

  2. Security
    - Update RLS policies to allow employers to update decision fields
    
  3. Notes
    - This connects the interview feedback to the final hiring decision
    - Allows employers to document their decision-making process
    - Tracks accountability for hiring decisions
*/

-- Add decision enum type if it doesn't exist
DO $$ BEGIN
  CREATE TYPE interview_decision AS ENUM ('pending', 'accepted', 'rejected', 'offer_extended');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- Add decision tracking fields to applications table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'applications' AND column_name = 'interview_decision'
  ) THEN
    ALTER TABLE applications ADD COLUMN interview_decision interview_decision DEFAULT 'pending';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'applications' AND column_name = 'decision_notes'
  ) THEN
    ALTER TABLE applications ADD COLUMN decision_notes text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'applications' AND column_name = 'decision_made_at'
  ) THEN
    ALTER TABLE applications ADD COLUMN decision_made_at timestamptz;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'applications' AND column_name = 'decision_made_by'
  ) THEN
    ALTER TABLE applications ADD COLUMN decision_made_by uuid REFERENCES profiles(id);
  END IF;
END $$;

-- Create index for decision queries
CREATE INDEX IF NOT EXISTS applications_interview_decision_idx ON applications(interview_decision);
CREATE INDEX IF NOT EXISTS applications_decision_made_at_idx ON applications(decision_made_at);

-- Add comment to document the workflow
COMMENT ON COLUMN applications.interview_decision IS 'Post-interview hiring decision: pending (no decision yet), accepted (moving forward), rejected (not proceeding), offer_extended (formal offer sent)';
