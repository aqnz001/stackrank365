/*
  # Add Candidate Display Information to Consent Requests

  1. Changes
    - Add `candidate_name` and `candidate_email` columns to `consent_requests` table
    - These fields store the candidate's name and email at the time of consent request creation
    - This allows recruiters to see who they're requesting consent from without requiring additional RLS policies

  2. Notes
    - Fields are optional (nullable) for backward compatibility
    - Existing records will have null values, but new records should populate these fields
*/

-- Add candidate display fields to consent_requests
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'consent_requests' AND column_name = 'candidate_name'
  ) THEN
    ALTER TABLE consent_requests ADD COLUMN candidate_name text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'consent_requests' AND column_name = 'candidate_email'
  ) THEN
    ALTER TABLE consent_requests ADD COLUMN candidate_email text;
  END IF;
END $$;

-- Create index for searching by candidate name/email
CREATE INDEX IF NOT EXISTS consent_requests_candidate_name_idx ON consent_requests(candidate_name);
CREATE INDEX IF NOT EXISTS consent_requests_candidate_email_idx ON consent_requests(candidate_email);
