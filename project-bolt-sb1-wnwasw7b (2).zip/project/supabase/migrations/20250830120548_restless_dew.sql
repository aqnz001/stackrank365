/*
  # Fix subscription plans RLS policies

  1. Security Changes
    - Remove restrictive INSERT/UPDATE policies that prevent plan creation
    - Add policy allowing authenticated users to read subscription plans
    - Add policy allowing admins to manage subscription plans
    - Add policy allowing system to create default plans during initialization

  2. Notes
    - This fixes the RLS policy violation when creating default subscription plans
    - Maintains security by restricting management to admins only
    - Allows all authenticated users to read available plans
*/

-- Drop existing restrictive policies
DROP POLICY IF EXISTS "subscription_plans_insert_authenticated" ON subscription_plans;
DROP POLICY IF EXISTS "subscription_plans_update_authenticated" ON subscription_plans;

-- Allow all authenticated users to read subscription plans
CREATE POLICY "subscription_plans_read_all"
  ON subscription_plans
  FOR SELECT
  TO authenticated
  USING (is_active = true);

-- Allow admins to manage subscription plans
CREATE POLICY "subscription_plans_admin_manage"
  ON subscription_plans
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

-- Allow system to create default plans (for initialization)
CREATE POLICY "subscription_plans_system_init"
  ON subscription_plans
  FOR INSERT
  TO authenticated
  WITH CHECK (
    -- Allow if no plans exist yet (initial setup)
    NOT EXISTS (SELECT 1 FROM subscription_plans WHERE is_active = true)
  );