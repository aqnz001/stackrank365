/*
  # Fix RLS policies for profiles and organizations

  1. Security Updates
    - Add missing RLS policy for profiles table to allow users to read their own data
    - Add missing RLS policy for organizations table to allow authenticated users to create organizations
    - Ensure proper access control for the registration flow

  2. Changes
    - Enable authenticated users to read their own profile data
    - Enable authenticated users to create new organizations during registration
    - Maintain security by restricting access appropriately
*/

-- Fix profiles table RLS policy
-- Drop existing policy if it exists and recreate with correct permissions
DROP POLICY IF EXISTS "Allow authenticated users to read own profile" ON profiles;

CREATE POLICY "Allow authenticated users to read own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Fix organizations table RLS policy  
-- Drop existing policy if it exists and recreate with correct permissions
DROP POLICY IF EXISTS "Allow authenticated users to create organizations" ON organizations;

CREATE POLICY "Allow authenticated users to create organizations"
  ON organizations
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Ensure the existing organization read policy works correctly
DROP POLICY IF EXISTS "Enable read for organization members" ON organizations;

CREATE POLICY "Enable read for organization members"
  ON organizations
  FOR SELECT
  TO authenticated
  USING (id IN ( 
    SELECT profiles.organization_id
    FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.organization_id IS NOT NULL
  ));

-- Ensure the existing organization update policy works correctly  
DROP POLICY IF EXISTS "Enable update for organization members" ON organizations;

CREATE POLICY "Enable update for organization members"
  ON organizations
  FOR UPDATE
  TO authenticated
  USING (id IN ( 
    SELECT profiles.organization_id
    FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.organization_id IS NOT NULL
  ))
  WITH CHECK (id IN ( 
    SELECT profiles.organization_id
    FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.organization_id IS NOT NULL
  ));