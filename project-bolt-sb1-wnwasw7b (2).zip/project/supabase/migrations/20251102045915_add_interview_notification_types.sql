/*
  # Add Interview Notification Types

  1. Changes
    - Add interview-related notification types to the notification_type enum
    - Supports: interview_scheduled, interview_confirmed, interview_rescheduled, interview_cancelled

  2. Security
    - No RLS changes needed
*/

-- Add new notification types for interviews
ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'interview_scheduled';
ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'interview_confirmed';
ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'interview_rescheduled';
ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'interview_cancelled';
