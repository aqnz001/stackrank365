/*
  # Add Shortlist Notes and Status Change History

  1. Changes to applications table
    - Add `shortlist_notes` field (text) for notes when shortlisting candidates
    - Add `shortlisted_at` field (timestamp) to track when candidate was shortlisted
    - Add `shortlisted_by` field (uuid) to track who shortlisted the candidate
    - Add `notes` field (jsonb) for storing structured notes history

  2. New Tables
    - `application_status_history`
      - Tracks all status changes with notes and metadata
      - Provides audit trail for hiring decisions
      - Includes who made the change and when

  3. Security
    - Enable RLS on application_status_history table
    - Allow employers to view history for their job applications
    - Allow admins full access for audit purposes

  4. Notes
    - This enables employers to capture notes during shortlisting
    - Provides full audit trail of all status changes
    - Supports the shortlist → offer/reject workflow
*/

-- Add shortlist tracking fields to applications table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'applications' AND column_name = 'shortlist_notes'
  ) THEN
    ALTER TABLE applications ADD COLUMN shortlist_notes text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'applications' AND column_name = 'shortlisted_at'
  ) THEN
    ALTER TABLE applications ADD COLUMN shortlisted_at timestamptz;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'applications' AND column_name = 'shortlisted_by'
  ) THEN
    ALTER TABLE applications ADD COLUMN shortlisted_by uuid REFERENCES profiles(id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'applications' AND column_name = 'notes'
  ) THEN
    ALTER TABLE applications ADD COLUMN notes jsonb DEFAULT '[]'::jsonb;
  END IF;
END $$;

-- Create application_status_history table
CREATE TABLE IF NOT EXISTS application_status_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id uuid NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
  previous_status text,
  new_status text NOT NULL,
  changed_by uuid NOT NULL REFERENCES profiles(id),
  change_notes text,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS application_status_history_application_id_idx ON application_status_history(application_id);
CREATE INDEX IF NOT EXISTS application_status_history_created_at_idx ON application_status_history(created_at DESC);
CREATE INDEX IF NOT EXISTS applications_shortlisted_at_idx ON applications(shortlisted_at);

-- Enable RLS on application_status_history
ALTER TABLE application_status_history ENABLE ROW LEVEL SECURITY;

-- RLS Policies for application_status_history

-- Employers can view status history for applications to their jobs
CREATE POLICY "Employers can view status history for their jobs"
  ON application_status_history
  FOR SELECT
  TO authenticated
  USING (
    application_id IN (
      SELECT a.id
      FROM applications a
      JOIN jobs j ON j.id = a.job_id
      JOIN profiles p ON p.organization_id = j.organization_id
      WHERE p.id = auth.uid() AND p.role = 'employer'
    )
  );

-- Candidates can view status history for their own applications
CREATE POLICY "Candidates can view their own status history"
  ON application_status_history
  FOR SELECT
  TO authenticated
  USING (
    application_id IN (
      SELECT id FROM applications WHERE candidate_id = auth.uid()
    )
  );

-- Admins can view all status history
CREATE POLICY "Admins can view all status history"
  ON application_status_history
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- System can insert status history (via trigger)
CREATE POLICY "Allow status history insertion"
  ON application_status_history
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create trigger function to automatically log status changes
CREATE OR REPLACE FUNCTION log_application_status_change()
RETURNS TRIGGER AS $$
BEGIN
  -- Only log if status actually changed
  IF (TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status) THEN
    INSERT INTO application_status_history (
      application_id,
      previous_status,
      new_status,
      changed_by,
      change_notes,
      metadata
    ) VALUES (
      NEW.id,
      OLD.status,
      NEW.status,
      auth.uid(),
      CASE
        WHEN NEW.status = 'shortlisted' THEN NEW.shortlist_notes
        WHEN NEW.status = 'rejected' THEN NEW.decision_notes
        WHEN NEW.status = 'hired' THEN NEW.decision_notes
        ELSE NULL
      END,
      jsonb_build_object(
        'shortlisted_at', NEW.shortlisted_at,
        'decision_made_at', NEW.decision_made_at,
        'interview_decision', NEW.interview_decision
      )
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger
DROP TRIGGER IF EXISTS application_status_change_trigger ON applications;
CREATE TRIGGER application_status_change_trigger
  AFTER UPDATE ON applications
  FOR EACH ROW
  EXECUTE FUNCTION log_application_status_change();

-- Add comments
COMMENT ON COLUMN applications.shortlist_notes IS 'Notes captured when employer shortlists a candidate';
COMMENT ON COLUMN applications.shortlisted_at IS 'Timestamp when candidate was shortlisted';
COMMENT ON COLUMN applications.shortlisted_by IS 'Profile ID of user who shortlisted the candidate';
COMMENT ON COLUMN applications.notes IS 'JSON array of structured notes with timestamps';
COMMENT ON TABLE application_status_history IS 'Audit trail of all application status changes';
