/*
  # Create jobs table

  1. New Tables
    - `jobs`
      - `id` (uuid, primary key)
      - `organization_id` (uuid, foreign key to organizations)
      - `title` (text, job title)
      - `description` (text, job description)
      - `location` (text, job location)
      - `salary_min` (integer, minimum salary)
      - `salary_max` (integer, maximum salary)
      - `employment_type` (enum: full-time, part-time, contract, temporary)
      - `skills` (text array, required skills)
      - `visibility` (enum: closed, open)
      - `ad_tier` (enum: basic, standard, premium)
      - `bid_limit` (integer, maximum number of bids)
      - `blocked_recruiter_ids` (uuid array, blocked recruiters)
      - `status` (enum: open, closed, on_hold, filled)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `jobs` table
    - Add policies for employers to manage their jobs
    - Add policies for recruiters to view open jobs
    - Add policies for candidates to view jobs based on visibility
*/

-- Create employment type enum
CREATE TYPE employment_type AS ENUM ('full-time', 'part-time', 'contract', 'temporary');

-- Create job visibility enum
CREATE TYPE job_visibility AS ENUM ('closed', 'open');

-- Create ad tier enum
CREATE TYPE ad_tier AS ENUM ('basic', 'standard', 'premium');

-- Create job status enum
CREATE TYPE job_status AS ENUM ('open', 'closed', 'on_hold', 'filled');

-- Create jobs table
CREATE TABLE IF NOT EXISTS jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  location text NOT NULL,
  salary_min integer,
  salary_max integer,
  employment_type employment_type NOT NULL,
  skills text[] DEFAULT '{}',
  visibility job_visibility DEFAULT 'closed',
  ad_tier ad_tier DEFAULT 'basic',
  bid_limit integer,
  blocked_recruiter_ids uuid[] DEFAULT '{}',
  status job_status DEFAULT 'open',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;

-- Create policies
-- Employers can manage jobs for their organization
CREATE POLICY "Employers can manage organization jobs"
  ON jobs
  FOR ALL
  TO authenticated
  USING (
    organization_id IN (
      SELECT organization_id 
      FROM profiles 
      WHERE id = auth.uid() 
      AND role = 'employer'
      AND organization_id IS NOT NULL
    )
  )
  WITH CHECK (
    organization_id IN (
      SELECT organization_id 
      FROM profiles 
      WHERE id = auth.uid() 
      AND role = 'employer'
      AND organization_id IS NOT NULL
    )
  );

-- Recruiters can view open jobs (not blocked)
CREATE POLICY "Recruiters can view open jobs"
  ON jobs
  FOR SELECT
  TO authenticated
  USING (
    visibility = 'open' 
    AND EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() 
      AND role = 'recruiter'
    )
    AND NOT (auth.uid() = ANY(blocked_recruiter_ids))
  );

-- Candidates can view jobs based on visibility
CREATE POLICY "Candidates can view jobs"
  ON jobs
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() 
      AND role = 'candidate'
    )
  );

-- Admins can view all jobs
CREATE POLICY "Admins can view all jobs"
  ON jobs
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE id = auth.uid() 
      AND role = 'admin'
    )
  );

-- Create updated_at trigger
CREATE TRIGGER update_jobs_updated_at
  BEFORE UPDATE ON jobs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS jobs_organization_id_idx ON jobs(organization_id);
CREATE INDEX IF NOT EXISTS jobs_status_idx ON jobs(status);
CREATE INDEX IF NOT EXISTS jobs_visibility_idx ON jobs(visibility);
CREATE INDEX IF NOT EXISTS jobs_created_at_idx ON jobs(created_at DESC);