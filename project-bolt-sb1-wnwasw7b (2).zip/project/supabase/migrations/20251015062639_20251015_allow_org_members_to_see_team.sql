/*
  # Allow Organization Members to View Team Members
  
  ## Changes
  
  1. RLS Policies
    - Add policy for organization members to read other profiles in their organization
    - Allows employers/recruiters to see their team members
    - Required for team management interfaces
  
  ## Security
  
  - Only allows reading profiles within the same organization
  - Requires user to be authenticated and have an organization_id
  - Users can only see profiles in their own organization
*/

-- Policy for organization members to read other profiles in their organization
-- This allows team members to see each other and enables team management
CREATE POLICY "Organization members can view team profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (
    organization_id IS NOT NULL 
    AND organization_id IN (
      SELECT organization_id 
      FROM profiles 
      WHERE id = auth.uid() 
      AND organization_id IS NOT NULL
    )
  );
