/*
  # Auto-process Resume Uploads

  1. New Functions
    - `auto_create_resume_parsed_data()` - Automatically creates a pending resume_parsed_data entry when a resume is uploaded
    
  2. Triggers
    - `trigger_auto_create_resume_parsed_data` - Fires after INSERT on file_uploads table for resume files
    
  3. Changes
    - When a resume file is uploaded to file_uploads table, automatically create a corresponding resume_parsed_data entry with status 'pending'
    - This ensures AI features can detect pending resumes and initiate processing
    
  4. Design Notes
    - Only triggers for file_type = 'resume'
    - Creates initial entry with status 'pending' 
    - Prevents duplicate entries using ON CONFLICT
    - Resume parsing Edge Function can then be called from frontend to process pending resumes
*/

-- Create function to auto-create resume_parsed_data entry
CREATE OR REPLACE FUNCTION auto_create_resume_parsed_data()
RETURNS TRIGGER AS $$
BEGIN
  -- Only process resume files
  IF NEW.file_type = 'resume' THEN
    -- Insert a pending record in resume_parsed_data
    INSERT INTO resume_parsed_data (
      file_upload_id,
      user_id,
      parsing_status,
      created_at,
      updated_at
    )
    VALUES (
      NEW.id,
      NEW.user_id,
      'pending',
      now(),
      now()
    )
    ON CONFLICT (file_upload_id) DO NOTHING;
    
    -- Log the creation
    RAISE NOTICE 'Created pending resume_parsed_data entry for file_upload_id: %', NEW.id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger on file_uploads table
DROP TRIGGER IF EXISTS trigger_auto_create_resume_parsed_data ON file_uploads;

CREATE TRIGGER trigger_auto_create_resume_parsed_data
  AFTER INSERT ON file_uploads
  FOR EACH ROW
  EXECUTE FUNCTION auto_create_resume_parsed_data();
