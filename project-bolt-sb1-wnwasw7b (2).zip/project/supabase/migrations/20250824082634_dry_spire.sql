/*
  # Fix organization_id column constraint

  1. Changes
    - Make organization_id column nullable in profiles table
    - This allows candidates and other users to sign up without requiring an organization

  2. Security
    - Maintains existing RLS policies
    - No changes to security model
*/

-- Make organization_id nullable for profiles table
ALTER TABLE profiles ALTER COLUMN organization_id DROP NOT NULL;