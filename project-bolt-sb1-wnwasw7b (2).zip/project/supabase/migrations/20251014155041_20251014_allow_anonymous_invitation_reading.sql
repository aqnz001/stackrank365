/*
  # Allow Anonymous Users to Read Their Invitations
  
  ## Changes
  
  1. RLS Policies
    - Add policy for anonymous users to read pending invitations by ID
    - This allows the invitation page to load before authentication
    - Users still need to authenticate to accept/decline
  
  ## Security
  
  - Only allows reading by specific invitation ID (not browsing all invitations)
  - Only pending invitations are visible
  - Still requires authentication to update invitation status
*/

-- Policy for anonymous/unauthenticated users to read specific pending invitations
-- This allows the invitation page to display invitation details before sign-in
CREATE POLICY "Anyone can read pending invitations by ID"
  ON team_invitations
  FOR SELECT
  TO anon, authenticated
  USING (status = 'pending');
