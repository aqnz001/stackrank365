/*
  # Fix Infinite Recursion in Organization Team Policy
  
  ## Changes
  
  1. Drop the problematic policy that causes recursion
  2. Create a new policy using a lateral join to avoid recursion
  3. This allows organization members to see team profiles without circular queries
  
  ## Security
  
  - Only allows reading profiles within the same organization
  - Requires user to be authenticated
  - Uses lateral join to safely check organization membership
*/

-- Drop the problematic policy
DROP POLICY IF EXISTS "Organization members can view team profiles" ON profiles;

-- Create a new policy that avoids recursion by using a lateral join
-- This checks if the requesting user has the same organization_id as the target profile
CREATE POLICY "Organization members can view team profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (
    organization_id IS NOT NULL 
    AND EXISTS (
      SELECT 1 
      FROM auth.users 
      WHERE auth.users.id = auth.uid()
      AND auth.users.raw_user_meta_data->>'organization_id' = profiles.organization_id::text
    )
  );
