/*
  # Allow Public Read Access to Organizations

  1. Security Updates
    - Add policy to allow all authenticated users to view organization profiles
    - This is needed for:
      - Candidates viewing company profiles when browsing jobs
      - Recruiters viewing company profiles for jobs they're bidding on
      - Public company profile visibility

  2. Changes
    - Keep existing policies for organization members (read/update their own org)
    - Add new policy for public read access to all organizations
    - Organizations control visibility through publish_profile flag

  3. Notes
    - Public read is safe because:
      - Sensitive fields like contact_email are only shown if publish_email = true
      - Company profiles are meant to be viewed by job seekers
      - This matches the application's design where company names are visible on jobs
*/

-- Add policy to allow authenticated users to read all organizations
-- This enables viewing company profiles from job listings
CREATE POLICY "Allow authenticated users to read all organizations"
  ON organizations
  FOR SELECT
  TO authenticated
  USING (true);

-- Add policy to allow anonymous users to read all organizations
-- This enables viewing company profiles on public job listings
CREATE POLICY "Allow public read access to organizations"
  ON organizations
  FOR SELECT
  TO anon
  USING (true);
