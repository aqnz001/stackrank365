/*
  # Fix Organization Team Policy with Public Function
  
  ## Changes
  
  1. Drop the problematic policies
  2. Create a stable function in public schema that gets user's organization_id
  3. Use the function in the RLS policy to avoid recursion
  
  ## Security
  
  - Only allows reading profiles within the same organization
  - Function is STABLE and SECURITY DEFINER to prevent recursion
  - Cached per transaction for performance
*/

-- Drop the problematic policy
DROP POLICY IF EXISTS "Organization members can view team profiles" ON profiles;

-- Create a function that gets the current user's organization_id
-- STABLE means it won't change within a transaction, preventing recursion
CREATE OR REPLACE FUNCTION public.get_my_org_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT organization_id 
  FROM profiles 
  WHERE id = auth.uid()
  LIMIT 1;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.get_my_org_id() TO authenticated;

-- Create policy using the function
-- The STABLE function result is cached, so it won't cause recursion
CREATE POLICY "Organization members can view team profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (
    organization_id IS NOT NULL 
    AND organization_id = public.get_my_org_id()
  );
