/*
  # Add completed_at field to interview_schedules

  1. Changes
    - Add `completed_at` timestamp field to track when interview was completed
    - This field is set when status changes to 'completed'
    
  2. Notes
    - Field is nullable since not all interviews are completed
    - Used for tracking completion time and decision workflow
*/

-- Add completed_at field if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'interview_schedules' AND column_name = 'completed_at'
  ) THEN
    ALTER TABLE interview_schedules ADD COLUMN completed_at timestamptz;
  END IF;
END $$;

-- Add index for completed_at queries
CREATE INDEX IF NOT EXISTS interview_schedules_completed_at_idx ON interview_schedules(completed_at);
