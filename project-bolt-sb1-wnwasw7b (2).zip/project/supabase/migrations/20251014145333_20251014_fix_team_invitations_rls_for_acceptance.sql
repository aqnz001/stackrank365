/*
  # Fix Team Invitations RLS for Invitation Acceptance
  
  ## Changes
  
  1. RLS Policies
    - Add policy for invitees to read their own pending invitations by email
    - Add policy for invitees to update their own invitations (accept/decline)
    - Keep existing policy for organization members to manage invitations
  
  ## Security
  
  - Invitees can only see invitations addressed to their email
  - Invitees can only read pending invitations
  - Invitees can only update status field of their own invitations
  - Organization members can manage all invitations for their organization
*/

-- Drop the existing broad policy
DROP POLICY IF EXISTS "team_invite_member" ON team_invitations;

-- Policy for organization members to manage their team invitations
CREATE POLICY "Organization members can manage team invitations"
  ON team_invitations
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM profiles p
      WHERE p.id = auth.uid()
        AND p.organization_id = team_invitations.org_id
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1
      FROM profiles p
      WHERE p.id = auth.uid()
        AND p.organization_id = team_invitations.org_id
    )
  );

-- Policy for invitees to read their own pending invitations
CREATE POLICY "Invitees can read their own pending invitations"
  ON team_invitations
  FOR SELECT
  TO authenticated
  USING (
    auth.jwt()->>'email' = invitee_email
    AND status = 'pending'
  );

-- Policy for invitees to update their invitation status (accept/decline)
CREATE POLICY "Invitees can update their invitation status"
  ON team_invitations
  FOR UPDATE
  TO authenticated
  USING (
    auth.jwt()->>'email' = invitee_email
    AND status = 'pending'
  )
  WITH CHECK (
    auth.jwt()->>'email' = invitee_email
    AND status IN ('accepted', 'declined')
  );

-- Policy for admins to manage all invitations
CREATE POLICY "Admins can manage all team invitations"
  ON team_invitations
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM profiles p
      WHERE p.id = auth.uid()
        AND p.role = 'admin'
    )
  );
