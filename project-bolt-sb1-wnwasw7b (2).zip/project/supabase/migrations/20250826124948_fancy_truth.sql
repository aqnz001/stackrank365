/*
  # Fix subscription plans RLS policies

  1. Security Updates
    - Drop existing restrictive policies
    - Add new policies that allow authenticated users to read and create plans
    - Maintain admin-only restrictions for sensitive operations

  2. Changes
    - Allow all authenticated users to read active subscription plans
    - Allow authenticated users to insert/upsert subscription plans (needed for createDefaultPlans)
    - Restrict admin operations to admin role only
*/

-- Drop existing policies
DROP POLICY IF EXISTS "subscription_plans_admin_write" ON subscription_plans;
DROP POLICY IF EXISTS "subscription_plans_insert_authenticated" ON subscription_plans;
DROP POLICY IF EXISTS "subscription_plans_select_all" ON subscription_plans;
DROP POLICY IF EXISTS "subscription_plans_upsert_authenticated" ON subscription_plans;

-- Create new policies
CREATE POLICY "subscription_plans_select_authenticated"
  ON subscription_plans
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "subscription_plans_insert_authenticated"
  ON subscription_plans
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "subscription_plans_update_authenticated"
  ON subscription_plans
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "subscription_plans_admin_all"
  ON subscription_plans
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );