/*
  # Create interview schedules table

  1. New Tables
    - `interview_schedules`
      - `id` (uuid, primary key)
      - `application_id` (uuid, foreign key to applications)
      - `recruiter_bid_id` (uuid, foreign key to recruiter_bids)
      - `interviewer_id` (uuid, foreign key to profiles)
      - `candidate_id` (uuid, foreign key to profiles)
      - `interview_type` (enum: phone, video, in_person, technical, panel)
      - `status` (enum: scheduled, confirmed, rescheduled, completed, cancelled, no_show)
      - `scheduled_at` (timestamp)
      - `duration_minutes` (integer)
      - `location` (text, optional)
      - `meeting_link` (text, optional)
      - `meeting_id` (text, optional)
      - `notes` (text, optional)
      - `feedback` (jsonb)
      - `reminder_sent` (boolean)
      - `calendar_event_id` (text, optional)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `interview_schedules` table
    - Add policies for candidates to view their own interviews
    - Add policies for employers to manage interviews for their organization jobs
    - Add policies for interviewers to manage interviews they conduct

  3. Constraints
    - Check that either application_id OR recruiter_bid_id is provided (not both)
    - Check that scheduled_at is in the future
    - Check that duration_minutes is positive
*/

-- Create interview_schedules table
CREATE TABLE IF NOT EXISTS public.interview_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id uuid REFERENCES public.applications(id) ON DELETE CASCADE,
  recruiter_bid_id uuid REFERENCES public.recruiter_bids(id) ON DELETE CASCADE,
  interviewer_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  candidate_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  interview_type public.interview_type NOT NULL DEFAULT 'video',
  status public.interview_status NOT NULL DEFAULT 'scheduled',
  scheduled_at timestamp with time zone NOT NULL,
  duration_minutes integer NOT NULL DEFAULT 60 CHECK (duration_minutes > 0),
  location text,
  meeting_link text,
  meeting_id text,
  notes text,
  feedback jsonb DEFAULT '{}',
  reminder_sent boolean DEFAULT false,
  calendar_event_id text,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  
  -- Constraints
  CONSTRAINT interview_schedules_source_check 
    CHECK ((application_id IS NOT NULL AND recruiter_bid_id IS NULL) OR 
           (application_id IS NULL AND recruiter_bid_id IS NOT NULL)),
  CONSTRAINT interview_schedules_future_check 
    CHECK (scheduled_at > created_at),
  CONSTRAINT interview_schedules_duration_check 
    CHECK (duration_minutes > 0)
);

-- Create indexes
CREATE INDEX IF NOT EXISTS interview_schedules_application_id_idx ON public.interview_schedules USING btree (application_id);
CREATE INDEX IF NOT EXISTS interview_schedules_recruiter_bid_id_idx ON public.interview_schedules USING btree (recruiter_bid_id);
CREATE INDEX IF NOT EXISTS interview_schedules_interviewer_id_idx ON public.interview_schedules USING btree (interviewer_id);
CREATE INDEX IF NOT EXISTS interview_schedules_candidate_id_idx ON public.interview_schedules USING btree (candidate_id);
CREATE INDEX IF NOT EXISTS interview_schedules_scheduled_at_idx ON public.interview_schedules USING btree (scheduled_at);
CREATE INDEX IF NOT EXISTS interview_schedules_status_idx ON public.interview_schedules USING btree (status);

-- Enable RLS
ALTER TABLE public.interview_schedules ENABLE ROW LEVEL SECURITY;

-- RLS Policies
DROP POLICY IF EXISTS "Candidates can view their own interviews" ON public.interview_schedules;
CREATE POLICY "Candidates can view their own interviews" ON public.interview_schedules
FOR SELECT USING (candidate_id = auth.uid());

DROP POLICY IF EXISTS "Interviewers can manage interviews they conduct" ON public.interview_schedules;
CREATE POLICY "Interviewers can manage interviews they conduct" ON public.interview_schedules
FOR ALL USING (interviewer_id = auth.uid()) WITH CHECK (interviewer_id = auth.uid());

DROP POLICY IF EXISTS "Employers can manage interviews for their organization jobs" ON public.interview_schedules;
CREATE POLICY "Employers can manage interviews for their organization jobs" ON public.interview_schedules
FOR ALL USING (
  (EXISTS (
    SELECT 1 FROM public.applications a
    JOIN public.jobs j ON j.id = a.job_id
    JOIN public.profiles p ON p.organization_id = j.organization_id
    WHERE a.id = interview_schedules.application_id 
    AND p.id = auth.uid() 
    AND p.role = 'employer'
  )) OR
  (EXISTS (
    SELECT 1 FROM public.recruiter_bids rb
    JOIN public.jobs j ON j.id = rb.job_id
    JOIN public.profiles p ON p.organization_id = j.organization_id
    WHERE rb.id = interview_schedules.recruiter_bid_id 
    AND p.id = auth.uid() 
    AND p.role = 'employer'
  ))
);

-- Trigger for updated_at
DROP TRIGGER IF EXISTS update_interview_schedules_updated_at ON public.interview_schedules;
CREATE TRIGGER update_interview_schedules_updated_at 
  BEFORE UPDATE ON public.interview_schedules 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();