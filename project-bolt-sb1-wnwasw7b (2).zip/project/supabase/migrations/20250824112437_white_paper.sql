/*
  # Fix organization RLS policies

  1. Security Changes
    - Drop existing restrictive INSERT policy for organizations
    - Add new policy allowing authenticated users to insert organizations
    - Keep existing policies for SELECT and UPDATE operations
  
  2. Changes
    - Allow any authenticated user to create organizations during signup
    - Maintain security for reading and updating organizations
*/

-- Drop the existing restrictive INSERT policy
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON organizations;

-- Create a new policy that allows authenticated users to insert organizations
CREATE POLICY "Allow authenticated users to create organizations"
  ON organizations
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Ensure the existing SELECT and UPDATE policies remain
-- (These should already exist from previous migrations)