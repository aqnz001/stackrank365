/*
  # Real-time Notifications & Messaging System

  1. New Tables
    - `notifications`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to profiles)
      - `type` (enum: application_received, bid_submitted, bid_accepted, etc.)
      - `title` (text)
      - `message` (text)
      - `data` (jsonb for additional context)
      - `read` (boolean, default false)
      - `created_at` (timestamp)
    
    - `messages`
      - `id` (uuid, primary key)
      - `conversation_id` (uuid)
      - `sender_id` (uuid, foreign key to profiles)
      - `recipient_id` (uuid, foreign key to profiles)
      - `content` (text)
      - `message_type` (enum: text, file, system)
      - `read` (boolean, default false)
      - `created_at` (timestamp)
    
    - `conversations`
      - `id` (uuid, primary key)
      - `participants` (uuid array)
      - `job_id` (uuid, optional foreign key to jobs)
      - `last_message_at` (timestamp)
      - `created_at` (timestamp)
    
    - `activity_feed`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to profiles)
      - `actor_id` (uuid, foreign key to profiles)
      - `action_type` (enum)
      - `entity_type` (enum: job, application, bid)
      - `entity_id` (uuid)
      - `data` (jsonb)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for user access control
    - Real-time subscriptions for notifications

  3. Functions
    - Notification creation triggers
    - Activity feed population
    - Real-time subscription helpers
*/

-- Create enums
CREATE TYPE notification_type AS ENUM (
  'application_received',
  'application_status_changed',
  'bid_submitted',
  'bid_accepted',
  'bid_rejected',
  'consent_requested',
  'consent_approved',
  'job_posted',
  'payment_received',
  'system_announcement'
);

CREATE TYPE message_type AS ENUM (
  'text',
  'file',
  'system'
);

CREATE TYPE activity_action AS ENUM (
  'created',
  'updated',
  'deleted',
  'applied',
  'submitted_bid',
  'accepted_bid',
  'rejected_bid',
  'approved_consent',
  'declined_consent'
);

CREATE TYPE activity_entity AS ENUM (
  'job',
  'application',
  'bid',
  'consent',
  'payment'
);

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type notification_type NOT NULL,
  title text NOT NULL,
  message text NOT NULL,
  data jsonb DEFAULT '{}',
  read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL,
  sender_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  recipient_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  message_type message_type DEFAULT 'text',
  read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Conversations table
CREATE TABLE IF NOT EXISTS conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  participants uuid[] NOT NULL,
  job_id uuid REFERENCES jobs(id) ON DELETE SET NULL,
  last_message_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Activity feed table
CREATE TABLE IF NOT EXISTS activity_feed (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  actor_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  action_type activity_action NOT NULL,
  entity_type activity_entity NOT NULL,
  entity_id uuid NOT NULL,
  data jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS notifications_user_id_idx ON notifications(user_id);
CREATE INDEX IF NOT EXISTS notifications_created_at_idx ON notifications(created_at DESC);
CREATE INDEX IF NOT EXISTS notifications_read_idx ON notifications(read);

CREATE INDEX IF NOT EXISTS messages_conversation_id_idx ON messages(conversation_id);
CREATE INDEX IF NOT EXISTS messages_sender_id_idx ON messages(sender_id);
CREATE INDEX IF NOT EXISTS messages_recipient_id_idx ON messages(recipient_id);
CREATE INDEX IF NOT EXISTS messages_created_at_idx ON messages(created_at DESC);

CREATE INDEX IF NOT EXISTS conversations_participants_idx ON conversations USING GIN(participants);
CREATE INDEX IF NOT EXISTS conversations_job_id_idx ON conversations(job_id);
CREATE INDEX IF NOT EXISTS conversations_last_message_at_idx ON conversations(last_message_at DESC);

CREATE INDEX IF NOT EXISTS activity_feed_user_id_idx ON activity_feed(user_id);
CREATE INDEX IF NOT EXISTS activity_feed_created_at_idx ON activity_feed(created_at DESC);
CREATE INDEX IF NOT EXISTS activity_feed_entity_idx ON activity_feed(entity_type, entity_id);

-- Enable RLS
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_feed ENABLE ROW LEVEL SECURITY;

-- RLS Policies for notifications
CREATE POLICY "Users can view their own notifications"
  ON notifications
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can update their own notifications"
  ON notifications
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- RLS Policies for messages
CREATE POLICY "Users can view messages they sent or received"
  ON messages
  FOR SELECT
  TO authenticated
  USING (sender_id = auth.uid() OR recipient_id = auth.uid());

CREATE POLICY "Users can send messages"
  ON messages
  FOR INSERT
  TO authenticated
  WITH CHECK (sender_id = auth.uid());

CREATE POLICY "Users can update messages they received"
  ON messages
  FOR UPDATE
  TO authenticated
  USING (recipient_id = auth.uid())
  WITH CHECK (recipient_id = auth.uid());

-- RLS Policies for conversations
CREATE POLICY "Users can view conversations they participate in"
  ON conversations
  FOR SELECT
  TO authenticated
  USING (auth.uid() = ANY(participants));

CREATE POLICY "Users can create conversations"
  ON conversations
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = ANY(participants));

CREATE POLICY "Participants can update conversations"
  ON conversations
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = ANY(participants))
  WITH CHECK (auth.uid() = ANY(participants));

-- RLS Policies for activity feed
CREATE POLICY "Users can view their own activity feed"
  ON activity_feed
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Function to create notification
CREATE OR REPLACE FUNCTION create_notification(
  p_user_id uuid,
  p_type notification_type,
  p_title text,
  p_message text,
  p_data jsonb DEFAULT '{}'
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  notification_id uuid;
BEGIN
  INSERT INTO notifications (user_id, type, title, message, data)
  VALUES (p_user_id, p_type, p_title, p_message, p_data)
  RETURNING id INTO notification_id;
  
  RETURN notification_id;
END;
$$;

-- Function to create activity feed entry
CREATE OR REPLACE FUNCTION create_activity(
  p_user_id uuid,
  p_actor_id uuid,
  p_action_type activity_action,
  p_entity_type activity_entity,
  p_entity_id uuid,
  p_data jsonb DEFAULT '{}'
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  activity_id uuid;
BEGIN
  INSERT INTO activity_feed (user_id, actor_id, action_type, entity_type, entity_id, data)
  VALUES (p_user_id, p_actor_id, p_action_type, p_entity_type, p_entity_id, p_data)
  RETURNING id INTO activity_id;
  
  RETURN activity_id;
END;
$$;

-- Trigger function for application notifications
CREATE OR REPLACE FUNCTION notify_application_received()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  job_record jobs%ROWTYPE;
  employer_id uuid;
BEGIN
  -- Get job details
  SELECT * INTO job_record FROM jobs WHERE id = NEW.job_id;
  
  -- Get employer user ID from organization
  SELECT p.id INTO employer_id 
  FROM profiles p 
  WHERE p.organization_id = job_record.organization_id 
    AND p.role = 'employer' 
  LIMIT 1;
  
  IF employer_id IS NOT NULL THEN
    -- Create notification for employer
    PERFORM create_notification(
      employer_id,
      'application_received',
      'New Application Received',
      format('New application from %s for %s', NEW.candidate_name, job_record.title),
      jsonb_build_object(
        'job_id', NEW.job_id,
        'application_id', NEW.id,
        'candidate_name', NEW.candidate_name
      )
    );
    
    -- Create activity feed entry
    PERFORM create_activity(
      employer_id,
      NEW.candidate_id,
      'applied',
      'application',
      NEW.id,
      jsonb_build_object('job_title', job_record.title)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger function for bid notifications
CREATE OR REPLACE FUNCTION notify_bid_submitted()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  job_record jobs%ROWTYPE;
  employer_id uuid;
  recruiter_name text;
BEGIN
  -- Get job details
  SELECT * INTO job_record FROM jobs WHERE id = NEW.job_id;
  
  -- Get recruiter name
  SELECT name INTO recruiter_name FROM profiles WHERE id = NEW.recruiter_id;
  
  -- Get employer user ID from organization
  SELECT p.id INTO employer_id 
  FROM profiles p 
  WHERE p.organization_id = job_record.organization_id 
    AND p.role = 'employer' 
  LIMIT 1;
  
  IF employer_id IS NOT NULL THEN
    -- Create notification for employer
    PERFORM create_notification(
      employer_id,
      'bid_submitted',
      'New Recruiter Bid',
      format('New bid from %s for %s', recruiter_name, job_record.title),
      jsonb_build_object(
        'job_id', NEW.job_id,
        'bid_id', NEW.id,
        'recruiter_name', recruiter_name
      )
    );
    
    -- Create activity feed entry
    PERFORM create_activity(
      employer_id,
      NEW.recruiter_id,
      'submitted_bid',
      'bid',
      NEW.id,
      jsonb_build_object('job_title', job_record.title)
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create triggers
DROP TRIGGER IF EXISTS trigger_notify_application_received ON applications;
CREATE TRIGGER trigger_notify_application_received
  AFTER INSERT ON applications
  FOR EACH ROW
  EXECUTE FUNCTION notify_application_received();

DROP TRIGGER IF EXISTS trigger_notify_bid_submitted ON recruiter_bids;
CREATE TRIGGER trigger_notify_bid_submitted
  AFTER INSERT ON recruiter_bids
  FOR EACH ROW
  EXECUTE FUNCTION notify_bid_submitted();

-- Enable real-time for notifications
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE messages;
ALTER PUBLICATION supabase_realtime ADD TABLE conversations;