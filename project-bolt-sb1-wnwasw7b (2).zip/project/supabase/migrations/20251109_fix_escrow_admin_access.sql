/*
  # Fix Escrow Admin Access

  1. Changes
    - Ensure escrow_policies and escrow_transactions have proper admin access
    - Add missing ALL policy for admins on escrow_transactions
    - Verify RLS is enabled

  2. Security
    - Admins can fully manage escrow_policies
    - Admins can fully manage escrow_transactions
    - Existing recruiter and employer policies remain intact
*/

-- Ensure RLS is enabled
ALTER TABLE escrow_policies ENABLE ROW LEVEL SECURITY;
ALTER TABLE escrow_transactions ENABLE ROW LEVEL SECURITY;

-- Drop and recreate admin policies to ensure they work correctly
DROP POLICY IF EXISTS "escrow_policies_admin_modify" ON escrow_policies;
CREATE POLICY "escrow_policies_admin_modify"
  ON escrow_policies
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

-- Ensure public read policy exists for active policies
DROP POLICY IF EXISTS "escrow_policies_public_read" ON escrow_policies;
CREATE POLICY "escrow_policies_public_read"
  ON escrow_policies
  FOR SELECT
  TO authenticated
  USING (
    is_active = true
    OR EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

-- Admin ALL access for escrow_transactions
DROP POLICY IF EXISTS "escrow_txn_admin_all" ON escrow_transactions;
CREATE POLICY "escrow_txn_admin_all"
  ON escrow_transactions
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );
