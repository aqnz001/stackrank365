/*
  # Create Draft Applications Table

  1. New Tables
    - `draft_applications`
      - `id` (uuid, primary key)
      - `candidate_id` (uuid, foreign key to profiles)
      - `job_id` (uuid, foreign key to jobs)
      - `draft_data` (jsonb) - Stores all form data including:
        - step (current wizard step)
        - useSaved (boolean - using saved resume or upload)
        - selectedResumeId (uuid)
        - uploadedResumeData (resume metadata if uploaded)
        - formData (cover letter, phone, location, etc.)
      - `last_saved_step` (integer) - Which step user was on
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `draft_applications` table
    - Candidates can only read/write/delete their own drafts
    - Drafts are automatically cleaned up after 30 days

  3. Performance
    - Add indexes for candidate_id and job_id lookups
    - Add index on updated_at for cleanup queries

  4. Design Notes
    - Only one draft per candidate per job (upsert pattern)
    - Draft is deleted when application is submitted
    - Auto-save functionality can be added in frontend
    - Stores complete wizard state for seamless resumption
*/

-- Create draft_applications table
CREATE TABLE IF NOT EXISTS draft_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  draft_data jsonb NOT NULL DEFAULT '{}',
  last_saved_step integer NOT NULL DEFAULT 1,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),

  CONSTRAINT draft_applications_unique_candidate_job UNIQUE(candidate_id, job_id),
  CONSTRAINT draft_applications_step_check CHECK (last_saved_step >= 1 AND last_saved_step <= 5)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS draft_applications_candidate_id_idx ON draft_applications(candidate_id);
CREATE INDEX IF NOT EXISTS draft_applications_job_id_idx ON draft_applications(job_id);
CREATE INDEX IF NOT EXISTS draft_applications_updated_at_idx ON draft_applications(updated_at DESC);

-- Enable Row Level Security
ALTER TABLE draft_applications ENABLE ROW LEVEL SECURITY;

-- RLS Policy: Candidates can view their own drafts
CREATE POLICY "Candidates can view their own draft applications"
  ON draft_applications
  FOR SELECT
  TO authenticated
  USING (candidate_id = auth.uid());

-- RLS Policy: Candidates can insert their own drafts
CREATE POLICY "Candidates can create their own draft applications"
  ON draft_applications
  FOR INSERT
  TO authenticated
  WITH CHECK (candidate_id = auth.uid());

-- RLS Policy: Candidates can update their own drafts
CREATE POLICY "Candidates can update their own draft applications"
  ON draft_applications
  FOR UPDATE
  TO authenticated
  USING (candidate_id = auth.uid())
  WITH CHECK (candidate_id = auth.uid());

-- RLS Policy: Candidates can delete their own drafts
CREATE POLICY "Candidates can delete their own draft applications"
  ON draft_applications
  FOR DELETE
  TO authenticated
  USING (candidate_id = auth.uid());

-- Create trigger for updated_at
CREATE OR REPLACE FUNCTION update_draft_applications_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger
    WHERE tgname = 'update_draft_applications_updated_at'
  ) THEN
    CREATE TRIGGER update_draft_applications_updated_at
      BEFORE UPDATE ON draft_applications
      FOR EACH ROW
      EXECUTE FUNCTION update_draft_applications_updated_at();
  END IF;
END $$;

-- Create function to cleanup old drafts (can be called by a scheduled job)
CREATE OR REPLACE FUNCTION cleanup_old_draft_applications()
RETURNS integer AS $$
DECLARE
  deleted_count integer;
BEGIN
  DELETE FROM draft_applications
  WHERE updated_at < now() - interval '30 days';

  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
