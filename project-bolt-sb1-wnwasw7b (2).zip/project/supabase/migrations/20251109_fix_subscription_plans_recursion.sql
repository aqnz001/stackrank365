/*
  # Fix Infinite Recursion in subscription_plans RLS Policies

  1. Changes
    - Drop all existing subscription_plans policies
    - Create simplified, non-recursive policies
    - Separate SELECT, INSERT, UPDATE, DELETE policies
    - Remove self-referencing queries that cause recursion

  2. Security
    - Allow all authenticated users to read active plans
    - Allow admins to manage all plans
    - Allow authenticated users to insert plans (for initial setup)

  3. Important Notes
    - Avoid using FOR ALL as it can cause conflicts
    - Avoid self-referencing queries (querying subscription_plans within its own policy)
    - Keep policies simple and non-recursive
*/

-- Drop ALL existing policies on subscription_plans
DROP POLICY IF EXISTS "subscription_plans_select_all" ON subscription_plans;
DROP POLICY IF EXISTS "subscription_plans_select_authenticated" ON subscription_plans;
DROP POLICY IF EXISTS "subscription_plans_read_all" ON subscription_plans;
DROP POLICY IF EXISTS "subscription_plans_insert_authenticated" ON subscription_plans;
DROP POLICY IF EXISTS "subscription_plans_update_authenticated" ON subscription_plans;
DROP POLICY IF EXISTS "subscription_plans_upsert_authenticated" ON subscription_plans;
DROP POLICY IF EXISTS "subscription_plans_admin_write" ON subscription_plans;
DROP POLICY IF EXISTS "subscription_plans_admin_all" ON subscription_plans;
DROP POLICY IF EXISTS "subscription_plans_admin_manage" ON subscription_plans;
DROP POLICY IF EXISTS "subscription_plans_system_init" ON subscription_plans;

-- Allow all authenticated users to SELECT active subscription plans
CREATE POLICY "Plans: Authenticated users can view active plans"
  ON subscription_plans
  FOR SELECT
  TO authenticated
  USING (is_active = true);

-- Allow admins to SELECT all plans (including inactive)
CREATE POLICY "Plans: Admins can view all plans"
  ON subscription_plans
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Allow authenticated users to INSERT plans (for initial setup)
CREATE POLICY "Plans: Authenticated users can create plans"
  ON subscription_plans
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Allow admins to UPDATE plans
CREATE POLICY "Plans: Admins can update plans"
  ON subscription_plans
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Allow admins to DELETE plans
CREATE POLICY "Plans: Admins can delete plans"
  ON subscription_plans
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );
