/*
  # Fix Company Logos Storage Policy

  1. Issue
    - The current policy for company-logos bucket incorrectly references `p.name` 
      (the user's profile name) instead of the storage object's path
    - This causes RLS violations when organization members try to upload logos

  2. Changes
    - Drop the existing faulty policy
    - Create a new policy that correctly checks if the user is a member of the 
      organization that matches the folder in the file path
    - The file path format is: {organization_id}/{filename}
    - Policy validates: user.organization_id matches the first part of the storage path

  3. Security
    - Users can only upload to their own organization's folder
    - Users can only manage (view/update/delete) their organization's logos
    - Public read access remains for displaying logos site-wide
*/

-- Drop the existing faulty policy
DROP POLICY IF EXISTS "Organization members can manage company logos" ON storage.objects;

-- Create new policy for INSERT (upload) operations
CREATE POLICY "Organization members can upload company logos"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'company-logos' 
    AND auth.uid() IS NOT NULL
    AND EXISTS (
      SELECT 1
      FROM profiles p
      WHERE p.id = auth.uid()
        AND p.organization_id::text = (storage.foldername(name))[1]
        AND p.role IN ('employer', 'recruiter')
    )
  );

-- Create policy for UPDATE operations
CREATE POLICY "Organization members can update company logos"
  ON storage.objects
  FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'company-logos'
    AND EXISTS (
      SELECT 1
      FROM profiles p
      WHERE p.id = auth.uid()
        AND p.organization_id::text = (storage.foldername(name))[1]
        AND p.role IN ('employer', 'recruiter')
    )
  );

-- Create policy for DELETE operations
CREATE POLICY "Organization members can delete company logos"
  ON storage.objects
  FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'company-logos'
    AND EXISTS (
      SELECT 1
      FROM profiles p
      WHERE p.id = auth.uid()
        AND p.organization_id::text = (storage.foldername(name))[1]
        AND p.role IN ('employer', 'recruiter')
    )
  );