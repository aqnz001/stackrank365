/*
  # Fix Resume Parsed Data RLS Policies

  1. Changes
    - Drop and recreate the employer access policy with simplified logic
    - Remove unnecessary join with file_uploads table
    - Make the policy more permissive for employers viewing their applicants' data

  2. Security
    - Employers can still only access parsed resume data for candidates who applied to their jobs
    - Policy is simplified to avoid complex join issues
*/

-- Drop the existing employer policy
DROP POLICY IF EXISTS "Employers can view parsed data for job applications" ON resume_parsed_data;

-- Create a simpler, more reliable policy for employers
CREATE POLICY "Employers can view applicant resume data"
  ON resume_parsed_data
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM applications a
      JOIN jobs j ON j.id = a.job_id
      JOIN profiles p ON p.organization_id = j.organization_id
      WHERE p.id = auth.uid()
      AND p.role = 'employer'
      AND a.candidate_id = resume_parsed_data.user_id
    )
  );
