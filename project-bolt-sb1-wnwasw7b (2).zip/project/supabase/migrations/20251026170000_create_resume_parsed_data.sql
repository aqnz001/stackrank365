/*
  # Create Resume Parsed Data Table

  1. New Tables
    - `resume_parsed_data`
      - `id` (uuid, primary key)
      - `file_upload_id` (uuid, foreign key to file_uploads)
      - `user_id` (uuid, foreign key to profiles)
      - `parsed_text` (text) - Raw extracted text content from resume
      - `parsed_skills` (text[]) - Array of extracted skills
      - `parsed_experiences` (jsonb) - Structured work experience data
      - `parsed_education` (jsonb) - Structured education data
      - `parsed_metadata` (jsonb) - Additional metadata (contact info, certifications, etc.)
      - `parsing_status` (enum: pending, completed, failed, stale)
      - `parsing_error` (text) - Error message if parsing failed
      - `parsed_at` (timestamptz) - When the parsing was completed
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `resume_parsed_data` table
    - Candidates can read their own parsed resume data
    - Employers can read parsed data for applications to their jobs
    - System can insert/update parsed data during upload process

  3. Performance
    - Add indexes for user_id and file_upload_id lookups
    - Add index for parsing_status for monitoring
    - Add GIN index on parsed_skills for array searches

  4. Design Notes
    - Parsing happens once at upload time and stored for reuse
    - Eliminates redundant parsing across multiple features
    - Parsed data linked to file_uploads via foreign key
    - Supports re-parsing if resume file is updated
    - Graceful error handling with status tracking
*/

-- Create parsing status enum
DO $$ BEGIN
  CREATE TYPE resume_parsing_status AS ENUM ('pending', 'completed', 'failed', 'stale');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- Create resume_parsed_data table
CREATE TABLE IF NOT EXISTS resume_parsed_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_upload_id uuid NOT NULL REFERENCES file_uploads(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  parsed_text text,
  parsed_skills text[] DEFAULT '{}',
  parsed_experiences jsonb DEFAULT '[]',
  parsed_education jsonb DEFAULT '[]',
  parsed_metadata jsonb DEFAULT '{}',
  parsing_status resume_parsing_status NOT NULL DEFAULT 'pending',
  parsing_error text,
  parsed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),

  CONSTRAINT resume_parsed_data_unique_file UNIQUE(file_upload_id),
  CONSTRAINT resume_parsed_data_completed_check CHECK (
    (parsing_status = 'completed' AND parsed_at IS NOT NULL) OR
    (parsing_status != 'completed')
  )
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS resume_parsed_data_user_id_idx ON resume_parsed_data(user_id);
CREATE INDEX IF NOT EXISTS resume_parsed_data_file_upload_id_idx ON resume_parsed_data(file_upload_id);
CREATE INDEX IF NOT EXISTS resume_parsed_data_parsing_status_idx ON resume_parsed_data(parsing_status);
CREATE INDEX IF NOT EXISTS resume_parsed_data_parsed_at_idx ON resume_parsed_data(parsed_at DESC);

-- Create GIN index for skills array searching
CREATE INDEX IF NOT EXISTS resume_parsed_data_skills_gin_idx ON resume_parsed_data USING GIN(parsed_skills);

-- Enable Row Level Security
ALTER TABLE resume_parsed_data ENABLE ROW LEVEL SECURITY;

-- RLS Policy: Candidates can read their own parsed resume data
CREATE POLICY "Candidates can view their own parsed resume data"
  ON resume_parsed_data
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- RLS Policy: System/authenticated users can insert parsed data
CREATE POLICY "Users can insert their own parsed resume data"
  ON resume_parsed_data
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- RLS Policy: Users can update their own parsed data (for re-parsing)
CREATE POLICY "Users can update their own parsed resume data"
  ON resume_parsed_data
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- RLS Policy: Employers can view parsed data for applications to their jobs
CREATE POLICY "Employers can view parsed data for job applications"
  ON resume_parsed_data
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM applications a
      JOIN jobs j ON j.id = a.job_id
      JOIN profiles p ON p.organization_id = j.organization_id
      JOIN file_uploads fu ON fu.user_id = resume_parsed_data.user_id
      WHERE p.id = auth.uid()
      AND p.role = 'employer'
      AND a.candidate_id = resume_parsed_data.user_id
      AND fu.file_type = 'resume'
    )
  );

-- RLS Policy: Recruiters can view parsed data for candidates they have consent to access
CREATE POLICY "Recruiters can view parsed data with consent"
  ON resume_parsed_data
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM consent_requests cr
      JOIN profiles p ON p.id = auth.uid()
      WHERE cr.candidate_id = resume_parsed_data.user_id
      AND cr.recruiter_id = auth.uid()
      AND cr.status = 'approved'
      AND p.role = 'recruiter'
    )
  );

-- Create trigger for updated_at
CREATE OR REPLACE FUNCTION update_resume_parsed_data_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger
    WHERE tgname = 'update_resume_parsed_data_updated_at'
  ) THEN
    CREATE TRIGGER update_resume_parsed_data_updated_at
      BEFORE UPDATE ON resume_parsed_data
      FOR EACH ROW
      EXECUTE FUNCTION update_resume_parsed_data_updated_at();
  END IF;
END $$;

-- Create helper function to check if parsed data is stale
CREATE OR REPLACE FUNCTION is_resume_parsed_data_stale(p_file_upload_id uuid)
RETURNS boolean AS $$
DECLARE
  v_file_updated_at timestamptz;
  v_parsed_at timestamptz;
BEGIN
  SELECT fu.updated_at, rpd.parsed_at
  INTO v_file_updated_at, v_parsed_at
  FROM file_uploads fu
  LEFT JOIN resume_parsed_data rpd ON rpd.file_upload_id = fu.id
  WHERE fu.id = p_file_upload_id;

  -- If no parsed data exists, it's stale
  IF v_parsed_at IS NULL THEN
    RETURN true;
  END IF;

  -- If file was updated after parsing, it's stale
  IF v_file_updated_at > v_parsed_at THEN
    RETURN true;
  END IF;

  RETURN false;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
