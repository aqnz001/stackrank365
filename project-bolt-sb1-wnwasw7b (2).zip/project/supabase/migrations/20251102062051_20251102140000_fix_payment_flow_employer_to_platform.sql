/*
  # Fix Payment Flow - Employer to Platform to Recruiter

  This migration corrects the payment flow:
  
  1. Employer Payment to Platform
    - Single payment when candidate is hired
    - Full amount based on bid (percent of salary or flat fee)
    - Tracked in `employer_payments` table
    
  2. Platform Payments to Recruiter
    - 3 monthly installments: 15%, 15%, 70%
    - Date-based, not milestone-based
    - Tracked in `scheduled_payments` table with payment_date
    
  3. Schema Changes
    - Add `employer_payments` table for tracking employer → platform payments
    - Update `scheduled_payments` to use `payment_date` instead of milestone triggers
    - Remove milestone_trigger field, add month_number
*/

-- Create employer_payments table (employer pays platform)
CREATE TABLE IF NOT EXISTS employer_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recruiter_bid_id uuid NOT NULL REFERENCES recruiter_bids(id) ON DELETE CASCADE,
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  application_id uuid NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
  employer_org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  amount integer NOT NULL CHECK (amount >= 0),
  currency text DEFAULT 'USD',
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'refunded', 'failed')),
  payment_date timestamptz,
  payment_method text,
  transaction_id text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Update scheduled_payments structure
DO $$ BEGIN
  ALTER TABLE scheduled_payments ADD COLUMN IF NOT EXISTS month_number integer CHECK (month_number IN (1, 2, 3));
  ALTER TABLE scheduled_payments ADD COLUMN IF NOT EXISTS payment_date timestamptz;
  ALTER TABLE scheduled_payments ADD COLUMN IF NOT EXISTS employer_payment_id uuid REFERENCES employer_payments(id) ON DELETE CASCADE;
  ALTER TABLE scheduled_payments DROP COLUMN IF EXISTS milestone_trigger;
  ALTER TABLE scheduled_payments DROP COLUMN IF EXISTS milestone_name;
  ALTER TABLE scheduled_payments ADD COLUMN IF NOT EXISTS installment_name text;
EXCEPTION
  WHEN duplicate_column THEN null;
  WHEN undefined_column THEN null;
END $$;

-- Add indexes
CREATE INDEX IF NOT EXISTS employer_payments_recruiter_bid_id_idx ON employer_payments(recruiter_bid_id);
CREATE INDEX IF NOT EXISTS employer_payments_job_id_idx ON employer_payments(job_id);
CREATE INDEX IF NOT EXISTS employer_payments_employer_org_id_idx ON employer_payments(employer_org_id);
CREATE INDEX IF NOT EXISTS employer_payments_status_idx ON employer_payments(status);
CREATE INDEX IF NOT EXISTS scheduled_payments_payment_date_idx ON scheduled_payments(payment_date);
CREATE INDEX IF NOT EXISTS scheduled_payments_month_number_idx ON scheduled_payments(month_number);

-- Enable RLS on employer_payments
ALTER TABLE employer_payments ENABLE ROW LEVEL SECURITY;

-- RLS Policies for employer_payments
CREATE POLICY "Employers can view their payments"
  ON employer_payments
  FOR SELECT
  TO authenticated
  USING (employer_org_id IN (
    SELECT organization_id FROM profiles WHERE id = auth.uid()
  ));

CREATE POLICY "Employers can create payments for their org"
  ON employer_payments
  FOR INSERT
  TO authenticated
  WITH CHECK (employer_org_id IN (
    SELECT organization_id FROM profiles WHERE id = auth.uid() AND role = 'employer'
  ));

CREATE POLICY "Admins can manage all employer payments"
  ON employer_payments
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Update trigger
CREATE TRIGGER update_employer_payments_updated_at
  BEFORE UPDATE ON employer_payments
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Clear existing incorrect sample data
DELETE FROM scheduled_payments WHERE recruiter_bid_id IN (
  '11111111-1111-1111-1111-111111111111',
  '22222222-2222-2222-2222-222222222222'
);
