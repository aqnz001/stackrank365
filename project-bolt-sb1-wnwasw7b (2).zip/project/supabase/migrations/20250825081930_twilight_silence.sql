/*
  # Create Interview Schedules and Workflow Tables

  1. New Tables
    - `interview_schedules`
      - `id` (uuid, primary key)
      - `application_id` (uuid, foreign key to applications)
      - `recruiter_bid_id` (uuid, foreign key to recruiter_bids)
      - `interviewer_id` (uuid, foreign key to profiles)
      - `candidate_id` (uuid, foreign key to profiles)
      - `interview_type` (enum: phone, video, in_person, technical, panel)
      - `status` (enum: scheduled, confirmed, rescheduled, completed, cancelled, no_show)
      - `scheduled_at` (timestamptz)
      - `duration_minutes` (integer)
      - `location` (text, optional)
      - `meeting_link` (text, optional)
      - `meeting_id` (text, optional)
      - `notes` (text, optional)
      - `feedback` (jsonb)
      - `reminder_sent` (boolean)
      - `calendar_event_id` (text, optional)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `document_shares`
      - `id` (uuid, primary key)
      - `owner_id` (uuid, foreign key to profiles)
      - `shared_with_id` (uuid, foreign key to profiles)
      - `file_upload_id` (uuid, foreign key to file_uploads)
      - `application_id` (uuid, foreign key to applications, optional)
      - `recruiter_bid_id` (uuid, foreign key to recruiter_bids, optional)
      - `access_level` (enum: view, download, edit)
      - `expires_at` (timestamptz, optional)
      - `password_protected` (boolean)
      - `access_password` (text, optional)
      - `download_count` (integer)
      - `last_accessed_at` (timestamptz, optional)
      - `is_active` (boolean)
      - `created_at` (timestamptz)

    - `workflow_templates`
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text, optional)
      - `category` (enum: hiring, onboarding, recruitment, compliance)
      - `trigger_event` (enum: application_received, bid_accepted, interview_scheduled, offer_made)
      - `steps` (jsonb)
      - `is_active` (boolean)
      - `organization_id` (uuid, foreign key to organizations)
      - `created_by` (uuid, foreign key to profiles)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `workflow_instances`
      - `id` (uuid, primary key)
      - `template_id` (uuid, foreign key to workflow_templates)
      - `entity_type` (enum: application, recruiter_bid, interview)
      - `entity_id` (uuid)
      - `status` (enum: active, completed, paused, cancelled)
      - `current_step` (integer)
      - `context_data` (jsonb)
      - `started_at` (timestamptz)
      - `completed_at` (timestamptz, optional)
      - `created_at` (timestamptz)

    - `workflow_steps`
      - `id` (uuid, primary key)
      - `workflow_instance_id` (uuid, foreign key to workflow_instances)
      - `step_number` (integer)
      - `step_name` (text)
      - `step_type` (enum: email, notification, task, delay, condition, approval)
      - `status` (enum: pending, in_progress, completed, skipped, failed)
      - `assigned_to` (uuid, foreign key to profiles, optional)
      - `due_date` (timestamptz, optional)
      - `completed_at` (timestamptz, optional)
      - `step_data` (jsonb)
      - `result_data` (jsonb)
      - `created_at` (timestamptz)

    - `status_updates`
      - `id` (uuid, primary key)
      - `entity_type` (enum: application, recruiter_bid, interview, job)
      - `entity_id` (uuid)
      - `old_status` (text, optional)
      - `new_status` (text)
      - `changed_by` (uuid, foreign key to profiles, optional)
      - `reason` (text, optional)
      - `notes` (text, optional)
      - `metadata` (jsonb)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all new tables
    - Add appropriate policies for each user role
    - Ensure data isolation between organizations

  3. Indexes
    - Add performance indexes for common queries
    - Foreign key indexes for joins
    - Date indexes for time-based queries
*/

-- Create custom types for interviews and workflows
DO $$ BEGIN
  CREATE TYPE interview_type AS ENUM ('phone', 'video', 'in_person', 'technical', 'panel');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE interview_status AS ENUM ('scheduled', 'confirmed', 'rescheduled', 'completed', 'cancelled', 'no_show');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE document_access_level AS ENUM ('view', 'download', 'edit');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE workflow_category AS ENUM ('hiring', 'onboarding', 'recruitment', 'compliance');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE workflow_trigger_event AS ENUM ('application_received', 'bid_accepted', 'interview_scheduled', 'offer_made');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE workflow_instance_status AS ENUM ('active', 'completed', 'paused', 'cancelled');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE workflow_entity_type AS ENUM ('application', 'recruiter_bid', 'interview');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE workflow_step_type AS ENUM ('email', 'notification', 'task', 'delay', 'condition', 'approval');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE workflow_step_status AS ENUM ('pending', 'in_progress', 'completed', 'skipped', 'failed');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE status_entity_type AS ENUM ('application', 'recruiter_bid', 'interview', 'job');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- Create interview_schedules table
CREATE TABLE IF NOT EXISTS interview_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id uuid REFERENCES applications(id) ON DELETE CASCADE,
  recruiter_bid_id uuid REFERENCES recruiter_bids(id) ON DELETE CASCADE,
  interviewer_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  candidate_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  interview_type interview_type NOT NULL DEFAULT 'video',
  status interview_status NOT NULL DEFAULT 'scheduled',
  scheduled_at timestamptz NOT NULL,
  duration_minutes integer NOT NULL DEFAULT 60,
  location text,
  meeting_link text,
  meeting_id text,
  notes text,
  feedback jsonb DEFAULT '{}',
  reminder_sent boolean DEFAULT false,
  calendar_event_id text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  CONSTRAINT interview_schedules_duration_check CHECK (duration_minutes > 0),
  CONSTRAINT interview_schedules_future_check CHECK (scheduled_at > created_at),
  CONSTRAINT interview_schedules_source_check CHECK (
    (application_id IS NOT NULL AND recruiter_bid_id IS NULL) OR
    (application_id IS NULL AND recruiter_bid_id IS NOT NULL)
  )
);

-- Create document_shares table
CREATE TABLE IF NOT EXISTS document_shares (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  shared_with_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  file_upload_id uuid NOT NULL REFERENCES file_uploads(id) ON DELETE CASCADE,
  application_id uuid REFERENCES applications(id) ON DELETE CASCADE,
  recruiter_bid_id uuid REFERENCES recruiter_bids(id) ON DELETE CASCADE,
  access_level document_access_level NOT NULL DEFAULT 'view',
  expires_at timestamptz,
  password_protected boolean DEFAULT false,
  access_password text,
  download_count integer DEFAULT 0,
  last_accessed_at timestamptz,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  
  CONSTRAINT document_shares_password_check CHECK (
    (password_protected = false) OR 
    (password_protected = true AND access_password IS NOT NULL)
  ),
  CONSTRAINT document_shares_expiry_check CHECK (
    expires_at IS NULL OR expires_at > created_at
  )
);

-- Create workflow_templates table
CREATE TABLE IF NOT EXISTS workflow_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  category workflow_category NOT NULL DEFAULT 'hiring',
  trigger_event workflow_trigger_event NOT NULL,
  steps jsonb NOT NULL DEFAULT '[]',
  is_active boolean DEFAULT true,
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  created_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create workflow_instances table
CREATE TABLE IF NOT EXISTS workflow_instances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id uuid NOT NULL REFERENCES workflow_templates(id) ON DELETE CASCADE,
  entity_type workflow_entity_type NOT NULL,
  entity_id uuid NOT NULL,
  status workflow_instance_status NOT NULL DEFAULT 'active',
  current_step integer DEFAULT 1,
  context_data jsonb DEFAULT '{}',
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Create workflow_steps table
CREATE TABLE IF NOT EXISTS workflow_steps (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_instance_id uuid NOT NULL REFERENCES workflow_instances(id) ON DELETE CASCADE,
  step_number integer NOT NULL,
  step_name text NOT NULL,
  step_type workflow_step_type NOT NULL,
  status workflow_step_status NOT NULL DEFAULT 'pending',
  assigned_to uuid REFERENCES profiles(id) ON DELETE SET NULL,
  due_date timestamptz,
  completed_at timestamptz,
  step_data jsonb DEFAULT '{}',
  result_data jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create status_updates table
CREATE TABLE IF NOT EXISTS status_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type status_entity_type NOT NULL,
  entity_id uuid NOT NULL,
  old_status text,
  new_status text NOT NULL,
  changed_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  reason text,
  notes text,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS interview_schedules_interviewer_id_idx ON interview_schedules(interviewer_id);
CREATE INDEX IF NOT EXISTS interview_schedules_candidate_id_idx ON interview_schedules(candidate_id);
CREATE INDEX IF NOT EXISTS interview_schedules_scheduled_at_idx ON interview_schedules(scheduled_at);
CREATE INDEX IF NOT EXISTS interview_schedules_status_idx ON interview_schedules(status);
CREATE INDEX IF NOT EXISTS interview_schedules_application_id_idx ON interview_schedules(application_id);
CREATE INDEX IF NOT EXISTS interview_schedules_recruiter_bid_id_idx ON interview_schedules(recruiter_bid_id);

CREATE INDEX IF NOT EXISTS document_shares_owner_id_idx ON document_shares(owner_id);
CREATE INDEX IF NOT EXISTS document_shares_shared_with_id_idx ON document_shares(shared_with_id);
CREATE INDEX IF NOT EXISTS document_shares_file_upload_id_idx ON document_shares(file_upload_id);
CREATE INDEX IF NOT EXISTS document_shares_is_active_idx ON document_shares(is_active);
CREATE INDEX IF NOT EXISTS document_shares_expires_at_idx ON document_shares(expires_at);

CREATE INDEX IF NOT EXISTS workflow_templates_organization_id_idx ON workflow_templates(organization_id);
CREATE INDEX IF NOT EXISTS workflow_templates_trigger_event_idx ON workflow_templates(trigger_event);
CREATE INDEX IF NOT EXISTS workflow_templates_is_active_idx ON workflow_templates(is_active);

CREATE INDEX IF NOT EXISTS workflow_instances_template_id_idx ON workflow_instances(template_id);
CREATE INDEX IF NOT EXISTS workflow_instances_entity_idx ON workflow_instances(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS workflow_instances_status_idx ON workflow_instances(status);
CREATE INDEX IF NOT EXISTS workflow_instances_started_at_idx ON workflow_instances(started_at);

CREATE INDEX IF NOT EXISTS workflow_steps_workflow_instance_id_idx ON workflow_steps(workflow_instance_id);
CREATE INDEX IF NOT EXISTS workflow_steps_assigned_to_idx ON workflow_steps(assigned_to);
CREATE INDEX IF NOT EXISTS workflow_steps_status_idx ON workflow_steps(status);
CREATE INDEX IF NOT EXISTS workflow_steps_due_date_idx ON workflow_steps(due_date);

CREATE INDEX IF NOT EXISTS status_updates_entity_idx ON status_updates(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS status_updates_changed_by_idx ON status_updates(changed_by);
CREATE INDEX IF NOT EXISTS status_updates_created_at_idx ON status_updates(created_at DESC);

-- Enable Row Level Security
ALTER TABLE interview_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE document_shares ENABLE ROW LEVEL SECURITY;
ALTER TABLE workflow_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE workflow_instances ENABLE ROW LEVEL SECURITY;
ALTER TABLE workflow_steps ENABLE ROW LEVEL SECURITY;
ALTER TABLE status_updates ENABLE ROW LEVEL SECURITY;

-- RLS Policies for interview_schedules
CREATE POLICY "Candidates can view their own interviews"
  ON interview_schedules
  FOR SELECT
  TO authenticated
  USING (candidate_id = auth.uid());

CREATE POLICY "Interviewers can manage interviews they conduct"
  ON interview_schedules
  FOR ALL
  TO authenticated
  USING (interviewer_id = auth.uid())
  WITH CHECK (interviewer_id = auth.uid());

CREATE POLICY "Employers can manage interviews for their organization jobs"
  ON interview_schedules
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM applications a
      JOIN jobs j ON j.id = a.job_id
      JOIN profiles p ON p.organization_id = j.organization_id
      WHERE a.id = interview_schedules.application_id
      AND p.id = auth.uid()
      AND p.role = 'employer'
    )
    OR
    EXISTS (
      SELECT 1 FROM recruiter_bids rb
      JOIN jobs j ON j.id = rb.job_id
      JOIN profiles p ON p.organization_id = j.organization_id
      WHERE rb.id = interview_schedules.recruiter_bid_id
      AND p.id = auth.uid()
      AND p.role = 'employer'
    )
  );

-- RLS Policies for document_shares
CREATE POLICY "Users can view documents shared with them"
  ON document_shares
  FOR SELECT
  TO authenticated
  USING (shared_with_id = auth.uid() OR owner_id = auth.uid());

CREATE POLICY "Users can manage documents they own"
  ON document_shares
  FOR ALL
  TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());

-- RLS Policies for workflow_templates
CREATE POLICY "Organization members can view workflow templates"
  ON workflow_templates
  FOR SELECT
  TO authenticated
  USING (
    organization_id IN (
      SELECT organization_id FROM profiles
      WHERE id = auth.uid() AND organization_id IS NOT NULL
    )
  );

CREATE POLICY "Organization members can manage workflow templates"
  ON workflow_templates
  FOR ALL
  TO authenticated
  USING (
    organization_id IN (
      SELECT organization_id FROM profiles
      WHERE id = auth.uid() AND organization_id IS NOT NULL
    )
  )
  WITH CHECK (
    organization_id IN (
      SELECT organization_id FROM profiles
      WHERE id = auth.uid() AND organization_id IS NOT NULL
    )
  );

-- RLS Policies for workflow_instances
CREATE POLICY "Organization members can view workflow instances"
  ON workflow_instances
  FOR SELECT
  TO authenticated
  USING (
    template_id IN (
      SELECT wt.id FROM workflow_templates wt
      JOIN profiles p ON p.organization_id = wt.organization_id
      WHERE p.id = auth.uid()
    )
  );

CREATE POLICY "Organization members can manage workflow instances"
  ON workflow_instances
  FOR ALL
  TO authenticated
  USING (
    template_id IN (
      SELECT wt.id FROM workflow_templates wt
      JOIN profiles p ON p.organization_id = wt.organization_id
      WHERE p.id = auth.uid()
    )
  );

-- RLS Policies for workflow_steps
CREATE POLICY "Assigned users can view their workflow steps"
  ON workflow_steps
  FOR SELECT
  TO authenticated
  USING (
    assigned_to = auth.uid()
    OR
    workflow_instance_id IN (
      SELECT wi.id FROM workflow_instances wi
      JOIN workflow_templates wt ON wt.id = wi.template_id
      JOIN profiles p ON p.organization_id = wt.organization_id
      WHERE p.id = auth.uid()
    )
  );

CREATE POLICY "Assigned users can update their workflow steps"
  ON workflow_steps
  FOR UPDATE
  TO authenticated
  USING (
    assigned_to = auth.uid()
    OR
    workflow_instance_id IN (
      SELECT wi.id FROM workflow_instances wi
      JOIN workflow_templates wt ON wt.id = wi.template_id
      JOIN profiles p ON p.organization_id = wt.organization_id
      WHERE p.id = auth.uid()
    )
  );

-- RLS Policies for status_updates
CREATE POLICY "Users can view status updates for their entities"
  ON status_updates
  FOR SELECT
  TO authenticated
  USING (
    changed_by = auth.uid()
    OR
    (entity_type = 'application' AND entity_id IN (
      SELECT id FROM applications WHERE candidate_id = auth.uid()
    ))
    OR
    (entity_type = 'recruiter_bid' AND entity_id IN (
      SELECT id FROM recruiter_bids WHERE recruiter_id = auth.uid()
    ))
    OR
    (entity_type = 'job' AND entity_id IN (
      SELECT j.id FROM jobs j
      JOIN profiles p ON p.organization_id = j.organization_id
      WHERE p.id = auth.uid()
    ))
  );

CREATE POLICY "Users can create status updates for entities they manage"
  ON status_updates
  FOR INSERT
  TO authenticated
  WITH CHECK (
    (entity_type = 'application' AND entity_id IN (
      SELECT a.id FROM applications a
      JOIN jobs j ON j.id = a.job_id
      JOIN profiles p ON p.organization_id = j.organization_id
      WHERE p.id = auth.uid() AND p.role = 'employer'
    ))
    OR
    (entity_type = 'recruiter_bid' AND entity_id IN (
      SELECT rb.id FROM recruiter_bids rb
      JOIN jobs j ON j.id = rb.job_id
      JOIN profiles p ON p.organization_id = j.organization_id
      WHERE p.id = auth.uid() AND p.role = 'employer'
    ))
    OR
    (entity_type = 'job' AND entity_id IN (
      SELECT j.id FROM jobs j
      JOIN profiles p ON p.organization_id = j.organization_id
      WHERE p.id = auth.uid() AND p.role = 'employer'
    ))
  );

-- Create triggers for updated_at columns
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'update_interview_schedules_updated_at'
  ) THEN
    CREATE TRIGGER update_interview_schedules_updated_at
      BEFORE UPDATE ON interview_schedules
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'update_workflow_templates_updated_at'
  ) THEN
    CREATE TRIGGER update_workflow_templates_updated_at
      BEFORE UPDATE ON workflow_templates
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;