/*
  # Fix Subscriptions Table Schema

  1. Schema Changes
    - Rename billing_cycle to billing_interval for consistency
    - Add missing quantity column
    - Add missing metadata column

  2. RLS Policy Changes
    - Add INSERT policy for subscriptions (organization members can create subscriptions)
    - Add UPDATE policy for subscriptions (organization members can update their subscriptions)

  3. Security
    - Maintains existing SELECT policy
    - Ensures organization-level access control
*/

-- Add missing columns if they don't exist
DO $$
BEGIN
  -- Add quantity column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscriptions' AND column_name = 'quantity'
  ) THEN
    ALTER TABLE subscriptions ADD COLUMN quantity integer NOT NULL DEFAULT 1;
  END IF;

  -- Add metadata column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscriptions' AND column_name = 'metadata'
  ) THEN
    ALTER TABLE subscriptions ADD COLUMN metadata jsonb DEFAULT '{}';
  END IF;
END $$;

-- Rename billing_cycle to billing_interval if column exists
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscriptions' AND column_name = 'billing_cycle'
  ) THEN
    ALTER TABLE subscriptions RENAME COLUMN billing_cycle TO billing_interval;
  END IF;
END $$;

-- Add INSERT policy for subscriptions
DROP POLICY IF EXISTS "Organization members can create subscriptions" ON subscriptions;
CREATE POLICY "Organization members can create subscriptions"
  ON subscriptions
  FOR INSERT
  TO authenticated
  WITH CHECK (billing_account_id IN (
    SELECT ba.id FROM billing_accounts ba
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ));

-- Add UPDATE policy for subscriptions
DROP POLICY IF EXISTS "Organization members can update subscriptions" ON subscriptions;
CREATE POLICY "Organization members can update subscriptions"
  ON subscriptions
  FOR UPDATE
  TO authenticated
  USING (billing_account_id IN (
    SELECT ba.id FROM billing_accounts ba
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ))
  WITH CHECK (billing_account_id IN (
    SELECT ba.id FROM billing_accounts ba
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ));

-- Ensure admins can manage subscriptions
DROP POLICY IF EXISTS "Admins can manage subscriptions" ON subscriptions;
CREATE POLICY "Admins can manage subscriptions"
  ON subscriptions
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));
