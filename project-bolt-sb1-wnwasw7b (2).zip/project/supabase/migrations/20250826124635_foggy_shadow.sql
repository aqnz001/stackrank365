/*
  # Fix RLS policies for subscription_plans table

  1. Security Updates
    - Update RLS policies for subscription_plans table
    - Allow authenticated users to insert default plans
    - Maintain read access for all users
    - Restrict write access to admins only for ongoing management

  2. Changes
    - Drop existing restrictive policies
    - Add new policies that allow initial setup
    - Ensure proper access control
*/

-- Drop existing policies
DROP POLICY IF EXISTS "subscription_plans_read_all" ON subscription_plans;
DROP POLICY IF EXISTS "subscription_plans_write_admin" ON subscription_plans;

-- Allow all authenticated users to read subscription plans
CREATE POLICY "subscription_plans_select_all"
  ON subscription_plans
  FOR SELECT
  TO authenticated
  USING (true);

-- Allow authenticated users to insert subscription plans (for initial setup)
CREATE POLICY "subscription_plans_insert_authenticated"
  ON subscription_plans
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Allow admins to update and delete subscription plans
CREATE POLICY "subscription_plans_admin_write"
  ON subscription_plans
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.role = 'admin'
    )
  );

-- Allow upsert operations for authenticated users (needed for createDefaultPlans)
CREATE POLICY "subscription_plans_upsert_authenticated"
  ON subscription_plans
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);