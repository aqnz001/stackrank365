/*
  # Create applications table

  1. New Tables
    - `applications`
      - `id` (uuid, primary key)
      - `job_id` (uuid, foreign key to jobs)
      - `candidate_id` (uuid, foreign key to profiles)
      - `candidate_name` (text)
      - `candidate_email` (text)
      - `source` (text) - 'direct' or 'recruiter'
      - `status` (text) - 'submitted', 'shortlisted', 'rejected', 'hired', 'withdrawn'
      - `cover_letter` (text)
      - `resume_url` (text, optional)
      - `phone` (text, optional)
      - `location` (text, optional)
      - `salary_expectation` (integer, optional)
      - `availability_date` (date, optional)
      - `work_authorization` (text, optional)
      - `willing_to_relocate` (boolean, default false)
      - `additional_info` (text, optional)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `applications` table
    - Add policies for candidates to manage their own applications
    - Add policies for employers to view applications for their jobs
    - Add policies for recruiters to view applications they submitted
*/

-- Create applications table
CREATE TABLE IF NOT EXISTS applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  candidate_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  candidate_name text NOT NULL,
  candidate_email text NOT NULL,
  source text NOT NULL DEFAULT 'direct' CHECK (source IN ('direct', 'recruiter')),
  status text NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted', 'shortlisted', 'rejected', 'hired', 'withdrawn')),
  cover_letter text,
  resume_url text,
  phone text,
  location text,
  salary_expectation integer,
  availability_date date,
  work_authorization text,
  willing_to_relocate boolean DEFAULT false,
  additional_info text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS applications_job_id_idx ON applications(job_id);
CREATE INDEX IF NOT EXISTS applications_candidate_id_idx ON applications(candidate_id);
CREATE INDEX IF NOT EXISTS applications_status_idx ON applications(status);
CREATE INDEX IF NOT EXISTS applications_created_at_idx ON applications(created_at DESC);

-- Enable RLS
ALTER TABLE applications ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Candidates can manage their own applications"
  ON applications
  FOR ALL
  TO authenticated
  USING (candidate_id = auth.uid())
  WITH CHECK (candidate_id = auth.uid());

CREATE POLICY "Employers can view applications for their jobs"
  ON applications
  FOR SELECT
  TO authenticated
  USING (
    job_id IN (
      SELECT j.id 
      FROM jobs j 
      JOIN profiles p ON p.organization_id = j.organization_id 
      WHERE p.id = auth.uid() AND p.role = 'employer'
    )
  );

CREATE POLICY "Employers can update applications for their jobs"
  ON applications
  FOR UPDATE
  TO authenticated
  USING (
    job_id IN (
      SELECT j.id 
      FROM jobs j 
      JOIN profiles p ON p.organization_id = j.organization_id 
      WHERE p.id = auth.uid() AND p.role = 'employer'
    )
  )
  WITH CHECK (
    job_id IN (
      SELECT j.id 
      FROM jobs j 
      JOIN profiles p ON p.organization_id = j.organization_id 
      WHERE p.id = auth.uid() AND p.role = 'employer'
    )
  );

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_applications_updated_at
  BEFORE UPDATE ON applications
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();