/*
  # Fix profile trigger and RLS policies

  1. Database Trigger
    - Create robust `handle_new_user` function that won't crash signup
    - Handle user metadata properly (name and role)
    - Use ON CONFLICT to handle race conditions

  2. RLS Policies
    - Allow profile insertion during signup
    - Allow users to read their own profiles
    - Ensure policies don't block the trigger
*/

-- Create or replace the user profile creation trigger function
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_name text := nullif(coalesce(new.raw_user_meta_data->>'name',''), '');
  v_role_text text := lower(coalesce(new.raw_user_meta_data->>'role',''));
  v_role public.user_role := null;
BEGIN
  -- Validate and convert role
  IF v_role_text IN ('employer','recruiter','candidate','admin') THEN
    v_role := v_role_text::public.user_role;
  END IF;

  -- Insert or update profile
  INSERT INTO public.profiles (id, email, name, role, updated_at)
  VALUES (new.id, new.email, v_name, v_role, now())
  ON CONFLICT (id) DO UPDATE
    SET email = EXCLUDED.email,
        name = COALESCE(EXCLUDED.name, public.profiles.name),
        role = COALESCE(EXCLUDED.role, public.profiles.role),
        updated_at = EXCLUDED.updated_at;

  RETURN new;
EXCEPTION WHEN OTHERS THEN
  -- Log but don't break signup
  RAISE NOTICE 'handle_new_user failed for %: %', new.id, SQLERRM;
  RETURN new;
END;
$$;

-- Recreate the trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Ensure RLS is enabled
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to recreate them cleanly
DROP POLICY IF EXISTS "profiles insert" ON public.profiles;
DROP POLICY IF EXISTS "profiles select own" ON public.profiles;
DROP POLICY IF EXISTS "Allow authenticated users to insert own profile" ON public.profiles;
DROP POLICY IF EXISTS "Allow authenticated users to read own profile" ON public.profiles;
DROP POLICY IF EXISTS "Allow authenticated users to update own profile" ON public.profiles;

-- Create comprehensive RLS policies
CREATE POLICY "profiles_insert_policy"
  ON public.profiles FOR INSERT 
  TO public 
  WITH CHECK (true);

CREATE POLICY "profiles_select_policy"
  ON public.profiles FOR SELECT 
  TO public 
  USING (auth.uid() = id);

CREATE POLICY "profiles_update_policy"
  ON public.profiles FOR UPDATE 
  TO public 
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);