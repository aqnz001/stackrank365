/*
  # Platform Administration & Analytics Schema

  1. New Tables
    - `platform_settings` - Global platform configuration
    - `user_sessions` - Track user login sessions and activity
    - `audit_logs` - Complete audit trail for admin actions
    - `platform_metrics` - Daily/monthly aggregated metrics
    - `reports` - Generated reports and exports
    - `feature_flags` - Feature toggle management

  2. Security
    - Enable RLS on all new tables
    - Admin-only access for most tables
    - Audit logging for sensitive operations

  3. Analytics Views
    - Revenue analytics
    - User engagement metrics
    - Job posting performance
    - Platform health monitoring
*/

-- Platform Settings Table
CREATE TABLE IF NOT EXISTS platform_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value jsonb NOT NULL DEFAULT '{}',
  description text,
  category text DEFAULT 'general',
  is_public boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE platform_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Only admins can manage platform settings"
  ON platform_settings
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'admin'
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'admin'
  ));

-- User Sessions Table
CREATE TABLE IF NOT EXISTS user_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  session_start timestamptz DEFAULT now(),
  session_end timestamptz,
  ip_address inet,
  user_agent text,
  device_type text,
  browser text,
  os text,
  country text,
  city text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE user_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own sessions"
  ON user_sessions
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can view all sessions"
  ON user_sessions
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'admin'
  ));

-- Audit Logs Table
CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id uuid,
  old_values jsonb,
  new_values jsonb,
  ip_address inet,
  user_agent text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Only admins can view audit logs"
  ON audit_logs
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'admin'
  ));

-- Platform Metrics Table
CREATE TABLE IF NOT EXISTS platform_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  metric_date date NOT NULL,
  metric_type text NOT NULL,
  metric_value numeric NOT NULL DEFAULT 0,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE platform_metrics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Only admins can manage platform metrics"
  ON platform_metrics
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'admin'
  ));

-- Reports Table
CREATE TABLE IF NOT EXISTS reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  report_type text NOT NULL,
  parameters jsonb DEFAULT '{}',
  file_path text,
  file_size bigint,
  status text DEFAULT 'pending',
  generated_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  generated_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own reports"
  ON reports
  FOR SELECT
  TO authenticated
  USING (generated_by = auth.uid());

CREATE POLICY "Admins can manage all reports"
  ON reports
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'admin'
  ));

-- Feature Flags Table
CREATE TABLE IF NOT EXISTS feature_flags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text,
  is_enabled boolean DEFAULT false,
  rollout_percentage integer DEFAULT 0 CHECK (rollout_percentage >= 0 AND rollout_percentage <= 100),
  target_roles text[] DEFAULT '{}',
  target_organizations uuid[],
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE feature_flags ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Everyone can read enabled feature flags"
  ON feature_flags
  FOR SELECT
  TO authenticated
  USING (is_enabled = true);

CREATE POLICY "Only admins can manage feature flags"
  ON feature_flags
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'admin'
  ));

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS platform_settings_key_idx ON platform_settings(key);
CREATE INDEX IF NOT EXISTS platform_settings_category_idx ON platform_settings(category);
CREATE INDEX IF NOT EXISTS user_sessions_user_id_idx ON user_sessions(user_id);
CREATE INDEX IF NOT EXISTS user_sessions_session_start_idx ON user_sessions(session_start DESC);
CREATE INDEX IF NOT EXISTS audit_logs_user_id_idx ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS audit_logs_created_at_idx ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS audit_logs_entity_idx ON audit_logs(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS platform_metrics_date_idx ON platform_metrics(metric_date DESC);
CREATE INDEX IF NOT EXISTS platform_metrics_type_idx ON platform_metrics(metric_type);
CREATE INDEX IF NOT EXISTS reports_generated_by_idx ON reports(generated_by);
CREATE INDEX IF NOT EXISTS reports_created_at_idx ON reports(created_at DESC);
CREATE INDEX IF NOT EXISTS feature_flags_name_idx ON feature_flags(name);

-- Create triggers for updated_at
CREATE TRIGGER update_platform_settings_updated_at
  BEFORE UPDATE ON platform_settings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_feature_flags_updated_at
  BEFORE UPDATE ON feature_flags
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert default platform settings
INSERT INTO platform_settings (key, value, description, category, is_public) VALUES
  ('platform_name', '"JobBoard Pro"', 'Platform display name', 'branding', true),
  ('platform_commission', '15', 'Platform commission percentage', 'pricing', false),
  ('basic_tier_price', '200', 'Basic job posting price in USD', 'pricing', true),
  ('standard_tier_price', '300', 'Standard job posting price in USD', 'pricing', true),
  ('premium_tier_price', '500', 'Premium job posting price in USD', 'pricing', true),
  ('default_guarantee_days', '90', 'Default guarantee period for recruiter placements', 'business', false),
  ('max_bid_limit', '50', 'Maximum number of bids allowed per job', 'business', false),
  ('email_notifications_enabled', 'true', 'Enable email notifications', 'notifications', false),
  ('maintenance_mode', 'false', 'Platform maintenance mode', 'system', false),
  ('registration_enabled', 'true', 'Allow new user registrations', 'system', false)
ON CONFLICT (key) DO NOTHING;

-- Insert default feature flags
INSERT INTO feature_flags (name, description, is_enabled, target_roles) VALUES
  ('advanced_analytics', 'Advanced analytics dashboard', true, ARRAY['admin', 'employer']),
  ('real_time_chat', 'Real-time messaging system', true, ARRAY['employer', 'recruiter', 'candidate']),
  ('ai_matching', 'AI-powered job matching', false, ARRAY['candidate', 'recruiter']),
  ('video_interviews', 'Video interview scheduling', false, ARRAY['employer', 'candidate']),
  ('bulk_operations', 'Bulk job and application management', true, ARRAY['employer', 'admin'])
ON CONFLICT (name) DO NOTHING;