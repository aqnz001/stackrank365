/*
  # Create job_ranking_configs table

  1. New Table
    - `job_ranking_configs`
      - `id` (uuid, primary key)
      - `job_id` (uuid, foreign key to jobs, nullable for templates)
      - `organization_id` (uuid, foreign key to organizations)
      - `config_name` (text) - name for the configuration
      - `is_template` (boolean) - whether this is a reusable template
      - `weights` (jsonb) - scoring weights configuration
        - skills_match_weight
        - experience_weight
        - education_weight
        - location_weight
        - salary_weight
        - availability_weight
      - `criteria` (jsonb) - additional ranking criteria
      - `created_by` (uuid, foreign key to profiles)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `job_ranking_configs` table
    - Organization members can manage their own configs
    - Admins can view all configs

  3. Indexes
    - Index on job_id for fast lookups
    - Index on organization_id for org-level queries
    - Index on is_template for template queries
*/

-- Create job_ranking_configs table
CREATE TABLE IF NOT EXISTS job_ranking_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid REFERENCES jobs(id) ON DELETE CASCADE,
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  config_name text NOT NULL,
  is_template boolean DEFAULT false,
  weights jsonb NOT NULL DEFAULT '{
    "skills_match_weight": 30,
    "experience_weight": 25,
    "education_weight": 15,
    "location_weight": 10,
    "salary_weight": 15,
    "availability_weight": 5
  }'::jsonb,
  criteria jsonb DEFAULT '{}'::jsonb,
  created_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS job_ranking_configs_job_id_idx
  ON job_ranking_configs(job_id);

CREATE INDEX IF NOT EXISTS job_ranking_configs_organization_id_idx
  ON job_ranking_configs(organization_id);

CREATE INDEX IF NOT EXISTS job_ranking_configs_is_template_idx
  ON job_ranking_configs(is_template)
  WHERE is_template = true;

-- Enable RLS
ALTER TABLE job_ranking_configs ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Organization members can view their ranking configs"
  ON job_ranking_configs
  FOR SELECT
  TO authenticated
  USING (
    organization_id IN (
      SELECT organization_id
      FROM profiles
      WHERE id = auth.uid() AND organization_id IS NOT NULL
    )
  );

CREATE POLICY "Organization members can create ranking configs"
  ON job_ranking_configs
  FOR INSERT
  TO authenticated
  WITH CHECK (
    organization_id IN (
      SELECT organization_id
      FROM profiles
      WHERE id = auth.uid() AND organization_id IS NOT NULL
    )
  );

CREATE POLICY "Organization members can update their ranking configs"
  ON job_ranking_configs
  FOR UPDATE
  TO authenticated
  USING (
    organization_id IN (
      SELECT organization_id
      FROM profiles
      WHERE id = auth.uid() AND organization_id IS NOT NULL
    )
  )
  WITH CHECK (
    organization_id IN (
      SELECT organization_id
      FROM profiles
      WHERE id = auth.uid() AND organization_id IS NOT NULL
    )
  );

CREATE POLICY "Organization members can delete their ranking configs"
  ON job_ranking_configs
  FOR DELETE
  TO authenticated
  USING (
    organization_id IN (
      SELECT organization_id
      FROM profiles
      WHERE id = auth.uid() AND organization_id IS NOT NULL
    )
  );

-- Admins can manage all configs
CREATE POLICY "Admins can manage all ranking configs"
  ON job_ranking_configs
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

-- Updated at trigger
CREATE TRIGGER update_job_ranking_configs_updated_at
  BEFORE UPDATE ON job_ranking_configs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert default templates
INSERT INTO job_ranking_configs (organization_id, config_name, is_template, weights, created_by)
SELECT
  o.id,
  'Skills-Focused',
  true,
  '{
    "skills_match_weight": 50,
    "experience_weight": 20,
    "education_weight": 10,
    "location_weight": 5,
    "salary_weight": 10,
    "availability_weight": 5
  }'::jsonb,
  NULL
FROM organizations o
WHERE o.type = 'employer'
ON CONFLICT DO NOTHING;

INSERT INTO job_ranking_configs (organization_id, config_name, is_template, weights, created_by)
SELECT
  o.id,
  'Experience-Focused',
  true,
  '{
    "skills_match_weight": 20,
    "experience_weight": 50,
    "education_weight": 15,
    "location_weight": 5,
    "salary_weight": 5,
    "availability_weight": 5
  }'::jsonb,
  NULL
FROM organizations o
WHERE o.type = 'employer'
ON CONFLICT DO NOTHING;

INSERT INTO job_ranking_configs (organization_id, config_name, is_template, weights, created_by)
SELECT
  o.id,
  'Budget-Conscious',
  true,
  '{
    "skills_match_weight": 25,
    "experience_weight": 20,
    "education_weight": 10,
    "location_weight": 10,
    "salary_weight": 30,
    "availability_weight": 5
  }'::jsonb,
  NULL
FROM organizations o
WHERE o.type = 'employer'
ON CONFLICT DO NOTHING;
