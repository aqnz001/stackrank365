/*
  # Add unique constraint to subscription_plans name column

  1. Database Changes
    - Add unique constraint to `subscription_plans.name` column
    - This enables proper upsert operations using ON CONFLICT

  2. Impact
    - Allows the application to safely upsert subscription plans
    - Prevents duplicate plan names in the database
*/

-- Add unique constraint to subscription_plans name column
ALTER TABLE public.subscription_plans 
ADD CONSTRAINT subscription_plans_name_key UNIQUE (name);