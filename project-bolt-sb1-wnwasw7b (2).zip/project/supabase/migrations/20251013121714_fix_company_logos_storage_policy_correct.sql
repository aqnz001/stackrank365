/*
  # Fix Company Logos Storage Policy - Correct Version

  1. Issue
    - Previous attempt still had the wrong reference
    - The policy needs to check `storage.objects.name` (the file path)
    - NOT `profiles.name` (the user's name)

  2. Changes
    - Drop all existing company-logos policies
    - Create new policies that correctly reference the storage object's name/path
    - File path format: {organization_id}/{filename}
    - Policy validates: user's organization_id matches the folder name in the storage path

  3. Security
    - Only organization members (employer/recruiter) can upload to their org folder
    - Only organization members can update/delete their org's logos
    - Public read access for all company logos
*/

-- Drop all existing company-logos policies
DROP POLICY IF EXISTS "Organization members can manage company logos" ON storage.objects;
DROP POLICY IF EXISTS "Organization members can upload company logos" ON storage.objects;
DROP POLICY IF EXISTS "Organization members can update company logos" ON storage.objects;
DROP POLICY IF EXISTS "Organization members can delete company logos" ON storage.objects;

-- CREATE: Allow organization members to upload logos to their organization's folder
CREATE POLICY "Org members upload logos"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'company-logos'
    AND EXISTS (
      SELECT 1
      FROM profiles p
      WHERE p.id = auth.uid()
        AND p.organization_id::text = (storage.foldername(objects.name))[1]
        AND p.role IN ('employer', 'recruiter')
    )
  );

-- UPDATE: Allow organization members to update their organization's logos
CREATE POLICY "Org members update logos"
  ON storage.objects
  FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'company-logos'
    AND EXISTS (
      SELECT 1
      FROM profiles p
      WHERE p.id = auth.uid()
        AND p.organization_id::text = (storage.foldername(objects.name))[1]
        AND p.role IN ('employer', 'recruiter')
    )
  );

-- DELETE: Allow organization members to delete their organization's logos
CREATE POLICY "Org members delete logos"
  ON storage.objects
  FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'company-logos'
    AND EXISTS (
      SELECT 1
      FROM profiles p
      WHERE p.id = auth.uid()
        AND p.organization_id::text = (storage.foldername(objects.name))[1]
        AND p.role IN ('employer', 'recruiter')
    )
  );