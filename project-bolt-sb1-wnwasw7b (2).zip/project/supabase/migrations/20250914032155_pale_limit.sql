/*
  # Create recruiter_profiles table

  1. New Tables
    - `recruiter_profiles`
      - `user_id` (uuid, primary key, foreign key to profiles.id)
      - `profile_json` (jsonb, stores structured recruiter profile data)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `recruiter_profiles` table
    - Add policy for authenticated users to manage their own profile data
    - Add policy for admins to view all recruiter profiles

  3. Triggers
    - Add trigger to automatically update `updated_at` column
*/

CREATE TABLE IF NOT EXISTS recruiter_profiles (
  user_id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  profile_json jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE recruiter_profiles ENABLE ROW LEVEL SECURITY;

-- Policy for recruiters to manage their own profile
CREATE POLICY "Recruiters can manage own profile"
  ON recruiter_profiles
  FOR ALL
  TO authenticated
  USING (user_id = uid())
  WITH CHECK (user_id = uid());

-- Policy for admins to view all recruiter profiles
CREATE POLICY "Admins can view all recruiter profiles"
  ON recruiter_profiles
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = uid() AND profiles.role = 'admin'
    )
  );

-- Trigger to update updated_at column
CREATE OR REPLACE FUNCTION update_recruiter_profiles_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_recruiter_profiles_updated_at
  BEFORE UPDATE ON recruiter_profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_recruiter_profiles_updated_at();