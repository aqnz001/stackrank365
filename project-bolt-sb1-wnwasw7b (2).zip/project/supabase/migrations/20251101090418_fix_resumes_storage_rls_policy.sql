/*
  # Fix Resume Storage RLS Policy for Employers

  1. Changes
    - Drop the broken "Employers can view resumes from applications" policy
    - Create a corrected policy that properly matches storage object names with application resume URLs
    
  2. Security
    - Employers can only access resumes from applications for jobs in their organization
    - The policy now correctly compares storage.objects.name with applications.resume_url
*/

DROP POLICY IF EXISTS "Employers can view resumes from applications" ON storage.objects;

CREATE POLICY "Employers can view resumes from applications"
  ON storage.objects
  FOR SELECT
  TO authenticated
  USING (
    bucket_id = 'resumes'
    AND EXISTS (
      SELECT 1
      FROM applications a
      JOIN jobs j ON a.job_id = j.id
      JOIN profiles p ON p.organization_id = j.organization_id
      WHERE p.id = auth.uid()
        AND p.role = 'employer'
        AND a.resume_url = storage.objects.name
    )
  );
