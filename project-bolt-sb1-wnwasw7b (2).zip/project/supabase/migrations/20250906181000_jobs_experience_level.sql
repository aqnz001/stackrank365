-- Add experience_level to jobs (text for flexibility: 'entry' | 'mid' | 'senior' | 'lead')

alter table if exists public.jobs
  add column if not exists experience_level text;

comment on column public.jobs.experience_level is 'Experience level for the job (e.g., entry, mid, senior, lead)';

