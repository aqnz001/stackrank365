/*
  # Create AI Assistant Conversations Table

  1. New Tables
    - `application_ai_conversations`
      - `id` (uuid, primary key)
      - `application_id` (uuid, foreign key to applications table)
      - `user_id` (uuid, references auth.users)
      - `question` (text, user's question)
      - `answer` (text, AI assistant's response)
      - `context_type` (text, type of content analyzed: 'resume', 'cover_letter', 'both')
      - `created_at` (timestamptz, default now())

  2. Security
    - Enable RLS on `application_ai_conversations` table
    - Add policy for users to read their own conversation history
    - Add policy for users to create new conversations for their applications

  3. Indexes
    - Index on application_id for fast conversation retrieval
    - Index on user_id for user-specific queries
*/

CREATE TABLE IF NOT EXISTS application_ai_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id uuid NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  question text NOT NULL,
  answer text NOT NULL,
  context_type text NOT NULL CHECK (context_type IN ('resume', 'cover_letter', 'both', 'general')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE application_ai_conversations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read their own AI conversations"
  ON application_ai_conversations
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create AI conversations for their applications"
  ON application_ai_conversations
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_ai_conversations_application 
  ON application_ai_conversations(application_id);

CREATE INDEX IF NOT EXISTS idx_ai_conversations_user 
  ON application_ai_conversations(user_id);

CREATE INDEX IF NOT EXISTS idx_ai_conversations_created 
  ON application_ai_conversations(created_at DESC);
