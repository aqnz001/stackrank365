/*
  # Document Sharing and File Management System

  1. New Tables
    - `file_uploads` - Store file metadata and references
    - `document_shares` - Manage document sharing permissions and access
  
  2. Security
    - Enable RLS on both tables
    - Users can only access their own files and files shared with them
    - Organization members can access organization files
    - Proper access level controls (view, download, edit)
  
  3. Features
    - File upload tracking with metadata
    - Secure document sharing with expiration dates
    - Password protection for sensitive documents
    - Download tracking and access logs
    - Integration with applications and recruiter bids
*/

-- Create file_uploads table if it doesn't exist (it should already exist based on schema)
CREATE TABLE IF NOT EXISTS public.file_uploads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
  organization_id uuid REFERENCES public.organizations(id) ON DELETE CASCADE,
  bucket_name text NOT NULL,
  file_path text NOT NULL,
  file_name text NOT NULL,
  file_size bigint NOT NULL,
  mime_type text NOT NULL,
  file_type text NOT NULL CHECK (file_type = ANY (ARRAY['resume'::text, 'profile_photo'::text, 'company_logo'::text, 'document'::text])),
  is_active boolean DEFAULT true,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Create document_shares table if it doesn't exist (it should already exist based on schema)
CREATE TABLE IF NOT EXISTS public.document_shares (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  shared_with_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  file_upload_id uuid REFERENCES public.file_uploads(id) ON DELETE CASCADE NOT NULL,
  application_id uuid REFERENCES public.applications(id) ON DELETE CASCADE,
  recruiter_bid_id uuid REFERENCES public.recruiter_bids(id) ON DELETE CASCADE,
  access_level public.document_access_level NOT NULL DEFAULT 'view',
  expires_at timestamp with time zone,
  password_protected boolean DEFAULT false,
  access_password text,
  download_count integer DEFAULT 0,
  last_accessed_at timestamp with time zone,
  is_active boolean DEFAULT true,
  created_at timestamp with time zone DEFAULT now(),
  CONSTRAINT document_shares_expiry_check CHECK (((expires_at IS NULL) OR (expires_at > created_at))),
  CONSTRAINT document_shares_password_check CHECK (((password_protected = false) OR ((password_protected = true) AND (access_password IS NOT NULL))))
);

-- Indexes for file_uploads (if they don't exist)
CREATE INDEX IF NOT EXISTS file_uploads_bucket_name_idx ON public.file_uploads USING btree (bucket_name);
CREATE INDEX IF NOT EXISTS file_uploads_file_type_idx ON public.file_uploads USING btree (file_type);
CREATE INDEX IF NOT EXISTS file_uploads_organization_id_idx ON public.file_uploads USING btree (organization_id);
CREATE INDEX IF NOT EXISTS file_uploads_user_id_idx ON public.file_uploads USING btree (user_id);

-- Indexes for document_shares (if they don't exist)
CREATE INDEX IF NOT EXISTS document_shares_expires_at_idx ON public.document_shares USING btree (expires_at);
CREATE INDEX IF NOT EXISTS document_shares_file_upload_id_idx ON public.document_shares USING btree (file_upload_id);
CREATE INDEX IF NOT EXISTS document_shares_is_active_idx ON public.document_shares USING btree (is_active);
CREATE INDEX IF NOT EXISTS document_shares_owner_id_idx ON public.document_shares USING btree (owner_id);
CREATE INDEX IF NOT EXISTS document_shares_shared_with_id_idx ON public.document_shares USING btree (shared_with_id);

-- Enable RLS on file_uploads (if not already enabled)
ALTER TABLE public.file_uploads ENABLE ROW LEVEL SECURITY;

-- RLS policies for file_uploads
DROP POLICY IF EXISTS "Users can view their own files" ON public.file_uploads;
CREATE POLICY "Users can view their own files" ON public.file_uploads
FOR SELECT USING (user_id = auth.uid());

DROP POLICY IF EXISTS "Users can upload their own files" ON public.file_uploads;
CREATE POLICY "Users can upload their own files" ON public.file_uploads
FOR INSERT WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "Users can update their own files" ON public.file_uploads;
CREATE POLICY "Users can update their own files" ON public.file_uploads
FOR UPDATE USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "Users can delete their own files" ON public.file_uploads;
CREATE POLICY "Users can delete their own files" ON public.file_uploads
FOR DELETE USING (user_id = auth.uid());

DROP POLICY IF EXISTS "Organization members can view organization files" ON public.file_uploads;
CREATE POLICY "Organization members can view organization files" ON public.file_uploads
FOR SELECT USING (organization_id IN ( SELECT profiles.organization_id FROM public.profiles WHERE ((profiles.id = auth.uid()) AND (profiles.organization_id IS NOT NULL))));

DROP POLICY IF EXISTS "Organization members can manage organization files" ON public.file_uploads;
CREATE POLICY "Organization members can manage organization files" ON public.file_uploads
FOR ALL USING (organization_id IN ( SELECT profiles.organization_id FROM public.profiles WHERE ((profiles.id = auth.uid()) AND (profiles.organization_id IS NOT NULL)))) WITH CHECK (organization_id IN ( SELECT profiles.organization_id FROM public.profiles WHERE ((profiles.id = auth.uid()) AND (profiles.organization_id IS NOT NULL))));

-- Enable RLS on document_shares (if not already enabled)
ALTER TABLE public.document_shares ENABLE ROW LEVEL SECURITY;

-- RLS policies for document_shares
DROP POLICY IF EXISTS "Users can manage documents they own" ON public.document_shares;
CREATE POLICY "Users can manage documents they own" ON public.document_shares
FOR ALL USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());

DROP POLICY IF EXISTS "Users can view documents shared with them" ON public.document_shares;
CREATE POLICY "Users can view documents shared with them" ON public.document_shares
FOR SELECT USING ((shared_with_id = auth.uid()) OR (owner_id = auth.uid()));

-- Triggers for updated_at columns
DROP TRIGGER IF EXISTS update_file_uploads_updated_at ON public.file_uploads;
CREATE TRIGGER update_file_uploads_updated_at BEFORE UPDATE ON public.file_uploads FOR EACH ROW EXECUTE FUNCTION update_file_uploads_updated_at();