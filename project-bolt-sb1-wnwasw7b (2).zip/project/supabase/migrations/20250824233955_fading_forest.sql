/*
  # Create recruiter bids and consent tables

  1. New Tables
    - `recruiter_bids`
      - `id` (uuid, primary key)
      - `job_id` (uuid, foreign key to jobs)
      - `recruiter_id` (uuid, foreign key to profiles)
      - `candidate_stub` (jsonb, anonymized candidate info)
      - `fee_type` (enum: flat, percent)
      - `fee_value` (numeric)
      - `guarantee_days` (integer)
      - `status` (enum: submitted, accepted, rejected, withdrawn, expired)
      - `revealed_candidate` (jsonb, full candidate info after acceptance)
      - `created_at`, `updated_at` (timestamps)
    
    - `consent_requests`
      - `id` (uuid, primary key)
      - `candidate_id` (uuid, foreign key to profiles)
      - `recruiter_id` (uuid, foreign key to profiles)
      - `job_id` (uuid, foreign key to jobs)
      - `status` (enum: requested, approved, declined, revoked)
      - `message` (text, optional recruiter message)
      - `requested_at`, `responded_at` (timestamps)

  2. Security
    - Enable RLS on both tables
    - Add policies for recruiters, employers, and candidates
*/

-- Create enums
CREATE TYPE bid_fee_type AS ENUM ('flat', 'percent');
CREATE TYPE bid_status AS ENUM ('submitted', 'accepted', 'rejected', 'withdrawn', 'expired');
CREATE TYPE consent_status AS ENUM ('requested', 'approved', 'declined', 'revoked');

-- Create recruiter_bids table
CREATE TABLE IF NOT EXISTS recruiter_bids (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  recruiter_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  candidate_stub jsonb NOT NULL,
  fee_type bid_fee_type NOT NULL,
  fee_value numeric NOT NULL CHECK (fee_value > 0),
  guarantee_days integer NOT NULL DEFAULT 90 CHECK (guarantee_days >= 30),
  status bid_status NOT NULL DEFAULT 'submitted',
  revealed_candidate jsonb,
  accepted_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create consent_requests table
CREATE TABLE IF NOT EXISTS consent_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  recruiter_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  status consent_status NOT NULL DEFAULT 'requested',
  message text,
  requested_at timestamptz DEFAULT now(),
  responded_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  -- Ensure one consent request per candidate-job pair
  UNIQUE(candidate_id, job_id)
);

-- Add indexes
CREATE INDEX recruiter_bids_job_id_idx ON recruiter_bids(job_id);
CREATE INDEX recruiter_bids_recruiter_id_idx ON recruiter_bids(recruiter_id);
CREATE INDEX recruiter_bids_status_idx ON recruiter_bids(status);
CREATE INDEX consent_requests_candidate_id_idx ON consent_requests(candidate_id);
CREATE INDEX consent_requests_recruiter_id_idx ON consent_requests(recruiter_id);
CREATE INDEX consent_requests_job_id_idx ON consent_requests(job_id);
CREATE INDEX consent_requests_status_idx ON consent_requests(status);

-- Add updated_at triggers
CREATE TRIGGER update_recruiter_bids_updated_at
  BEFORE UPDATE ON recruiter_bids
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_consent_requests_updated_at
  BEFORE UPDATE ON consent_requests
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE recruiter_bids ENABLE ROW LEVEL SECURITY;
ALTER TABLE consent_requests ENABLE ROW LEVEL SECURITY;

-- RLS Policies for recruiter_bids

-- Recruiters can create and view their own bids
CREATE POLICY "Recruiters can manage their own bids"
  ON recruiter_bids
  FOR ALL
  TO authenticated
  USING (recruiter_id = auth.uid())
  WITH CHECK (recruiter_id = auth.uid());

-- Employers can view bids for their jobs
CREATE POLICY "Employers can view bids for their jobs"
  ON recruiter_bids
  FOR SELECT
  TO authenticated
  USING (
    job_id IN (
      SELECT j.id FROM jobs j
      JOIN profiles p ON p.organization_id = j.organization_id
      WHERE p.id = auth.uid() AND p.role = 'employer'
    )
  );

-- Employers can update bid status for their jobs
CREATE POLICY "Employers can update bid status for their jobs"
  ON recruiter_bids
  FOR UPDATE
  TO authenticated
  USING (
    job_id IN (
      SELECT j.id FROM jobs j
      JOIN profiles p ON p.organization_id = j.organization_id
      WHERE p.id = auth.uid() AND p.role = 'employer'
    )
  )
  WITH CHECK (
    job_id IN (
      SELECT j.id FROM jobs j
      JOIN profiles p ON p.organization_id = j.organization_id
      WHERE p.id = auth.uid() AND p.role = 'employer'
    )
  );

-- RLS Policies for consent_requests

-- Candidates can view and manage their consent requests
CREATE POLICY "Candidates can manage their consent requests"
  ON consent_requests
  FOR ALL
  TO authenticated
  USING (candidate_id = auth.uid())
  WITH CHECK (candidate_id = auth.uid());

-- Recruiters can create and view their consent requests
CREATE POLICY "Recruiters can manage their consent requests"
  ON consent_requests
  FOR ALL
  TO authenticated
  USING (recruiter_id = auth.uid())
  WITH CHECK (recruiter_id = auth.uid());

-- Employers can view consent requests for their jobs
CREATE POLICY "Employers can view consent requests for their jobs"
  ON consent_requests
  FOR SELECT
  TO authenticated
  USING (
    job_id IN (
      SELECT j.id FROM jobs j
      JOIN profiles p ON p.organization_id = j.organization_id
      WHERE p.id = auth.uid() AND p.role = 'employer'
    )
  );