/*
  # Add recruiter_bid_id to applications table

  1. Schema Changes
    - Add `recruiter_bid_id` column to applications table
      - uuid, nullable, foreign key to recruiter_bids(id)
      - Links applications that were created from accepted recruiter bids
    - Add composite index on (job_id, recruiter_bid_id) for performance
    - Add check constraint to ensure recruiter-sourced apps have valid bid references

  2. Data Integrity
    - Applications from direct candidates will have null recruiter_bid_id
    - Applications from accepted bids will have the bid ID stored
    - Cascading delete: if a bid is deleted, the application remains but bid_id nullified

  3. Security
    - Update RLS policies to allow recruiters to view applications they created via bids
    - Maintain existing employer access to all job applications

  4. Notes
    - This fixes the issue where applications created from accepted bids
      were not properly linked back to their source bid
    - Enables tracking and analytics on recruiter-sourced vs direct applications
*/

-- Add recruiter_bid_id column to applications table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'applications' AND column_name = 'recruiter_bid_id'
  ) THEN
    ALTER TABLE applications
    ADD COLUMN recruiter_bid_id uuid REFERENCES recruiter_bids(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Add composite index for optimized queries filtering by job and bid
CREATE INDEX IF NOT EXISTS applications_job_bid_idx
  ON applications(job_id, recruiter_bid_id)
  WHERE recruiter_bid_id IS NOT NULL;

-- Add index on recruiter_bid_id for reverse lookups
CREATE INDEX IF NOT EXISTS applications_recruiter_bid_id_idx
  ON applications(recruiter_bid_id)
  WHERE recruiter_bid_id IS NOT NULL;

-- Add check constraint: recruiter-sourced applications should ideally have a bid reference
-- Note: This is a soft constraint - we allow null for backwards compatibility
-- but new recruiter-sourced applications should include the bid_id
ALTER TABLE applications DROP CONSTRAINT IF EXISTS applications_recruiter_source_check;
ALTER TABLE applications
  ADD CONSTRAINT applications_recruiter_source_check
  CHECK (
    (source = 'direct' AND recruiter_bid_id IS NULL) OR
    (source = 'recruiter')
  );

-- Add RLS policy for recruiters to view applications they created via bids
CREATE POLICY "Recruiters can view applications from their accepted bids"
  ON applications
  FOR SELECT
  TO authenticated
  USING (
    recruiter_bid_id IN (
      SELECT rb.id
      FROM recruiter_bids rb
      WHERE rb.recruiter_id = auth.uid() AND rb.status = 'accepted'
    )
  );

-- Create a trigger to automatically update the bid status when application is created
CREATE OR REPLACE FUNCTION update_bid_on_application_create()
RETURNS TRIGGER AS $$
BEGIN
  -- If this application was created from a bid, mark additional metadata
  IF NEW.recruiter_bid_id IS NOT NULL THEN
    UPDATE recruiter_bids
    SET updated_at = now()
    WHERE id = NEW.recruiter_bid_id;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER applications_from_bids_trigger
  AFTER INSERT ON applications
  FOR EACH ROW
  WHEN (NEW.recruiter_bid_id IS NOT NULL)
  EXECUTE FUNCTION update_bid_on_application_create();
