/*
  # Ensure Escrow Transactions Has Billing Account Column

  1. Changes
    - Add billing_account_id column to escrow_transactions if it doesn't exist
    - Ensure proper foreign key constraint to billing_accounts table
    - Verify RLS policies work with this column

  2. Security
    - Maintain existing RLS policies
    - Column is nullable to support both old and new data models

  3. Notes
    - This ensures compatibility between different schema versions
    - Existing data is not affected
*/

-- Add billing_account_id column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
    AND table_name = 'escrow_transactions'
    AND column_name = 'billing_account_id'
  ) THEN
    ALTER TABLE public.escrow_transactions
    ADD COLUMN billing_account_id uuid REFERENCES public.billing_accounts(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Add indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_escrow_transactions_billing_account
  ON public.escrow_transactions(billing_account_id);

CREATE INDEX IF NOT EXISTS idx_escrow_transactions_recruiter_bid
  ON public.escrow_transactions(recruiter_bid_id);

CREATE INDEX IF NOT EXISTS idx_escrow_transactions_status
  ON public.escrow_transactions(status);
