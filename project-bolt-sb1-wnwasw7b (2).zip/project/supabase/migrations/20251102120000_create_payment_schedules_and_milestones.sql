/*
  # Payment Schedules and Milestone System

  1. New Tables
    - `payment_schedules` - Defines payment milestone templates for recruiter bids
      - `id` (uuid, primary key)
      - `name` (text) - Template name (e.g., "Standard 3-Milestone", "Quick 2-Payment")
      - `description` (text) - Description of the payment schedule
      - `milestones` (jsonb) - Array of milestone definitions with percentages and triggers
      - `is_active` (boolean) - Whether this template is available
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `scheduled_payments` - Tracks individual milestone payments for bids
      - `id` (uuid, primary key)
      - `recruiter_bid_id` (uuid, foreign key to recruiter_bids)
      - `escrow_transaction_id` (uuid, foreign key to escrow_transactions)
      - `milestone_name` (text) - Name of milestone (e.g., "Interview Scheduled", "Candidate Hired")
      - `milestone_trigger` (text) - Event that triggers payment release
      - `amount` (integer) - Amount in cents
      - `percentage` (numeric) - Percentage of total fee
      - `status` (enum) - pending, triggered, released, failed
      - `trigger_date` (timestamptz) - When milestone was triggered
      - `release_date` (timestamptz) - When payment was released
      - `sequence_order` (integer) - Order of milestone in schedule
      - `notes` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `candidate_selections` - Tracks final hiring decisions
      - `id` (uuid, primary key)
      - `job_id` (uuid, foreign key to jobs)
      - `application_id` (uuid, foreign key to applications)
      - `recruiter_bid_id` (uuid, foreign key to recruiter_bids, nullable)
      - `selected_by` (uuid, foreign key to profiles)
      - `offer_extended_date` (timestamptz)
      - `start_date` (timestamptz)
      - `onboarding_status` (enum) - offer_extended, offer_accepted, onboarding, active, completed
      - `onboarding_notes` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Schema Changes
    - Add `milestone_payments` jsonb field to recruiter_bids
    - Add `payment_schedule_id` uuid field to recruiter_bids
    - Add `next_steps` jsonb field to applications
    - Add `next_steps` jsonb field to recruiter_bids
    - Add `onboarding_status` text field to applications

  3. Security
    - Enable RLS on all new tables
    - Organization-based access policies
    - Recruiter and employer visibility controls
*/

-- Create enums
DO $$ BEGIN
  CREATE TYPE scheduled_payment_status AS ENUM ('pending', 'triggered', 'released', 'failed');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE onboarding_status_type AS ENUM ('offer_extended', 'offer_accepted', 'onboarding', 'active', 'completed');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- Create payment_schedules table
CREATE TABLE IF NOT EXISTS payment_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  milestones jsonb NOT NULL DEFAULT '[]',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create scheduled_payments table
CREATE TABLE IF NOT EXISTS scheduled_payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recruiter_bid_id uuid NOT NULL REFERENCES recruiter_bids(id) ON DELETE CASCADE,
  escrow_transaction_id uuid REFERENCES escrow_transactions(id) ON DELETE SET NULL,
  milestone_name text NOT NULL,
  milestone_trigger text NOT NULL,
  amount integer NOT NULL CHECK (amount >= 0),
  percentage numeric NOT NULL CHECK (percentage >= 0 AND percentage <= 100),
  status scheduled_payment_status DEFAULT 'pending',
  trigger_date timestamptz,
  release_date timestamptz,
  sequence_order integer NOT NULL DEFAULT 1,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create candidate_selections table
CREATE TABLE IF NOT EXISTS candidate_selections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  application_id uuid NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
  recruiter_bid_id uuid REFERENCES recruiter_bids(id) ON DELETE SET NULL,
  selected_by uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  offer_extended_date timestamptz,
  start_date timestamptz,
  onboarding_status onboarding_status_type DEFAULT 'offer_extended',
  onboarding_notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(job_id)
);

-- Add new columns to recruiter_bids
DO $$ BEGIN
  ALTER TABLE recruiter_bids ADD COLUMN IF NOT EXISTS milestone_payments jsonb DEFAULT '[]';
  ALTER TABLE recruiter_bids ADD COLUMN IF NOT EXISTS payment_schedule_id uuid REFERENCES payment_schedules(id) ON DELETE SET NULL;
  ALTER TABLE recruiter_bids ADD COLUMN IF NOT EXISTS next_steps jsonb DEFAULT '[]';
EXCEPTION
  WHEN duplicate_column THEN null;
END $$;

-- Add new columns to applications
DO $$ BEGIN
  ALTER TABLE applications ADD COLUMN IF NOT EXISTS next_steps jsonb DEFAULT '[]';
  ALTER TABLE applications ADD COLUMN IF NOT EXISTS onboarding_status text;
EXCEPTION
  WHEN duplicate_column THEN null;
END $$;

-- Add new columns to escrow_transactions
DO $$ BEGIN
  ALTER TABLE escrow_transactions ADD COLUMN IF NOT EXISTS job_id uuid REFERENCES jobs(id) ON DELETE SET NULL;
  ALTER TABLE escrow_transactions ADD COLUMN IF NOT EXISTS employer_org_id uuid REFERENCES organizations(id) ON DELETE SET NULL;
  ALTER TABLE escrow_transactions ADD COLUMN IF NOT EXISTS recruiter_id uuid REFERENCES profiles(id) ON DELETE SET NULL;
  ALTER TABLE escrow_transactions ADD COLUMN IF NOT EXISTS fee_type text;
  ALTER TABLE escrow_transactions ADD COLUMN IF NOT EXISTS fee_value numeric;
EXCEPTION
  WHEN duplicate_column THEN null;
END $$;

-- Create indexes
CREATE INDEX IF NOT EXISTS scheduled_payments_recruiter_bid_id_idx ON scheduled_payments(recruiter_bid_id);
CREATE INDEX IF NOT EXISTS scheduled_payments_status_idx ON scheduled_payments(status);
CREATE INDEX IF NOT EXISTS scheduled_payments_trigger_date_idx ON scheduled_payments(trigger_date);
CREATE INDEX IF NOT EXISTS candidate_selections_job_id_idx ON candidate_selections(job_id);
CREATE INDEX IF NOT EXISTS candidate_selections_application_id_idx ON candidate_selections(application_id);
CREATE INDEX IF NOT EXISTS candidate_selections_recruiter_bid_id_idx ON candidate_selections(recruiter_bid_id);

-- Enable RLS
ALTER TABLE payment_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE scheduled_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE candidate_selections ENABLE ROW LEVEL SECURITY;

-- RLS Policies for payment_schedules (public read for active templates)
CREATE POLICY "Anyone can view active payment schedules"
  ON payment_schedules
  FOR SELECT
  TO authenticated
  USING (is_active = true);

CREATE POLICY "Admins can manage payment schedules"
  ON payment_schedules
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));

-- RLS Policies for scheduled_payments
CREATE POLICY "Recruiters can view their scheduled payments"
  ON scheduled_payments
  FOR SELECT
  TO authenticated
  USING (recruiter_bid_id IN (
    SELECT rb.id FROM recruiter_bids rb
    WHERE rb.recruiter_id = auth.uid()
  ));

CREATE POLICY "Employers can view scheduled payments for their jobs"
  ON scheduled_payments
  FOR SELECT
  TO authenticated
  USING (recruiter_bid_id IN (
    SELECT rb.id FROM recruiter_bids rb
    JOIN jobs j ON j.id = rb.job_id
    JOIN profiles p ON p.organization_id = j.organization_id
    WHERE p.id = auth.uid() AND p.role = 'employer'
  ));

CREATE POLICY "Admins can manage scheduled payments"
  ON scheduled_payments
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));

-- RLS Policies for candidate_selections
CREATE POLICY "Employers can manage candidate selections for their jobs"
  ON candidate_selections
  FOR ALL
  TO authenticated
  USING (job_id IN (
    SELECT j.id FROM jobs j
    JOIN profiles p ON p.organization_id = j.organization_id
    WHERE p.id = auth.uid() AND p.role = 'employer'
  ))
  WITH CHECK (job_id IN (
    SELECT j.id FROM jobs j
    JOIN profiles p ON p.organization_id = j.organization_id
    WHERE p.id = auth.uid() AND p.role = 'employer'
  ));

CREATE POLICY "Candidates can view their selection status"
  ON candidate_selections
  FOR SELECT
  TO authenticated
  USING (application_id IN (
    SELECT a.id FROM applications a
    WHERE a.candidate_id = auth.uid()
  ));

CREATE POLICY "Recruiters can view selections for their bids"
  ON candidate_selections
  FOR SELECT
  TO authenticated
  USING (recruiter_bid_id IN (
    SELECT rb.id FROM recruiter_bids rb
    WHERE rb.recruiter_id = auth.uid()
  ));

CREATE POLICY "Admins can manage all candidate selections"
  ON candidate_selections
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));

-- Update triggers
CREATE TRIGGER update_payment_schedules_updated_at
  BEFORE UPDATE ON payment_schedules
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_scheduled_payments_updated_at
  BEFORE UPDATE ON scheduled_payments
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_candidate_selections_updated_at
  BEFORE UPDATE ON candidate_selections
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert default payment schedule templates
INSERT INTO payment_schedules (name, description, milestones, is_active) VALUES
  (
    'Standard 3-Milestone',
    'Payment split across three key milestones: interview, hire, and probation completion',
    '[
      {"name": "Interview Scheduled", "trigger": "interview_scheduled", "percentage": 20, "description": "Released when interview is scheduled with candidate"},
      {"name": "Candidate Hired", "trigger": "candidate_hired", "percentage": 50, "description": "Released when candidate accepts offer and starts"},
      {"name": "Probation Completed", "trigger": "probation_completed", "percentage": 30, "description": "Released after 90 days of successful employment"}
    ]'::jsonb,
    true
  ),
  (
    'Quick 2-Payment',
    'Faster payment schedule with two milestones: hire and probation',
    '[
      {"name": "Candidate Hired", "trigger": "candidate_hired", "percentage": 70, "description": "Released when candidate accepts offer and starts"},
      {"name": "Probation Completed", "trigger": "probation_completed", "percentage": 30, "description": "Released after 90 days of successful employment"}
    ]'::jsonb,
    true
  ),
  (
    'Interview Only',
    'Single payment released when interview is successfully scheduled',
    '[
      {"name": "Interview Scheduled", "trigger": "interview_scheduled", "percentage": 100, "description": "Full payment released when interview is scheduled"}
    ]'::jsonb,
    true
  ),
  (
    'Hire Only',
    'Single payment released when candidate is hired',
    '[
      {"name": "Candidate Hired", "trigger": "candidate_hired", "percentage": 100, "description": "Full payment released when candidate accepts offer and starts"}
    ]'::jsonb,
    true
  )
ON CONFLICT DO NOTHING;

-- Add notification types for payment milestones
DO $$ BEGIN
  ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'payment_milestone_triggered';
  ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'payment_released';
  ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'escrow_payment_received';
  ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'candidate_selected';
  ALTER TYPE notification_type ADD VALUE IF NOT EXISTS 'offer_extended';
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;
