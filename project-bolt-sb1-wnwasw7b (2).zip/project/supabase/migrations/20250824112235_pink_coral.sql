/*
  # Fix organization creation RLS policies

  1. Security Changes
    - Drop existing restrictive policies that prevent organization creation during signup
    - Add permissive policy to allow authenticated users to create organizations
    - Maintain security for read/update operations
*/

-- Drop existing policies that might be blocking inserts
DROP POLICY IF EXISTS "Allow authenticated users to create organizations" ON organizations;
DROP POLICY IF EXISTS "Allow organization members to update organization" ON organizations;
DROP POLICY IF EXISTS "Allow users to read organizations they belong to" ON organizations;
DROP POLICY IF EXISTS "Organization members can view organization" ON organizations;

-- Create new policies that allow organization creation during signup
CREATE POLICY "Enable insert for authenticated users" ON organizations
  FOR INSERT TO authenticated
  WITH CHECK (true);

CREATE POLICY "Enable read for organization members" ON organizations
  FOR SELECT TO authenticated
  USING (
    id IN (
      SELECT organization_id 
      FROM profiles 
      WHERE id = auth.uid() AND organization_id IS NOT NULL
    )
  );

CREATE POLICY "Enable update for organization members" ON organizations
  FOR UPDATE TO authenticated
  USING (
    id IN (
      SELECT organization_id 
      FROM profiles 
      WHERE id = auth.uid() AND organization_id IS NOT NULL
    )
  )
  WITH CHECK (
    id IN (
      SELECT organization_id 
      FROM profiles 
      WHERE id = auth.uid() AND organization_id IS NOT NULL
    )
  );