/*
  # Payment & Billing System

  1. New Tables
    - `billing_accounts` - Organization billing information
    - `payment_methods` - Stored payment methods
    - `invoices` - Invoice tracking
    - `invoice_items` - Line items for invoices
    - `payments` - Payment transaction records
    - `subscriptions` - Recurring subscription management
    - `escrow_transactions` - Recruiter success fee escrow

  2. Security
    - Enable RLS on all billing tables
    - Organization-based access policies
    - Admin access for platform management

  3. Enums
    - Payment status types
    - Invoice status types
    - Subscription status types
*/

-- Create enums for billing
CREATE TYPE payment_status AS ENUM ('pending', 'processing', 'succeeded', 'failed', 'canceled', 'refunded');
CREATE TYPE invoice_status AS ENUM ('draft', 'open', 'paid', 'void', 'uncollectible');
CREATE TYPE subscription_status AS ENUM ('active', 'canceled', 'incomplete', 'incomplete_expired', 'past_due', 'trialing', 'unpaid');
CREATE TYPE escrow_status AS ENUM ('pending', 'held', 'released', 'refunded', 'disputed');

-- Billing accounts table
CREATE TABLE IF NOT EXISTS billing_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid REFERENCES organizations(id) ON DELETE CASCADE,
  stripe_customer_id text UNIQUE,
  billing_email text,
  company_name text,
  tax_id text,
  billing_address jsonb DEFAULT '{}',
  payment_method_id text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Payment methods table
CREATE TABLE IF NOT EXISTS payment_methods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  billing_account_id uuid REFERENCES billing_accounts(id) ON DELETE CASCADE,
  stripe_payment_method_id text UNIQUE NOT NULL,
  type text NOT NULL,
  card_brand text,
  card_last4 text,
  card_exp_month integer,
  card_exp_year integer,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Invoices table
CREATE TABLE IF NOT EXISTS invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  billing_account_id uuid REFERENCES billing_accounts(id) ON DELETE CASCADE,
  stripe_invoice_id text UNIQUE,
  invoice_number text UNIQUE,
  status invoice_status DEFAULT 'draft',
  amount_due integer NOT NULL DEFAULT 0,
  amount_paid integer DEFAULT 0,
  currency text DEFAULT 'usd',
  description text,
  due_date timestamptz,
  paid_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Invoice items table
CREATE TABLE IF NOT EXISTS invoice_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid REFERENCES invoices(id) ON DELETE CASCADE,
  description text NOT NULL,
  quantity integer DEFAULT 1,
  unit_amount integer NOT NULL,
  total_amount integer NOT NULL,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Payments table
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  billing_account_id uuid REFERENCES billing_accounts(id) ON DELETE CASCADE,
  invoice_id uuid REFERENCES invoices(id) ON DELETE SET NULL,
  stripe_payment_intent_id text UNIQUE,
  amount integer NOT NULL,
  currency text DEFAULT 'usd',
  status payment_status DEFAULT 'pending',
  payment_method_id text,
  description text,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Subscriptions table
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  billing_account_id uuid REFERENCES billing_accounts(id) ON DELETE CASCADE,
  stripe_subscription_id text UNIQUE,
  status subscription_status DEFAULT 'active',
  plan_name text NOT NULL,
  plan_amount integer NOT NULL,
  currency text DEFAULT 'usd',
  billing_cycle text DEFAULT 'monthly',
  current_period_start timestamptz,
  current_period_end timestamptz,
  trial_end timestamptz,
  canceled_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Escrow transactions table
CREATE TABLE IF NOT EXISTS escrow_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recruiter_bid_id uuid REFERENCES recruiter_bids(id) ON DELETE CASCADE,
  billing_account_id uuid REFERENCES billing_accounts(id) ON DELETE CASCADE,
  stripe_payment_intent_id text UNIQUE,
  amount integer NOT NULL,
  platform_fee integer NOT NULL,
  recruiter_fee integer NOT NULL,
  currency text DEFAULT 'usd',
  status escrow_status DEFAULT 'pending',
  held_until timestamptz,
  released_at timestamptz,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE billing_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_methods ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoice_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE escrow_transactions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for billing_accounts
CREATE POLICY "Organization members can manage billing accounts"
  ON billing_accounts
  FOR ALL
  TO authenticated
  USING (organization_id IN (
    SELECT profiles.organization_id 
    FROM profiles 
    WHERE profiles.id = auth.uid() AND profiles.organization_id IS NOT NULL
  ))
  WITH CHECK (organization_id IN (
    SELECT profiles.organization_id 
    FROM profiles 
    WHERE profiles.id = auth.uid() AND profiles.organization_id IS NOT NULL
  ));

-- RLS Policies for payment_methods
CREATE POLICY "Organization members can manage payment methods"
  ON payment_methods
  FOR ALL
  TO authenticated
  USING (billing_account_id IN (
    SELECT ba.id FROM billing_accounts ba
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ))
  WITH CHECK (billing_account_id IN (
    SELECT ba.id FROM billing_accounts ba
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ));

-- RLS Policies for invoices
CREATE POLICY "Organization members can view invoices"
  ON invoices
  FOR SELECT
  TO authenticated
  USING (billing_account_id IN (
    SELECT ba.id FROM billing_accounts ba
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ));

-- RLS Policies for invoice_items
CREATE POLICY "Organization members can view invoice items"
  ON invoice_items
  FOR SELECT
  TO authenticated
  USING (invoice_id IN (
    SELECT i.id FROM invoices i
    JOIN billing_accounts ba ON ba.id = i.billing_account_id
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ));

-- RLS Policies for payments
CREATE POLICY "Organization members can view payments"
  ON payments
  FOR SELECT
  TO authenticated
  USING (billing_account_id IN (
    SELECT ba.id FROM billing_accounts ba
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ));

-- RLS Policies for subscriptions
CREATE POLICY "Organization members can view subscriptions"
  ON subscriptions
  FOR SELECT
  TO authenticated
  USING (billing_account_id IN (
    SELECT ba.id FROM billing_accounts ba
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ));

-- RLS Policies for escrow_transactions
CREATE POLICY "Recruiters can view their escrow transactions"
  ON escrow_transactions
  FOR SELECT
  TO authenticated
  USING (recruiter_bid_id IN (
    SELECT rb.id FROM recruiter_bids rb
    WHERE rb.recruiter_id = auth.uid()
  ));

CREATE POLICY "Employers can view escrow for their jobs"
  ON escrow_transactions
  FOR SELECT
  TO authenticated
  USING (recruiter_bid_id IN (
    SELECT rb.id FROM recruiter_bids rb
    JOIN jobs j ON j.id = rb.job_id
    JOIN profiles p ON p.organization_id = j.organization_id
    WHERE p.id = auth.uid() AND p.role = 'employer'
  ));

-- Admin policies
CREATE POLICY "Admins can manage all billing data"
  ON billing_accounts
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS billing_accounts_organization_id_idx ON billing_accounts(organization_id);
CREATE INDEX IF NOT EXISTS billing_accounts_stripe_customer_id_idx ON billing_accounts(stripe_customer_id);
CREATE INDEX IF NOT EXISTS payment_methods_billing_account_id_idx ON payment_methods(billing_account_id);
CREATE INDEX IF NOT EXISTS invoices_billing_account_id_idx ON invoices(billing_account_id);
CREATE INDEX IF NOT EXISTS invoices_status_idx ON invoices(status);
CREATE INDEX IF NOT EXISTS payments_billing_account_id_idx ON payments(billing_account_id);
CREATE INDEX IF NOT EXISTS payments_status_idx ON payments(status);
CREATE INDEX IF NOT EXISTS escrow_transactions_recruiter_bid_id_idx ON escrow_transactions(recruiter_bid_id);
CREATE INDEX IF NOT EXISTS escrow_transactions_status_idx ON escrow_transactions(status);

-- Update triggers
CREATE TRIGGER update_billing_accounts_updated_at
  BEFORE UPDATE ON billing_accounts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_invoices_updated_at
  BEFORE UPDATE ON invoices
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_payments_updated_at
  BEFORE UPDATE ON payments
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_subscriptions_updated_at
  BEFORE UPDATE ON subscriptions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_escrow_transactions_updated_at
  BEFORE UPDATE ON escrow_transactions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();