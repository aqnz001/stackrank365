/*
  # Fix Subscription Amounts

  1. Purpose
    - Ensures all subscription-related amounts are stored correctly in cents
    - Fixes any amounts that were accidentally stored in dollars or multiplied incorrectly
  
  2. Changes
    - Checks subscription_plans table for amounts > 1000000 (likely incorrect)
    - Checks subscriptions table for amounts > 1000000 (likely incorrect)
    - Divides any suspiciously large amounts by 100 to correct them
  
  3. Notes
    - Standard pricing: Basic $299, Standard $599, Premium $999
    - Correct cent values: 29900, 59900, 99900
    - Incorrect values would be: 2990000, 5990000, 9990000
*/

-- Fix subscription_plans table
-- If any amount is greater than 1,000,000 cents ($10,000), it's likely been multiplied incorrectly
UPDATE subscription_plans
SET amount = amount / 100,
    updated_at = now()
WHERE amount > 1000000;

-- Fix subscriptions table
-- Same logic: amounts over $10,000 are suspicious
UPDATE subscriptions
SET plan_amount = plan_amount / 100,
    updated_at = now()
WHERE plan_amount > 1000000;

-- Also fix invoices if they have similar issues
UPDATE invoices
SET amount_due = amount_due / 100,
    amount_paid = amount_paid / 100,
    updated_at = now()
WHERE amount_due > 1000000 OR amount_paid > 1000000;

-- Fix invoice_items if needed
UPDATE invoice_items
SET unit_amount = unit_amount / 100,
    total_amount = total_amount / 100
WHERE unit_amount > 1000000 OR total_amount > 1000000;

-- Fix payments if needed
UPDATE payments
SET amount = amount / 100,
    updated_at = now()
WHERE amount > 1000000;
