/*
  # Enhanced Billing System RLS Policies

  1. Policy Updates
    - Add INSERT policies for invoices, invoice_items, and payments
    - Add UPDATE policies for invoices and payments
    - Add comprehensive admin policies for all billing tables
    - Enable organization members to create billing records

  2. Security
    - Maintains organization-level access control
    - Admins can view and manage all billing data
    - Organization members can create and manage their own billing records
*/

-- ============================================
-- INVOICES POLICIES
-- ============================================

-- Allow organization members to create invoices
DROP POLICY IF EXISTS "Organization members can create invoices" ON invoices;
CREATE POLICY "Organization members can create invoices"
  ON invoices
  FOR INSERT
  TO authenticated
  WITH CHECK (billing_account_id IN (
    SELECT ba.id FROM billing_accounts ba
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ));

-- Allow organization members to update invoices
DROP POLICY IF EXISTS "Organization members can update invoices" ON invoices;
CREATE POLICY "Organization members can update invoices"
  ON invoices
  FOR UPDATE
  TO authenticated
  USING (billing_account_id IN (
    SELECT ba.id FROM billing_accounts ba
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ))
  WITH CHECK (billing_account_id IN (
    SELECT ba.id FROM billing_accounts ba
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ));

-- Allow admins to manage all invoices
DROP POLICY IF EXISTS "Admins can manage all invoices" ON invoices;
CREATE POLICY "Admins can manage all invoices"
  ON invoices
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));

-- ============================================
-- INVOICE ITEMS POLICIES
-- ============================================

-- Allow organization members to create invoice items
DROP POLICY IF EXISTS "Organization members can create invoice items" ON invoice_items;
CREATE POLICY "Organization members can create invoice items"
  ON invoice_items
  FOR INSERT
  TO authenticated
  WITH CHECK (invoice_id IN (
    SELECT i.id FROM invoices i
    JOIN billing_accounts ba ON ba.id = i.billing_account_id
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ));

-- Allow admins to manage all invoice items
DROP POLICY IF EXISTS "Admins can manage all invoice items" ON invoice_items;
CREATE POLICY "Admins can manage all invoice items"
  ON invoice_items
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));

-- ============================================
-- PAYMENTS POLICIES
-- ============================================

-- Allow organization members to create payments
DROP POLICY IF EXISTS "Organization members can create payments" ON payments;
CREATE POLICY "Organization members can create payments"
  ON payments
  FOR INSERT
  TO authenticated
  WITH CHECK (billing_account_id IN (
    SELECT ba.id FROM billing_accounts ba
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ));

-- Allow organization members to update payments
DROP POLICY IF EXISTS "Organization members can update payments" ON payments;
CREATE POLICY "Organization members can update payments"
  ON payments
  FOR UPDATE
  TO authenticated
  USING (billing_account_id IN (
    SELECT ba.id FROM billing_accounts ba
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ))
  WITH CHECK (billing_account_id IN (
    SELECT ba.id FROM billing_accounts ba
    JOIN profiles p ON p.organization_id = ba.organization_id
    WHERE p.id = auth.uid()
  ));

-- Allow admins to manage all payments
DROP POLICY IF EXISTS "Admins can manage all payments" ON payments;
CREATE POLICY "Admins can manage all payments"
  ON payments
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));

-- ============================================
-- PAYMENT METHODS POLICIES (for completeness)
-- ============================================

-- Allow admins to manage all payment methods
DROP POLICY IF EXISTS "Admins can manage all payment methods" ON payment_methods;
CREATE POLICY "Admins can manage all payment methods"
  ON payment_methods
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
  ));
