# How to Use the Post-Interview Decision Workflow

This guide will walk you through making hiring decisions after conducting interviews with candidates.

## Step-by-Step Guide

### Step 1: Navigate to the Interviews Tab

1. Log in to your employer dashboard
2. Click on the **"Interviews"** tab in the navigation menu
3. You'll see a list of all your scheduled, completed, and upcoming interviews

### Step 2: Look for Interviews Needing Decisions

**Visual Indicators:**

- **Orange Alert Banner**: At the top of the Interviews page, you'll see an alert if you have any interviews awaiting decision
  - Example: "3 Interviews Awaiting Decision - You have completed interviews that need a hiring decision..."

- **"Decision Pending" Badge**: In the interview list, completed interviews with feedback will show an orange "Decision Pending" badge next to the date

- **Green "Make Decision" Button**: Instead of a blue "View" button, you'll see a green "Make Decision" button for interviews that need your decision

### Step 3: Review the Interview

Click on an interview (either the "View" or "Make Decision" button) to see:

- Interview details (date, time, type, location)
- Interview status
- Candidate information
- Job title

### Step 4: Complete the Interview (if not already done)

If the interview status is not "completed":

1. After conducting the interview, click **"Mark Complete"** button
2. The interview status will change to "completed"

### Step 5: Add Interview Feedback

Once the interview is marked as completed:

1. Click the **"Add Feedback"** button
2. Fill out the feedback form:
   - **Overall Rating**: Click on 1-5 stars
   - **Recommendation**: Choose from dropdown:
     - "Proceed to next round"
     - "Recommend for hire"
     - "Do not proceed"
     - "Need more information"
   - **Notes**: Write your detailed feedback about the interview
3. Click **"Submit Feedback"**

### Step 6: Make Your Decision

After adding feedback, you'll see a **"Make Decision"** button appear:

1. Click the **"Make Decision"** button (green)
2. The **Interview Decision Modal** will open

### Step 7: Review Interview Summary

The modal shows:
- Interview date and type
- Candidate name and position
- Your interview rating (1-5 stars)
- Your recommendation from feedback
- Your interview notes

### Step 8: Select Your Decision

Choose one of three options:

#### Option 1: Accept
- **What it means**: Move the candidate forward in the hiring process
- **What happens**:
  - Application status → "shortlisted"
  - Candidate gets acceptance notification
  - You can schedule additional interviews or evaluations

#### Option 2: Extend Offer
- **What it means**: Formally offer the job to the candidate
- **What happens**:
  - Application status → "hired"
  - Candidate gets job offer notification
  - Payment milestones triggered (for recruiter-sourced candidates)
  - Escrow funds begin processing

#### Option 3: Reject
- **What it means**: Do not move forward with this candidate
- **What happens**:
  - Application status → "rejected"
  - Candidate gets professional rejection notification
  - Application archived

### Step 9: Add Decision Notes

**Required**: You must provide decision notes explaining your reasoning.

**Examples:**

For **Accept**:
```
Candidate demonstrated strong problem-solving skills and has relevant
experience with React and TypeScript. Good cultural fit with the team.
Recommend proceeding to final interview with CTO.
```

For **Extend Offer**:
```
Excellent candidate. Offering Senior Engineer position at $95,000
annual salary, start date January 15, 2025. Benefits include health
insurance, 401k match, and 3 weeks PTO. HR sending formal offer letter.
```

For **Reject**:
```
While candidate showed enthusiasm, they lack the required 5+ years
experience with distributed systems. Technical assessment revealed gaps
in microservices knowledge. Better suited for mid-level position.
```

### Step 10: Review and Confirm

Before submitting:

1. Review the impact statement shown in the yellow alert box
2. Verify your decision and notes are correct
3. Click **"Confirm Decision"**

### Step 11: Decision Recorded

After confirmation:
- Success message appears
- Modal closes automatically
- Interview is updated
- Candidate receives notification
- Application status is updated

## Finding Your Decisions

### View Decision History

**In Applications Tab:**
1. Go to **Applications** tab
2. Filter by status (shortlisted, rejected, hired)
3. Click on any application to view:
   - Decision made
   - Decision notes
   - Who made the decision
   - When it was made

**In Interviews Tab:**
- Interviews with decisions made will no longer show the "Make Decision" button
- The "Decision Pending" badge will be removed

## Troubleshooting

### I don't see the "Make Decision" button

**Checklist:**
- [ ] Is the interview status "completed"?
- [ ] Have you added interview feedback?
- [ ] Did you fill in the rating and recommendation?
- [ ] Try refreshing the page

**How to check:**
1. Open the interview details
2. Look for the interview status at the top
3. Check if there's an "Add Feedback" button (if yes, feedback is missing)
4. If you see "Mark Complete" button, the interview isn't completed yet

### The decision didn't save

**Possible causes:**
- Decision notes were empty
- Internet connection interrupted
- Session expired

**Solution:**
1. Refresh the page
2. Log out and log back in
3. Try making the decision again
4. Ensure your notes are filled in

### Candidate didn't receive notification

**Check:**
1. Verify candidate's email in their profile
2. Ask candidate to check spam/junk folder
3. Check notification appears in their dashboard
4. Contact platform support if issue persists

## Best Practices

### Timing
- Make decisions within 2-3 business days of completing the interview
- Don't leave candidates waiting unnecessarily
- Set a reminder if you need time to think

### Documentation
- Be specific in your decision notes
- Document both positives and concerns
- These notes are part of your hiring record
- May be needed for legal/compliance purposes

### Communication
- Remember candidates will be notified automatically
- Your rejection notes should be professional and constructive
- Acceptance notes should include next steps

### Decision Quality
- Review the interview feedback before deciding
- Consider the recommendation you made during feedback
- Discuss with other team members if uncertain
- Use "Need more information" if you need another interview

## Quick Reference

| Interview Status | Actions Available |
|-----------------|-------------------|
| Scheduled | Confirm, Cancel, Reschedule |
| Confirmed | Mark Complete, Cancel |
| Completed (no feedback) | Add Feedback |
| Completed (with feedback) | **Make Decision** |
| Decision Made | View only |

| Decision Type | Application Status | Notification Sent |
|--------------|-------------------|-------------------|
| Accept | Shortlisted | Yes - Acceptance |
| Extend Offer | Hired | Yes - Job Offer |
| Reject | Rejected | Yes - Professional Rejection |

## Need Help?

- Check the main documentation: `POST_INTERVIEW_DECISION_WORKFLOW.md`
- Contact your platform administrator
- Submit a support ticket
- Review the FAQ section

---

**Remember**: Your hiring decisions are tracked for audit and compliance purposes. Always provide clear, professional documentation of your reasoning.
