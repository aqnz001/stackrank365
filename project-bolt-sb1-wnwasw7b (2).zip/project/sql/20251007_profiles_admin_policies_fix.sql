-- Replace recursive admin policies on profiles with JWT-claim based checks to avoid
-- "infinite recursion detected in policy for relation profiles".

-- Admin SELECT all profiles
drop policy if exists "admin select all" on public.profiles;
create policy "admin select all" on public.profiles
  for select
  using (coalesce(auth.jwt() ->> 'role', '') = 'admin');

-- Admin UPDATE (e.g., update kyc)
drop policy if exists "admin update kyc" on public.profiles;
create policy "admin update kyc" on public.profiles
  for update
  using (coalesce(auth.jwt() ->> 'role', '') = 'admin')
  with check (coalesce(auth.jwt() ->> 'role', '') = 'admin');

-- Optionally, keep or recreate "read own profile" and "update own profile" if missing
-- (safe defaults included here in case they aren't present)
do $$ begin
  if not exists (
    select 1 from pg_policies
    where schemaname='public' and tablename='profiles' and policyname='read own profile'
  ) then
    execute 'create policy "read own profile" on public.profiles for select using (id = auth.uid())';
  end if;
  if not exists (
    select 1 from pg_policies
    where schemaname='public' and tablename='profiles' and policyname='update own profile'
  ) then
    execute 'create policy "update own profile" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid())';
  end if;
end $$;

