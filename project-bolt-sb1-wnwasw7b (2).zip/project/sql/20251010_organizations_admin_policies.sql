-- Ensure RLS and admin visibility on organizations
alter table public.organizations enable row level security;

drop policy if exists organizations_admin_select on public.organizations;
create policy organizations_admin_select on public.organizations
  for select
  using (coalesce(auth.jwt() ->> 'role', '') = 'admin');

-- Optional: allow members to read their own organization
drop policy if exists organizations_member_select on public.organizations;
create policy organizations_member_select on public.organizations
  for select
  using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid() and p.organization_id = organizations.id
    )
  );

