-- Extend subscription_plans with audience and availability window
alter table subscription_plans
  add column if not exists audience text not null default 'employer' check (audience in ('employer','recruiter')),
  add column if not exists available_from timestamptz,
  add column if not exists available_to timestamptz;

