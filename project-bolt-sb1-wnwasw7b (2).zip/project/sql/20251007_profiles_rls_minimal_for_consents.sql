-- Allow recruiters to read minimal candidate info (name/email) only for candidates
-- they have an existing consent_requests relationship with.

drop policy if exists profiles_minimal_for_related_consents on public.profiles;
create policy profiles_minimal_for_related_consents on public.profiles
  for select
  using (
    -- Allow recruiters to read minimal info for candidates tied to their consent requests
    exists (
      select 1 from public.consent_requests cr
      where cr.candidate_id = profiles.id
        and cr.recruiter_id = auth.uid()
    )
    -- Allow admins via JWT claim (avoids recursive SELECT on profiles)
    or coalesce(auth.jwt() ->> 'role', '') = 'admin'
  );
