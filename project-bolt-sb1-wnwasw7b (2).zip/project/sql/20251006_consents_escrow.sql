-- Enable required extensions
create extension if not exists pgcrypto;

-- Consent policy templates created by recruiters
create table if not exists public.consent_policies (
  id uuid primary key default gen_random_uuid(),
  recruiter_id uuid not null references public.profiles(id) on delete cascade,
  type text not null check (type in ('terms','privacy')),
  title text not null,
  content text not null,
  is_default boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.consent_policies enable row level security;

-- RLS: recruiters manage own, admins manage all
drop policy if exists consent_policies_recruiter_select on public.consent_policies;
create policy consent_policies_recruiter_select on public.consent_policies
  for select
  using (
    recruiter_id = auth.uid()
    or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  );

drop policy if exists consent_policies_recruiter_modify on public.consent_policies;
create policy consent_policies_recruiter_modify on public.consent_policies
  for all
  using (recruiter_id = auth.uid())
  with check (recruiter_id = auth.uid());

drop policy if exists consent_policies_admin_modify on public.consent_policies;
create policy consent_policies_admin_modify on public.consent_policies
  for all
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
  with check (true);

-- Platform escrow policy (admin-managed)
create table if not exists public.escrow_policies (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  content text not null,
  is_active boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.escrow_policies enable row level security;
drop policy if exists escrow_policies_public_read on public.escrow_policies;
create policy escrow_policies_public_read on public.escrow_policies
  for select
  using (
    is_active = true
    or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  );

drop policy if exists escrow_policies_admin_modify on public.escrow_policies;
create policy escrow_policies_admin_modify on public.escrow_policies
  for all
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
  with check (true);

create table if not exists public.escrow_transactions (
  id uuid primary key default gen_random_uuid(),
  recruiter_bid_id uuid not null references public.recruiter_bids(id) on delete cascade,
  -- optional columns may be added later via alter statements below
  fee_type text not null check (fee_type in ('flat','percent')),
  fee_value numeric not null,
  amount numeric,
  currency text not null default 'USD',
  status text not null check (status in ('initiated','authorized','captured','released','refunded','disputed')) default 'initiated',
  created_by uuid not null default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Ensure expected columns exist even if table was created previously with a different shape
alter table public.escrow_transactions add column if not exists recruiter_id uuid references public.profiles(id);
alter table public.escrow_transactions add column if not exists job_id uuid references public.jobs(id);
alter table public.escrow_transactions add column if not exists employer_org_id uuid references public.organizations(id);
alter table public.escrow_transactions add column if not exists employer_org_name text;
alter table public.escrow_transactions add column if not exists recruiter_company text;
alter table public.escrow_transactions enable row level security;

-- RLS: employers see by their org, recruiters see their own, admins see all
drop policy if exists escrow_txn_recruiter_select on public.escrow_transactions;
create policy escrow_txn_recruiter_select on public.escrow_transactions
  for select
  using (recruiter_id = auth.uid());

drop policy if exists escrow_txn_employer_select on public.escrow_transactions;
create policy escrow_txn_employer_select on public.escrow_transactions
  for select
  using (
    exists (
      select 1 from public.profiles pr
      where pr.id = auth.uid() and pr.organization_id = employer_org_id and pr.role = 'employer'
    )
  );

drop policy if exists escrow_txn_admin_select on public.escrow_transactions;
create policy escrow_txn_admin_select on public.escrow_transactions
  for select
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'));

-- Inserts allowed to authenticated users; constrain via app logic and not null foreign keys
drop policy if exists escrow_txn_insert on public.escrow_transactions;
create policy escrow_txn_insert on public.escrow_transactions
  for insert
  with check (auth.uid() is not null);

-- Updates allowed for admins
drop policy if exists escrow_txn_admin_update on public.escrow_transactions;
create policy escrow_txn_admin_update on public.escrow_transactions
  for update
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin'))
  with check (true);

-- Basic trigger to keep updated_at current
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists trg_touch_updated_at_consent_policies on public.consent_policies;
create trigger trg_touch_updated_at_consent_policies
before update on public.consent_policies
for each row execute procedure public.touch_updated_at();

drop trigger if exists trg_touch_updated_at_escrow_policies on public.escrow_policies;
create trigger trg_touch_updated_at_escrow_policies
before update on public.escrow_policies
for each row execute procedure public.touch_updated_at();

drop trigger if exists trg_touch_updated_at_escrow_tx on public.escrow_transactions;
create trigger trg_touch_updated_at_escrow_tx
before update on public.escrow_transactions
for each row execute procedure public.touch_updated_at();
