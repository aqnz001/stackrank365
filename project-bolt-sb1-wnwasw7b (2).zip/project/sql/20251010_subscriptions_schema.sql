-- Idempotent subscription schema (minimal to support UI)

-- billing accounts
create table if not exists billing_accounts (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  created_at timestamp with time zone default now()
);

-- subscription plans
create table if not exists subscription_plans (
  id uuid primary key default gen_random_uuid(),
  stripe_price_id text,
  name text not null,
  description text,
  amount integer not null,
  currency text not null default 'usd',
  billing_interval text not null default 'month',
  trial_period_days integer not null default 0,
  features text[] not null default '{}',
  limits jsonb not null default '{}',
  is_active boolean not null default true,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- subscriptions
create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  billing_account_id uuid not null references billing_accounts(id) on delete cascade,
  stripe_subscription_id text,
  status text not null default 'active',
  plan_name text not null,
  plan_amount integer not null,
  currency text not null default 'usd',
  billing_interval text not null default 'month',
  quantity integer not null default 1,
  current_period_start timestamp with time zone,
  current_period_end timestamp with time zone,
  trial_end timestamp with time zone,
  canceled_at timestamp with time zone,
  metadata jsonb default '{}',
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- payment methods (optional minimal)
create table if not exists payment_methods (
  id uuid primary key default gen_random_uuid(),
  billing_account_id uuid not null references billing_accounts(id) on delete cascade,
  stripe_payment_method_id text,
  type text,
  card_brand text,
  card_last4 text,
  card_exp_month integer,
  card_exp_year integer,
  bank_name text,
  bank_last4 text,
  is_default boolean default false,
  is_verified boolean default false,
  created_at timestamp with time zone default now()
);

