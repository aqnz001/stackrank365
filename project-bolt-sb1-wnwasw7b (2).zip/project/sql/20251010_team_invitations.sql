-- Team invitations for orgs (idempotent)
create table if not exists team_invitations (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.organizations(id) on delete cascade,
  invited_by uuid not null references public.profiles(id) on delete set null,
  invitee_email text not null,
  role text not null check (role in ('employer','recruiter')),
  status text not null default 'pending' check (status in ('pending','accepted','expired','revoked')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table team_invitations enable row level security;
drop policy if exists team_invite_member on team_invitations;
create policy team_invite_member on team_invitations
  for all
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.organization_id = org_id));

