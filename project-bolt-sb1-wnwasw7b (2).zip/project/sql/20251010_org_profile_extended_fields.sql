-- Add extended organization profile fields (idempotent)
ALTER TABLE organizations
  ADD COLUMN IF NOT EXISTS contact_email text,
  ADD COLUMN IF NOT EXISTS publish_email boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS website text,
  ADD COLUMN IF NOT EXISTS about text,
  ADD COLUMN IF NOT EXISTS publish_profile boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS country text,
  ADD COLUMN IF NOT EXISTS city text,
  ADD COLUMN IF NOT EXISTS postal_code text,
  ADD COLUMN IF NOT EXISTS logo_path text;

-- Optional: make defaults explicit for booleans
UPDATE organizations SET publish_email = COALESCE(publish_email, false);
UPDATE organizations SET publish_profile = COALESCE(publish_profile, false);

