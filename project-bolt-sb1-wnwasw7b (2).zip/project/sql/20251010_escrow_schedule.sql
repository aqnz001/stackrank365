-- Extend escrow_transactions to support payout scheduling and payee
alter table public.escrow_transactions
  add column if not exists scheduled_payout_at timestamptz,
  add column if not exists payee_user_id uuid references public.profiles(id),
  add column if not exists payee_org_id uuid references public.organizations(id);

